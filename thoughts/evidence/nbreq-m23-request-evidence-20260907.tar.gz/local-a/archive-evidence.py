from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path('target/m23')
final = root / 'b'
assert (final / 'windows.exit').read_text(encoding='utf-8-sig').strip() == '0'
windows_log = (final / 'windows-verify.log').read_text(encoding='utf-8')
assert 'NBReq verification complete: all 24 steps passed' in windows_log
assert 'test backend::native_tls::tests::m23_small_borrowed_request_preserves_one_tls_record ... ok' in windows_log
assert '10 passed; 0 failed' in (final / 'windows-x86.log').read_text(encoding='utf-8')
assert '10 passed; 0 failed' in (root / 'request-final-green.log').read_text(encoding='utf-8')
assert '0 passed; 6 failed' in (root / 'request-red.log').read_text(encoding='utf-8')
assert '0 passed; 1 failed' in (root / 'tls-record-red.log').read_text(encoding='utf-8')
for host in ['linux', 'intel', 'arm']:
    folder = final / (host + '-evidence')
    assert (folder / 'run.exit').read_text().strip() == '0'
    for version in ['stable', '1.85.0']:
        text = (folder / ('verify-' + version + '.log')).read_text(encoding='utf-8')
        assert 'nbreq-m23-request-20260907-b/nbreq' in text.splitlines()[0]
        assert 'NBReq verification complete: all 24 steps passed' in text
        assert 'test backend::native_tls::tests::m23_small_borrowed_request_preserves_one_tls_record ... ok' in text
for path in [final / 'windows-comparison', final / 'linux-evidence/comparison']:
    cases = json.loads((path / 'results.json').read_text(encoding='utf-8'))
    assert len(cases) == 60 and all(c['valid'] for c in cases)
    assert all(c['joined'] and c['exit_code'] == 0 and not c['forced'] for case in cases for c in case['cleanup'])
    provenance = json.loads((path / 'provenance.json').read_text(encoding='utf-8'))
    assert provenance['sources']['before'] == '3704fc13a50678386a8189e12344f27ae084c5cdb143c1ae821877115d256302'
    assert provenance['sources']['after'] == '3a3c4ce23f6d05c94b5028cbbc75778ae44eccfaf2d1bcf2e117aa0b1131bf81'

files = {}
extensions = {'.log', '.json', '.py', '.ps1', '.sh', '.sha256', '.diff', '.rs', '.exit'}
for folder, prefix in [(root, 'local-a/'), (final, 'local-b/')]:
    for path in folder.iterdir():
        if path.is_file() and path.suffix in extensions:
            files[prefix + path.name] = path.read_bytes()
    for path in folder.glob('bridge-*.json'):
        receipts = json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(receipts, list): receipts = [receipts]
        for receipt in receipts:
            if not isinstance(receipt, dict) or not {'Root', 'Id'} <= receipt.keys():
                continue
            result = Path(receipt['Root']) / 'results' / (receipt['Id'] + '.json')
            assert result.is_file(), result
            files['receipts/' + receipt['Id'] + '.json'] = result.read_bytes()
for folder, prefix in [(root / 'windows-comparison', 'preliminary-windows/'), (final / 'windows-comparison', 'windows/')] + [(final / (host + '-evidence'), host + '/') for host in ['linux', 'intel', 'arm']]:
    for path in folder.rglob('*'):
        if path.is_file(): files[prefix + path.relative_to(folder).as_posix()] = path.read_bytes()

artifacts = {}
for revision, folder, name in [('a', root, 'nbreq-m23-request-20260907.tar.gz'), ('b', final, 'nbreq-m23-request-20260907-b.tar.gz')]:
    source = folder / name
    bundle = json.loads((folder / 'bundle.json').read_text(encoding='utf-8'))
    data = source.read_bytes()
    assert hashlib.sha256(data).hexdigest() == bundle['sha256']
    with tarfile.open(source) as archive:
        members = {member.name.removeprefix('nbreq/'): archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    manifest = members['m23-source.sha256']
    assert hashlib.sha256(manifest).hexdigest() == bundle['manifest_sha256']
    for line in manifest.decode().splitlines():
        digest, path = line.split('  ', 1)
        assert hashlib.sha256(members[path]).hexdigest() == digest
        if revision == 'b' and not path.startswith('m23-'):
            assert Path(path).read_bytes() == members[path], path
    destination = Path('thoughts/evidence') / name
    destination.write_bytes(data)
    artifacts['source_' + revision] = dict(path=destination.as_posix(), sha256=bundle['sha256'], manifest_sha256=bundle['manifest_sha256'])

manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['evidence.sha256'] = manifest
output = Path('thoughts/evidence/nbreq-m23-request-evidence-20260907.tar.gz')
with tarfile.open(output, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(output) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
assert restored == files
artifacts['evidence'] = dict(path=output.as_posix(), sha256=hashlib.sha256(output.read_bytes()).hexdigest(), files=len(files), bytes=output.stat().st_size)
artifacts.update(final_comparison_cases=120, preliminary_comparison_cases=60, final_full_verifiers=7, final_ownership_tests=10, initial_red_tests=6, additional_tls_record_red=1)
Path('thoughts/evidence/nbreq_m23_request_artifacts.json').write_bytes(json.dumps(artifacts, indent=2).encode('utf-8'))
print(json.dumps(artifacts, indent=2))
