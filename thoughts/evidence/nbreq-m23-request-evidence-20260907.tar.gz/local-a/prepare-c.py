from pathlib import Path

root = Path('target/m23')
prior = root / 'b'
out = root / 'c'
out.mkdir(exist_ok=True)
remote = (prior / 'remote.sh').read_text(encoding='utf-8').replace('nbreq-m23-request-20260907-b)', 'nbreq-m23-request-20260907-c)')
remote = remote.replace('cd "$lab/nbreq"', '''if test -d "$previous/previous-attempt"; then
    cp -R "$previous/previous-attempt" "$lab/previous-attempt/earlier-a"
fi
cd "$lab/nbreq"''')
remote = remote.replace("assert 'NBReq verification complete: all 24 steps passed' in text", "assert 'test registry::tests::shutdown_commits_stream_terminals_before_exposing_reactor_stop ... ok' in text\nassert 'NBReq verification complete: all 24 steps passed' in text")
remote = remote.replace('if test "$scope" = measure; then', '''if test "$scope" = verify-arm; then
    export RUSTUP_TOOLCHAIN=stable
    python3 - <<'PY' > "$lab/shutdown-rechecks.log" 2>&1
import subprocess
for iteration in range(30):
    subprocess.run(['cargo', 'test', '--offline', '--all-features', '--lib', 'cancel_and_shutdown_wake_blocked_upload_producers', '--', '--nocapture'], check=True)
    print('SHUTDOWN_RECHECK_PASS', iteration + 1, flush=True)
PY
fi
if test "$scope" = measure; then''')
(out / 'remote.sh').write_bytes(remote.encode('utf-8'))
collect = (prior / 'collect.py').read_text(encoding='utf-8').replace("lab.name == 'nbreq-m23-request-20260907-b'", "lab.name == 'nbreq-m23-request-20260907-c'")
collect = collect.replace("assert 'NBReq verification complete: all 24 steps passed' in text", "assert 'test registry::tests::shutdown_commits_stream_terminals_before_exposing_reactor_stop ... ok' in text\n    assert 'NBReq verification complete: all 24 steps passed' in text")
(out / 'collect.py').write_bytes(collect.encode('utf-8'))
prepare = (prior / 'prepare.py').read_text(encoding='utf-8').replace("Path('target/m23/b')", "Path('target/m23/c')").replace("'nbreq-m23-request-20260907-b.tar.gz'", "'nbreq-m23-request-20260907-c.tar.gz'")
prepare = prepare.replace("'src/backend/native_tls.rs', 'src/types.rs'", "'src/backend/native_tls.rs', 'src/registry.rs', 'src/types.rs'")
(out / 'prepare.py').write_bytes(prepare.encode('utf-8'))
windows = (prior / 'windows.ps1').read_text(encoding='utf-8').replace("'target/m23/b'", "'target/m23/c'")
windows = windows.replace('    New-Item -ItemType Directory', '''    cargo test --offline --all-features --target i686-pc-windows-msvc --lib shutdown -- --test-threads=1 *> "$m23Root/windows-x86-shutdown.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows x86 shutdown regression checks failed.' }
    New-Item -ItemType Directory''')
(out / 'windows.ps1').write_bytes(windows.encode('utf-8'))
(out / 'receive.py').write_bytes((prior / 'receive.py').read_bytes())
