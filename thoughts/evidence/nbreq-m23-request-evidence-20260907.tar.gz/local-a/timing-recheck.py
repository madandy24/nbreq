from pathlib import Path
import hashlib
import importlib.util
import json

spec = importlib.util.spec_from_file_location('m1_runner', 'tools/f5-observe/memory/run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
root = Path('target/m23/c/windows-comparison')
original = json.loads((root / 'provenance.json').read_text(encoding='utf-8'))
output = Path('target/m23/d/windows-extended-recheck')
output.mkdir(parents=True, exist_ok=False)
binaries = {}
for version in ['before', 'after']:
    identity = original['binaries'][version]['plain']
    path = Path(identity['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == identity['sha256']
    binaries[version] = path
(output / 'provenance.json').write_bytes(json.dumps(original, indent=2).encode('utf-8'))
results = []
for repetition in range(4, 9):
    for version in (['after', 'before'] if repetition % 2 == 0 else ['before', 'after']):
        name = f'{version}-https-c32-b51200-extended-plain-r{repetition}'
        binary = binaries[version]
        case = runner.run_case(binary, binary, output / name, original['sources'][version], 'https', 32, 51200, 16, True)
        assert not case['client']['instrumented']
        case.update(case=name, repetition=repetition, version=version)
        results.append(case)
        print('PASS', name, flush=True)
(output / 'results.json').write_bytes(json.dumps(results, indent=2).encode('utf-8'))
print('M23_EXTENDED_RECHECK_PASS', len(results))
