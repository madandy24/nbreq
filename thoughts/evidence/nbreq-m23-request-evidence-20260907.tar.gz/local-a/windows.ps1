$ErrorActionPreference = 'Stop'
$m23Root = Join-Path (Get-Location) 'target/m23'
$m23Exit = 1
try {
    cargo run --offline --manifest-path tools/xtask/Cargo.toml -- verify --offline *> "$m23Root/windows-verify.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows verifier failed; inspect its log.' }
    cargo test --offline --all-features --target i686-pc-windows-msvc --lib m23_ -- --test-threads=1 *> "$m23Root/windows-x86.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows x86 companions failed.' }
    New-Item -ItemType Directory -Path "$m23Root/bin" | Out-Null
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml *> "$m23Root/windows-build-plain.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows plain observer build failed.' }
    Copy-Item -LiteralPath tools/f5-observe/memory/target/release/nbreq-f5-memory.exe -Destination "$m23Root/bin/plain.exe"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter *> "$m23Root/windows-build-meter.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows meter observer build failed.' }
    Copy-Item -LiteralPath tools/f5-observe/memory/target/release/nbreq-f5-memory.exe -Destination "$m23Root/bin/meter.exe"
    $m23Bundle = Get-Content -LiteralPath "$m23Root/bundle.json" -Raw -Encoding UTF8 | ConvertFrom-Json
    & 'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 "$m23Root/compare.py" --before-plain target/m2/bin/plain.exe --before-meter target/m2/bin/meter.exe --after-plain "$m23Root/bin/plain.exe" --after-meter "$m23Root/bin/meter.exe" --output "$m23Root/windows-comparison" --source $m23Bundle.manifest_sha256 *> "$m23Root/windows-comparison.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows paired comparison failed.' }
    $m23Exit = 0
    Write-Output 'M23_WINDOWS_PASS'
} finally {
    Set-Content -LiteralPath "$m23Root/windows.exit" -Value $m23Exit -Encoding UTF8
}
