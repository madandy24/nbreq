from pathlib import Path
import base64
import hashlib
import importlib.util
import io
import json
import sys
import tarfile

lab = Path(sys.argv[1]).resolve()
assert lab.name == 'nbreq-m23-request-20260907-c'
assert (lab / 'run.exit').read_text().strip() == '0'
spec = importlib.util.spec_from_file_location('m1_runner', str(lab / 'nbreq/tools/f5-observe/memory/run.py'))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original = json.loads((lab / 'comparison/provenance.json').read_text())
output = lab / 'https-small-timing-recheck'
output.mkdir(exist_ok=False)
binaries = {}
for version in ['before', 'after']:
    identity = original['binaries'][version]['plain']
    path = Path(identity['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == identity['sha256']
    binaries[version] = path
(output / 'provenance.json').write_text(json.dumps(original, indent=2))
results = []
for repetition in range(4, 9):
    for version in (['after', 'before'] if repetition % 2 == 0 else ['before', 'after']):
        name = f'{version}-https-c32-b1024-normal-plain-r{repetition}'
        binary = binaries[version]
        case = runner.run_case(binary, binary, output / name, original['sources'][version], 'https', 32, 1024, 16, False)
        assert not case['client']['instrumented']
        case.update(case=name, repetition=repetition, version=version)
        results.append(case)
        print('PASS', name, flush=True)
(output / 'results.json').write_text(json.dumps(results, indent=2))
files = {p.relative_to(output).as_posix(): p.read_bytes() for p in output.rglob('*') if p.is_file()}
files['runner.py'] = Path(__file__).read_bytes()
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['evidence.sha256'] = manifest
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
payload = buffer.getvalue()
print('M23_TIMING_RECHECK_PASS', len(results))
print('M23_ARCHIVE_SHA256', hashlib.sha256(payload).hexdigest())
print('M23_ARCHIVE_BASE64', base64.b64encode(payload).decode())
