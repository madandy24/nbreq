from pathlib import Path
from statistics import median
import json
import sys

folder = Path(sys.argv[1])
cases = json.loads((folder / 'results.json').read_text(encoding='utf-8'))
assert len(cases) == 10 and all(c['valid'] for c in cases)
assert all(p['joined'] and p['exit_code'] == 0 and not p['forced'] for c in cases for p in c['cleanup'])
summary = dict(cases=len(cases))
for version in ['before', 'after']:
    phases = [next(p for p in c['phases'] if p['phase'] == 'steady') for c in cases if c['version'] == version]
    summary[version] = {}
    for key in ['requests_per_second', 'latency_p95_ms']:
        values = [p[key] for p in phases]
        summary[version][key] = dict(min=min(values), median=median(values), max=max(values), values=values)
(folder.parent / (folder.name + '-summary.json')).write_bytes(json.dumps(summary, indent=2).encode('utf-8'))
print(json.dumps(summary, indent=2))
