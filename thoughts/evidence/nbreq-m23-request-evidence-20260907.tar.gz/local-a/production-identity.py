from pathlib import Path
import hashlib
import json
import tarfile

def source(revision):
    folder = Path('target/m23') / revision
    bundle = json.loads((folder / 'bundle.json').read_text(encoding='utf-8'))
    path = folder / Path(bundle['path']).name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == bundle['sha256']
    with tarfile.open(path) as archive:
        files = {m.name.removeprefix('nbreq/'): archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
    return bundle, files

c, c_files = source('c')
d, d_files = source('d')
changed = sorted(name for name in c_files.keys() | d_files.keys() if not name.startswith('m23-') and c_files.get(name) != d_files.get(name))
assert changed == ['src/dns_wiring_tests.rs'], changed
assert '#[cfg(all(test, feature = "native"))]\nmod dns_wiring_tests;' in d_files['src/lib.rs'].decode().replace('\r\n', '\n')
for name, data in d_files.items():
    if not name.startswith('m23-'):
        assert Path(name).read_bytes() == data, name
result = dict(measured_revision='c', final_revision='d', measured_manifest=c['manifest_sha256'], final_manifest=d['manifest_sha256'], changed_repository_files=changed, changed_file_compiled_only_for_tests=True, all_production_and_observer_build_inputs_identical=True, final_checkout_matches=True)
Path('target/m23/d/production-identity.json').write_bytes(json.dumps(result, indent=2).encode('utf-8'))
print(json.dumps(result, indent=2))
