#!/bin/sh
set -eu
lab=$1
cache=$2
scope=$3
before=$4
case "$lab" in */nbreq-m23-request-20260907) ;; *) exit 2 ;; esac
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$cache"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export RUSTUP_TOOLCHAIN=stable
trap 'code=$?; printf "%s\n" "$code" > "$lab/run.exit"' EXIT
cd "$lab/nbreq"
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m23-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
# Clear only this package in the established NBReq test cache. Relocated archive timestamps
# can otherwise retain an old library even if unit tests rebuild. Dependency caches stay warm.
cargo clean --offline -p nbreq
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    CARGO_TARGET_DIR="$lab/runner-$toolchain" cargo build --locked --offline --manifest-path tools/xtask/Cargo.toml
    "$lab/runner-$toolchain/debug/nbreq-xtask" verify --offline > "$lab/verify-$toolchain.log" 2>&1
    python3 - "$lab" "$toolchain" <<'PY'
import pathlib, sys
lab=pathlib.Path(sys.argv[1])
text=(lab/('verify-'+sys.argv[2]+'.log')).read_text()
assert 'NBReq verification root: '+str(lab/'nbreq') in text.splitlines()[0]
assert 'test backend::native_http::tests::request_ownership::m23_large_bodies_survive_early_307_308_and_reuse_for_buffered_and_stream_readers ... ok' in text
assert 'test backend::native_tls::tests::m23_borrowed_body_progress_survives_tiny_ciphertext_windows_and_reuse ... ok' in text
assert 'NBReq verification complete: all 24 steps passed' in text
print('CURRENT_ROOT_AND_M23_TESTS_PASS',sys.argv[2])
print(text.splitlines()[-1])
PY
done
if test "$scope" = measure; then
    export RUSTUP_TOOLCHAIN=stable
    cargo clean --offline --manifest-path tools/f5-observe/memory/Cargo.toml -p nbreq-f5-memory
    mkdir "$lab/bin"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/plain"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/meter"
    source_hash=$(python3 -c 'import hashlib,pathlib; print(hashlib.sha256(pathlib.Path("m23-source.sha256").read_bytes()).hexdigest())')
    python3 m23-compare.py --before-plain "$before/bin-final/plain" --before-meter "$before/bin-final/meter" --after-plain "$lab/bin/plain" --after-meter "$lab/bin/meter" --output "$lab/comparison" --source "$source_hash"
fi
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m23-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
printf 'M23_HOST_PASS\n'
