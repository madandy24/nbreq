use std::io::Read;
use std::net::{TcpListener, TcpStream};
use std::time::{Duration, Instant};

fn observe(normalize: bool) {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    listener.set_nonblocking(true).unwrap();
    let client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
    let (mut stream, _) = listener.accept().unwrap();
    if normalize {
        stream.set_nonblocking(false).unwrap();
    }
    stream.set_read_timeout(Some(Duration::from_millis(250))).unwrap();
    let started = Instant::now();
    let error = stream.read_exact(&mut [0_u8; 2]).unwrap_err();
    println!("normalized={normalize}, kind={:?}, elapsed_ms={}, error={error}", error.kind(), started.elapsed().as_millis());
    drop(client);
}

fn main() {
    observe(false);
    observe(true);
}
