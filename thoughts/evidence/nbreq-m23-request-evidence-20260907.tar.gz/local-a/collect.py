from pathlib import Path
import base64
import hashlib
import io
import json
import sys
import tarfile

lab = Path(sys.argv[1]).resolve()
assert lab.name == 'nbreq-m23-request-20260907'
assert (lab / 'run.exit').read_text().strip() == '0'
for toolchain in ['stable', '1.85.0']:
    text = (lab / ('verify-' + toolchain + '.log')).read_text()
    assert 'NBReq verification root: ' + str(lab / 'nbreq') in text.splitlines()[0]
    assert 'test backend::native_tls::tests::m23_borrowed_body_progress_survives_tiny_ciphertext_windows_and_reuse ... ok' in text
    assert 'NBReq verification complete: all 24 steps passed' in text
files = {p.relative_to(lab).as_posix(): p.read_bytes() for p in lab.glob('*.log')}
for name in ['run.exit', 'nbreq/m23-source.sha256']:
    files[name] = (lab / name).read_bytes()
if (lab / 'comparison').exists():
    cases = json.loads((lab / 'comparison/results.json').read_text())
    assert len(cases) == 60 and all(c['valid'] for c in cases)
    assert all(c['joined'] and c['exit_code'] == 0 and not c['forced'] for case in cases for c in case['cleanup'])
    before = json.loads((lab.parent / 'nbreq-m2-response-20260907/comparison-final/provenance.json').read_text())
    current = json.loads((lab / 'comparison/provenance.json').read_text())
    assert all(before['binaries']['after'][mode]['sha256'] == current['binaries']['before'][mode]['sha256'] for mode in ['plain', 'meter'])
    for p in (lab / 'comparison').rglob('*'):
        if p.is_file(): files[p.relative_to(lab).as_posix()] = p.read_bytes()
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['evidence.sha256'] = manifest
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
payload = buffer.getvalue()
print('M23_ARCHIVE_SHA256', hashlib.sha256(payload).hexdigest())
print('M23_ARCHIVE_BASE64', base64.b64encode(payload).decode())
