from pathlib import Path

root = Path('target/m23')
text = (root / 'archive-evidence-c.py').read_text(encoding='utf-8')
text = text.replace("final = root / 'c'", "final = root / 'd'\nmeasured = root / 'c'")
text = text.replace("final_hash = '003e80423d2eab3c70965384ae3615bd41c51f35f80922a9772b2ae22a418196'", "measured_hash = '003e80423d2eab3c70965384ae3615bd41c51f35f80922a9772b2ae22a418196'")
text = text.replace("(final / 'windows-verify-attempt1.log')", "(measured / 'windows-verify-attempt1.log')")
text = text.replace('nbreq-m23-request-20260907-c/nbreq', 'nbreq-m23-request-20260907-d/nbreq')
text = text.replace("(final / 'arm-evidence/shutdown-rechecks.log')", "(measured / 'arm-evidence/shutdown-rechecks.log')")
text = text.replace("[final / 'windows-comparison', final / 'linux-evidence/comparison']", "[measured / 'windows-comparison', measured / 'linux-evidence/comparison']")
text = text.replace("== final_hash", "== measured_hash")
text = text.replace("files = {}\nextensions", '''identity = json.loads((final / 'production-identity.json').read_text(encoding='utf-8'))
assert identity['all_production_and_observer_build_inputs_identical']
assert identity['changed_repository_files'] == ['src/dns_wiring_tests.rs']
for folder in [final / 'windows-extended-recheck', final / 'linux-small-recheck']:
    cases = json.loads((folder / 'results.json').read_text(encoding='utf-8'))
    assert len(cases) == 10 and all(c['valid'] for c in cases)
    assert all(p['joined'] and p['exit_code'] == 0 and not p['forced'] for c in cases for p in c['cleanup'])
    provenance = json.loads((folder / 'provenance.json').read_text(encoding='utf-8'))
    assert provenance['sources']['after'] == measured_hash
files = {}
extensions''')
text = text.replace("(final, 'local-c/')", "(measured, 'local-c/'), (final, 'local-d/')")
text = text.replace("(final / 'windows-comparison', 'windows/')", "(measured / 'windows-comparison', 'windows/'), (final / 'windows-extended-recheck', 'timing-windows/'), (final / 'linux-small-recheck', 'timing-linux/')")
text = text.replace("folders += [(final / (host + '-evidence'), host + '/') for host in ['linux', 'intel', 'arm']]", "folders += [(measured / (host + '-evidence'), 'measured-c-' + host + '/') for host in ['linux', 'intel', 'arm']]\nfolders += [(final / (host + '-evidence'), 'final-d-' + host + '/') for host in ['linux', 'intel', 'arm']]")
text = text.replace("('c', final, 'nbreq-m23-request-20260907-c.tar.gz')", "('c', measured, 'nbreq-m23-request-20260907-c.tar.gz'), ('d', final, 'nbreq-m23-request-20260907-d.tar.gz')")
text = text.replace("revision == 'c'", "revision == 'd'")
text = text.replace('unresolved_windows_dns_failure=True', "dns_fixture_nonblocking_mode_corrected=True, measured_source_revision='c', final_test_source_revision='d', timing_followup_cases=20")
(root / 'archive-evidence-d.py').write_bytes(text.encode('utf-8'))
