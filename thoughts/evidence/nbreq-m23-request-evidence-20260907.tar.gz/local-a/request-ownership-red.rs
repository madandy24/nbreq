use super::super::*;
use crate::Method;
use std::net::TcpListener;

const LARGE_BODY: usize = 2 * 1024 * 1024;

fn backend(tls: bool) -> NativeHttpBackend {
    let config = EngineConfig::manual();
    let configs = tls.then(|| {
        let key = rcgen::KeyPair::generate().expect("key");
        let cert = rcgen::CertificateParams::new(vec!["ownership.test".into()])
            .expect("certificate parameters")
            .self_signed(&key)
            .expect("certificate");
        NativeTlsConfigs::with_test_root(cert.der().clone()).expect("TLS configs")
    });
    NativeHttpBackend::new(
        HttpLimits::from_config(&config),
        None,
        configs,
        ConnectionLimits::from_config(&config),
    )
    .expect("backend")
}

fn pending(backend: &NativeHttpBackend, tls: bool) -> (PendingResolve, *const u8) {
    let mut bytes = Vec::with_capacity(LARGE_BODY + 37);
    bytes.resize(LARGE_BODY, 0xa5);
    let pointer = bytes.as_ptr();
    let request = Request::post(format!(
        "{}://ownership.test/upload",
        if tls { "https" } else { "http" }
    ))
    .body(bytes)
    .build()
    .expect("request");
    let pending = backend
        .make_pending(
            RequestId { engine: 1, sequence: 1 },
            request,
            PendingDeadlines { connect: None, total: None, inactivity: None },
            0,
            ErrorKind::InvalidRequest,
            PendingResponse::Buffered,
        )
        .unwrap_or_else(|(error, _)| panic!("pending request: {error}"));
    (pending, pointer)
}

fn connecting(tls: bool) -> (NativeHttpBackend, SlotId, TcpListener, *const u8) {
    let listener = TcpListener::bind("127.0.0.1:0").expect("listener");
    let mut backend = backend(tls);
    let (pending, pointer) = pending(&backend, tls);
    let id = pending.request_id;
    assert!(backend.reserve_connection(&pending.key));
    assert!(backend
        .begin_connection(VecDeque::from([listener.local_addr().expect("address")]), pending)
        .is_none());
    let slot = backend.request_to_slot[&id];
    (backend, slot, listener, pointer)
}

#[test]
fn m23_pending_request_keeps_body_out_of_serialized_storage() {
    for tls in [false, true] {
        let backend = backend(tls);
        let (pending, pointer) = pending(&backend, tls);
        assert_eq!(pending.request.body().as_ptr(), pointer);
        assert_eq!(pending.request.body().len(), LARGE_BODY);
        assert!(pending.serialized.bytes.capacity() < 1024,
            "DNS/connect preparation duplicated a whole body: {} bytes", pending.serialized.bytes.capacity());
        assert!(pending.serialized.bytes.ends_with(b"\r\n\r\n"));
        assert!(pending.serialized.bytes.windows(b"Content-Length: 2097152".len())
            .any(|value| value == b"Content-Length: 2097152"));
    }
}

#[test]
fn m23_connection_waiter_keeps_only_original_body_storage() {
    let mut backend = backend(false);
    backend.connection_limits.global = 1;
    let (pending, pointer) = pending(&backend, false);
    let key = pending.key.clone();
    let id = pending.request_id;
    assert!(backend.reserve_connection(&key));
    assert!(backend.start_pending(pending).is_none());
    assert_eq!(backend.waiting.len(), 1);
    let waiting = &backend.waiting[0];
    assert_eq!(waiting.request.body().as_ptr(), pointer);
    assert!(waiting.serialized.bytes.capacity() < 1024,
        "connection admission retained a second full request body");
    backend.cancel(id);
    assert!(backend.waiting.is_empty());
    backend.release_connection(&key);
    backend.shutdown().expect("shutdown");
}

#[test]
fn m23_cleartext_connecting_state_does_not_duplicate_the_body() {
    let (mut backend, slot, _listener, pointer) = connecting(false);
    let transfer = &backend.transfers[&slot];
    assert_eq!(transfer.request.body().as_ptr(), pointer);
    let head = transfer.connecting.as_ref().expect("connecting")
        .cleartext_request.as_ref().expect("cleartext head");
    assert!(head.capacity() < 1024,
        "TCP connect state retained a whole serialized body: {} bytes", head.capacity());
    assert!(backend.reactor.outbound_is_empty(slot).expect("outbound"));
    backend.shutdown().expect("shutdown");
}

#[test]
fn m23_tls_handshake_does_not_duplicate_the_body() {
    let (mut backend, slot, _listener, pointer) = connecting(true);
    let transfer = &mut backend.transfers.get_mut(&slot).expect("transfer");
    assert_eq!(transfer.request.body().as_ptr(), pointer);
    let tls = transfer.tls.as_mut().expect("TLS");
    assert!(tls.request_plaintext_capacity() < 1024,
        "TLS retained a second whole request body before handshake");
    let session = tls.take_handshake().expect("handshake session");
    assert!(tls.handshake_in_worker());
    assert!(tls.request_plaintext_capacity() < 1024);
    tls.restore_handshake(session);
    assert_eq!(transfer.request.body().as_ptr(), pointer);
    backend.shutdown().expect("shutdown");
}

#[test]
fn m23_cleartext_send_queue_has_a_body_independent_bound() {
    let (mut backend, slot, _listener, _) = connecting(false);
    let capacity = backend.reactor.outbound_capacity(slot).expect("capacity");
    assert!(capacity <= 65 * 1024,
        "large buffered bodies must use a bounded send window, got {capacity}");
    backend.shutdown().expect("shutdown");
}

#[test]
fn m23_redirect_moves_the_original_body_allocation() {
    let mut bytes = Vec::with_capacity(LARGE_BODY + 37);
    bytes.resize(LARGE_BODY, 0x5a);
    let pointer = bytes.as_ptr();
    let request = Request::post("https://ownership.test/start")
        .header("Authorization", "secret")
        .header("Content-Length", LARGE_BODY.to_string())
        .body(bytes)
        .build()
        .expect("request");
    let redirected = request.redirected("https://other.test/finish".into(), Method::Post, true, true);
    assert_eq!(redirected.body().len(), LARGE_BODY);
    assert_eq!(redirected.body().as_ptr(), pointer,
        "body-preserving redirect copied the payload");
    assert!(!redirected.headers().iter().any(|header| header.name().eq_ignore_ascii_case("authorization")));
    assert!(redirected.headers().iter().any(|header| header.name().eq_ignore_ascii_case("content-length")));
}
