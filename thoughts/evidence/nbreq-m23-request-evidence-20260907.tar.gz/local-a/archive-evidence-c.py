from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path('target/m23')
final = root / 'c'
before_hash = '3704fc13a50678386a8189e12344f27ae084c5cdb143c1ae821877115d256302'
final_hash = '003e80423d2eab3c70965384ae3615bd41c51f35f80922a9772b2ae22a418196'
shutdown_test = 'test registry::tests::shutdown_commits_stream_terminals_before_exposing_reactor_stop ... ok'
assert (final / 'windows.exit').read_text(encoding='utf-8-sig').strip() == '0'
windows_log = (final / 'windows-verify.log').read_text(encoding='utf-8')
assert 'NBReq verification complete: all 24 steps passed' in windows_log
assert shutdown_test in windows_log
assert '10 passed; 0 failed' in (final / 'windows-x86.log').read_text(encoding='utf-8')
assert '24 passed; 0 failed' in (final / 'windows-x86-shutdown.log').read_text(encoding='utf-8')
assert '10 passed; 0 failed' in (root / 'request-c-green.log').read_text(encoding='utf-8')
assert '24 passed; 0 failed' in (root / 'shutdown-green.log').read_text(encoding='utf-8')
assert '0 passed; 6 failed' in (root / 'request-red.log').read_text(encoding='utf-8')
assert '0 passed; 1 failed' in (root / 'tls-record-red.log').read_text(encoding='utf-8')
red = (root / 'shutdown-order-red.log').read_text(encoding='utf-8')
assert '0 passed; 1 failed' in red and 'reactor stop exposed before all terminals: true' in red
assert 'streaming response producer ended without a terminal result' in red
assert 'left: Some(Io)' in (final / 'windows-verify-attempt1.log').read_text(encoding='utf-8')
assert (final / 'windows-dns-rechecks.log').read_text(encoding='utf-8').count('DNS_RECHECK_PASS ') == 20
for host in ['linux', 'intel', 'arm']:
    folder = final / (host + '-evidence')
    assert (folder / 'run.exit').read_text().strip() == '0'
    for version in ['stable', '1.85.0']:
        text = (folder / ('verify-' + version + '.log')).read_text(encoding='utf-8')
        assert 'nbreq-m23-request-20260907-c/nbreq' in text.splitlines()[0]
        assert 'NBReq verification complete: all 24 steps passed' in text
        assert 'test backend::native_tls::tests::m23_small_borrowed_request_preserves_one_tls_record ... ok' in text
        assert shutdown_test in text
assert (final / 'arm-evidence/shutdown-rechecks.log').read_text(encoding='utf-8').count('SHUTDOWN_RECHECK_PASS ') == 30
for path in [final / 'windows-comparison', final / 'linux-evidence/comparison']:
    cases = json.loads((path / 'results.json').read_text(encoding='utf-8'))
    assert len(cases) == 60 and all(c['valid'] for c in cases)
    assert all(c['joined'] and c['exit_code'] == 0 and not c['forced'] for case in cases for c in case['cleanup'])
    provenance = json.loads((path / 'provenance.json').read_text(encoding='utf-8'))
    assert provenance['sources']['before'] == before_hash
    assert provenance['sources']['after'] == final_hash

files = {}
extensions = {'.log', '.json', '.py', '.ps1', '.sh', '.sha256', '.diff', '.rs', '.exit'}
for folder, prefix in [(root, 'local-a/'), (root / 'b', 'local-b/'), (final, 'local-c/')]:
    for path in folder.iterdir():
        if path.is_file() and path.suffix in extensions:
            files[prefix + path.name] = path.read_bytes()
    for path in folder.glob('bridge-*.json'):
        receipts = json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(receipts, list): receipts = [receipts]
        for receipt in receipts:
            if not isinstance(receipt, dict) or not {'Root', 'Id'} <= receipt.keys():
                continue
            result = Path(receipt['Root']) / 'results' / (receipt['Id'] + '.json')
            assert result.is_file(), result
            files['receipts/' + receipt['Id'] + '.json'] = result.read_bytes()
folders = [(root / 'windows-comparison', 'preliminary-a-windows/'),
           (root / 'b/windows-comparison', 'preliminary-b-windows/'),
           (root / 'b/linux-evidence', 'preliminary-b-linux/'),
           (root / 'b/intel-evidence', 'preliminary-b-intel/'),
           (final / 'windows-comparison', 'windows/')]
folders += [(final / (host + '-evidence'), host + '/') for host in ['linux', 'intel', 'arm']]
for folder, prefix in folders:
    for path in folder.rglob('*'):
        if path.is_file(): files[prefix + path.relative_to(folder).as_posix()] = path.read_bytes()

artifacts = {}
for revision, folder, name in [('a', root, 'nbreq-m23-request-20260907.tar.gz'), ('b', root / 'b', 'nbreq-m23-request-20260907-b.tar.gz'), ('c', final, 'nbreq-m23-request-20260907-c.tar.gz')]:
    source = folder / name
    bundle = json.loads((folder / 'bundle.json').read_text(encoding='utf-8'))
    data = source.read_bytes()
    assert hashlib.sha256(data).hexdigest() == bundle['sha256']
    with tarfile.open(source) as archive:
        members = {member.name.removeprefix('nbreq/'): archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    manifest = members['m23-source.sha256']
    assert hashlib.sha256(manifest).hexdigest() == bundle['manifest_sha256']
    for line in manifest.decode().splitlines():
        digest, path = line.split('  ', 1)
        assert hashlib.sha256(members[path]).hexdigest() == digest
        if revision == 'c' and not path.startswith('m23-'):
            assert Path(path).read_bytes() == members[path], path
    destination = Path('thoughts/evidence') / name
    destination.write_bytes(data)
    artifacts['source_' + revision] = dict(path=destination.as_posix(), sha256=bundle['sha256'], manifest_sha256=bundle['manifest_sha256'])

manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['evidence.sha256'] = manifest
output = Path('thoughts/evidence/nbreq-m23-request-evidence-20260907.tar.gz')
with tarfile.open(output, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(output) as archive:
    restored = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
assert restored == files
artifacts['evidence'] = dict(path=output.as_posix(), sha256=hashlib.sha256(output.read_bytes()).hexdigest(), files=len(files), bytes=output.stat().st_size)
artifacts.update(final_comparison_cases=120, preliminary_comparison_cases=180, final_full_verifiers=7, final_ownership_tests=10, initial_red_tests=6, additional_tls_record_red=1, additional_shutdown_order_red=1, shutdown_focused_tests=24, arm_shutdown_repetitions=30, unresolved_windows_dns_failure=True, windows_dns_isolated_rechecks=20)
Path('thoughts/evidence/nbreq_m23_request_artifacts.json').write_bytes(json.dumps(artifacts, indent=2).encode('utf-8'))
print(json.dumps(artifacts, indent=2))
