from pathlib import Path

root = Path('target/m23')
out = root / 'b'
out.mkdir(exist_ok=True)
remote = (root / 'remote.sh').read_text(encoding='utf-8').replace('nbreq-m23-request-20260907)', 'nbreq-m23-request-20260907-b)')
remote = remote.replace('before=$4', 'before=$4\nprevious=$5')
remote = remote.replace('cd "$lab/nbreq"', '''test -f "$previous/run.exit"
mkdir "$lab/previous-attempt"
cp "$previous"/*.log "$previous/run.exit" "$previous/nbreq/m23-source.sha256" "$lab/previous-attempt/"
cd "$lab/nbreq"''')
remote = remote.replace("assert 'NBReq verification complete: all 24 steps passed' in text", "assert 'test backend::native_tls::tests::m23_small_borrowed_request_preserves_one_tls_record ... ok' in text\nassert 'NBReq verification complete: all 24 steps passed' in text")
(out / 'remote.sh').write_bytes(remote.encode('utf-8'))
collect = (root / 'collect.py').read_text(encoding='utf-8').replace("lab.name == 'nbreq-m23-request-20260907'", "lab.name == 'nbreq-m23-request-20260907-b'")
collect = collect.replace("manifest = ''.join", "for p in (lab / 'previous-attempt').rglob('*'):\n    if p.is_file(): files[p.relative_to(lab).as_posix()] = p.read_bytes()\nmanifest = ''.join")
(out / 'collect.py').write_bytes(collect.encode('utf-8'))
prepare = (root / 'prepare.py').read_text(encoding='utf-8').replace("Path('target/m23')", "Path('target/m23/b')").replace("'nbreq-m23-request-20260907.tar.gz'", "'nbreq-m23-request-20260907-b.tar.gz'")
(out / 'prepare.py').write_bytes(prepare.encode('utf-8'))
windows = (root / 'windows.ps1').read_text(encoding='utf-8').replace("'target/m23'", "'target/m23/b'")
(out / 'windows.ps1').write_bytes(windows.encode('utf-8'))
