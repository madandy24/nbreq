$ErrorActionPreference = 'Stop'
$m23Root = Join-Path (Get-Location) 'target/m23/d'
$m23Exit = 1
try {
    cargo run --offline --manifest-path tools/xtask/Cargo.toml -- verify --offline *> "$m23Root/windows-verify.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows D verifier failed.' }
    cargo test --offline --all-features --target i686-pc-windows-msvc --lib m23_ -- --test-threads=1 *> "$m23Root/windows-x86.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows D x86 memory tests failed.' }
    cargo test --offline --all-features --target i686-pc-windows-msvc --lib shutdown -- --test-threads=1 *> "$m23Root/windows-x86-shutdown.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows D x86 shutdown tests failed.' }
    for ($m23Iteration = 1; $m23Iteration -le 20; $m23Iteration++) {
        cargo test --offline --all-features --lib public_tcp_fallback_completes_and_classifies_bad_tcp_replies -- --nocapture >> "$m23Root/windows-dns-rechecks.log" 2>&1
        if ($LASTEXITCODE -ne 0) { throw 'Windows D DNS fixture recheck failed.' }
        "DNS_RECHECK_PASS $m23Iteration" >> "$m23Root/windows-dns-rechecks.log"
    }
    $m23Exit = 0
    Write-Output 'M23_WINDOWS_D_PASS'
} finally {
    Set-Content -LiteralPath "$m23Root/windows.exit" -Value $m23Exit -Encoding UTF8
}
