from pathlib import Path
import difflib
import hashlib
import io
import json
import subprocess
import tarfile

out = Path('target/m23/b')
before_manifest = '3704fc13a50678386a8189e12344f27ae084c5cdb143c1ae821877115d256302'
compare = Path('target/m2/compare.py').read_text(encoding='utf-8')
compare = compare.replace('36886e7d54643a8aa60cae9c6f9f099c90a44d65d3dee246ae3b56334e1aa4ed', before_manifest)
compare = compare.replace('M2_COMPARE_PASS', 'M23_COMPARE_PASS').replace('.write_text(json.dumps(', '.write_text(json.dumps(')
(out / 'compare.py').write_bytes(compare.encode('utf-8'))

names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')
prefixes = ('src/', 'tests/', 'support/', 'examples/', 'docs/', 'tools/xtask/', 'tools/f5-observe/')
roots = {'Cargo.toml', 'Cargo.lock', 'README.md', 'SECURITY.md', 'LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.html', '.gitignore', 'rustfmt.toml'}
files = {name: Path(name).read_bytes() for name in names if (name in roots or name.startswith(prefixes)) and Path(name).is_file() and '/target/' not in name and '/__pycache__/' not in name}
for name in ('Cargo.lock', 'tools/f5-observe/memory/Cargo.lock', 'tools/f5-observe/memory/meter/Cargo.lock'):
    files[name] = Path(name).read_bytes()
with tarfile.open('thoughts/evidence/nbreq-m2-response-20260907.tar.gz') as archive:
    prior = {member.name.removeprefix('nbreq/'): archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
changed = sorted(name for name, data in files.items() if prior.get(name) != data)
assert changed == ['src/backend/native_http.rs', 'src/backend/native_http/http1.rs', 'src/backend/native_http/tests.rs', 'src/backend/native_http/tests/request_ownership.rs', 'src/backend/native_tls.rs', 'src/types.rs'], changed
diff = ''.join(''.join(difflib.unified_diff(prior.get(name, b'').decode().splitlines(True), files[name].decode().splitlines(True), fromfile='before/'+name, tofile='after/'+name)) for name in changed)
(out / 'source.diff').write_bytes(diff.encode('utf-8'))
for name in ('remote.sh', 'compare.py', 'collect.py'):
    files['m23-' + name] = (out / name).read_bytes().replace(b'\r\n', b'\n')
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode('utf-8')
files['m23-source.sha256'] = manifest
path = out / 'nbreq-m23-request-20260907-b.tar.gz'
assert not path.exists(), 'Frozen source already exists; choose a new explicit revision rather than overwrite it.'
with tarfile.open(path, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo('nbreq/' + name)
        info.size = len(data)
        info.mode = 0o755 if name.endswith('.sh') else 0o644
        archive.addfile(info, io.BytesIO(data))
result = dict(path=str(path.resolve()), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), manifest_sha256=hashlib.sha256(manifest).hexdigest(), files=len(files), changed_from_m2_response=changed)
(out / 'bundle.json').write_bytes(json.dumps(result, indent=2).encode('utf-8'))
(out / 'source.sha256').write_bytes(manifest)

for name, provenance in [('windows', 'target/m2/windows-comparison/provenance.json'), ('linux', 'target/m2/linux-evidence/comparison-final/provenance.json')]:
    before = json.loads(Path(provenance).read_text(encoding='utf-8'))
    assert before['sources']['after'] == before_manifest
    if name == 'windows':
        for mode in ['plain', 'meter']:
            binary = before['binaries']['after'][mode]
            assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest() == binary['sha256']
    (out / (name + '-before-provenance.json')).write_bytes(json.dumps(before, indent=2).encode('utf-8'))
print(json.dumps(result, indent=2))
