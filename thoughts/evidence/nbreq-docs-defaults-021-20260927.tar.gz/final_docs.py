from pathlib import Path
import hashlib, json, os, re
from owned_command import command

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
out = lab / 'final-docs'
out.mkdir(exist_ok=False)
assert json.loads((lab/'full-verifier/summary.json').read_text())['status'] == 'passed'
assert json.loads((lab/'focused/summary.json').read_text())['status'] == 'passed'
inputs = json.loads((lab/'full-verifier/inputs.json').read_text())['files']
changed = [p for p, digest in inputs.items() if hashlib.sha256((root/p).read_bytes()).hexdigest() != digest]
assert changed == ['docs/getting-started.md'], changed
before = (lab/'focused/documents/docs/getting-started.md').read_bytes()
after = (root/'docs/getting-started.md').read_bytes()
old = b'TLS staging and HTTP streaming response windows'
new = b'TLS staging and HTTP streaming windows'
assert before.count(old) == 1
assert after == before.replace(old, new)
assert re.findall(rb'```.*?```', before, re.S) == re.findall(rb'```.*?```', after, re.S)
env = dict(os.environ, CARGO_TARGET_DIR='C:/User/projects/nbreq/target/docs-021-20260927/build',
           RUSTUP_TOOLCHAIN='stable', CARGO_NET_OFFLINE='true', RUSTDOCFLAGS='-D warnings')
command(['cargo','doc','--locked','--offline','--all-features','--no-deps','-p','nbreq'],
        root, out, 'strict-rustdoc', env, 300)
final_hashes = {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in inputs}
assert all(final_hashes[p] == digest for p, digest in inputs.items() if p not in changed)
assert (root/'docs/getting-started.md').read_bytes() == after
(out/'getting-started.md').write_bytes(after)
(out/'summary.json').write_text(json.dumps(dict(status='passed', final_hashes=final_hashes,
    full_verifier_delta='Only remove response from HTTP streaming response windows in docs/getting-started.md',
    code_blocks_unchanged=True, runtime_sources_unchanged=True,
    scope='Exact post-verifier wording delta plus strict all-feature NBReq rustdoc build'), indent=2)+'\n')
print('Final wording delta and strict rustdoc passed.', flush=True)
