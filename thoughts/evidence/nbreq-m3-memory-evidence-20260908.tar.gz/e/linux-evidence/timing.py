from pathlib import Path
from statistics import median
import argparse, hashlib, importlib.util, json

p=argparse.ArgumentParser()
p.add_argument('--before',type=Path,required=True)
p.add_argument('--after',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--source',required=True)
a=p.parse_args()
spec=importlib.util.spec_from_file_location('observer','tools/f5-observe/memory/run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
a.output.mkdir(parents=True,exist_ok=False)
provenance=dict(host=runner.host_info(),sources=dict(before='b1ddee56304a55f26f9ef0c7b215e9ca1d5f10632c47aa5bcd764965b15b519d',after=a.source),binaries={v:dict(path=str(getattr(a,v).resolve()),sha256=hashlib.sha256(getattr(a,v).read_bytes()).hexdigest()) for v in ('before','after')})
(a.output/'provenance.json').write_text(json.dumps(provenance,indent=2))
cases=[]
for rep in range(3):
    for protocol in ('http','https'):
        versions=['before','after','capped'] if rep%2==0 else ['capped','after','before']
        for version in versions:
            binary=a.before if version=='before' else a.after
            source=provenance['sources']['before' if version=='before' else 'after']
            name=f'{version}-{protocol}-r{rep+1}'
            case=runner.run_case(binary.resolve(),binary.resolve(),a.output/name,source,protocol,32,1024,512,False,buffered_budget=8*1024*1024 if version=='capped' else None)
            case.update(version=version,repetition=rep+1,case=name)
            cases.append(case)
            print('PASS',name,flush=True)
(a.output/'results.json').write_text(json.dumps(cases,indent=2))
assert all(c['valid'] and all(p['joined'] and not p['forced'] and p['exit_code']==0 for p in c['cleanup']) for c in cases)
summary=[]
for protocol in ('http','https'):
    for version in ('before','after','capped'):
        phases=[p for c in cases if c['protocol']==protocol and c['version']==version for p in c['phases'] if p['phase']=='steady']
        summary.append(dict(protocol=protocol,version=version,wall_ms=median(p['wall_ms'] for p in phases),p95_ms=median(p['latency_p95_ms'] for p in phases)))
(a.output/'analysis.json').write_text(json.dumps(summary,indent=2))
print('M3_TIMING_PASS',len(cases),json.dumps(summary),flush=True)
