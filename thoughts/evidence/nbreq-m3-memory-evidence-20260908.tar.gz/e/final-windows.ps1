$ErrorActionPreference = 'Stop'
$m3Root = 'C:/User/projects/nbreq/target/m3/e'
$m3FinalExit = 1
try {
    while (!(Test-Path -LiteralPath "$m3Root/windows-measure.exit")) { Start-Sleep -Seconds 5 }
    if ((Get-Content "$m3Root/windows-measure.exit").Trim() -ne '0') { throw 'Measurement stage failed' }
    cargo run --locked --offline --manifest-path tools/xtask/Cargo.toml -- verify --offline *> "$m3Root/windows-verify.log"
    if ($LASTEXITCODE -ne 0) { throw 'Full verifier failed' }
    & 'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 target/m3/run_gds_test.py gds-e-http --local-nbreq C:/User/projects/nbreq --lib --test dphttpclient::tests *> "$m3Root/gds-http-wrapper.log"
    if ($LASTEXITCODE -ne 0) { throw 'GDS HTTP tests failed' }
    & 'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 target/m3/run_gds_test.py gds-e-webrpc --local-nbreq C:/User/projects/nbreq --lib --test dpwebrpc::tests *> "$m3Root/gds-webrpc-wrapper.log"
    if ($LASTEXITCODE -ne 0) { throw 'GDS WebRPC tests failed' }
    & 'C:/User/SecuritasNew/gds/rust/gds/build.ps1' -LocalNbreq C:/User/projects/nbreq -SkipCopy -OutputFile "$m3Root/gds-native-build-full.log" *> "$m3Root/gds-native-build-wrapper.log"
    if ($LASTEXITCODE -ne 0) { throw 'GDS native DLL build failed' }
    $m3FinalExit = 0
    Write-Output 'M3_WINDOWS_FINAL_PASS'
} finally { Set-Content -LiteralPath "$m3Root/windows-final.exit" -Value $m3FinalExit -Encoding utf8 }
