from pathlib import Path
from statistics import median
import json, sys

root = Path(sys.argv[1])
cases = json.loads((root/'results.json').read_text())
assert len(cases) == 60
assert all(c['valid'] and all(p['joined'] and not p['forced'] and p['exit_code'] == 0 for p in c['cleanup']) for c in cases)
rows = []
for protocol, size, extended in [('http',1024,False),('http',51200,False),('https',1024,False),('https',51200,False),('https',51200,True)]:
    row = dict(protocol=protocol, size=size, extended=extended)
    for version in ('before','after'):
        selected = [c for c in cases if c['version']==version and c['protocol']==protocol and c['client']['body_bytes']==size and c['client']['extended']==extended]
        assert len(selected) == 6
        row[version] = {}
        for phase_name in ('steady','burst_retained','released_idle','large_transfer_retained','post_large_idle'):
            timing = [p for c in selected if not c['client']['instrumented'] for p in c['phases'] if p['phase']==phase_name]
            memory = [p for c in selected if c['client']['instrumented'] for p in c['phases'] if p['phase']==phase_name]
            if not timing: continue
            row[version][phase_name] = dict(
                wall_ms=median(p['wall_ms'] for p in timing),
                p95_ms=median(p['latency_p95_ms'] for p in timing) if timing[0]['latency_p95_ms'] is not None else None,
                heap_live=median(p['allocation']['live_after'] for p in memory),
                heap_peak=median(p['allocation']['peak_live'] for p in memory),
                rss_peak=median(p['process']['sampled_peaks']['rss'] for p in timing))
    rows.append(row)
(root/'analysis.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
