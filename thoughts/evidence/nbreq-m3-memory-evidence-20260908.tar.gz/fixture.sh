#!/bin/sh
set -eu
lab=$1
cache=$2
prior=$3
case "$lab" in */nbreq-m3-20260908-b) ;; *) exit 2 ;; esac
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$cache"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
trap 'code=$?; printf "%s\n" "$code" > "$lab/run.exit"' EXIT
# A owns this cache until its gates and measurements have joined.
while ! test -f "$prior/run.exit"; do sleep 5; done
test "$(cat "$prior/run.exit")" = 0
cd "$lab/nbreq"
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m3-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    cargo test --locked --offline --all-features --lib dns_wiring_tests:: -- --test-threads=1 > "$lab/fixture-$toolchain.log" 2>&1
    printf 'M3_FINAL_FIXTURE_PASS %s\n' "$toolchain"
done
printf 'M3_FINAL_FIXTURE_HOST_PASS\n'
