$ErrorActionPreference = 'Stop'
$m3Root = 'C:/User/projects/nbreq/target/m3/d'
$m3Exit = 1
try {
    cargo test --locked --offline --all-features --target i686-pc-windows-msvc --lib m3_ -- --test-threads=1 *> "$m3Root/windows-x86.log"
    if ($LASTEXITCODE -ne 0) { throw 'x86 memory tests failed' }
    New-Item -ItemType Directory -Path "$m3Root/bin" -Force | Out-Null
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml *> "$m3Root/windows-build-plain.log"
    if ($LASTEXITCODE -ne 0) { throw 'plain observer build failed' }
    Copy-Item -LiteralPath tools/f5-observe/memory/target/release/nbreq-f5-memory.exe -Destination "$m3Root/bin/plain.exe"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter *> "$m3Root/windows-build-meter.log"
    if ($LASTEXITCODE -ne 0) { throw 'meter observer build failed' }
    Copy-Item -LiteralPath tools/f5-observe/memory/target/release/nbreq-f5-memory.exe -Destination "$m3Root/bin/meter.exe"
    $m3Bundle = Get-Content -LiteralPath "$m3Root/bundle.json" -Raw | ConvertFrom-Json
    & 'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 "$m3Root/compare.py" --before-plain target/m24/b/bin/plain.exe --before-meter target/m24/b/bin/meter.exe --after-plain "$m3Root/bin/plain.exe" --after-meter "$m3Root/bin/meter.exe" --output "$m3Root/windows-comparison" --source $m3Bundle.manifest_sha256 *> "$m3Root/windows-comparison.log"
    if ($LASTEXITCODE -ne 0) { throw 'paired observations failed' }
    & 'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 "$m3Root/cap_probe.py" "$m3Root/windows-cap-probe" "$m3Root/bin/plain.exe" "$m3Root/bin/meter.exe" $m3Bundle.manifest_sha256 *> "$m3Root/windows-cap-probe.log"
    if ($LASTEXITCODE -ne 0) { throw 'configured-cap observations failed' }
    $m3Exit = 0
    Write-Output 'M3_WINDOWS_MEASURE_PASS'
} finally { Set-Content -LiteralPath "$m3Root/windows-measure.exit" -Value $m3Exit -Encoding utf8 }
