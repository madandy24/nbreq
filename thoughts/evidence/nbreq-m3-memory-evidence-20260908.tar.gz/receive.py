from pathlib import Path
import base64,hashlib,io,json,sys,tarfile
receipt_path,destination=map(Path,sys.argv[1:])
result=json.loads(receipt_path.read_text(encoding='utf-8-sig'))
assert result['status']=='completed' and result['ok'] and result['exit_code']==0
data=base64.b64decode(''.join(result['output'].split()),validate=True)
destination=destination.resolve();destination.mkdir(parents=True,exist_ok=False)
files={}
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive:
        target=(destination/member.name).resolve()
        assert target.is_relative_to(destination)
        if member.isdir():
            target.mkdir(parents=True,exist_ok=True)
            continue
        assert member.isfile()
        payload=archive.extractfile(member).read();files[member.name]=payload
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
assert (destination/'run.exit').read_text().strip()=='0'
for name,payload in files.items():
    if name.startswith('verify-'):
        log=payload.decode()
        assert 'NBReq verification complete: all 24 steps passed' in log,name
        assert 'm3_https_budget_covers_plaintext_and_failed_exchange_releases_every_charge ... ok' in log
    if name.startswith('fixture-'):
        log=payload.decode()
        assert 'public_tcp_fallback_completes_and_classifies_bad_tcp_replies ... ok' in log
        assert 'test result: ok.' in log
destination.with_suffix('.tar.gz').write_bytes(data)
print(json.dumps(dict(destination=str(destination),files=len(files),sha256=hashlib.sha256(data).hexdigest())))
