from pathlib import Path
import hashlib,importlib.util,json,sys

out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
plain,meter=map(Path,sys.argv[2:4]);source=sys.argv[4]
spec=importlib.util.spec_from_file_location('runner','tools/f5-observe/memory/run.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)

results=[]
for mode,binary in [('plain',plain),('meter',meter)]:
    for extended in [False,True]:
        budget=(12 if extended else 8)*1024*1024
        name=mode+('-extended' if extended else '-normal')
        case=runner.run_case(plain,binary,out/name,source,'https',32,51200,16,extended,buffered_budget=budget)
        case.update(case=name,configured_buffered_budget=budget)
        assert case['valid'] and all(c['joined'] and c['exit_code']==0 and not c['forced'] for c in case['cleanup'])
        assert case['final']['metrics']['high_buffered_reserved_bytes'] <= budget
        results.append(case)
        print('M3_CAP_PROBE_PASS',name,case['final']['metrics']['high_buffered_reserved_bytes'],flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2))
(out/'provenance.json').write_text(json.dumps(dict(source=source,host=runner.host_info(),budgets={case['case']:case['configured_buffered_budget'] for case in results},binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [plain,meter]}),indent=2))
