from pathlib import Path
import hashlib,io,json,tarfile
out=Path(__file__).parent
with tarfile.open(out/'nbreq-m3-20260908-a.tar.gz') as source:
    files={m.name.removeprefix('nbreq/'):source.extractfile(m).read() for m in source if m.isfile()}
files.pop('m3-source.sha256')
changes=[name for name,data in files.items() if not name.startswith('m3-') and Path(name).read_bytes()!=data]
assert changes==['src/dns_wiring_tests.rs'],changes
files['src/dns_wiring_tests.rs']=Path('src/dns_wiring_tests.rs').read_bytes()
files['m3-fixture.sh']=(out/'fixture.sh').read_bytes().replace(b'\r\n',b'\n')
manifest=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
files['m3-source.sha256']=manifest
path=out/'nbreq-m3-20260908-b.tar.gz'
assert not path.exists()
with tarfile.open(path,'w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo('nbreq/'+name);info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
result=dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256(manifest).hexdigest(),changed_from_a=changes,files=len(files))
(out/'bundle-b.json').write_bytes(json.dumps(result,indent=2).encode())
(out/'source-b.sha256').write_bytes(manifest)
print(json.dumps(result))
