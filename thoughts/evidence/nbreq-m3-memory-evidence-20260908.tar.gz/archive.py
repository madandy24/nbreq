from pathlib import Path
import hashlib, io, json, shutil, tarfile

lab=Path('target/m3')
public=Path('thoughts/evidence')
gds=Path('C:/User/SecuritasNew')
private=gds/'gds/doc/evidence'
private.mkdir(exist_ok=True)
digest=lambda b:hashlib.sha256(b).hexdigest()

def pack(path, files):
    assert not path.exists(), path
    manifest=''.join(digest(b)+'  '+n+'\n' for n,b in sorted(files.items())).encode()
    files['artifact-files.sha256']=manifest
    with tarfile.open(path,'w:gz') as archive:
        for name,data in sorted(files.items()):
            entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
            archive.addfile(entry,io.BytesIO(data))
    with tarfile.open(path) as archive:
        assert all(digest(archive.extractfile(n).read())==digest(b) for n,b in files.items())
    return dict(path=str(path).replace('\\','/'),sha256=digest(path.read_bytes()),files=len(files),bytes=path.stat().st_size)

gate_logs=[lab/'e/windows-verify.log']+[lab/f'e/{host}-evidence/verify-{tc}.log' for host in ('linux','intel','arm') for tc in ('stable','1.85.0')]
for path in gate_logs:
    data=path.read_text(encoding='utf-8-sig')
    assert 'NBReq verification complete: all 24 steps passed' in data,path
    assert 'm3_short_vectored_writes_preserve_header_body_order_and_release_after_drain ... ok' in data,path
assert '17 passed; 0 failed' in (lab/'e/windows-x86.log').read_text()
for root,count in [(lab/'e/windows-comparison',60),(lab/'e/linux-evidence/comparison',60),(lab/'e/windows-timing-v2',18),(lab/'e/linux-evidence/timing-v2',18)]:
    cases=json.loads((root/'results.json').read_text())
    assert len(cases)==count
    assert all(c['valid'] and all(p['joined'] and not p['forced'] and p['exit_code']==0 for p in c['cleanup']) for c in cases)
    prov=json.loads((root/'provenance.json').read_text())
    assert prov['sources']['after']=='a96770653e711daa096aa44d33767d2a55210f0228c0a152a1d251aee81de170'
assert 'M3_TIMING_PASS 18' in (lab/'e/linux-evidence/timing-v2.log').read_text()
assert (lab/'e/linux-evidence/timing-v2.exit').read_text()=='0n'

for line in (lab/'e/source.sha256').read_text().splitlines():
    expected,name=line.split('  ',1)
    path=lab/'e'/name.removeprefix('m3-') if name.startswith('m3-') else Path(name)
    assert digest(path.read_bytes().replace(b'\r\n',b'\n') if name.startswith('m3-') else path.read_bytes())==expected,name

sources={}
for rev in 'abcde':
    original=(lab if rev in 'ab' else lab/rev)/f'nbreq-m3-20260908-{rev}.tar.gz'
    destination=public/original.name
    assert not destination.exists()
    shutil.copy2(original,destination)
    with tarfile.open(destination) as archive:
        manifest=archive.extractfile('nbreq/m3-source.sha256').read()
        for row in manifest.decode().splitlines():
            expected,name=row.split('  ',1)
            assert digest(archive.extractfile('nbreq/'+name).read())==expected
    sources[rev]=dict(path=str(destination).replace('\\','/'),sha256=digest(destination.read_bytes()),manifest_sha256=digest(manifest))

files={}
extensions={'.log','.json','.txt','.stderr','.exit','.sha256','.py','.ps1','.sh','.der'}
for path in sorted(lab.rglob('*')):
    name=path.relative_to(lab)
    if not path.is_file() or path.suffix not in extensions or 'bin' in name.parts or '__pycache__' in name.parts:
        continue
    if any('gds' in part.lower() for part in name.parts):
        continue
    files[str(name).replace('\\','/')]=path.read_bytes()
evidence=pack(public/'nbreq-m3-memory-evidence-20260908.tar.gz',files)

assert (lab/'e/windows-final.exit').read_text(encoding='utf-8-sig').strip()=='0'
for name,count in [('e/gds-http-wrapper.log',16),('e/gds-webrpc-wrapper.log',74),('gds-ureq-http-wrapper.log',2),('gds-ureq-webrpc-wrapper.log',73)]:
    assert f'{count} passed; 0 failed' in (lab/name).read_text(encoding='utf-8-sig'),name
before=json.loads((lab/'gds-installed-dll-before.json').read_text(encoding='utf-8-sig'))
after=json.loads((lab/'e/gds-installed-dll-after.json').read_text(encoding='utf-8-sig'))
assert before['Hash']==after['Hash']==digest((gds/'gds/gds.dll').read_bytes()).upper()
private_files={}
for path in lab.rglob('*'):
    if path.is_file() and 'gds' in path.name.lower():
        private_files['evidence/'+str(path.relative_to(lab)).replace('\\','/')]=path.read_bytes()
for name in ['gds/rust/gds/Cargo.toml','gds/rust/gds/Cargo.lock','gds/rust/gds/build.ps1','gds/rust/gds/src/dplib/dphttpclient.rs','gds/scripts/test_rust.py','gds/BUILD.md','gds/doc/nbreq_memory_controls.md','gds/doc/nbreq_m3_verification.md']:
    private_files['source/'+name]=(gds/name).read_bytes()
private_evidence=pack(private/'nbreq-m3-memory-20260908.tar.gz',private_files)
result=dict(status='verified',final_source='e',sources=sources,evidence=evidence,gds_private_evidence=private_evidence,
    final_full_verifiers=7,windows_x86_m3_tests=17,paired_memory_cases=120,longer_timing_cases=36,configured_cap_cases=4,
    gds_native_tests=dict(http=16,webrpc=74),gds_ureq_only_tests=dict(http=2,webrpc=73),installed_dll_sha256=after['Hash'].lower(),
    gds_adapter_sha256=digest((gds/'gds/rust/gds/src/dplib/dphttpclient.rs').read_bytes()))
(public/'nbreq_m3_artifacts.json').write_text(json.dumps(result,indent=2)+'\n')
(private/'nbreq_m3_artifacts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
