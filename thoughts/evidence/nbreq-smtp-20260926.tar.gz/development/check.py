"""Run one bounded SMTP development check through the existing audited supervisor."""
import argparse
import importlib.util
import os
from pathlib import Path
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
parser.add_argument('--label', required=True)
parser.add_argument('--timeout', type=int, default=300)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
root = args.root.resolve()
out = args.out.resolve()
if not args.label.replace('-', '').replace('_', '').isalnum():
    parser.error('label must contain only letters, digits, hyphens or underscores')
if args.timeout <= 0:
    parser.error('timeout must be positive')
argv = args.command[1:] if args.command[:1] == ['--'] else args.command
if not argv:
    parser.error('supply a command after --')
out.mkdir(parents=True, exist_ok=True)
if (out / (args.label + '.log')).exists():
    parser.error('use a new label; preserve previous evidence')
spec = importlib.util.spec_from_file_location('smtp_gate', Path(__file__).with_name('gate.py'))
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)

supervisor.command(argv, root, out, args.label, dict(os.environ), args.timeout)
print(args.label + ': passed', flush=True)
