"""Retain only this SMTP proof's bridge audit records, without duplicate transfer payloads."""
import hashlib
import json
from pathlib import Path

lab = Path(__file__).resolve().parent
sessions = Path('C:/User/SecuritasNew/gds/scripts/sessions')
selected = {
    'putty_bridge': ['20260925-161136-10770a88', '20260925-163418-070c2f26',
                     '20260925-163616-2045eabb', '20260925-164026-fc5bc743',
                     '20260925-164116-17e892c6', '20260925-164158-00e39737',
                     '20260925-164233-6c0313cf', '20260925-164302-dcc662bd',
                     '20260925-164449-e0d37faa'],
    'putty_bridge_scaleway_nbreq': ['20260925-163451-20da9e6b',
                                   '20260925-163608-ba656e63', '20260925-164017-114b7ff5'],
    'putty_bridge_intel_mac': ['20260925-163456-c8404428',
                             '20260925-163612-c3978c7c', '20260925-164021-64b49253'],
}
records = []
for queue, ids in selected.items():
    for identifier in ids:
        file = sessions / queue / 'results' / (identifier + '.json')
        original = file.read_bytes()
        record = json.loads(original.decode('utf-8-sig'))
        assert record['ok'] and record['exit_code'] == 0
        record['original_result_sha256'] = hashlib.sha256(original).hexdigest()
        record['queue'] = queue
        try:
            output = json.loads(record['output'])
        except json.JSONDecodeError:
            output = None
        if isinstance(output, dict) and 'base64' in output:
            output.pop('base64')
            record['output'] = output
            record['transfer_payload_omitted'] = 'Already verified and retained as extracted evidence files'
        records.append(record)
(lab / 'bridge-records.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print('Retained {} successful bridge audit records'.format(len(records)))
