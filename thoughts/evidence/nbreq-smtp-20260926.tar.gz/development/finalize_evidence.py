"""Record frozen-source/Win32 provenance and bundle reviewed SMTP evidence only."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import tarfile

LAB = Path(__file__).resolve().parent
ROOT = LAB.parent / 'worktrees' / 'nbreq-smtp'
COMMIT = 'd5c0ba13a94261b5b5496c0a8ef63b0e48cb0978'
SOURCE = '642b601e0dc17d080c47a60aae7ecfdfe394ece91c4574e077ea766f564ed3e2'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def provenance():
    manifest_path = LAB / 'd5c0ba13a942-source.json'
    assert digest(manifest_path.read_bytes()) == SOURCE
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    assert manifest['commit'] == COMMIT
    frozen = LAB / 'frozen-d5c0ba13a942'
    for name, expected in manifest['files'].items():
        assert digest((frozen / name).read_bytes()) == expected, name
        if name not in ('smtp-gate.py', 'smtp-collect.py', 'smtp-live.py'):
            assert digest((ROOT / name).read_bytes()) == expected, name
    win32 = LAB / 'windows32-d5c0ba13a942'
    log = (win32 / 'native-win32-tests.log').read_text(encoding='utf-8')
    artifacts = {}
    for name in ('smtp_integration-f37b16008d563bfa.exe', 'validation-ad605ccdd7a8fc69.exe'):
        binary = win32 / 'build' / 'i686-pc-windows-msvc' / 'debug' / 'deps' / name
        assert name in log
        data = binary.read_bytes()
        assert data[:2] == b'MZ'
        offset = struct.unpack_from('<I', data, 0x3c)[0]
        assert data[offset:offset + 4] == b'PE\0\0'
        machine = struct.unpack_from('<H', data, offset + 4)[0]
        assert machine == 0x14c
        artifacts[name] = dict(machine='0x014c (Intel 386)', sha256=digest(data))
    payload = dict(commit=COMMIT, source=SOURCE, source_files_verified=len(manifest['files']),
                   frozen_source_directory=str(frozen),
                   win32_source_binding='Root invoked the recorded command from this frozen source directory; raw Cargo compile lines independently name this directory. This file records post-test hash verification, not a contemporaneous launch record.',
                   scope='Post-test frozen source, matching worktree source, and actual executed Win32 test PE headers',
                   win32_test_binaries=artifacts)
    (LAB / 'final-provenance.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(payload, indent=2))


def bundle():
    inputs = {}

    def include(path, name):
        assert path.is_file() and not path.is_symlink(), str(path)
        assert path.stat().st_size <= 32 * 1024 * 1024
        assert name not in inputs
        data = path.read_bytes()
        assert (b'-----BEGIN ' + b'PRIVATE KEY-----') not in data, name
        assert (b'-----BEGIN RSA ' + b'PRIVATE KEY-----') not in data, name
        inputs[name] = data

    def tree(folder, prefix):
        assert folder.is_dir(), str(folder)
        for current, dirs, files in os.walk(folder):
            dirs[:] = sorted(d for d in dirs if not d.startswith('build')
                             and d not in ('certs', '__pycache__', '.git'))
            for name in sorted(files):
                file = Path(current) / name
                if file.suffix not in ('.json', '.jsonl', '.log', '.txt', '.eml'):
                    continue
                assert folder.resolve() in file.resolve().parents
                include(file, prefix + '/' + file.relative_to(folder).as_posix())

    for name in ('windows-d5c0ba13a942', 'windows32-d5c0ba13a942',
                 'linux-d5c0ba13a942', 'intel-d5c0ba13a942', 'arm-d5c0ba13a942',
                 'owner-live-d5c0ba13a942', 'checks', 'live'):
        tree(LAB / name, name)
    for file in sorted(LAB.iterdir()):
        if file.is_file() and file.suffix in ('.log', '.txt', '.json', '.py'):
            include(file, 'development/' + file.name)
    include(LAB / 'nbreq-smtp-d5c0ba13a942-source.tar.gz', 'source/nbreq-smtp-d5c0ba13a942-source.tar.gz')
    archive = ROOT / 'thoughts' / 'evidence' / 'nbreq-smtp-20260926.tar.gz'
    index = archive.with_name('nbreq_smtp_artifacts.json')
    assert not archive.exists() and not index.exists(), 'Preserve earlier evidence'
    manifest = dict(production_commit=COMMIT, source_manifest_sha256=SOURCE,
                    files={name: dict(sha256=digest(data), bytes=len(data))
                           for name, data in sorted(inputs.items())})
    payload = json.dumps(manifest, indent=2).encode('utf-8')
    with tarfile.open(archive, 'x:gz', compresslevel=9) as output:
        for name, data in sorted(list(inputs.items()) + [('manifest.json', payload)]):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(data), 0o644
            output.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as output:
        assert len(output.getmembers()) == len(inputs) + 1
        for name, expected in manifest['files'].items():
            assert digest(output.extractfile(name).read()) == expected['sha256']
    summary = dict(production_commit=COMMIT, source_manifest_sha256=SOURCE,
                   archive=archive.name, bytes=archive.stat().st_size,
                   sha256=digest(archive.read_bytes()), files=len(inputs),
                   uncompressed_bytes=sum(map(len, inputs.values())),
                   excludes=['build trees', 'executables', 'fixture private keys', 'credentials', 'GDS source'],
                   manifest=manifest)
    index.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in summary.items() if key != 'manifest'}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['provenance', 'bundle'])
    args = parser.parse_args()
    provenance() if args.mode == 'provenance' else bundle()
