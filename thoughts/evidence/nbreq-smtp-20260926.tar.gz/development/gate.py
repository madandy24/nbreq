"""Bounded, frozen-source SMTP checks; never submits external mail."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temporary.replace(path)


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def stop(child, log):
    if child.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'],
                       stdout=log, stderr=subprocess.STDOUT, timeout=15)
    else:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    child.wait(timeout=15)


def command(argv, root, out, label, env, timeout):
    print(label, flush=True)
    record = dict(command=argv, timeout_seconds=timeout)
    started = time.monotonic()
    with (out / (label + '.log')).open('xb') as log:
        child = subprocess.Popen(argv, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=os.name != 'nt')
        try:
            write(out / 'command.json', dict(label=label, pid=child.pid, **record))
            record['exit_code'] = child.wait(timeout=timeout)
        except BaseException as error:
            record['failure'] = repr(error)
            stop(child, log)
            raise
        finally:
            record['elapsed_seconds'] = time.monotonic() - started
            write(out / (label + '.result.json'), record)
    if record['exit_code']:
        raise RuntimeError(label + ' failed with exit ' + str(record['exit_code']))


def verify_source(root):
    raw = (root / 'smtp-source.json').read_bytes()
    manifest = json.loads(raw)
    for name, expected in manifest['files'].items():
        path = (root / name).resolve()
        if root not in path.parents or not path.is_file() or path.is_symlink():
            raise RuntimeError('invalid source path: ' + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('source mismatch: ' + name)
    return hashlib.sha256(raw).hexdigest(), manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['launch', 'run'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--msrv', action='store_true')
    parser.add_argument('--nbreq-regressions', action='store_true')
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    if args.mode == 'launch':
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, '-B', str(Path(__file__).resolve()), 'run',
                '--root', str(root), '--out', str(out)]
        if args.msrv:
            argv.append('--msrv')
        if args.nbreq_regressions:
            argv.append('--nbreq-regressions')
        with (out / 'job.log').open('xb') as log:
            child = None
            try:
                child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                         start_new_session=os.name != 'nt', close_fds=True)
                record = dict(pid=child.pid, command=argv, out=str(out))
                write(out / 'launch.json', record)
            except BaseException:
                if child is not None:
                    stop(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0

    started = time.monotonic()
    failure, source, binary_hash = None, None, None
    try:
        source, manifest = verify_source(root)
        write(out / 'host.json', dict(platform=platform.platform(), machine=platform.machine(),
                                     python=sys.version, source=source, commit=manifest['commit'],
                                     started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        env = dict(os.environ)
        env['PATH'] = str(Path.home() / '.cargo' / 'bin') + os.pathsep + env.get('PATH', '')
        env['CARGO_TARGET_DIR'] = str(out / 'build')
        env['CARGO_BUILD_JOBS'] = '2'
        env['CARGO_INCREMENTAL'] = '0'
        env['CARGO_PROFILE_DEV_DEBUG'] = '0'
        env['CARGO_PROFILE_TEST_DEBUG'] = '0'
        suffix = '.exe' if os.name == 'nt' else ''
        cargo = str(Path.home() / '.cargo' / 'bin' / ('cargo' + suffix))
        rustc = str(Path(cargo).with_name('rustc' + suffix))
        for version, label in [('stable', 'stable')] + ([('1.85.0', 'msrv')] if args.msrv else []):
            env['RUSTUP_TOOLCHAIN'] = version
            command([rustc, '+' + version, '-vV'], root, out, label + '-compiler', env, 30)
            command([cargo, '+' + version, 'fetch', '--locked'], root, out, label + '-fetch', env, 300)
            command([cargo, '+' + version, 'test', '--locked', '--offline', '-p', 'nbreq-smtp',
                     '--all-targets'], root, out, label + '-tests', env, 900)
            command([cargo, '+' + version, 'test', '--locked', '--offline', '-p', 'nbreq-smtp',
                     '--doc'], root, out, label + '-doc', env, 600)
            if version == 'stable':
                command([cargo, '+stable', 'clippy', '--locked', '--offline', '-p', 'nbreq-smtp',
                         '--all-targets', '--', '-D', 'warnings'], root, out, 'stable-clippy', env, 600)
                command([cargo, '+stable', 'build', '--locked', '--offline', '-p', 'nbreq-smtp',
                         '--examples'], root, out, 'stable-examples', env, 600)
                if args.nbreq_regressions:
                    command([cargo, '+stable', 'test', '--locked', '--offline', '-p', 'nbreq',
                             '--all-features'], root, out, 'nbreq-regressions', env, 1200)
        # An MSRV all-targets build may replace the executable under the shared target
        # directory. Rebuild the exact live example with stable last, then bind its bytes
        # to this successful gate result.
        env['RUSTUP_TOOLCHAIN'] = 'stable'
        command([cargo, '+stable', 'build', '--locked', '--offline', '-p', 'nbreq-smtp',
                 '--example', 'send_message'], root, out, 'frozen-send-message', env, 600)
        binary = out / 'build' / 'debug' / 'examples' / ('send_message' + suffix)
        if not binary.is_file() or binary.is_symlink():
            raise RuntimeError('frozen SMTP example binary missing or not a regular file')
        binary_hash = sha256_file(binary)
        final_source, _ = verify_source(root)
        if source != final_source:
            raise RuntimeError('manifest changed during gate')
    except BaseException as error:
        failure = repr(error)
    result = dict(status='failed' if failure else 'passed', failure=failure, source=source,
                  send_message_binary_sha256=binary_hash,
                  elapsed_seconds=time.monotonic() - started, pid=os.getpid())
    write(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


if __name__ == '__main__':
    raise SystemExit(main())
