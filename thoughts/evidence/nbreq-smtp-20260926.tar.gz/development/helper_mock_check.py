"""No-network checks for the frozen SMTP gate and one-shot live launcher."""

import ast
import hashlib
import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory


HERE = Path(__file__).resolve().parent


def load(name, path):
    ast.parse(path.read_text(encoding="utf-8"))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


gate = load("smtp_gate_mock", HERE / "gate.py")
live = load("smtp_live_mock", HERE / "live.py")

expected_statuses = {
    0: "server-accepted",
    2: "server-rejected",
    3: "not-accepted",
    4: "uncertain",
    1: "uncertain",
    None: "uncertain",
}
for exit_code, expected in expected_statuses.items():
    assert live.classify_result(exit_code, None) == expected
assert live.classify_result(0, "launch failed") == "uncertain"
assert live.classify_result({}, None) == "uncertain"

with TemporaryDirectory(prefix="nbreq-smtp-helper-mock-") as folder:
    temporary = Path(folder)
    binary = temporary / "send_message"
    binary.write_bytes(b"frozen-reviewed-example")
    reviewed_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
    assert gate.sha256_file(binary) == reviewed_hash
    assert live.checked_binary_hash(binary, reviewed_hash, gate.sha256_file) == reviewed_hash
    binary.write_bytes(b"changed-example")
    try:
        live.checked_binary_hash(binary, reviewed_hash, gate.sha256_file)
    except RuntimeError:
        pass
    else:
        raise AssertionError("changed executable passed the frozen gate hash")

    attempt = temporary / "attempt"
    attempt.mkdir()
    result = attempt / "result.json"
    result.write_text("original result", encoding="utf-8")
    live.acquire_attempt(attempt, "source hash", reviewed_hash)
    try:
        live.acquire_attempt(attempt, "source hash", reviewed_hash)
    except FileExistsError:
        pass
    else:
        raise AssertionError("duplicate attempt token was acquired")
    assert result.read_text(encoding="utf-8") == "original result"

print("helper syntax, status, binary hash, and duplicate token checks passed")
