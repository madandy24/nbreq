"""Validate bridge-returned evidence chunks and extract only regular evidence files."""
import argparse
import base64
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--result', type=Path, action='append', required=True)
p.add_argument('--archive', type=Path, required=True)
p.add_argument('--sha256', required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
chunks = {}
parts = None
for file in a.result:
    response = json.loads(file.read_text(encoding='utf-8-sig'))
    assert response['ok'] and response['exit_code'] == 0, response
    payload = json.loads(response['output'])
    assert payload['sha256'] == a.sha256
    chunk = base64.b64decode(payload['base64'], validate=True)
    assert hashlib.sha256(chunk).hexdigest() == payload['chunk_sha256']
    assert payload['part'] not in chunks
    if parts is not None:
        assert parts == payload['parts']
    parts = payload['parts']
    chunks[payload['part']] = chunk
assert sorted(chunks) == list(range(parts))
data = b''.join(chunks[i] for i in range(parts))
assert hashlib.sha256(data).hexdigest() == a.sha256
with a.archive.open('xb') as file:
    file.write(data)
a.out.mkdir(parents=True, exist_ok=False)
with tarfile.open(a.archive, 'r:gz') as bundle:
    members = bundle.getmembers()
    names = set()
    for member in members:
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute()
        assert '..' not in path.parts and '\\' not in member.name
        assert member.name not in names and member.size <= 32 * 1024 * 1024
        names.add(member.name)
    for member in members:
        target = a.out.joinpath(*PurePosixPath(member.name).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as file:
            file.write(bundle.extractfile(member).read())
manifest = json.loads((a.out / 'evidence-manifest.json').read_text(encoding='utf-8'))
assert names == set(manifest['files']) | {'evidence-manifest.json'}
for name, expected in manifest['files'].items():
    assert hashlib.sha256((a.out / name).read_bytes()).hexdigest() == expected, name
print(json.dumps(dict(out=str(a.out), files=len(manifest['files']), sha256=a.sha256,
                      result=manifest['result']), indent=2))
