"""One explicitly authorized owner test mail, after the frozen Linux SMTP gate passes."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

MESSAGE_SHA256 = '5a08a7b2ad6d62727e8137a89754906b2caf666b86fb041b90b9dec624173f34'
EHLO = '[IPv6:2400:8907::f03c:92ff:fe87:ceda]'


def classify_result(exit_code, failure):
    """Unknown or interrupted process termination is always delivery-uncertain."""
    if type(exit_code) is not int:
        return 'uncertain'
    if failure is not None and exit_code == 0:
        return 'uncertain'
    return {0: 'server-accepted', 2: 'server-rejected',
            3: 'not-accepted', 4: 'uncertain'}.get(exit_code, 'uncertain')


def acquire_attempt(out, source, binary_hash):
    """Claim the single run atomically, before any terminal result may be written."""
    with (out / 'attempt.token').open('xb') as token:
        token.write(json.dumps(dict(pid=os.getpid(), source=source,
                                    binary_sha256=binary_hash)).encode('utf-8'))


def checked_binary_hash(binary, expected, sha256_file):
    if not binary.is_file() or binary.is_symlink():
        raise RuntimeError('frozen SMTP example binary is missing or not regular')
    actual = sha256_file(binary)
    if actual != expected:
        raise RuntimeError('SMTP example binary changed after the frozen gate')
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['launch', 'run'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--gate', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--message', type=Path, required=True)
    args = parser.parse_args()
    root, gate, out, message = (p.resolve() for p in (args.root, args.gate, args.out, args.message))
    if out != gate / 'owner-live':
        raise RuntimeError('use the single fixed owner-live attempt directory for this gate')
    if os.name != 'posix' or socket.gethostname() != 'gds-srv-test2':
        raise RuntimeError('this one-mail proof is authorized for the identified Linux test host')
    spec = importlib.util.spec_from_file_location('smtp_gate', root / 'smtp-gate.py')
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    source, manifest = supervisor.verify_source(root)
    gate_result = json.loads((gate / 'result.json').read_text(encoding='utf-8'))
    if (gate_result.get('status') != 'passed' or gate_result.get('source') != source
            or not gate_result.get('send_message_binary_sha256')):
        raise RuntimeError('matching frozen platform gate must pass before mail submission')
    if hashlib.sha256(message.read_bytes()).hexdigest() != MESSAGE_SHA256:
        raise RuntimeError('only the exact reviewed harmless owner test message is authorized')
    binary = gate / 'build' / 'debug' / 'examples' / 'send_message'
    binary_hash = checked_binary_hash(binary, gate_result['send_message_binary_sha256'],
                                      supervisor.sha256_file)
    argv = [str(binary), 'cavesvr3.caverock.com', '25', 'starttls', EHLO,
            'andrew@gdsresponse.com', 'andrew@caverock.com', str(message)]
    if args.mode == 'launch':
        # Never reuse an attempt folder: a missing final result is not permission to resend.
        out.mkdir(parents=True, exist_ok=False)
        intent = dict(source=source, commit=manifest['commit'], message_sha256=MESSAGE_SHA256,
                      binary_sha256=binary_hash, command=argv, retry_policy='never automatic')
        supervisor.write(out / 'intent.json', intent)
        worker = [sys.executable, '-B', str(Path(__file__).resolve()), 'run', '--root', str(root),
                  '--gate', str(gate), '--out', str(out), '--message', str(message)]
        with (out / 'job.log').open('xb') as log:
            child = None
            try:
                child = subprocess.Popen(worker, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                         start_new_session=True, close_fds=True)
                supervisor.write(out / 'launch.json', dict(pid=child.pid, command=worker))
            except BaseException:
                if child is not None:
                    supervisor.stop(child, log)
                raise
        print(json.dumps(dict(pid=child.pid, out=str(out), message_sha256=MESSAGE_SHA256)))
        return 0
    intent = json.loads((out / 'intent.json').read_text(encoding='utf-8'))
    if (intent.get('command') != argv or intent.get('binary_sha256') != binary_hash
            or intent.get('source') != source or intent.get('commit') != manifest['commit']
            or intent.get('message_sha256') != MESSAGE_SHA256):
        raise RuntimeError('attempt identity changed; do not submit')
    # Exclusive command log also prevents accidentally running this mode twice.
    if (out / 'live-send.log').exists() or (out / 'result.json').exists():
        raise RuntimeError('this attempt already started; preserve its evidence and do not resend')
    # Acquire the one-shot token before the result-writing try. A duplicate caller
    # must never write over the first attempt's terminal evidence.
    acquire_attempt(out, source, binary_hash)
    failure = None
    try:
        supervisor.command(argv, root, out, 'live-send', dict(os.environ), 150)
    except BaseException as error:
        failure = repr(error)
    command_result_path = out / 'live-send.result.json'
    try:
        command_result = (json.loads(command_result_path.read_text(encoding='utf-8'))
                          if command_result_path.is_file() else {})
    except BaseException as error:
        command_result = {}
        failure = (failure + '; ' if failure else '') + repr(error)
    exit_code = command_result.get('exit_code')
    status = classify_result(exit_code, failure)
    result = dict(status=status, failure=failure, cli_exit_code=exit_code,
                  source=source, message_sha256=MESSAGE_SHA256, binary_sha256=binary_hash,
                  mailbox_delivery='not independently confirmed', automatic_retry=False)
    supervisor.write(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 0 if status == 'server-accepted' else 1


if __name__ == '__main__':
    raise SystemExit(main())
