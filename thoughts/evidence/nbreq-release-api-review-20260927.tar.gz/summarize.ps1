$ErrorActionPreference = 'Stop'
$lab = 'C:/User/projects/nbreq/target/api-release-review-20260927'
$inputs = Get-Content "$lab/inputs.json" -Raw | ConvertFrom-Json
$modes = @()
foreach ($name in @('default','native-only','minimal','test-support')) {
    $metadata = Get-Content "$lab/metadata-$name.stdout.log" -Raw | ConvertFrom-Json
    $nbreq = @($metadata.packages | Where-Object name -eq 'nbreq')[0]
    if ($null -ne $nbreq.source -or ($nbreq.manifest_path -replace '\\','/') -ne "$($inputs.checkout)/Cargo.toml") { throw 'Wrong nbreq path' }
    $node = @($metadata.resolve.nodes | Where-Object id -eq $nbreq.id)[0]
    $testlog = Get-Content "$lab/test-$name.stdout.log" -Raw
    if ($testlog -notmatch 'test result: ok\. (\d+) passed; 0 failed;') { throw 'No passed result' }
    $modes += [ordered]@{mode=$name;tests_passed=[int]$Matches[1];nbreq_id=$nbreq.id;source=$nbreq.source;manifest_path=$nbreq.manifest_path;nbreq_features=$node.features;metadata_sha256=(Get-FileHash "$lab/metadata-$name.stdout.log").Hash}
}
foreach ($entry in $inputs.consumer_source) {
    $relative = $entry.path -replace '^tools/release-consumer/',''
    if ($relative -ne 'Cargo.toml' -and (Get-FileHash "$lab/consumer/$relative").Hash -ne $entry.sha256) { throw 'Copied consumer source changed' }
}
$tlsmeta = Get-Content "$lab/tls-metadata.stdout.log" -Raw | ConvertFrom-Json
$tlspkg = @($tlsmeta.packages | Where-Object name -eq 'nbreq')[0]
if ($null -ne $tlspkg.source -or ($tlspkg.manifest_path -replace '\\','/') -ne "$($inputs.checkout)/Cargo.toml") { throw 'Wrong TLS nbreq path' }
$beforeHash = (Get-FileHash "$lab/checkout-hashes-before.json").Hash
$afterHash = (Get-FileHash "$lab/checkout-hashes-after.json").Hash
if ($beforeHash -ne $afterHash) { throw 'Checkout changed' }
$summary = [ordered]@{
    status='passed';baseline=$inputs.baseline;current=$inputs.head;checkout=$inputs.checkout;
    rustc=$inputs.rustc;cargo=$inputs.cargo;consumer_source=$inputs.consumer_source;
    source_identity='All six old Rust consumer/probe files match published-tag blobs and copied-file SHA256; original manifest matches tag and only lab manifest gains path patch.';
    dependency_resolution=$inputs.resolution;lock_sha256=(Get-FileHash "$lab/consumer-Cargo.lock").Hash;
    modes=$modes;total_old_consumer_tests=29;
    import_probes=@((Get-Content "$lab/results.json" -Raw | ConvertFrom-Json) | Where-Object { $_.label -match '^(resolver|testing)-' });
    tls_api_checks=(Get-Content "$lab/tls-results.json" -Raw | ConvertFrom-Json);
    tls_nbreq_identity=[ordered]@{id=$tlspkg.id;source=$tlspkg.source;manifest_path=$tlspkg.manifest_path};
    checkout_source_hash_manifest_sha256=$beforeHash;checkout_unchanged=($beforeHash -eq $afterHash);
    limitations=@('Windows x86_64 stable only; no fresh MSRV or other-platform execution','Representative unchanged downstream consumers, not exhaustive mechanical SemVer analysis','Offline cached registry graph with explicit current root and helper paths; not published-package or registry-only proof','TLS API checks compile typed calls and do not execute TLS handshakes','No cargo-semver-checks installation, production edits, version edits, release/publish actions');
    previous_evidence='thoughts/nbreq_020_consumer_readiness.md records older package/platform tests; historical results not attributed to this HEAD.'
}
$summary | ConvertTo-Json -Depth 12 | Set-Content "$lab/summary.json"
$files = @(Get-ChildItem -LiteralPath $lab -File)
$files += @(Get-ChildItem -LiteralPath "$lab/consumer","$lab/tls-consumer" -File -Recurse)
$files | Where-Object Name -ne 'evidence-hashes.json' | ForEach-Object { [ordered]@{path=$_.FullName;sha256=(Get-FileHash $_.FullName).Hash} } | ConvertTo-Json -Depth 5 | Set-Content "$lab/evidence-hashes.json"
Write-Output 'Summary and evidence hashes saved.'
