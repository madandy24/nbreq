#![allow(dead_code)]
use nbreq::{Engine, EngineConfig, Error, ExecuteError, PendingTlsConnect, TcpConnectRequest,
    TcpConnection, TcpConnector, TlsConnectCompletion, TlsConnection, TlsOptions, TlsTrust};
use std::time::Duration;
fn options() -> Result<(EngineConfig, TlsOptions), Error> {
    let config = EngineConfig::spawned()
        .with_tls_trust(TlsTrust::SuppliedRootsOnly)
        .with_additional_tls_root_certificate(Vec::new());
    let tls = TlsOptions::new("localhost")?.handshake_timeout(Duration::from_secs(5));
    let _: &str = tls.server_name();
    let _: Duration = tls.timeout();
    Ok((config, tls))
}
fn connect(connector: &TcpConnector, request: TcpConnectRequest, options: TlsOptions)
    -> Result<TlsConnection, ExecuteError> { connector.execute_tls(request, options) }
fn submit(connector: &TcpConnector, request: TcpConnectRequest, options: TlsOptions)
    -> Result<PendingTlsConnect, Error> { connector.submit_tls(request, options) }
fn upgrade(connection: TcpConnection, options: TlsOptions)
    -> Result<TlsConnection, ExecuteError> { connection.into_tls(options) }
fn passive_upgrade(connection: TcpConnection, options: TlsOptions)
    -> Result<PendingTlsConnect, Error> { connection.submit_tls(options) }
fn manual(engine: &mut Engine, pending: PendingTlsConnect)
    -> Result<TlsConnectCompletion, Error> { engine.drive_until(pending) }
fn streams(connection: TlsConnection) {
    let (mut reader, mut writer) = connection.split();
    let _ = reader.try_read(&mut [0u8; 16]);
    let _ = writer.try_send(vec![1]);
    let _ = writer.try_finish();
}
