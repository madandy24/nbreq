$ErrorActionPreference = 'Stop'
$lab = 'C:/User/projects/nbreq/target/api-release-review-20260927'
$checkout = 'C:/User/projects/nbreq/target/worktrees/nbreq-smtp'
$tls = "$lab/tls-consumer"
New-Item -ItemType Directory -Path "$tls/src" -Force | Out-Null
@"
[package]
name = 'nbreq-tls-api-review'
version = '0.0.0'
edition = '2024'
publish = false
[workspace]
[features]
default = ['nbreq/default']
native = ['nbreq/native']
[dependencies]
nbreq = { path = '$checkout', default-features = false }
"@ | Set-Content "$tls/Cargo.toml"
@'
#![allow(dead_code)]
use nbreq::{Engine, EngineConfig, Error, ExecuteError, PendingTlsConnect, TcpConnectRequest,
    TcpConnection, TcpConnector, TlsConnectCompletion, TlsConnection, TlsOptions, TlsTrust};
use std::time::Duration;
fn options() -> Result<(EngineConfig, TlsOptions), Error> {
    let config = EngineConfig::spawned()
        .with_tls_trust(TlsTrust::SuppliedRootsOnly)
        .with_additional_tls_root_certificate(Vec::new());
    let tls = TlsOptions::new("localhost")?.handshake_timeout(Duration::from_secs(5));
    let _: &str = tls.server_name();
    let _: Duration = tls.timeout();
    Ok((config, tls))
}
fn connect(connector: &TcpConnector, request: TcpConnectRequest, options: TlsOptions)
    -> Result<TlsConnection, ExecuteError> { connector.execute_tls(request, options) }
fn submit(connector: &TcpConnector, request: TcpConnectRequest, options: TlsOptions)
    -> Result<PendingTlsConnect, Error> { connector.submit_tls(request, options) }
fn upgrade(connection: TcpConnection, options: TlsOptions)
    -> Result<TlsConnection, ExecuteError> { connection.into_tls(options) }
fn passive_upgrade(connection: TcpConnection, options: TlsOptions)
    -> Result<PendingTlsConnect, Error> { connection.submit_tls(options) }
fn manual(engine: &mut Engine, pending: PendingTlsConnect)
    -> Result<TlsConnectCompletion, Error> { engine.drive_until(pending) }
fn streams(connection: TlsConnection) {
    let (mut reader, mut writer) = connection.split();
    let _ = reader.try_read(&mut [0u8; 16]);
    let _ = writer.try_send(vec![1]);
    let _ = writer.try_finish();
}
'@ | Set-Content "$tls/src/lib.rs"
$env:CARGO_TARGET_DIR = "$lab/build"
$results = [System.Collections.Generic.List[object]]::new()
function Run([string]$label, [string[]]$a) {
    & cargo @a 1> "$lab/$label.stdout.log" 2> "$lab/$label.stderr.log"
    $code = $LASTEXITCODE
    $results.Add([ordered]@{label=$label;command=@('cargo')+$a;cwd=(Get-Location).Path;exit=$code;passed=($code -eq 0)})
    $results | ConvertTo-Json -Depth 6 | Set-Content "$lab/tls-results.json"
    Write-Output "$label exit=$code"
    if ($code -ne 0) { throw "$label failed" }
}
Push-Location $tls
Run 'tls-resolve' @('generate-lockfile','--offline')
Run 'tls-default' @('check','--locked','--offline','--lib')
Run 'tls-native-only' @('check','--locked','--offline','--lib','--no-default-features','--features','native')
Run 'tls-minimal' @('check','--locked','--offline','--lib','--no-default-features')
Run 'tls-metadata' @('metadata','--locked','--offline','--format-version','1')
Pop-Location
