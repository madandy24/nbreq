$ErrorActionPreference = 'Stop'
$lab = 'C:/User/projects/nbreq/target/api-release-review-20260927'
$checkout = 'C:/User/projects/nbreq/target/worktrees/nbreq-smtp'
$consumer = "$lab/consumer"
New-Item -ItemType Directory -Path $consumer -Force | Out-Null
Copy-Item "$checkout/tools/release-consumer/src","$checkout/tools/release-consumer/probes","$checkout/tools/release-consumer/Cargo.toml" -Destination $consumer -Recurse
Add-Content "$consumer/Cargo.toml" "`n[patch.crates-io]`nnbreq = { path = '$checkout' }"
$env:CARGO_TARGET_DIR = "$lab/build"
$results = [System.Collections.Generic.List[object]]::new()
function Run([string]$label, [string[]]$a, [int]$expected=0, [string]$contains='') {
    Write-Output "Starting $label"
    $timer = [Diagnostics.Stopwatch]::StartNew()
    & cargo @a 1> "$lab/$label.stdout.log" 2> "$lab/$label.stderr.log"
    $exit = $LASTEXITCODE
    $timer.Stop()
    $log = (Get-Content "$lab/$label.stdout.log","$lab/$label.stderr.log" -Raw) -join "`n"
    $passed = $exit -eq $expected -and ($contains -eq '' -or $log.Contains($contains))
    $results.Add([ordered]@{label=$label;command=@('cargo')+$a;cwd=(Get-Location).Path;exit=$exit;expected=$expected;passed=$passed;seconds=$timer.Elapsed.TotalSeconds})
    $results | ConvertTo-Json -Depth 6 | Set-Content "$lab/results.json"
    Write-Output "$label exit=$exit passed=$passed seconds=$($timer.Elapsed.TotalSeconds)"
    if (-not $passed) { throw "$label failed" }
}
Push-Location $checkout
$head = (& git rev-parse HEAD).Trim()
$base = (& git rev-parse 'v0.2.0^{}').Trim()
$identity = @()
foreach ($p in (& git ls-files tools/release-consumer/src tools/release-consumer/probes tools/release-consumer/Cargo.toml)) {
    $old = (& git rev-parse "${base}:$p").Trim()
    $now = (& git rev-parse "HEAD:$p").Trim()
    if ($old -ne $now) { throw "Consumer changed: $p" }
    $identity += [ordered]@{path=$p;old_blob=$old;current_blob=$now;sha256=(Get-FileHash "$checkout/$p").Hash}
}
$hashes = @()
foreach ($p in (& git ls-files src Cargo.toml Cargo.lock support)) { $hashes += [ordered]@{path=$p;sha256=(Get-FileHash "$checkout/$p").Hash} }
$hashes | ConvertTo-Json -Depth 5 | Set-Content "$lab/checkout-hashes-before.json"
[ordered]@{head=$head;baseline=$base;checkout=$checkout;consumer_source=$identity;initial_status=@(& git status --porcelain);rustc=@(& rustc -Vv);cargo=@(& cargo -V);resolution='Offline cached registry; root nbreq explicitly patched to current checkout; support dependencies use checkout paths'} | ConvertTo-Json -Depth 8 | Set-Content "$lab/inputs.json"
Pop-Location
Push-Location $consumer
Run 'resolve' @('generate-lockfile','--offline')
Run 'metadata-default' @('metadata','--locked','--offline','--format-version','1')
$meta = Get-Content "$lab/metadata-default.stdout.log" -Raw | ConvertFrom-Json
$pkg = @($meta.packages | Where-Object name -eq 'nbreq')
if ($pkg.Count -ne 1 -or $null -ne $pkg[0].source -or ($pkg[0].manifest_path -replace '\\','/') -ne "$checkout/Cargo.toml") { throw 'Incorrect source resolved' }
$modes = @(
    @{label='default';args=@()},
    @{label='native-only';args=@('--no-default-features','--features','native,v020')},
    @{label='minimal';args=@('--no-default-features','--features','v020')},
    @{label='test-support';args=@('--features','test-support')}
)
foreach ($m in $modes) {
    Run "test-$($m.label)" (@('test','--locked','--offline','--lib')+$m.args+@('--','--test-threads=1')) 0 'test result: ok.'
    if ($m.label -ne 'default') { Run "metadata-$($m.label)" (@('metadata','--locked','--offline','--format-version','1')+$m.args) }
}
Run 'resolver-present' @('check','--locked','--offline','--bin','resolver_probe')
Run 'resolver-absent' @('check','--locked','--offline','--bin','resolver_probe','--no-default-features','--features','native,v020') 101 'unresolved import'
Run 'testing-present' @('check','--locked','--offline','--bin','testing_probe','--features','test-support')
Run 'testing-absent' @('check','--locked','--offline','--bin','testing_probe') 101 'unresolved import'
Copy-Item "$consumer/Cargo.lock" "$lab/consumer-Cargo.lock"
Pop-Location
Push-Location $checkout
$after = @()
foreach ($p in (& git ls-files src Cargo.toml Cargo.lock support)) { $after += [ordered]@{path=$p;sha256=(Get-FileHash "$checkout/$p").Hash} }
$after | ConvertTo-Json -Depth 5 | Set-Content "$lab/checkout-hashes-after.json"
if ((Get-FileHash "$lab/checkout-hashes-before.json").Hash -ne (Get-FileHash "$lab/checkout-hashes-after.json").Hash) { throw 'Source changed during checks' }
@(& git status --porcelain) | Set-Content "$lab/final-status.log"
Pop-Location
