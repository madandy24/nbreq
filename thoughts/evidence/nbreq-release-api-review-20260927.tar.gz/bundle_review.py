"""Preserve only API-review consumer sources and technical evidence, never build output."""
import hashlib
import json
from pathlib import Path
import tarfile

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
summary = json.loads((lab / 'summary.json').read_text(encoding='utf-8-sig'))
assert summary['status'] == 'passed'
files = []
for path in lab.rglob('*'):
    relative = path.relative_to(lab)
    if len(relative.parts) > 1 and relative.parts[0] not in {'consumer', 'tls-consumer'}:
        continue
    if path.is_file() and path.suffix in {'.rs', '.toml', '.lock', '.json', '.log', '.ps1', '.py'}:
        assert not path.is_symlink() and lab in path.resolve().parents
        files.append(path)
manifest = {path.relative_to(lab).as_posix(): {'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in sorted(files)}
archive = root / 'thoughts/evidence/nbreq-release-api-review-20260927.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as output:
    for path in sorted(files):
        output.add(path, arcname=path.relative_to(lab).as_posix(), recursive=False)
with tarfile.open(archive, 'r:gz') as check:
    members = check.getmembers()
    assert len(members) == len(manifest)
    for member in members:
        assert member.isfile() and member.name in manifest
        data = check.extractfile(member).read()
        assert len(data) == manifest[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == manifest[member.name]['sha256']
identity = {'archive': archive.name, 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(manifest)}
(root / 'thoughts/evidence/nbreq_release_api_review_artifacts.json').write_text(
    json.dumps({**identity, 'summary': summary, 'files': manifest}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(identity))
