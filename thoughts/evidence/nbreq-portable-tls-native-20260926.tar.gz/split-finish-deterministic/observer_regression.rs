#[cfg(test)]
mod close_observer_regression {
    use super::*;
    #[test]
    fn observes_client_close_already_processed_with_final_handshake_flight() {
        let identity = TestIdentity::localhost();
        let provider = Arc::new(rustls::crypto::ring::default_provider());
        let mut roots = rustls::RootCertStore::empty();
        roots.add(CertificateDer::from(identity.root_der)).expect("test root");
        let config = rustls::ClientConfig::builder_with_provider(provider.clone())
            .with_protocol_versions(&[&rustls::version::TLS13]).expect("protocol")
            .with_root_certificates(roots).with_no_client_auth();
        let server_config = ServerConfig::builder_with_provider(provider)
            .with_protocol_versions(&[&rustls::version::TLS13]).expect("protocol")
            .with_no_client_auth().with_single_cert(vec![identity.leaf_der],
                PrivateKeyDer::Pkcs8(PrivatePkcs8KeyDer::from(identity.key_der))).expect("identity");
        let mut client = rustls::ClientConnection::new(Arc::new(config),
            rustls::pki_types::ServerName::try_from("127.0.0.1").expect("IP")).expect("client");
        let mut server = ServerConnection::new(Arc::new(server_config)).expect("server");
        let mut wire = Vec::new();
        while client.wants_write() { client.write_tls(&mut wire).expect("ClientHello"); }
        server.read_tls(&mut Cursor::new(wire)).expect("server ClientHello input");
        server.process_new_packets().expect("server ClientHello processing");
        let mut wire = Vec::new();
        while server.wants_write() { server.write_tls(&mut wire).expect("server flight"); }
        client.read_tls(&mut Cursor::new(wire)).expect("client handshake input");
        client.process_new_packets().expect("client verified handshake");
        assert!(!client.is_handshaking());
        assert!(server.is_handshaking());
        // Coalesce client Finished, application and close_notify into the server's
        // final handshake read, with no scheduling assumption or NBReq production code.
        client.writer().write_all(b"split-write").expect("application");
        client.send_close_notify();
        let mut wire = Vec::new();
        while client.wants_write() { client.write_tls(&mut wire).expect("final flight"); }
        assert_eq!(server.read_tls(&mut Cursor::new(&wire)).expect("final input"), wire.len());
        let state = server.process_new_packets().expect("server final flight");
        assert!(!server.is_handshaking());
        assert!(state.peer_has_closed());
        assert_eq!(state.plaintext_bytes_to_read(), b"split-write".len());
        eprintln!("precondition: handshake complete, authenticated close latched, {} plaintext bytes buffered", state.plaintext_bytes_to_read());
        let listener = TcpListener::bind("127.0.0.1:0").expect("pair listener");
        let client_socket = TcpStream::connect_timeout(&listener.local_addr().expect("address"), Duration::from_secs(1)).expect("connect");
        let (mut socket, _) = listener.accept().expect("accept");
        socket.set_read_timeout(Some(Duration::from_millis(100))).expect("read bound");
        socket.set_write_timeout(Some(Duration::from_millis(100))).expect("write bound");
        let (events, receiver) = mpsc::channel();
        let observed = observe_client_close(&mut server, &mut socket, &events,
            &AtomicBool::new(false), Instant::now() + Duration::from_secs(1)).expect("observer");
        eprintln!("actual fixture observer returned {observed}");
        assert!(observed, "fixture must recognize close_notify already processed during final handshake read");
        assert_eq!(receiver.recv_timeout(Duration::from_secs(1)).expect("event"),
            Event::PeerCloseNotify { application: b"split-write".to_vec() });
        drop(client_socket);
    }
}
