"""Recheck only the changed TLS fixture against a previously passed full native gate."""
import argparse
import json
import os
from pathlib import Path
import signal

import native_gate
import owned_command as supervisor

def terminate(_signal, _frame):
    raise SystemExit('fixture follow-up gate received SIGTERM')

signal.signal(signal.SIGTERM, terminate)
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--baseline-root', type=Path, required=True)
p.add_argument('--baseline-gate', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
root, baseline, previous, out = (x.resolve() for x in (a.root, a.baseline_root, a.baseline_gate, a.out))
out.mkdir(parents=True, exist_ok=False)
failure, steps, identity, old_identity, delta, record = None, [], None, None, None, None
try:
    identity, manifest = native_gate.verify(root)
    old_identity, old = native_gate.verify(baseline)
    record = json.loads((previous / 'result.json').read_bytes())
    assert record['status'] == 'passed' and record['source'] == old_identity
    assert record['commit'] == old['commit']
    delta = sorted(name for name in set(manifest['files']) | set(old['files'])
                   if manifest['files'].get(name) != old['files'].get(name))
    assert set(delta) == {'tests/support/tcp_tls_fixture.rs', 'tests/support/tcp_tls_fixture_regressions.rs',
                          'snapshot.py', 'fixture_gate.py'}, delta
    probe = Path(record['binaries']['probe']['path'])
    assert supervisor.sha(probe) == record['binaries']['probe']['sha256']
    env = dict(os.environ, RUSTUP_TOOLCHAIN='stable', CARGO_TARGET_DIR=str(previous / 'build'),
               CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_PROFILE_TEST_DEBUG='0',
               CARGO_PROFILE_DEV_DEBUG='0')
    env.pop('CARGO_BUILD_TARGET', None)
    env['PATH'] = str(Path.home() / '.cargo/bin') + os.pathsep + env.get('PATH', '')
    cargo = str(Path.home() / '.cargo/bin/cargo')
    tests = ['--test', 'tcp_tls', '--test', 'tcp_tls_api']
    commands = [
        ('format', [cargo, '+stable', 'fmt', '--all', '--', '--check']),
        ('native-only', [cargo, '+stable', 'test', '--locked', '--offline', '--no-default-features',
                         '--features', 'native'] + tests),
        ('all-features', [cargo, '+stable', 'test', '--locked', '--offline', '--all-features'] + tests),
        ('clippy', [cargo, '+stable', 'clippy', '--locked', '--offline', '--all-features'] + tests +
                   ['--', '-D', 'warnings']),
        ('msrv', [cargo, '+1.85.0', 'test', '--locked', '--offline', '--all-features'] + tests),
    ]
    for label, argv in commands:
        if label == 'msrv':
            env['RUSTUP_TOOLCHAIN'] = '1.85.0'
        supervisor.command(argv, root, out, label, env, 600)
        steps.append(label)
except BaseException as error:
    failure = repr(error)
finally:
    try:
        assert native_gate.verify(root)[0] == identity
        assert native_gate.verify(baseline)[0] == old_identity
        if record:
            assert supervisor.sha(Path(record['binaries']['probe']['path'])) == record['binaries']['probe']['sha256']
    except BaseException as error:
        failure = (failure + '; ' if failure else '') + 'final integrity: ' + repr(error)
    result = dict(status='failed' if failure else 'passed', failure=failure, steps=steps,
                  source=identity, baseline_source=old_identity, delta=delta)
    supervisor.write(out / 'result.json', result)
print(json.dumps(result), flush=True)
if failure:
    raise SystemExit(1)
