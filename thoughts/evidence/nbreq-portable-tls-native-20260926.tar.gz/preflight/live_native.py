"""Bounded unauthenticated IMAPS/SMTP verification using the frozen native gate's probe."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--gate', type=Path, required=True)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
gate, source, out = a.gate.resolve(), a.source.resolve(), a.out.resolve()
sys.path.insert(0, str(source))
import native_gate
import owned_command as supervisor

def terminate(_signum, _frame):
    raise SystemExit('native live TLS probe received SIGTERM')

signal.signal(signal.SIGTERM, terminate)
record = json.loads((gate / 'result.json').read_bytes())
assert record['status'] == 'passed'
identity, manifest = native_gate.verify(source)
assert identity == record['source'] and manifest['commit'] == record['commit']
binary = Path(record['binaries']['probe']['path'])
expected = record['binaries']['probe']['sha256']
assert not binary.is_symlink() and supervisor.sha(binary) == expected
out.mkdir(parents=True, exist_ok=False)
failure, steps = None, []
try:
    for mode, port in [('imaps', '993'), ('smtp', '25')]:
        supervisor.command([str(binary), mode, 'cavesvr3.caverock.com', port, '--bundled-roots'],
                           source, out, mode, dict(os.environ), 60)
        steps.append(mode)
except BaseException as error:
    failure = repr(error)
finally:
    try:
        assert supervisor.sha(binary) == expected and native_gate.verify(source)[0] == identity
    except BaseException as error:
        failure = (failure + '; ' if failure else '') + 'final integrity: ' + repr(error)
    result = dict(status='failed' if failure else 'passed', failure=failure, steps=steps,
                  source=identity, commit=record['commit'], probe_sha256=expected,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    supervisor.write(out / 'result.json', result)
print(json.dumps(result), flush=True)
if failure:
    raise SystemExit(1)
