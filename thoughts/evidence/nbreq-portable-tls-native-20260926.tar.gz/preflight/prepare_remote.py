"""Verify a frozen source/binary archive, then extract regular files into a fresh directory."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile

archive, root = map(Path, sys.argv[1:3])
expected, manifest_name = sys.argv[3:5]
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
with tarfile.open(archive) as bundle:
    members = bundle.getmembers()
    assert len(members) <= 1000 and len({m.name for m in members}) == len(members)
    assert sum(m.size for m in members) < 200 * 1024 * 1024
    for member in members:
        path = PurePosixPath(member.name)
        assert member.isfile() and member.size < 64 * 1024 * 1024
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.name
        assert ':' not in member.name and member.name == path.as_posix()
    manifest = json.loads(bundle.extractfile(manifest_name).read())
    assert {m.name for m in members} == set(manifest['files']) | {manifest_name}
    # Validate every payload before creating the destination.
    for name, digest in manifest['files'].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == digest, name
    root.mkdir(exist_ok=False)
    for member in members:
        destination = root / member.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output:
            output.write(bundle.extractfile(member).read())
print(json.dumps(dict(root=str(root), files=len(members), sha256=expected)))
