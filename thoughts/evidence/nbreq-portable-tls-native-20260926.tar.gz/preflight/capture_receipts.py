"""Preserve only this task's explicit bridge receipts, including failed live outcomes."""
from pathlib import Path
import json

lab = Path(__file__).resolve().parent
queues = Path('C:/User/SecuritasNew/gds/scripts/sessions')
selected = {
    'putty_bridge': ['20260926-025139-cc626b8d'],
    'putty_bridge_intel_mac': '''20260926-025143-8a1e8062 20260926-031037-49d82fa6
20260926-031125-591edaf7 20260926-031219-01dc4f3e 20260926-031403-b4f8ad31
20260926-031523-16d8b929 20260926-031848-2c53bd89 20260926-031924-cd2656fc
20260926-031958-c7ead5c7 20260926-032042-2183dcdd 20260926-032114-c48d1697
20260926-032624-2fba3ca0 20260926-032703-ee2f2457 20260926-032848-8d49353a
20260926-032935-b0d93e39'''.split(),
    'putty_bridge_scaleway_nbreq': '''20260926-025147-5de01ff6 20260926-031039-32208e0a
20260926-031126-9aaf37ca 20260926-031220-f1d84788 20260926-031404-d3dd9a5c
20260926-031525-4bbeae44 20260926-031849-2f570663 20260926-031926-6406417f
20260926-031959-f8865ee9 20260926-032043-c49dd12c 20260926-032116-27b590d2
20260926-032623-d2ed6083 20260926-032704-beab8a92 20260926-032849-1f787269
20260926-032936-0dc35bbb'''.split(),
}
out = lab / 'bridge-receipts'
out.mkdir(exist_ok=False)
for queue, ids in selected.items():
    folder = out / queue
    folder.mkdir()
    for identity in ids:
        path = queues / queue / 'results' / (identity + '.json')
        payload = path.read_bytes()
        data = json.loads(payload.decode('utf-8-sig'))
        assert data['id'] == identity and data['status'] in ('completed', 'failed')
        with (folder / path.name).open('xb') as copy:
            copy.write(payload)
print('Preserved', sum(map(len, selected.values())), 'explicit bridge receipts')
