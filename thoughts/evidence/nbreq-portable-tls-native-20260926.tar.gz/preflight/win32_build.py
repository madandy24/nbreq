"""Build and freeze identical Windows x86 public-API/proof artifacts for native and Wine runs."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import signal
import struct
import tarfile

import native_gate
import owned_command as supervisor

def terminate(_signal, _frame):
    raise SystemExit('Win32 build received SIGTERM')

signal.signal(signal.SIGTERM, terminate)

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
root, out = a.root.resolve(), a.out.resolve()
out.mkdir(parents=True, exist_ok=False)
source, manifest = native_gate.verify(root)
env = dict(os.environ, RUSTUP_TOOLCHAIN='stable', CARGO_TARGET_DIR=str(out / 'build'),
           CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_PROFILE_TEST_DEBUG='0')
env.pop('CARGO_BUILD_TARGET', None)
target = 'i686-pc-windows-msvc'
failure = None
try:
    for label, argv, timeout in [
        ('compiler', ['rustc', '+stable', '-vV'], 30),
        ('tests-build', ['cargo', '+stable', 'test', '--locked', '--offline', '--all-features',
                         '--lib', '--test', 'portable_tls', '--target', target, '--no-run',
                         '--message-format=json'], 900),
        ('probe-build', ['cargo', '+stable', 'build', '--locked', '--offline', '--release',
                         '--manifest-path', 'tools/tcp-tls-probe/Cargo.toml',
                         '--features', 'bundled-roots', '--target', target], 900),
    ]:
        supervisor.command(argv, root, out, label, env, timeout)
    artifacts = {}
    for line in (out / 'tests-build.log').read_text(encoding='utf-8').splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if item.get('reason') != 'compiler-artifact' or not item.get('executable'):
            continue
        if item['target']['name'] in ('nbreq', 'portable_tls') and item['profile']['test']:
            name = item['target']['name']
            assert name not in artifacts
            artifacts[name] = Path(item['executable'])
    assert set(artifacts) == {'nbreq', 'portable_tls'}
    artifacts['probe'] = out / 'build' / target / 'release' / 'nbreq-tcp-tls-probe.exe'
    frozen = out / 'artifacts'
    (frozen / 'bin').mkdir(parents=True)
    files = {}
    for name, path in artifacts.items():
        blob = path.read_bytes()
        assert blob[:2] == b'MZ'
        pe = struct.unpack_from('<I', blob, 0x3c)[0]
        assert blob[pe:pe + 4] == b'PE\0\0' and struct.unpack_from('<H', blob, pe + 4)[0] == 0x14c
        files['bin/' + name + '.exe'] = blob
    for name in ('run_win32.py', 'owned_command.py', 'collect.py'):
        files[name] = Path(__file__).with_name(name).read_bytes()
    metadata = dict(commit=manifest['commit'], source=source, target=target, pe_machine='0x014c',
                    rustc=(out / 'compiler.log').read_text(),
                    files={n: hashlib.sha256(b).hexdigest() for n, b in files.items()})
    files['binary-manifest.json'] = json.dumps(metadata, indent=2).encode()
    archive = out / ('nbreq-portable-win32-' + manifest['commit'][:12] + '.tar.gz')
    with tarfile.open(archive, 'x:gz', compresslevel=9) as bundle:
        for name, blob in files.items():
            path = frozen / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as f:
                f.write(blob)
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(blob), 0o644
            bundle.addfile(entry, io.BytesIO(blob))
    assert native_gate.verify(root)[0] == source
    supervisor.write(out / 'result.json', dict(status='passed', source=source, commit=manifest['commit'],
                     archive=str(archive), sha256=supervisor.sha(archive), artifacts=str(frozen)))
except BaseException as error:
    supervisor.write(out / 'result.json', dict(status='failed', source=source, failure=repr(error)))
    raise
