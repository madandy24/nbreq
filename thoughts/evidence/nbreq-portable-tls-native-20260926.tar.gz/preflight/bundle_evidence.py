"""Bundle reviewed portable TLS technical evidence; exclude build trees, binaries and private keys."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--archive', type=Path, required=True)
p.add_argument('--summary', type=Path, required=True)
a = p.parse_args()
lab = Path(__file__).resolve().parent
selected = {}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verified_archive(path, expected, manifest_name, extracted=None):
    assert sha(path) == expected, path
    with tarfile.open(path) as bundle:
        members = bundle.getmembers()
        names = {m.name for m in members}
        assert len(names) == len(members)
        for m in members:
            assert m.isfile() and not PurePosixPath(m.name).is_absolute()
            assert '..' not in PurePosixPath(m.name).parts and '\\' not in m.name
            assert m.size <= 32 * 1024 * 1024
        metadata_bytes = bundle.extractfile(manifest_name).read()
        metadata = json.loads(metadata_bytes)
        assert names == set(metadata['files']) | {manifest_name}
        for name, expected_hash in metadata['files'].items():
            blob = bundle.extractfile(name).read()
            assert hashlib.sha256(blob).hexdigest() == expected_hash, name
            if extracted:
                path = extracted / name
                assert not path.is_symlink() and extracted in path.resolve().parents
                assert path.read_bytes() == blob, path
        if extracted:
            assert (extracted / manifest_name).read_bytes() == metadata_bytes
        return metadata

source_ids = {}
for commit, digest in [
    ('b5c8eb0c1a87', '718a4bf1f6cea8b0b24d130d174134bb51fc8f95c4f6d79a03c03234ce5d432a'),
    ('8d24e27d31ec', '834fd233505693877a764db6ff84ff5c875a7fbdde2aec52e66ed95dfb90ce61'),
]:
    frozen = lab / ('frozen-' + commit)
    data = verified_archive(lab / ('nbreq-portable-tls-' + commit + '-source.tar.gz'), digest,
                            'portable-source.json', frozen)
    snapshot = json.loads((lab / (commit + '-snapshot.json')).read_bytes())
    identity = sha(frozen / 'portable-source.json')
    assert data['commit'].startswith(commit) and snapshot['commit'] == data['commit']
    assert snapshot['source'] == identity and snapshot['sha256'] == digest
    source_ids[commit] = identity

for folder, digest in [
    ('intel-b5c8eb0', '52b2fe784ca5e53b5ea31fd7c2c2a47bcf61c70bc5f3df761002903c7188c716'),
    ('arm-b5c8eb0', '0ca57fa81e7db4e9dfad59d571f58de739ff875f9f4f850fb07df04cd8304723'),
    ('intel-fixture-8d24e27', 'b1c04af3771198278915e4b67d7e382c35b3a6b6e2cdac515d432ea76269b890'),
    ('arm-fixture-8d24e27', '0dd68c963703b1a1c9601b2cfae2e81fc77e938097dfa9aebb8c4af197ddba63'),
]:
    data = verified_archive(lab / (folder + '-evidence.tar.gz'), digest,
                            'evidence-manifest.json', lab / folder)
    assert data['result'] == json.loads((lab / folder / 'result.json').read_bytes())
    assert data['result']['status'] == 'passed'

binary = verified_archive(lab / 'win32-b5c8eb0/nbreq-portable-win32-b5c8eb0c1a87.tar.gz',
                          '4cc1f1e2059f941f4063e8af5c15e1fe1ed313f17949fa47cc3565f020bff49f',
                          'binary-manifest.json', lab / 'win32-b5c8eb0/artifacts')
assert binary['source'] == source_ids['b5c8eb0c1a87'] and binary['target'] == 'i686-pc-windows-msvc'

for label, digest in [
    ('b5c8eb0', '5e4acd862b58b77d3e801427757346a7efe47a1106b024e506842a318232dd36'),
    ('8d24e27', '964bd7855f3067de8a71a7bdae94d2efa2c30f527df67ead67a9ec4d7d171b55'),
]:
    folder = lab / ('package-' + label)
    inventory = json.loads((folder / 'inventory.json').read_bytes())
    crate = folder / 'build/package/nbreq-0.2.0.crate'
    assert sha(crate) == digest == inventory['package_sha256']
    with tarfile.open(crate) as bundle:
        members = bundle.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert {m.name for m in members} == set(inventory['files'])
        for m in members:
            assert m.isfile() and m.name.startswith('nbreq-0.2.0/') and '..' not in PurePosixPath(m.name).parts
            assert hashlib.sha256(bundle.extractfile(m).read()).hexdigest() == inventory['files'][m.name]
        vcs = json.load(bundle.extractfile('nbreq-0.2.0/.cargo_vcs_info.json'))
        assert vcs == inventory['vcs'] and vcs['git']['sha1'] == inventory['commit']
        assert vcs['git']['sha1'].startswith(label) and not vcs['git'].get('dirty', False)

summary = json.loads(a.summary.read_bytes())
assert summary['source_ids'] == source_ids
assert summary['not_run'] == ['native Linux', 'Wine 5 Win32 tests and live probes']
assert summary['implementation_commit'] == binary['commit']
assert summary['fixture_commit'] == '8d24e27d31ec78d3687c03734439b9bcb7a6e0e7'
for check in summary['checks']:
    path = lab / check['path']
    assert lab in path.resolve().parents and not path.is_symlink()
    record = json.loads(path.read_bytes())
    assert sha(path) == check['sha256']
    for key, expected in check['expected'].items():
        assert record[key] == expected, (path, key)
    if 'source' in record:
        assert record['source'] in source_ids.values(), path
    if 'commit' in record:
        assert record['commit'] in (summary['implementation_commit'], summary['fixture_commit']), path

remaining = json.loads((lab / 'windows-8d24e27-remaining/result.json').read_bytes())
for name, digest in remaining['prior_evidence_sha256'].items():
    assert sha(lab / 'windows-8d24e27' / name) == digest
audit = json.loads((lab / 'audit-provenance.json').read_bytes())
assert sha(lab / 'frozen-8d24e27d31ec/Cargo.lock') == audit['root_lock_sha256']
for label in ('b5c8eb0', '8d24e27'):
    assert sha(lab / ('package-' + label) / 'consumer-Cargo.lock') == audit['consumer_lock_sha256']
assert sha(lab / 'audit-config-existing.toml') == audit['config_sha256']
assert audit['preserved_ignore'] == ['RUSTSEC-2026-0009']
assert sha(lab / 'THIRD_PARTY_LICENSES.verify.html') == sha(lab / 'frozen-8d24e27d31ec/THIRD_PARTY_LICENSES.html')
assert sha(lab / 'THIRD_PARTY_LICENSES.verify.html') == '580bc77ac9b0f1d7f55fa3c7638503ab09d59d1bcb58bc7363060216d5390f50'
for item in json.loads((lab / 'red-snapshot/manifest.json').read_bytes()):
    path = Path(item['copy'])
    assert (lab / 'red-snapshot') in path.resolve().parents
    assert sha(path) == item['sha256'].lower()
red = (lab / 'portable-runtime-red-final.log').read_text(encoding='utf-8')
assert '0 passed; 3 failed' in red and 'portable TLS trust is not implemented yet' in red

def unreadable(error):
    raise error

def add(path, name):
    assert path.is_file() and not path.is_symlink() and lab in path.resolve().parents
    assert path.stat().st_size <= 32 * 1024 * 1024, path
    assert name not in selected and '..' not in Path(name).parts
    blob = path.read_bytes()
    # Source files may contain the scanner's marker strings; payload keys are never selected.
    if path.suffix not in ('.py', '.rs', '.gz', '.crate'):
        assert b'-----BEGIN PRIVATE KEY-----' not in blob
        assert b'-----BEGIN RSA PRIVATE KEY-----' not in blob
        assert b'-----BEGIN EC PRIVATE KEY-----' not in blob
    selected[name] = blob

allowed = {'.json', '.jsonl', '.log', '.txt', '.py', '.rs', '.toml', '.lock'}
directories = [
    'red-snapshot', 'fixture-close-locked-red', 'fixture-close-locked-green',
    'split-finish-deterministic', 'split-finish-b5c8eb0-repro',
    'http-timeout-8d24e27-diagnostic',
    'windows-b5c8eb0', 'windows-x86-b5c8eb0', 'windows-8d24e27', 'windows-8d24e27-remaining',
    'intel-b5c8eb0', 'arm-b5c8eb0', 'intel-fixture-8d24e27', 'arm-fixture-8d24e27',
    'win32-b5c8eb0', 'package-b5c8eb0', 'package-8d24e27', 'bridge-receipts',
]
for folder in directories:
    root = lab / folder
    assert root.is_dir(), root
    assert not root.is_symlink()
    for current, dirs, files in os.walk(root, onerror=unreadable):
        assert all(not (Path(current) / d).is_symlink() for d in dirs)
        dirs[:] = sorted(d for d in dirs if not d.startswith('build') and d not in ('__pycache__', '.git', 'certs'))
        for name in sorted(files):
            path = Path(current) / name
            if path.suffix in allowed:
                add(path, folder + '/' + path.relative_to(root).as_posix())
for path in lab.iterdir():
    if path.is_file() and path.suffix in allowed and path != a.summary.resolve():
        add(path, 'preflight/' + path.name)
for commit in ('b5c8eb0c1a87', '8d24e27d31ec'):
    path = lab / ('nbreq-portable-tls-' + commit + '-source.tar.gz')
    add(path, 'sources/' + path.name)
for label in ('b5c8eb0', '8d24e27'):
    path = lab / ('package-' + label) / 'build/package/nbreq-0.2.0.crate'
    add(path, 'packages/nbreq-' + label + '.crate')
payload = json.dumps(dict(summary=summary,
                         files={n: hashlib.sha256(b).hexdigest() for n, b in sorted(selected.items())}),
                     indent=2).encode()
with tarfile.open(a.archive, 'x:gz', compresslevel=9) as bundle:
    for name, blob in list(sorted(selected.items())) + [('evidence-manifest.json', payload)]:
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(blob), 0o644
        bundle.addfile(item, io.BytesIO(blob))
record = dict(archive=str(a.archive), files=len(selected) + 1, bytes=a.archive.stat().st_size,
              sha256=hashlib.sha256(a.archive.read_bytes()).hexdigest(), summary=summary)
print(json.dumps(record, indent=2))
