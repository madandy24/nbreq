"""Finish frozen Windows gates after retaining the parallel request-arrival timing failure."""
import json
import hashlib
import os
from pathlib import Path
import signal

import native_gate
import owned_command as supervisor

def terminate(_signal, _frame):
    raise SystemExit('Windows continuation received SIGTERM')

signal.signal(signal.SIGTERM, terminate)
lab = Path(__file__).resolve().parent
root, prior = lab / 'frozen-8d24e27d31ec', lab / 'windows-8d24e27'
out = lab / 'windows-8d24e27-remaining'
out.mkdir(exist_ok=False)
identity, manifest = native_gate.verify(root)
previous = json.loads((prior / 'result.json').read_bytes())
assert previous['source'] == identity
assert previous['commit'] == manifest['commit'] and previous['status'] == 'failed'
prior_evidence = {name: hashlib.sha256((prior / name).read_bytes()).hexdigest()
                  for name in ('result.json', 'stable-verify.result.json', 'bundle-only-tests.result.json')}
assert json.loads((prior / 'stable-verify.result.json').read_bytes())['exit_code'] == 0
assert json.loads((prior / 'bundle-only-tests.result.json').read_bytes())['exit_code'] == 101
env = dict(os.environ, RUSTUP_TOOLCHAIN='stable', RUST_TEST_THREADS='1',
           CARGO_TARGET_DIR=str(prior / 'build'), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
env.pop('CARGO_BUILD_TARGET', None)
failure, steps, binary = None, [], None

def run(label, argv, timeout=1200):
    supervisor.command(argv, root, out, label, env, timeout)
    steps.append(label)

try:
    run('bundle-only-serial', ['cargo', '+stable', 'test', '--locked', '--offline',
                              '--no-default-features', '--features', 'bundled-roots'])
    env['RUSTUP_TOOLCHAIN'] = '1.85.0'
    run('msrv-compiler', ['rustc', '+1.85.0', '-vV'], 30)
    run('msrv-serial', ['cargo', '+1.85.0', 'test', '--locked', '--offline', '--all-features'])
    env['RUSTUP_TOOLCHAIN'] = 'stable'
    probe = ['--manifest-path', 'tools/tcp-tls-probe/Cargo.toml']
    run('probe-clippy', ['cargo', '+stable', 'clippy', '--locked', '--offline'] + probe +
        ['--all-features', '--all-targets', '--', '-D', 'warnings'], 600)
    run('probe-release', ['cargo', '+stable', 'build', '--locked', '--offline', '--release'] +
        probe + ['--features', 'bundled-roots'], 900)
    path = prior / 'build/release/nbreq-tcp-tls-probe.exe'
    binary = dict(path=str(path), sha256=supervisor.sha(path))
except BaseException as error:
    failure = repr(error)
finally:
    try:
        assert native_gate.verify(root)[0] == identity
    except BaseException as error:
        failure = (failure + '; ' if failure else '') + 'final integrity: ' + repr(error)
    result = dict(status='failed' if failure else 'passed', failure=failure, source=identity,
                  commit=manifest['commit'], steps=steps, test_threads=1, probe=binary,
                  prior_evidence_sha256=prior_evidence,
                  qualification='Prior parallel full30-step gate passed. Retain extra parallel bundle-only request-arrival failure separately.')
    supervisor.write(out / 'result.json', result)
print(json.dumps(result), flush=True)
if failure:
    raise SystemExit(1)
