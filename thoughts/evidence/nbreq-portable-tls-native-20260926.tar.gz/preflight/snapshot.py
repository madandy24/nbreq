"""Freeze committed NBReq workspace sources and reviewed test supervisors."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
args = parser.parse_args()
root, lab = args.root.resolve(), Path(__file__).resolve().parent
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
prefixes = ('src/', 'tests/', 'examples/', 'support/', 'smtp/', 'docs/',
            'tools/xtask/', 'tools/tcp-tls-probe/')
exact = {'Cargo.toml', 'Cargo.lock', 'README.md', 'SECURITY.md', 'THIRD_PARTY_LICENSES.html',
         'CHANGELOG.md',
         'LICENSE-APACHE', 'LICENSE-MIT', 'about.toml', 'about.hbs',
         'tools/release-soak/process_sample.py'}
files = {}
for name in sorted(names):
    if not name or not (name in exact or name.startswith(prefixes)):
        continue
    path = root / name
    assert not path.is_symlink() and path.is_file() and root in path.resolve().parents
    assert not any(p in ('target', '__pycache__', '.git', '.agents', '.codex') for p in path.relative_to(root).parts)
    assert path.suffix not in ('.key', '.pfx', '.p12')
    blob = path.read_bytes()
    assert not any(marker in blob for marker in (b'-----BEGIN PRIVATE KEY-----',
                                                b'-----BEGIN RSA PRIVATE KEY-----',
                                                b'-----BEGIN EC PRIVATE KEY-----'))
    files[name] = blob
for name in ('native_gate.py', 'owned_command.py', 'collect.py', 'snapshot.py', 'fixture_gate.py'):
    files[name] = (lab / name).read_bytes()
manifest = dict(commit=commit, purpose='Portable verified TLS native matrix; no deployment',
                files={name: hashlib.sha256(blob).hexdigest() for name, blob in files.items()})
payload = json.dumps(manifest, indent=2).encode()
identity = hashlib.sha256(payload).hexdigest()
archive = lab / ('nbreq-portable-tls-' + commit[:12] + '-source.tar.gz')
frozen = lab / ('frozen-' + commit[:12])
frozen.mkdir(exist_ok=False)
with tarfile.open(archive, 'x:gz', compresslevel=9) as output:
    for name, blob in list(files.items()) + [('portable-source.json', payload)]:
        destination = frozen / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as file:
            file.write(blob)
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(blob), 0o644
        output.addfile(item, io.BytesIO(blob))
record = dict(commit=commit, source=identity, archive=str(archive), frozen=str(frozen),
              files=len(files) + 1, bytes=archive.stat().st_size,
              sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
with (lab / (commit[:12] + '-snapshot.json')).open('x', encoding='utf-8') as file:
    json.dump(record, file, indent=2)
print(json.dumps(record, indent=2))
