"""Bind the qualified portable TLS checkpoint summary to retained result files."""
import hashlib
import json
from pathlib import Path

lab = Path(__file__).resolve().parent
items = [
    ('windows-b5c8eb0/result.json', {'status': 'failed'}),
    ('windows-x86-b5c8eb0/result.json', {'status': 'passed'}),
    ('windows-8d24e27/stable-verify.result.json', {'exit_code': 0}),
    ('windows-8d24e27/bundle-only-tests.result.json', {'exit_code': 101}),
    ('windows-8d24e27/result.json', {'status': 'failed'}),
    ('windows-8d24e27-remaining/result.json', {'status': 'passed', 'test_threads': 1}),
    ('intel-b5c8eb0/result.json', {'status': 'passed'}),
    ('arm-b5c8eb0/result.json', {'status': 'passed'}),
    ('intel-fixture-8d24e27/result.json', {'status': 'passed'}),
    ('arm-fixture-8d24e27/result.json', {'status': 'passed'}),
    ('intel-b5c8eb0/live/result.json', {'status': 'passed', 'steps': ['imaps', 'smtp']}),
    ('arm-b5c8eb0/live/result.json', {'status': 'failed', 'steps': ['imaps']}),
    ('package-b5c8eb0/result.json', {'status': 'passed'}),
    ('package-8d24e27/result.json', {'status': 'passed'}),
    ('fixture-close-locked-red/permanent-red.result.json', {'exit_code': 101}),
    ('fixture-close-locked-green/result.json', {'failure': None}),
    ('audit-frozen-root.json', {'vulnerabilities': {'found': False, 'count': 0, 'list': []}, 'warnings': {}}),
    ('audit-packaged-consumer.json', {'vulnerabilities': {'found': False, 'count': 0, 'list': []}, 'warnings': {}}),
]
checks = []
for name, expected in items:
    payload = (lab / name).read_bytes()
    record = json.loads(payload)
    assert all(record[k] == v for k, v in expected.items()), name
    checks.append(dict(path=name, expected=expected, sha256=hashlib.sha256(payload).hexdigest()))
source_ids = {commit: hashlib.sha256((lab / ('frozen-' + commit) / 'portable-source.json').read_bytes()).hexdigest()
              for commit in ('b5c8eb0c1a87', '8d24e27d31ec')}
summary = dict(
    implementation_commit='b5c8eb0c1a87d25fff945dac52b7ceb87fc6680e',
    fixture_commit='8d24e27d31ec78d3687c03734439b9bcb7a6e0e7',
    status='Code/native checkpoint; Linux/Wine acceptance pending authorized upload',
    source_ids=source_ids, checks=checks,
    not_run=['native Linux', 'Wine 5 Win32 tests and live probes'],
    qualifications=[
        'Native Windows full30-step parallel gate passed; extra parallel bundled-roots suite failed a pre-existing plain-HTTP request-arrival assertion after correct150ms timeout classification. Serial bundled-roots and Rust1.85 gates passed; parallel test stability is not fixed.',
        'Mac full gates ran b5c8 production. Final8d24 changes only the shared TLS fixture/regressions; both affected suites were rechecked native-only/all-features/MSRV plus lint/format with exact manifest-delta proof.',
        'Windows native Win32 and Intel Mac verified live IMAPS and SMTP STARTTLS. ARM verified IMAPS; SMTP hit read inactivity timeout with unknown stage/cause. No ARM SMTP or Wine live success claim.',
        'The prior platform-verifier Wine5 failure is not repaired in Platform mode. Portable modes are explicit and have not yet been executed under Wine in this checkpoint.',
        'Existing RUSTSEC-2026-0009 development-only time parsing exception is unchanged; parsing feature absent, runtime/consumer graph excludes time.',
        'No GDS code, deployment, publication or push performed.',
    ])
with (lab / 'evidence-summary.json').open('x', encoding='utf-8') as out:
    json.dump(summary, out, indent=2)
print('Summary bound to', len(checks), 'result records')
