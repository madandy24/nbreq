"""Bounded portable-TLS native checks on a frozen source tree; never publish."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

import owned_command as supervisor


def verify(root):
    path = root / 'portable-source.json'
    raw = path.read_bytes()
    manifest = json.loads(raw)
    for name, expected in manifest['files'].items():
        source = root / name
        if source.is_symlink() or root not in source.resolve().parents or supervisor.sha(source) != expected:
            raise RuntimeError('frozen source mismatch: ' + name)
    return hashlib.sha256(raw).hexdigest(), manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['launch', 'run'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    if args.mode == 'launch':
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, '-B', str(Path(__file__).resolve()), 'run',
                '--root', str(root), '--out', str(out)]
        with (out / 'job.log').open('xb') as log:
            child = None
            try:
                child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                         start_new_session=os.name != 'nt', close_fds=True)
                record = dict(pid=child.pid, command=argv, out=str(out))
                supervisor.write(out / 'launch.json', record)
            except BaseException:
                if child is not None:
                    supervisor.stop(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0

    out.mkdir(parents=True, exist_ok=True)
    with (out / 'run.token').open('xb') as token:
        token.write(str(os.getpid()).encode())
    started = time.monotonic()
    source, manifest, failure, binaries = None, None, None, {}
    try:
        source, manifest = verify(root)
        supervisor.write(out / 'host.json', dict(platform=platform.platform(), machine=platform.machine(),
                         python=sys.version, source=source, commit=manifest['commit'],
                         started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        env = dict(os.environ)
        env.pop('CARGO_BUILD_TARGET', None)
        env.update(CARGO_TARGET_DIR=str(out / 'build'), CARGO_BUILD_JOBS='2',
                   CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
                   RUSTUP_TOOLCHAIN='stable')
        env['PATH'] = str(Path.home() / '.cargo' / 'bin') + os.pathsep + env.get('PATH', '')
        suffix = '.exe' if os.name == 'nt' else ''
        cargo = str(Path.home() / '.cargo' / 'bin' / ('cargo' + suffix))
        rustc = str(Path(cargo).with_name('rustc' + suffix))

        def run(label, argv, timeout=900):
            supervisor.command(argv, root, out, label, env, timeout)

        run('stable-compiler', [rustc, '+stable', '-vV'], 30)
        run('stable-cargo', [cargo, '+stable', '--version'], 30)
        for label, package in [('workspace-fetch', []),
                               ('probe-fetch', ['--manifest-path', 'tools/tcp-tls-probe/Cargo.toml']),
                               ('xtask-fetch', ['--manifest-path', 'tools/xtask/Cargo.toml'])]:
            run(label, [cargo, '+stable', 'fetch', '--locked'] + package, 300)
        run('stable-verify', [cargo, '+stable', 'run', '--locked', '--offline', '--manifest-path',
                             'tools/xtask/Cargo.toml', '--', 'verify', '--offline'], 1800)
        run('bundle-only-tests', [cargo, '+stable', 'test', '--locked', '--offline',
                                 '--no-default-features', '--features', 'bundled-roots'], 900)
        env['RUSTUP_TOOLCHAIN'] = '1.85.0'
        run('msrv-compiler', [rustc, '+1.85.0', '-vV'], 30)
        run('msrv-tests', [cargo, '+1.85.0', 'test', '--locked', '--offline', '--all-features'], 1200)
        env['RUSTUP_TOOLCHAIN'] = 'stable'
        package = ['--manifest-path', 'tools/tcp-tls-probe/Cargo.toml']
        run('probe-clippy', [cargo, '+stable', 'clippy', '--locked', '--offline'] + package +
            ['--all-features', '--all-targets', '--', '-D', 'warnings'], 600)
        run('probe-release', [cargo, '+stable', 'build', '--locked', '--offline', '--release'] +
            package + ['--features', 'bundled-roots'], 900)
        binary = out / 'build' / 'release' / ('nbreq-tcp-tls-probe' + suffix)
        binaries['probe'] = dict(path=str(binary), sha256=supervisor.sha(binary))
    except BaseException as error:
        failure = repr(error)
    finally:
        try:
            final_source, _ = verify(root)
            if final_source != source:
                raise RuntimeError('source manifest changed during checks')
            for record in binaries.values():
                if supervisor.sha(Path(record['path'])) != record['sha256']:
                    raise RuntimeError('built executable changed during checks')
        except BaseException as error:
            failure = (failure + '; ' if failure else '') + 'final integrity: ' + repr(error)
        result = dict(status='failed' if failure else 'passed', failure=failure, source=source,
                      commit=manifest['commit'] if manifest else None, binaries=binaries,
                      elapsed_seconds=time.monotonic() - started)
        supervisor.write(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


if __name__ == '__main__':
    def terminate(_signum, _frame):
        raise SystemExit('portable TLS gate received SIGTERM')
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
