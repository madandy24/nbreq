from pathlib import Path
import hashlib,json,re,tarfile
root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent/'msrv-lint-fix'
summary=json.loads((lab/'attempt-02/summary.json').read_text())
assert len(summary['commands'])==9 and all(c['exit']==0 for c in summary['commands'])
assert summary['source_hashes_unchanged']
assert 'NBReq verification complete: all 30 steps passed' in (lab/'attempt-02/msrv-verifier.log').read_text()
for name,digest in json.loads((lab/'attempt-02/source-after.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
files={p.relative_to(lab).as_posix():p for p in lab.rglob('*') if p.is_file()}
for name,path in files.items():
    assert path.suffix in {'.json','.log','.txt','.rs','.py','.diff'}
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16})',path.read_bytes())
destination=root/'thoughts/evidence/nbreq-msrv-lint-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz') as bundle:
    for name,path in files.items():bundle.add(path,arcname=name,recursive=False)
members={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in files.items()}
with tarfile.open(destination) as bundle:
    assert all(m.isfile() for m in bundle.getmembers())
    assert {m.name:hashlib.sha256(bundle.extractfile(m).read()).hexdigest() for m in bundle.getmembers()}==members
record=dict(archive=destination.name,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    bytes=destination.stat().st_size,regular_members=len(members),summary=summary,members=members)
(root/'thoughts/evidence/nbreq_msrv_lint_021_artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['archive','sha256','bytes','regular_members']},indent=2))
