# Independent post-publication review — 2026-09-27

Accepted: core NBReq 0.2.1 is published and the reviewed post-publication gates passed. No unresolved findings. Review used saved receipts and raw artifacts; no builds, network requests, or source changes were performed by the reviewer.

The successful Cargo publication log, crates.io API, sparse index, downloaded archive, and approved dry-run archive agree on SHA-256 `fa12940c09ff6d3c61c32d4e4b885c8d229131cce9e9839f42c6b4d46ee46903` and 408,235 bytes. All downloaded archive members match the approved inventory. Its clean VCS identity is `44bbd1b1badf33771efe264e433e2bdfdc6983d4`; API/index receipts report version 0.2.1 as not yanked.

Annotated tag `v0.2.1` has object `f1bf3c9003aa80ef1d506a84ebc5f1904a4b3c5a`. Local tag type/object/peeled commit agree with the retained remote tag receipt and the published source commit.

Published matrix run `36303600781` completed successfully on all eight Windows, Ubuntu, Intel macOS, and Apple Silicon macOS/toolchain jobs. All eight downloaded artifact hashes match their GitHub digests and matrix receipt. Raw logs confirm 672 passing tests, 32 expected unresolved-import probes, and 144 successful example runs. All 16 consumer locks resolve NBReq 0.2.1 from crates.io with the exact published checksum, with helpers and bundled-root dependencies also from the registry. Eight newer-compiler graphs retain their original fresh locks; eight old-Rust graphs explicitly select yoke-derive 0.8.2 without unrelated identity changes. All bundled-policy test markers are present. Packaged example locks are separately bound and correctly described as unchanged packaged locks. All five distinct selected/example locks match the audited bytes and have no reported vulnerabilities or warnings.

Published matrix raw-log archive SHA-256: `71ba211df5261b4d187a0c6c74980685e0ecd93006d12504665431de28cab935`.

Saved live README/docs pages match their receipt hashes. README structure and compiler workaround checks passed; ten API/versioned-source target receipts report HTTP 200 at the exact requested 0.2.1/tag URLs, without wrong-version redirects.

The revised retention helper binds published source, mode, archive identity, registry-only cases, and remote tag identity before packaging evidence. Its current selection contains 319 files, including nested archives covering 4,046 scanned files; the scoped token/private-key pattern scan found no matches. The rejected broad Intel diagnostic archive, copied source tree, bridge files, and raw upload rejection are excluded. This review receipt is an additional intended retained file. The final retention archive must still be generated and checked against its member index; this review does not claim that not-yet-created archive has been verified.
