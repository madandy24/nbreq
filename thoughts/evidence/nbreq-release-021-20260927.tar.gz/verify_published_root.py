from pathlib import Path
import hashlib,json,urllib.request
lab=Path('C:/User/projects/nbreq/target/release-021-20260927')
expected=json.loads((lab/'final-root-candidate.json').read_text())
def get(url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'nbreq-release-check/0.2 (https://github.com/madandy24/nbreq)'}),timeout=60) as response:
        return response.read()
data=json.loads(get('https://crates.io/api/v1/crates/nbreq/0.2.1'))
version=data['version']
assert version['num']=='0.2.1' and version['checksum']==expected['sha256'] and not version['yanked']
package=get('https://crates.io'+version['dl_path'])
assert hashlib.sha256(package).hexdigest()==expected['sha256']
(lab/'nbreq-0.2.1.crate').write_bytes(package)
(lab/'nbreq-published.json').write_text(json.dumps(data,indent=2))
entries=[json.loads(line) for line in get('https://index.crates.io/nb/re/nbreq').splitlines()]
entry=next(e for e in entries if e['vers']=='0.2.1')
assert entry['cksum']==expected['sha256'] and not entry['yanked']
(lab/'nbreq-index.json').write_text(json.dumps(entry,indent=2))
record=dict(version='0.2.1',created_at=version['created_at'],sha256=expected['sha256'],bytes=len(package),
    source_commit=expected['source_commit'],url='https://crates.io/crates/nbreq/0.2.1',
    index_visible=True,download_matches_candidate=True)
(lab/'published-root.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
