import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('C:/User/projects/nbreq')
LAB = ROOT / 'target/release-021-20260927/msrv-lint-fix'
ENV = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / 'target/docs-021-20260927/build'), PYTHONDONTWRITEBYTECODE='1')

def hashes():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs', '.toml', '.lock')) or p == 'rust-toolchain')}

before = hashes()
(LAB / 'source-before.json').write_text(json.dumps(before, indent=2))
(LAB / 'fixture.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'tests/support/tcp_tls_fixture.rs'], cwd=ROOT))
results = []
commands = [
    ('msrv-versions', '1.85.0', ['rustc', '-vV']),
    ('msrv-clippy-version', '1.85.0', ['cargo', 'clippy', '--version']),
    ('msrv-verifier', '1.85.0', ['cargo', 'run', '--locked', '--offline', '--manifest-path', 'tools/xtask/Cargo.toml', '--', 'verify', '--offline']),
    ('stable-versions', 'stable', ['rustc', '-vV']),
    ('stable-clippy-version', 'stable', ['cargo', 'clippy', '--version']),
    ('stable-clippy', 'stable', ['cargo', 'clippy', '--locked', '--offline', '--all-features', '--all-targets', '--', '-D', 'warnings']),
    ('stable-tls-tests', 'stable', ['cargo', 'test', '--locked', '--offline', '--all-features', '--test', 'tcp_tls', '--test', 'tcp_tls_api']),
]
for name, toolchain, args in commands:
    env = dict(ENV, RUSTUP_TOOLCHAIN=toolchain)
    command = ['rustup', 'run', toolchain, *args]
    started = time.time()
    print(f'START {name}: {command}', flush=True)
    with (LAB / f'{name}.log').open('wb') as out:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=subprocess.STDOUT)
    results.append(dict(name=name, command=command, toolchain=toolchain, exit=result.returncode, elapsed_seconds=time.time()-started))
    (LAB / 'results.json').write_text(json.dumps(results, indent=2))
    print(f'END {name}: exit={result.returncode}', flush=True)
    if result.returncode:
        break
after = hashes()
(LAB / 'source-after.json').write_text(json.dumps(after, indent=2))
summary = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), commands=results, environment={'CARGO_TARGET_DIR': ENV['CARGO_TARGET_DIR']}, source_hashes_unchanged=before == after, changed_source_paths=[p for p in set(before) | set(after) if before.get(p) != after.get(p)], fixture_before_sha256=hashlib.sha256((LAB / 'tcp_tls_fixture.before.rs').read_bytes()).hexdigest(), fixture_after_sha256=hashlib.sha256((ROOT / 'tests/support/tcp_tls_fixture.rs').read_bytes()).hexdigest())
(LAB / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary), flush=True)
