from pathlib import Path
import json, re
lab=Path(__file__).resolve().parent
namespace={}
exec((lab/'github_release.py').read_text().split('parser=argparse.ArgumentParser()')[0],namespace)
jobs=json.loads((lab/'hosted-ci/jobs.json').read_text())
for job in jobs:
    if job['conclusion']!='failure': continue
    path=lab/'hosted-ci'/('job-'+str(job['id'])+'.log')
    if not path.exists(): path.write_bytes(namespace['api']('/actions/jobs/'+str(job['id'])+'/logs',binary=True))
    print(job['name'], 'failed steps:', [s['name'] for s in job['steps'] if s.get('conclusion')=='failure'])
    lines=path.read_text(encoding='utf-8-sig').splitlines()
    indices=set()
    for i,line in enumerate(lines):
        if re.search(r'error:|error\[|FAILED|panicked at|Error:',line):
            indices.update(range(max(0,i-3),min(len(lines),i+9)))
    print('\n'.join(lines[i] for i in sorted(indices)))
