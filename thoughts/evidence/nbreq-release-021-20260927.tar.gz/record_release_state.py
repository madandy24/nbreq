"""Record exact local/remote annotated tag identity and current release stage."""
from pathlib import Path
import json, subprocess

root = Path('C:/User/projects/nbreq')
lab = Path(__file__).resolve().parent
published = json.loads((lab / 'published-root.json').read_text())
source = published['source_commit']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True, timeout=60).strip()

tag = git('rev-parse', 'refs/tags/v0.2.1')
assert git('cat-file', '-t', tag) == 'tag'
assert git('rev-parse', 'v0.2.1^{commit}') == source
remote = dict(line.split()[::-1] for line in git(
    'ls-remote', 'origin', 'refs/tags/v0.2.1', 'refs/tags/v0.2.1^{}').splitlines())
assert remote == {'refs/tags/v0.2.1': tag, 'refs/tags/v0.2.1^{}': source}
receipt = dict(status='passed', tag='v0.2.1', annotated_tag_object=tag,
               source_commit=source, remote=remote,
               url='https://github.com/madandy24/nbreq/tree/v0.2.1')
(lab / 'published-tag-verified.json').write_text(json.dumps(receipt, indent=2) + '\n')

checkpoint = json.loads((lab / 'active-checkpoint.json').read_text())
checkpoint.update(published=True, publication=published, tag=receipt,
                  pre_publication_review='Accepted; pre-publication-review.md',
                  ci_status='10/10 passed', candidate_status='8/8 passed; independently verified',
                  published_matrix_run=36303600781, live_docs='passed')
matrix = lab / 'published-matrix-verified.json'
if matrix.exists():
    result = json.loads(matrix.read_text())
    assert result['status'] == 'passed' and result['source'] == source
    checkpoint['published_matrix_status'] = '8/8 passed; validated raw receipts and audited locks'
    checkpoint['remaining'] = ['Final independent published-evidence acceptance',
                               'Retain bounded release evidence and complete release plan',
                               'Push notes-only closeout, keeping release tag at published source']
else:
    checkpoint['published_matrix_status'] = 'in progress'
    checkpoint['remaining'] = ['Complete and download published matrix, then validate raw receipts',
                               'Final independent published-evidence acceptance',
                               'Retain bounded release evidence and complete release plan',
                               'Push notes-only closeout, keeping release tag at published source']
if matrix.exists() and (lab / 'post-publication-review.md').exists():
    checkpoint['post_publication_review'] = 'Accepted; post-publication-review.md'
    checkpoint['remaining'] = ['Retain bounded release evidence and complete release plan',
                               'Push notes-only closeout, keeping release tag at published source']
(lab / 'active-checkpoint.json').write_text(json.dumps(checkpoint, indent=2) + '\n')
print('Annotated release tag matches the published source locally and remotely; checkpoint updated.')
