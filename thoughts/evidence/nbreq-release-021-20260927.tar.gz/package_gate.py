"""Exercise packaged portable TLS tests and an independent opt-in consumer; never publish."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import subprocess
import tarfile
import tempfile
from urllib.parse import unquote, urlsplit

import owned_command as supervisor

def terminate(_signal, _frame):
    raise SystemExit('Package gate received SIGTERM')

signal.signal(signal.SIGTERM, terminate)

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
root, out = a.root.resolve(), a.out.resolve()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
version = re.search(r'(?m)^version = "([^"]+)"', (root / 'Cargo.toml').read_text()).group(1)
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, CARGO_TARGET_DIR=str(out / 'build'), RUSTUP_TOOLCHAIN='stable',
           CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_PROFILE_TEST_DEBUG='0')
env.pop('CARGO_BUILD_TARGET', None)
steps, failure, metadata = [], None, {}

def run(label, argv, cwd=root, timeout=900):
    supervisor.command(argv, cwd, out, label, env, timeout)
    steps.append(label)

try:
    run('compiler', ['rustc', '+stable', '-vV'], timeout=30)
    run('package', ['cargo', '+stable', 'package', '--locked', '--offline', '-p', 'nbreq'])
    archive = out / 'build' / 'package' / ('nbreq-' + version + '.crate')
    prefix = 'nbreq-' + version + '/'
    with tarfile.open(archive) as bundle:
        entries = bundle.getmembers()
        names = {e.name for e in entries}
        assert len(names) == len(entries)
        assert all(e.isfile() and e.name.startswith(prefix) and '\\' not in e.name
                   and '..' not in PurePosixPath(e.name).parts for e in entries)
        vcs = json.load(bundle.extractfile(prefix + '.cargo_vcs_info.json'))
        assert vcs['git']['sha1'] == commit and not vcs['git'].get('dirty', False)
        for name in ['tests/portable_tls.rs', 'tests/support/portable_tls_fixture.rs',
                     'src/backend/native_tls/portable_tests.rs',
                     'src/backend/native_http/tests/standalone_tls_shutdown.rs',
                     'tests/fixtures/portable-trust/cavesvr3-chain-0.der']:
            assert prefix + name in names, name
        links = []
        for entry in entries:
            if not entry.name.endswith('.md'):
                continue
            for destination in re.findall(r'\]\(([^\s)]+)\)', bundle.extractfile(entry).read().decode()):
                url = urlsplit(destination)
                if url.scheme or url.netloc or not url.path:
                    continue
                parts = list(PurePosixPath(entry.name).parent.parts)
                for part in PurePosixPath(unquote(url.path)).parts:
                    if part == '..':
                        assert len(parts) > 1
                        parts.pop()
                    elif part != '.':
                        parts.append(part)
                target = '/'.join(parts)
                assert target in names, (entry.name, destination)
                links.append(dict(document=entry.name, destination=destination, target=target))
        hashes = {e.name: hashlib.sha256(bundle.extractfile(e).read()).hexdigest() for e in entries}
        isolated = Path(tempfile.mkdtemp(prefix='nbreq-portable-package-' + commit[:8] + '-')).resolve()
        for entry in entries:
            destination = isolated / entry.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as f:
                f.write(bundle.extractfile(entry).read())
    metadata = dict(commit=commit, vcs=vcs, files=hashes, links=links,
                    package_sha256=supervisor.sha(archive), isolated_root=str(isolated))
    supervisor.write(out / 'inventory.json', metadata)
    packaged = isolated / prefix.rstrip('/')
    run('packaged-public-tests', ['cargo', '+stable', 'test', '--locked', '--offline',
                                 '--all-features', '--test', 'portable_tls'], packaged)
    run('packaged-bundle-proof', ['cargo', '+stable', 'test', '--locked', '--offline',
                                 '--all-features', '--lib', 'portable_tests'], packaged)
    run('packaged-close-regressions', ['cargo', '+stable', 'test', '--locked', '--offline',
                                      '--all-features', '--test', 'tcp_tls_api'], packaged)
    run('packaged-final-shutdown', ['cargo', '+stable', 'test', '--locked', '--offline',
                                   '--all-features', '--lib', 'final_tls_write_shutdown_'], packaged)
    shutdown_log = (out / 'packaged-final-shutdown.log').read_text(encoding='utf-8')
    assert re.findall(r'test result: ok\.\s+(\d+) passed;\s+0 failed', shutdown_log) == ['2']
    consumer = isolated / 'consumer'
    (consumer / 'src').mkdir(parents=True)
    (consumer / 'Cargo.toml').write_text('''[package]
name = "portable-trust-consumer"
version = "0.0.0"
edition = "2021"
[workspace]
[features]
bundled-roots = ["nbreq/bundled-roots"]
[dependencies]
nbreq = { path = "../nbreq-''' + version + '''", default-features = false, features = ["native"] }
''', encoding='utf-8')
    source = '''use nbreq::{Engine, EngineConfig, ErrorKind, TlsTrust};
fn main() {
    let default = EngineConfig::spawned();
    assert_eq!(default.tls_trust(), TlsTrust::Platform);
    let _platform = Engine::new(default).expect("platform construction");
    let der = include_bytes!("../../nbreq-VERSION/tests/fixtures/portable-trust/cavesvr3-chain-2.der");
    let _supplied = Engine::new(EngineConfig::spawned()
        .with_tls_trust(TlsTrust::SuppliedRootsOnly)
        .with_additional_tls_root_certificate(der.to_vec())).expect("supplied construction");
    let bundled = Engine::new(EngineConfig::spawned().with_tls_trust(TlsTrust::BundledMozilla));
    if cfg!(feature = "bundled-roots") { assert!(bundled.is_ok()); }
    else { assert_eq!(bundled.err().expect("missing optional feature").kind(), ErrorKind::Unsupported); }
    println!("consumer trust construction passed; bundled-roots={}", cfg!(feature = "bundled-roots"));
}
'''.replace('VERSION', version)
    (consumer / 'src/main.rs').write_text(source, encoding='utf-8')
    run('consumer-resolve', ['cargo', '+stable', 'generate-lockfile', '--offline'], consumer)
    for name, features in [('default', []), ('bundle', ['--features', 'bundled-roots'])]:
        run('consumer-' + name, ['cargo', '+stable', 'run', '--locked', '--offline'] + features, consumer)
        run('consumer-tree-' + name, ['cargo', '+stable', 'tree', '--locked', '--offline'] + features, consumer)
    for name in ('Cargo.toml', 'Cargo.lock', 'src/main.rs'):
        (out / ('consumer-' + name.replace('/', '-'))).write_bytes((consumer / name).read_bytes())
except BaseException as error:
    failure = repr(error)
finally:
    try:
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == commit
    except BaseException as error:
        failure = (failure + '; ' if failure else '') + 'source integrity: ' + repr(error)
    supervisor.write(out / 'result.json', dict(status='failed' if failure else 'passed', failure=failure,
                     commit=commit, steps=steps, package_sha256=metadata.get('package_sha256')))
if failure:
    raise SystemExit(failure)
print('Packaged portable TLS tests and independent consumers passed')
