from pathlib import Path
import datetime,json,subprocess,urllib.request,urllib.error
root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent
expected=json.loads((lab/'final-root-candidate.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
refs=subprocess.check_output(['git','ls-remote','origin','refs/heads/main','refs/tags/v0.2.1','refs/tags/v0.2.1^{}'],cwd=root,text=True).splitlines()
assert refs==[expected['source_commit']+'\trefs/heads/main'],refs
url='https://crates.io/api/v1/crates/nbreq/0.2.1'
try:
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'nbreq-021-release-preflight'}),timeout=45) as response:
        raise RuntimeError('NBReq0.2.1 already exists; inspect before any publication')
except urllib.error.HTTPError as error:
    assert error.code==404,error.code
record=dict(source=expected['source_commit'],remote_main_matches=True,tag_absent=True,registry_version_absent=True,
            checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(lab/'prepublish-preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
