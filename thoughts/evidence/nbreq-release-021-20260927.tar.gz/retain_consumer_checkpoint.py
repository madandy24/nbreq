from pathlib import Path
import hashlib, json, tarfile

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab=Path('C:/User/projects/nbreq/target/release-bundle-consumer-20260927')
release=Path(__file__).resolve().parent
hashes=json.loads((lab/'evidence-hashes.json').read_text())
entries={}
for name,digest in hashes.items():
    path=(lab/name).resolve()
    assert path.is_relative_to(lab.resolve()) and path.is_file()
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    assert path.suffix.lower() not in ['.exe','.dll','.pdb','.rlib']
    entries['consumer/'+name]=path
entries['consumer/evidence-hashes.json']=lab/'evidence-hashes.json'
for name in ['upstream-yoke-metadata.json','inherited-archive-audit.json',
             'workspace-audit/audit.log','workspace-audit/audit.result.json','workspace-audit/result.json']:
    entries['release/'+name]=release/name
summary=json.loads((lab/'summary.json').read_text())
for name,digest in summary['tooling_hashes'].items():
    assert hashlib.sha256((root/'tools/release-consumer'/name).read_bytes()).hexdigest()==digest
destination=root/'thoughts/evidence/nbreq-release-consumer-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz') as bundle:
    for name,path in entries.items():bundle.add(path,arcname=name,recursive=False)
member_hashes={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in entries.items()}
with tarfile.open(destination) as bundle:
    members=bundle.getmembers()
    assert len(members)==len(entries) and all(m.isfile() for m in members)
    assert {m.name:hashlib.sha256(bundle.extractfile(m).read()).hexdigest() for m in members}==member_hashes
record=dict(archive=destination.name,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    bytes=destination.stat().st_size,regular_members=len(entries),
    status='Tooling verified; fresh Rust 1.85 release gate blocked upstream',
    summary=summary,members=member_hashes)
(root/'thoughts/evidence/nbreq_release_consumer_021_artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['archive','sha256','bytes','regular_members','status']},indent=2))
