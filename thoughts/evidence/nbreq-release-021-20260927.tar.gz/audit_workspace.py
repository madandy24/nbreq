from pathlib import Path
import json, os, subprocess
from owned_command import command

root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent
out=lab/'workspace-audit'
out.mkdir(exist_ok=False)
command([str(root/'target/tools/cargo-audit/bin/cargo-audit.exe'),'audit',
         '--db',str(lab/'advisory-db'),'--file','Cargo.lock','--json'],
        root,out,'audit',dict(os.environ),300)
report=json.loads((out/'audit.log').read_text())
assert not report['vulnerabilities']['found'] and not report['warnings']
database=subprocess.check_output(['git','-C',str(lab/'advisory-db'),'log','-1','--format=%H %cI'],text=True).strip()
(out/'result.json').write_text(json.dumps(dict(status='passed',database=database),indent=2))
print('Workspace lock audit passed: '+database)
