from pathlib import Path
import hashlib,json,re,tarfile
root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent/'intel-tls-diagnostic'
summary=json.loads((lab/'summary.json').read_text())
assert len(summary['results'])==6 and all(c['exit']==c['expected_exit'] for c in summary['results'])
assert summary['source_hashes_unchanged']
assert 'NBReq verification complete: all 30 steps passed' in (lab/'stable-verifier.log').read_text()
for name,digest in json.loads((lab/'source-after.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
manifest=json.loads((lab/'public-evidence-manifest.json').read_text())
entries={}
for name,identity in manifest.items():
    path=(lab/name).resolve()
    assert path.parent==lab.resolve() and path.is_file() and not path.is_symlink()
    assert path.suffix in {'.json','.log','.txt','.rs','.py','.diff'}
    data=path.read_bytes()
    assert len(data)==identity['bytes'] and hashlib.sha256(data).hexdigest()==identity['sha256']
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16})',data)
    entries[name]=path
entries['public-evidence-manifest.json']=lab/'public-evidence-manifest.json'
destination=root/'thoughts/evidence/nbreq-tls-watchdog-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz') as bundle:
    for name,path in entries.items():bundle.add(path,arcname=name,recursive=False)
members={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in entries.items()}
with tarfile.open(destination) as bundle:
    assert all(m.isfile() for m in bundle.getmembers())
    assert {m.name:hashlib.sha256(bundle.extractfile(m).read()).hexdigest() for m in bundle.getmembers()}==members
record=dict(archive=destination.name,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    bytes=destination.stat().st_size,regular_members=len(entries),summary=summary,members=members)
(root/'thoughts/evidence/nbreq_tls_watchdog_021_artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['archive','sha256','bytes','regular_members']},indent=2))
