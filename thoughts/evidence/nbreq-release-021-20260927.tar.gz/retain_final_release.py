"""Retain bounded release receipts and archives, excluding build directories."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, re, tarfile, zipfile

root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent
published=json.loads((lab/'published-root.json').read_text())
matrix=json.loads((lab/'published-matrix-verified.json').read_text())
assert matrix['status']=='passed' and matrix['mode']=='published'
assert matrix['source']==published['source_commit'] and matrix['jobs']==8
assert len(matrix['artifacts'])==8
assert all(a['archive_sha256']==published['sha256'] for a in matrix['artifacts'])
assert all(c['registry_only'] and c['support_from_registry']
           for a in matrix['artifacts'] for c in a['cases'])
assert hashlib.sha256((lab/'nbreq-0.2.1.crate').read_bytes()).hexdigest()==published['sha256']
tag=json.loads((lab/'published-tag-verified.json').read_text())
assert tag['status']=='passed' and tag['source_commit']==published['source_commit']
assert tag['remote']['refs/tags/v0.2.1^{}']==published['source_commit']
assert tag['remote']['refs/tags/v0.2.1']==tag['annotated_tag_object']
assert json.loads((lab/'published-docs-verified.json').read_text())['status']=='passed'
entries={}
allowed={'.json','.log','.lock','.zip','.py','.html','.crate','.txt','.toml','.md','.rs'}
directories=['hosted-ci','hosted-candidate','hosted-published','package-final','dry-run','publish',
             'candidate-lock-audits','published-lock-audits','msrv-lint-fix']
for prefix in ['', 'attempt-1/', 'attempt-2/']:
    for directory in directories:
        base=lab/(prefix+directory)
        if not base.exists(): continue
        for path in base.rglob('*'):
            rel=path.relative_to(base)
            if any(part in {'build','target','__pycache__'} for part in rel.parts): continue
            if path.is_file() and path.suffix in allowed:
                entries[path.relative_to(lab).as_posix()]=path
for base in [lab,lab/'attempt-1',lab/'attempt-2']:
    if not base.exists(): continue
    for path in base.iterdir():
        if path.is_file() and path.suffix in allowed: entries[path.relative_to(lab).as_posix()]=path
secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16})')
def inspect(name,data,depth=0):
    assert depth<5 and not secret.search(data),name
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as bundle:
            for member in bundle.infolist():
                assert not PurePosixPath(member.filename).is_absolute() and '..' not in PurePosixPath(member.filename).parts
                if not member.is_dir(): inspect(name+'!/'+member.filename,bundle.read(member),depth+1)
    elif name.endswith(('.crate','.tar.gz')):
        with tarfile.open(fileobj=io.BytesIO(data)) as bundle:
            for member in bundle.getmembers():
                assert not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
                assert member.isfile() or member.isdir()
                if member.isfile(): inspect(name+'!/'+member.name,bundle.extractfile(member).read(),depth+1)
for name,path in entries.items():
    assert path.resolve().is_relative_to(lab.resolve()) and not path.is_symlink()
    inspect(name,path.read_bytes())
destination=root/'thoughts/evidence/nbreq-release-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz') as bundle:
    for name,path in entries.items(): bundle.add(path,arcname=name,recursive=False)
members={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in entries.items()}
with tarfile.open(destination) as bundle:
    assert all(m.isfile() for m in bundle.getmembers())
    assert {m.name:hashlib.sha256(bundle.extractfile(m).read()).hexdigest() for m in bundle.getmembers()}==members
record=dict(archive=destination.name,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    bytes=destination.stat().st_size,regular_members=len(entries),publication=published,members=members)
(root/'thoughts/evidence/nbreq_release_021_artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
