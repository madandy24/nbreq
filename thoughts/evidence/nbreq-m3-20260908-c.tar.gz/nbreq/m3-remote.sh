#!/bin/sh
set -eu
lab=$1
cache=$2
scope=$3
before=$4
case "$lab" in */nbreq-m3-20260908-c) ;; *) exit 2 ;; esac
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$cache"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export RUSTUP_TOOLCHAIN=stable
trap 'code=$?; printf "%s\n" "$code" > "$lab/run.exit"' EXIT
prior=$(dirname "$lab")/nbreq-m3-20260908-b
while ! test -f "$prior/run.exit"; do sleep 5; done
test "$(cat "$prior/run.exit")" = 0
cd "$lab/nbreq"
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m3-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
cargo clean --offline -p nbreq
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    CARGO_TARGET_DIR="$lab/runner-$toolchain" cargo build --locked --offline --manifest-path tools/xtask/Cargo.toml
    "$lab/runner-$toolchain/debug/nbreq-xtask" verify --offline > "$lab/verify-$toolchain.log" 2>&1
    printf 'M3_VERIFY_PASS %s\n' "$toolchain"
done
export RUSTUP_TOOLCHAIN=stable
if [ "$scope" = measure ]; then
    mkdir -p "$lab/bin"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/plain"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/meter"
    source_hash=$(python3 -c 'import hashlib,pathlib; print(hashlib.sha256(pathlib.Path("m3-source.sha256").read_bytes()).hexdigest())')
    python3 m3-compare.py --before-plain "$before/bin/plain" --before-meter "$before/bin/meter" --after-plain "$lab/bin/plain" --after-meter "$lab/bin/meter" --output "$lab/comparison" --source "$source_hash"
fi
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m3-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
printf 'M3_HOST_PASS\n'
