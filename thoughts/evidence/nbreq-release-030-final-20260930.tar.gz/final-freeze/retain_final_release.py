"""Plan, then retain compact final-source 0.3.0 evidence with exact read-back.

`plan` writes only an ignored lab inventory. `archive` requires the approved
SHA256 of that plan and creates the tracked evidence archive and compact index.
No source checkout, build/cache tree, advisory DB checkout, or private bridge
directory is traversed. Run only after the final local and hosted gates finish.
"""

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import zipfile


ROOT = Path("C:/User/projects/nbreq")
FINAL = ROOT / "target/release-030-final-20260930"
PRIOR = ROOT / "target/release-030-20260929/attempt-2"
EVIDENCE = ROOT / "thoughts/evidence"
ARCHIVE = EVIDENCE / "nbreq-release-030-final-20260930.tar.gz"
PUBLIC_INDEX = EVIDENCE / "nbreq_release_030_final_artifacts.json"
PLAN = FINAL / "retention-plan.json"
SOURCE = "ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08"
PACKAGE_SHA = "193601f9a1616659afcd1802d3f904dded739a73ffc4786fffb828feb102f242"
PRIOR_SOURCE = "a64bf92bd74c871cb77e8eac5c4e9e0cde91a0b1"
PRIOR_PACKAGE_SHA = "b84102cabb72214305bddb4f365d093b3fdb17cee7cf3fa2e1620d28f8034b1a"
MAX_FILE = 128 * 1024 * 1024
MAX_NESTED_TOTAL = 256 * 1024 * 1024
ALLOWED_SUFFIXES = (".json", ".jsonl", ".log", ".txt", ".md", ".py", ".rs", ".diff",
                    ".toml", ".lock", ".zip", ".crate")
DENIED_COMPONENTS = {"build", "target", "cache", "__pycache__", "unpacked",
                     "advisory-db", ".git", "node_modules", "tmp", "temp"}
GROUPS = {"verify", "package", "packaged-tests", "registry", "registry-candidate",
          "publish-dry-run", "authoritative-package", "hosted-ci", "ci-selected-locks",
          "selected-lock-audit", "public-index-preflight", "public-index-preflight-final",
          "frozen-source", "frozen-source-final"}
SINGLE_FILES = {"release_gate.py", "github_release.py", "validate_matrix.py",
                "scan_selected_locks.py", "retain_final_release.py", "prepare_advisory_db.py",
                "preflight_public_index.py", "preflight_public_index_final.py",
                "check_frozen_checkout.py", "check_frozen_checkout-original.py",
                "check_frozen_checkout_final.py",
                "normalize_frozen_checkout.py", "normalization-plan.json",
                "normalization-attempt.json", "normalization-rollback.json",
                "normalization-first-attempt.json", "normalization-first-rollback.json",
                "normalization-refresh-attempt.json", "frozen-checkout-normalization.json",
                "diagnose_frozen_eol_status.py",
                "eol-status-diagnostic.json", "advisory-db-snapshot.json", "rustsec-clone.log",
                "postrun_extraction_check.py", "postrun-extraction-identity.json",
                "rustsec-clone.result.json", "command.json", "ci-matrix-verified.json",
                "ci-artifact-inventory.json", "final-review.json"}
SECRET_SHAPES = (
    re.compile(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})"),
    re.compile(rb"AKIA[A-Z0-9]{16}"),
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"(?i:authorization)\s*[:=]\s*(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{16,}"),
    re.compile(rb"(?:xox[baprs]-[A-Za-z0-9-]{20,}|sk-[A-Za-z0-9_-]{30,})"),
)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def git_blobs(commit):
    """Read every tracked blob from an exact commit without using working-tree state."""
    listing = subprocess.run(["git", "-C", str(ROOT), "ls-tree", "-r", "-z", commit],
                             check=True, stdout=subprocess.PIPE).stdout
    entries = []
    for row in listing.split(b"\0"):
        if not row:
            continue
        metadata, raw_path = row.split(b"\t", 1)
        mode, kind, object_id = metadata.split(b" ")
        require(kind == b"blob" and mode in (b"100644", b"100755"),
                "unexpected tracked object in final commit")
        entries.append((raw_path.decode("utf-8"), object_id))
    response = subprocess.run(["git", "-C", str(ROOT), "cat-file", "--batch"],
                              input=b"".join(object_id + b"\n" for _, object_id in entries),
                              check=True, stdout=subprocess.PIPE).stdout
    cursor = 0
    blobs = {}
    for path, object_id in entries:
        end = response.index(b"\n", cursor)
        returned_id, kind, raw_size = response[cursor:end].split(b" ")
        require(returned_id == object_id and kind == b"blob", "Git blob identity mismatch")
        size = int(raw_size)
        cursor = end + 1
        data = response[cursor:cursor + size]
        require(len(data) == size and response[cursor + size:cursor + size + 1] == b"\n",
                "Git blob framing mismatch")
        cursor += size + 1
        require(path not in blobs, "duplicate Git path")
        blobs[path] = data
    require(cursor == len(response), "unexpected Git batch trailing bytes")
    return blobs


def bind_precommit_verifier(source):
    before = read_json(FINAL / "verify/source-before.json")
    after = read_json(FINAL / "verify/source-after.json")
    require(before == after and len(before["files"]) == 475 and
            before["commit"] == "566cbd0ee3f870cbe6cfef0dc92531f6da1b63b6",
            "precommit verifier source snapshot changed")
    blobs = git_blobs(source)
    require(set(blobs) == set(before["files"]),
            "precommit verifier/final commit tracked file sets differ")
    differing = []
    for path, old_hash in before["files"].items():
        blob = blobs[path]
        lf = blob.replace(b"\r\n", b"\n")
        acceptable_hashes = {sha(blob), sha(lf), sha(lf.replace(b"\n", b"\r\n"))}
        if old_hash not in acceptable_hashes:
            # A checkout can contain mixed line endings. Its exact raw hash
            # must still match the verifier snapshot before normalization.
            checkout = ROOT / path
            checkout_bytes = checkout.read_bytes()
            if not (sha(checkout_bytes) == old_hash and
                    checkout_bytes.replace(b"\r\n", b"\n") == lf):
                differing.append(path)
    require(not differing,
            "precommit verifier differs from final tracked source: " +
            ", ".join(differing[:10]))
    return dict(precommit=before["commit"], tracked_files=len(blobs),
                postverify_source_differences=differing)


def check_name(name):
    path = PurePosixPath(name)
    require(name == path.as_posix() and not path.is_absolute() and len(path.parts) > 0 and
            all(part not in ("", ".", "..") and "\\" not in part and ":" not in part and
                not any(ord(char) < 32 for char in part) for part in path.parts),
            "unsafe archive member: " + name)
    return path


def scan_text(name, data):
    for pattern in SECRET_SHAPES:
        require(pattern.search(data) is None, "credential-shaped content: " + name)


def nested_inventory(name, data):
    if not (name.endswith(".zip") or name.endswith(".crate") or name.endswith(".tar.gz")):
        scan_text(name, data)
        return None
    members = []
    seen = set()
    expanded = 0
    if name.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            require(len(archive.infolist()) <= 20000, "too many ZIP entries: " + name)
            for item in archive.infolist():
                require(not item.is_dir() and not (item.flag_bits & 1),
                        "directory/encrypted nested ZIP entry: " + name)
                path = check_name(item.filename)
                kind = (item.external_attr >> 16) & 0o170000
                require(kind in (0, stat.S_IFREG), "nonregular nested ZIP member: " + name)
                require(item.file_size <= MAX_FILE, "oversized nested ZIP member: " + name)
                nested = archive.read(item)
                require(len(nested) == item.file_size, "nested ZIP size mismatch: " + name)
                require(path.as_posix().casefold() not in seen, "duplicate nested ZIP member: " + name)
                seen.add(path.as_posix().casefold())
                expanded += len(nested)
                require(expanded <= MAX_NESTED_TOTAL, "oversized nested ZIP: " + name)
                require(not item.filename.endswith((".zip", ".gz", ".crate")),
                        "unexpected archive inside ZIP: " + name + "/" + item.filename)
                scan_text(name + "/" + item.filename, nested)
                members.append(dict(path=item.filename, bytes=len(nested), sha256=sha(nested)))
    else:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
            tar_members = archive.getmembers()
            require(len(tar_members) <= 20000, "too many nested TAR entries: " + name)
            for item in tar_members:
                require(item.isfile(), "nonregular nested TAR member: " + name)
                path = check_name(item.name)
                require(item.size <= MAX_FILE, "oversized nested TAR member: " + name)
                nested = archive.extractfile(item).read()
                require(len(nested) == item.size, "nested TAR size mismatch: " + name)
                require(path.as_posix().casefold() not in seen, "duplicate nested TAR member: " + name)
                seen.add(path.as_posix().casefold())
                expanded += len(nested)
                require(expanded <= MAX_NESTED_TOTAL, "oversized nested TAR: " + name)
                require(not item.name.endswith((".zip", ".gz", ".crate")),
                        "unexpected archive inside TAR: " + name + "/" + item.name)
                scan_text(name + "/" + item.name, nested)
                members.append(dict(path=item.name, bytes=len(nested), sha256=sha(nested)))
    return members


def add_file(files, source, name):
    require(not source.is_symlink(), "symlink evidence source: " + name)
    source = source.resolve(strict=True)
    require(source.is_file(), "not a regular evidence file: " + name)
    require(source.is_relative_to(ROOT), "evidence escaped workspace: " + name)
    require(name not in files, "duplicate evidence path: " + name)
    check_name(name)
    require(source.stat().st_size <= MAX_FILE, "oversized evidence file: " + name)
    files[name] = source


def group_files(files, base, label, groups, singles):
    for relative in sorted(singles):
        path = base / relative
        if path.is_file():
            add_file(files, path, label + "/" + relative.replace("\\", "/"))
    for group in sorted(groups):
        folder = base / group
        if not folder.is_dir():
            continue
        require(not folder.is_symlink(), "symlink evidence group: " + str(folder))
        for current, directories, filenames in os.walk(folder, followlinks=False):
            current_path = Path(current)
            directories[:] = [name for name in directories
                              if name.lower() not in DENIED_COMPONENTS and
                              not name.startswith(".") and not (current_path / name).is_symlink()]
            for filename in filenames:
                path = current_path / filename
                if filename.startswith(".") or not filename.lower().endswith(ALLOWED_SUFFIXES):
                    continue
                relative = path.relative_to(base)
                add_file(files, path, label + "/" + relative.as_posix())


def collect(source, package_sha):
    require(source == SOURCE and package_sha == PACKAGE_SHA,
            "unexpected final dated source or package SHA")
    prior_index = read_json(EVIDENCE / "nbreq_release_030_artifacts.json")
    prior_archive = EVIDENCE / prior_index["archive"]
    require(prior_index["source"] == PRIOR_SOURCE and
            prior_index["canonical_package_sha256"] == PRIOR_PACKAGE_SHA and
            prior_index["sha256"] == sha(prior_archive.read_bytes()) and
            prior_index["bytes"] == prior_archive.stat().st_size,
            "prior reviewed evidence archive identity mismatch")
    prior_reference = dict(path=prior_archive.relative_to(ROOT).as_posix(),
                           sha256=prior_index["sha256"], bytes=prior_index["bytes"])

    verify = read_json(FINAL / "verify/summary.json")
    binding = bind_precommit_verifier(source)
    require(verify["status"] == "passed" and verify["source_hashes_unchanged"] and
            verify["commit"] == binding["precommit"] and
            "NBReq verification complete: all 30 steps passed" in
            (FINAL / "verify/full-verifier.log").read_text(encoding="utf-8"),
            "precommit 30-step verifier or final-source binding incomplete")
    for stage in ("package", "packaged-tests", "registry", "publish-dry-run"):
        outcome = read_json(FINAL / stage / "summary.json")
        require(outcome["status"] == "passed" and outcome["commit"] == source and
                outcome["source_hashes_unchanged"],
                "final dated-source local gate incomplete: " + stage)
    for compiler in ("stable", "1.85.0"):
        for check in ("packaged-focused", "packaged-bundle", "packaged-shutdown",
                      "packaged-http-composition", "packaged-doctests"):
            result = read_json(FINAL / "packaged-tests" /
                               (compiler + "-" + check + ".result.json"))
            require(result["exit_code"] == 0, "packaged verification failed: " +
                    compiler + "/" + check)

    previous_inventory = read_json(PRIOR / "authoritative-package/inventory.json")
    current_inventory = read_json(FINAL / "authoritative-package/inventory.json")
    canonical = Path(current_inventory["path"])
    require(previous_inventory["commit"] == PRIOR_SOURCE and
            previous_inventory["sha256"] == PRIOR_PACKAGE_SHA and
            current_inventory["commit"] == source and
            current_inventory["sha256"] == package_sha and
            current_inventory["vcs"]["git"]["sha1"] == source and
            canonical.resolve() ==
            (FINAL / "authoritative-package/build/package/nbreq-0.3.0.crate").resolve() and
            canonical.stat().st_size == current_inventory["bytes"] and
            sha(canonical.read_bytes()) == package_sha,
            "final canonical package identity mismatch")
    delta = read_json(FINAL / "package/source-delta.json")
    changed = {row["path"] for row in delta["changed"]}
    require(delta["exact_expected_delta"] and not delta["added"] and not delta["removed"] and
            changed == {".cargo_vcs_info.json", "CHANGELOG.md",
                        "docs/migrating-to-0.3.md"} and
            delta["prior_commit"] == PRIOR_SOURCE and delta["current_commit"] == source and
            delta["prior_archive_sha256"] == PRIOR_PACKAGE_SHA and
            delta["current_archive_sha256"] == package_sha and
            set(previous_inventory["files"]) == set(current_inventory["files"]) and
            {name for name in previous_inventory["files"]
             if previous_inventory["files"][name] != current_inventory["files"][name]} == changed,
            "prior-to-final package delta exceeds two docs and VCS metadata")
    extraction = read_json(FINAL / "postrun-extraction-identity.json")
    require(extraction["status"] == "passed" and extraction["source_commit"] == source and
            Path(extraction["archive_path"]).resolve() == canonical.resolve() and
            extraction["archive_sha256"] == package_sha and
            extraction["expected_file_count"] == extraction["actual_file_count"] == 116 and
            not extraction["added"] and not extraction["removed"] and
            not extraction["changed"],
            "post-test extracted package inputs differ from canonical archive")
    registry = read_json(FINAL / "registry-candidate/result.json")
    require(registry["status"] == "passed" and registry["archive_sha256"] == package_sha and
            len(registry["cases"]) == 4, "final local registry matrix incomplete")

    dry = read_json(FINAL / "publish-dry-run/archive-byte-identity.json")
    command = read_json(FINAL / "publish-dry-run/publish-dry-run.result.json")
    require(dry["identical"] and dry["source_commit"] == source and
            dry["dry_run_command"] == command and command["exit_code"] == 0 and
            command["argv"] ==
            ["rustup", "run", "stable", "cargo", "publish", "--dry-run", "--locked", "-p", "nbreq"],
            "final dry-run command/identity incomplete")
    generated = {"tmp-crate": FINAL / "publish-dry-run/build/package/tmp-crate/nbreq-0.3.0.crate",
                 "tmp-registry": FINAL / "publish-dry-run/build/package/tmp-registry/nbreq-0.3.0.crate"}
    for label, path in {"canonical": canonical, **generated}.items():
        item = dry["canonical"] if label == "canonical" else dry["generated"][label]
        require(Path(item["path"]).resolve() == path.resolve() and
                item["sha256"] == package_sha and item["bytes"] == path.stat().st_size and
                sha(path.read_bytes()) == package_sha,
                "final dry-run archive bytes mismatch: " + label)

    initial_index = read_json(FINAL / "public-index-preflight/summary.json")
    corrected_index = read_json(FINAL / "public-index-preflight-final/summary.json")
    require(initial_index["status"] == "failed" and
            "nbreq-darwin" in initial_index["error"] and
            corrected_index["status"] == "passed" and
            {item["crate"] for item in corrected_index["results"]} ==
            {"nbreq", "nbreq-winpoll", "nbreq-darwin"} and
            next(item for item in corrected_index["results"] if item["crate"] == "nbreq")
            ["selected"]["v030_present"] is False,
            "public-index point-in-time preflight classification mismatch")
    public_expected = {
        "nbreq-winpoll": ("0.1.1", "9e4fc64245514209beb6e3feccb4b980e1c259546a9e07543e3529e1d7053696"),
        "nbreq-darwin": ("0.1.0", "31d7a69844b990331f85dc497f14d0b6a08f8ceaee402e7c6aa19919f3e3c839"),
    }
    for item in corrected_index["results"]:
        name = item["crate"]
        raw = FINAL / "public-index-preflight-final/raw" / (name + ".jsonl")
        records = [json.loads(line) for line in raw.read_bytes().splitlines() if line]
        require(Path(item["raw_file"]).resolve() == raw.resolve() and
                item["raw_sha256"] == sha(raw.read_bytes()) and
                item["raw_bytes"] == raw.stat().st_size and
                item["index_entries"] == len(records) and
                item["index_url"] == "https://index.crates.io/nb/re/" + name and
                item["response_url"] == item["index_url"],
                "public sparse-index raw response identity mismatch: " + name)
        if name == "nbreq":
            require("0.3.0" not in [record["vers"] for record in records],
                    "nbreq 0.3.0 present in retained public index snapshot")
        else:
            version, checksum = public_expected[name]
            selected = [record for record in records if record["vers"] == version]
            require(len(selected) == 1 and selected[0]["cksum"] == checksum and
                    selected[0]["yanked"] is False and
                    item["selected"] == dict(version=version, sha256=checksum, yanked=False),
                    "helper sparse-index checksum/yank mismatch: " + name)
    snapshot = read_json(FINAL / "advisory-db-snapshot.json")
    require(snapshot["source"] == "https://github.com/RustSec/advisory-db.git" and
            snapshot["clean"] and
            snapshot["commit"] == "f23b768236fe2880e4cfa167da662cad8ca79240" and
            snapshot["auditor_version"] == "cargo-audit 0.22.2" and
            snapshot["policy_sha256"] == sha((ROOT / ".cargo/audit.toml").read_bytes()),
            "fresh advisory database or auditor identity mismatch")

    ci = read_json(FINAL / "ci-matrix-verified.json")
    require(ci["status"] == "passed" and ci["source"] == source and
            ci["jobs"] == 10 and ci["consumer_graphs"] == 16 and
            ci["positive_tests"] == 752 and ci["negative_probes"] == 32 and
            ci["examples"] == 144,
            "final dated-source hosted CI matrix incomplete")
    audit = read_json(FINAL / "selected-lock-audit/summary.json")
    require(audit["status"] == "passed" and audit["source"] == source and
            audit["package_sha256"] == package_sha and
            audit["prior_candidate_source"] == PRIOR_SOURCE and
            audit["final_ci_run_id"] == ci["run_id"] and
            audit["carried_prior_locks"] == 10 and
            audit["distinct_locks"] == audit["audited_locks"] and
            audit["advisory_database_commit"] == snapshot["commit"],
            "fresh union-of-locks audit incomplete")

    failed_frozen = read_json(FINAL / "frozen-source/summary.json")
    failed_archive = FINAL / "frozen-source/build/package/nbreq-0.3.0.crate"
    require(failed_frozen["status"] == "failed" and
            "archive differs from verified canonical bytes" in failed_frozen["failure"] and
            failed_frozen["source"] == source and
            failed_frozen["canonical_package_sha256"] == package_sha and
            failed_frozen["source_hashes_unchanged"] and
            Path(failed_frozen["generated_path"]).resolve() == failed_archive.resolve() and
            failed_frozen["generated_sha256"] == sha(failed_archive.read_bytes()) and
            failed_frozen["bytes"] == failed_archive.stat().st_size and
            failed_frozen["generated_sha256"] != package_sha,
            "initial frozen-checkout mismatch diagnostic was not preserved")
    failed_before = read_json(FINAL / "frozen-source/source-before.json")
    require(failed_before == read_json(FINAL / "frozen-source/source-after.json") and
            failed_before["commit"] == source and not failed_before["status"],
            "initial frozen checkout source snapshot changed")
    rejected_normalization = read_json(FINAL / "normalization-first-attempt.json")
    rollback = read_json(FINAL / "normalization-first-rollback.json")
    require(len(rejected_normalization["expected_paths"]) == 19 and
            rejected_normalization["changed_paths"] ==
            rejected_normalization["expected_paths"] and
            rejected_normalization["exact_canonical_bytes"] and
            rejected_normalization["all_other_tracked_files_unchanged"] and
            rejected_normalization["status"] and
            rollback["status"] == "restored" and rollback["checkout_clean"] and
            rollback["all_tracked_hashes_restored"] and rollback["commit"] == source,
            "first checkout normalization failure or rollback evidence incomplete")
    refreshed = read_json(FINAL / "normalization-refresh-attempt.json")
    require(refreshed["commit"] == source and not refreshed["status"] and
            refreshed["changed_paths"] == refreshed["expected_paths"] ==
            rejected_normalization["expected_paths"] and
            refreshed["exact_canonical_bytes"] and
            refreshed["index_entries_unchanged"] and
            refreshed["index_entries_equal_head"] and
            refreshed["staged_diff_clean"] and
            refreshed["all_other_tracked_files_unchanged"],
            "refreshed checkout index/source proof incomplete")
    normalization_plan = read_json(FINAL / "normalization-plan.json")
    normalization = read_json(FINAL / "frozen-checkout-normalization.json")
    paths = {item["path"] for item in normalization["paths"]}
    require(normalization_plan["status"] == "validated" and
            normalization_plan["apply"] is False and
            normalization["status"] == "passed" and normalization["apply"] is True and
            normalization_plan["paths"] == normalization["paths"] and
            normalization["commit"] == source and
            normalization["canonical_archive_sha256"] == package_sha and
            normalization["failed_archive_sha256"] == failed_frozen["generated_sha256"] and
            normalization["reason"] == "Windows checkout CRLF conversion only" and
            normalization["git_status_clean"] and
            normalization["index_entries_unchanged"] and
            normalization["index_entries_equal_head"] and
            normalization["staged_diff_clean"] and
            normalization["previous_failed_attempt"] ==
            "normalization-first-attempt.json" and
            normalization["previous_rollback"] == "normalization-first-rollback.json" and
            normalization["all_other_tracked_files_unchanged"] and
            normalization["tracked_file_count"] == len(failed_before["files"]) and
            normalization["other_tracked_file_count"] == len(failed_before["files"]) - 19 and
            len(normalization["paths"]) == len(paths) == 19 and
            set(normalization["changed_paths"]) == paths and
            set(normalization["checkout_after_sha256"]) == paths and
            {"LICENSE-APACHE", "LICENSE-MIT"}.issubset(paths) and
            all(path in ("LICENSE-APACHE", "LICENSE-MIT") or
                (path.startswith("tests/fixtures/fuzz/") and path.endswith(".seed"))
                for path in paths),
            "frozen checkout normalization receipt exceeds exact CRLF scope")
    frozen = read_json(FINAL / "frozen-source-final/summary.json")
    frozen_before = read_json(FINAL / "frozen-source-final/source-before.json")
    changed_checkout = {name for name in failed_before["files"]
                        if failed_before["files"][name] != frozen_before["files"][name]}
    require(set(failed_before["files"]) == set(frozen_before["files"]) and
            changed_checkout == paths and frozen_before["commit"] == source and
            not frozen_before["status"],
            "final frozen checkout changed files outside normalized CRLF set")
    with tarfile.open(canonical, mode="r:gz") as accepted_package, tarfile.open(
            failed_archive, mode="r:gz") as rejected_package:
        for item in normalization["paths"]:
            path = item["path"]
            member = "nbreq-0.3.0/" + path
            accepted = accepted_package.extractfile(member).read()
            rejected = rejected_package.extractfile(member).read()
            require(item["canonical_sha256"] ==
                    item["git_blob_sha256"] == current_inventory["files"][path] ==
                    normalization["checkout_after_sha256"][path] ==
                    frozen_before["files"][path] == sha(accepted) and
                    item["failed_archive_sha256"] ==
                    item["checkout_before_sha256"] ==
                    failed_before["files"][path] == sha(rejected) and
                    rejected == accepted.replace(b"\n", b"\r\n"),
                    "normalized path is not exact CRLF-to-Git-blob restoration: " + path)
    require(frozen["status"] == "passed" and frozen["source"] == source and
            frozen["canonical_package_sha256"] == package_sha and
            frozen["generated_sha256"] == package_sha and
            frozen["bytes"] == canonical.stat().st_size and
            Path(frozen["normalization_receipt"]).resolve() ==
            (FINAL / "frozen-checkout-normalization.json").resolve() and
            Path(frozen["checkout"]).resolve() ==
            Path("C:/Users/andre/.codex/worktrees/nbreq-release-030/nbreq").resolve() and
            Path(frozen["generated_path"]).resolve() ==
            (FINAL / "frozen-source-final/build/package/nbreq-0.3.0.crate").resolve() and
            frozen["source_hashes_unchanged"] and
            frozen["publication_authorized"] is False and
            frozen_before == read_json(FINAL / "frozen-source-final/source-after.json") and
            frozen_before["commit"] == source and not frozen_before["status"] and
            sha(Path(frozen["generated_path"]).read_bytes()) == package_sha,
            "frozen clean checkout package byte-identity proof incomplete")
    review = read_json(FINAL / "final-review.json")
    require(review["status"] == "passed" and review["source"] == source and
            review["canonical_package_sha256"] == package_sha and
            review["scope"] == "final-release-readiness" and
            review["publication_authorized"] is False,
            "final independent pre-release review receipt missing or mismatched")

    files = {}
    group_files(files, FINAL, "final-freeze", GROUPS, SINGLE_FILES)
    add_file(files, canonical, "final-freeze/canonical/nbreq-0.3.0.crate")
    add_file(files, failed_archive, "final-freeze/frozen-source-failed/nbreq-0.3.0.crate")
    return files, prior_reference, binding
def inventory(files):
    rows = []
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        rows.append(dict(path=name, source=str(path), bytes=len(data), sha256=sha(data),
                         nested=nested_inventory(name, data)))
    return rows


def plan(source, package_sha):
    require(not PLAN.exists(), "retention plan already exists")
    files, prior, verifier_binding = collect(source, package_sha)
    rows = inventory(files)
    record = dict(source=source, canonical_package_sha256=package_sha,
                  prior_reviewed_release_archive=prior,
                  precommit_verifier_binding=verifier_binding,
                  carried_candidate="prior source a64bf92; qualified by exact docs/VCS package delta",
                  first_public_index_preflight="failed on expected-checksum transcription typo; retained",
                  first_frozen_checkout="failed on 19 CRLF-only members; failed .crate retained",
                  final_frozen_checkout="exact Git-blob normalization then clean byte-identical package",
                  final_source="dated commit ae7bfeed; CI, local package, registry, audit and frozen checkout",
                  files=rows, file_count=len(rows), total_source_bytes=sum(r["bytes"] for r in rows),
                  excluded="build/cache/unpacked/advisory DB/private bridge trees")
    PLAN.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(plan=str(PLAN), plan_sha256=sha(PLAN.read_bytes()),
                          files=len(rows), bytes=record["total_source_bytes"]), indent=2))


def archive(approved_plan_sha):
    require(re.fullmatch(r"[0-9a-f]{64}", approved_plan_sha) is not None,
            "archive requires approved exact plan SHA256")
    require(PLAN.is_file() and sha(PLAN.read_bytes()) == approved_plan_sha,
            "approved plan hash mismatch")
    require(not ARCHIVE.exists() and not PUBLIC_INDEX.exists(),
            "release evidence output already exists")
    record = read_json(PLAN)
    files, prior, verifier_binding = collect(
        record["source"], record["canonical_package_sha256"])
    rows = inventory(files)
    require(rows == record["files"] and prior == record["prior_reviewed_release_archive"] and
            verifier_binding == record["precommit_verifier_binding"],
            "evidence changed after plan approval")
    internal = json.dumps({key: value for key, value in record.items() if key != "files"} |
                          {"files": [{key: value for key, value in row.items() if key != "source"}
                                     for row in rows]}, indent=2).encode("utf-8") + b"\n"
    manifest_name = "retained-files.json"
    pending_archive = FINAL / "retention-pending.tar.gz"
    require(not pending_archive.exists(), "pending archive already exists")
    with pending_archive.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
            with tarfile.open(fileobj=gz, mode="w") as bundle:
                entries = ([(row["path"], files[row["path"]].read_bytes()) for row in rows]
                           + [(manifest_name, internal)])
                for name, data in entries:
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    bundle.addfile(info, io.BytesIO(data))
    expected = {row["path"]: row["sha256"] for row in rows} | {manifest_name: sha(internal)}
    with tarfile.open(pending_archive, mode="r:gz") as bundle:
        members = bundle.getmembers()
        require(len(members) == len(expected) and
                {item.name for item in members} == set(expected),
                "archive member set mismatch")
        for item in members:
            require(item.isfile() and item.name in expected and
                    sha(bundle.extractfile(item).read()) == expected[item.name],
                    "archive read-back mismatch: " + item.name)
    os.replace(pending_archive, ARCHIVE)
    external = dict(archive=ARCHIVE.name, sha256=sha(ARCHIVE.read_bytes()),
                    bytes=ARCHIVE.stat().st_size, source=record["source"],
                    canonical_package_sha256=record["canonical_package_sha256"],
                    approved_plan_sha256=approved_plan_sha, regular_members=len(expected),
                    prior_reviewed_release_archive=prior,
                    groups={group: sum(row["path"].startswith(group + "/") for row in rows)
                            for group in ("final-freeze",)})
    PUBLIC_INDEX.write_text(json.dumps(external, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(external, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("plan", "archive"))
    parser.add_argument("--source", help="final release commit for plan")
    parser.add_argument("--package-sha", help="final canonical .crate SHA256 for plan")
    parser.add_argument("--approved-plan-sha", help="explicitly approved plan SHA256 for archive")
    args = parser.parse_args()
    if args.mode == "plan":
        require(args.source and args.package_sha and not args.approved_plan_sha,
                "plan needs source and package SHA")
        plan(args.source, args.package_sha)
    else:
        require(args.approved_plan_sha and not args.source and not args.package_sha,
                "archive needs the approved plan SHA only")
        archive(args.approved_plan_sha)


if __name__ == "__main__":
    main()
