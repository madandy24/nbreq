"""Scan prior accepted and final-source 0.3.0 locks with a fresh RustSec DB.

The prior candidate ran source a64bf92, not this final dated source. It is
included only as explicitly qualified carried evidence. Final CI, local
registry consumers, and the canonical package supply final-source locks.
No Cargo build, network fetch, or tracked-source change occurs here.
"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import tomllib

from release_gate import run
from validate_matrix import LAB, ROOT, require, sha, source_file


DATABASE = LAB / "advisory-db"
EXPECTED_DATABASE_COMMIT = "f23b768236fe2880e4cfa167da662cad8ca79240"
PRIOR = ROOT / "target/release-030-20260929/attempt-2"
PRIOR_SOURCE = "a64bf92bd74c871cb77e8eac5c4e9e0cde91a0b1"
PRIOR_PACKAGE_SHA = "b84102cabb72214305bddb4f365d093b3fdb17cee7cf3fa2e1620d28f8034b1a"
AUDITOR = ROOT / "target/tools/cargo-audit/bin/cargo-audit.exe"
OUT = LAB / "selected-lock-audit"
EXPECTED_ADVISORY_COUNT = 1277


def add_lock(locks, data, origin):
    parsed = tomllib.loads(data.decode("utf-8"))
    require(parsed.get("package"), "empty lock: " + origin)
    digest = sha(data)
    if digest in locks:
        require(locks[digest]["data"] == data, "lock hash collision")
        locks[digest]["origins"].append(origin)
    else:
        locks[digest] = dict(data=data, origins=[origin])


def prior_accepted_locks(locks):
    candidate = json.loads((PRIOR / "candidate-matrix-verified.json").read_text(encoding="utf-8"))
    prior_summary = json.loads((PRIOR / "selected-lock-audit-final/summary.json").read_text(
        encoding="utf-8"))
    inputs = json.loads((PRIOR / "selected-lock-audit-final/inputs.json").read_text(
        encoding="utf-8"))
    require(candidate["status"] == "passed" and candidate["source"] == PRIOR_SOURCE and
            candidate["canonical_package_sha256"] == PRIOR_PACKAGE_SHA and
            prior_summary["status"] == "passed" and prior_summary["source"] == PRIOR_SOURCE and
            prior_summary["package_sha256"] == PRIOR_PACKAGE_SHA and
            prior_summary["advisory_database_commit"] == EXPECTED_DATABASE_COMMIT and
            prior_summary["distinct_locks"] == prior_summary["audited_locks"] == 10 and
            inputs["source"] == PRIOR_SOURCE and inputs["package_sha256"] == PRIOR_PACKAGE_SHA,
            "prior candidate/accepted lock audit identity mismatch")
    listed = inputs["locks"]
    require(len(listed) == 10 and
            {item["sha256"] for item in listed} ==
            {item["sha256"] for item in prior_summary["receipts"]},
            "prior audited lock list mismatch")
    for item in listed:
        digest = item["sha256"]
        data = (PRIOR / "selected-lock-audit-final/locks" / (digest + ".lock")).read_bytes()
        require(sha(data) == digest and item["origins"],
                "prior accepted lock changed: " + digest)
        add_lock(locks, data, "prior-source-" + PRIOR_SOURCE[:8] + ":" +
                 ",".join(item["origins"]))
    return candidate["run_id"]


def hosted_locks(mode, source, package_sha, locks):
    receipt = json.loads((LAB / (mode + "-matrix-verified.json")).read_text(encoding="utf-8"))
    require(receipt["status"] == "passed" and receipt["source"] == source and
            receipt["consumer_graphs"] == 16 and receipt["positive_tests"] == 752 and
            receipt["negative_probes"] == 32 and receipt["examples"] == 144,
            "hosted matrix receipt mismatch: " + mode)
    require(receipt["canonical_package_sha256"] == (package_sha if mode == "candidate" else None),
            "hosted package identity mismatch: " + mode)
    folder = LAB / (mode + "-selected-locks")
    index = json.loads((folder / "index.json").read_text(encoding="utf-8"))
    require(index == receipt["selected_locks"] and len(index) == receipt["selected_lock_count"],
            "hosted lock inventory mismatch: " + mode)
    for item in index:
        digest = item["sha256"]
        path = folder / (digest + ".lock")
        data = path.read_bytes()
        require(sha(data) == digest and item["origins"], "hosted lock changed: " + digest)
        add_lock(locks, data, mode + ":" + ",".join(item["origins"]))
    return receipt["run_id"]


def local_registry_locks(source, package_sha, locks):
    folder = LAB / "registry-candidate"
    inputs = json.loads((folder / "inputs.json").read_text(encoding="utf-8"))
    result = json.loads((folder / "result.json").read_text(encoding="utf-8"))
    require(result["status"] == "passed" and result["archive_sha256"] == package_sha and
            inputs["archive_sha256"] == package_sha and
            inputs["package_vcs"]["git"]["sha1"] == source and
            len(result["cases"]) == 4,
            "local registry candidate identity mismatch")
    labels = {case["label"] for case in result["cases"]}
    require(labels == {f"{compiler}-{kind}" for compiler in ("stable", "1.85.0")
                       for kind in ("fresh", "mio-coexist")},
            "local registry consumer graph labels mismatch")
    for case in result["cases"]:
        label = case["label"]
        data = (folder / label / "Cargo.lock").read_bytes()
        require(sha(data) == case["lock_sha256"], "local selected lock changed: " + label)
        policy = json.loads((folder / label / "consumer-policy.json").read_text(encoding="utf-8"))
        require(policy["status"] == "selected" and
                policy["selected"]["sha256"] == case["lock_sha256"],
                "local lock-policy mismatch: " + label)
        add_lock(locks, data, "local-registry:" + label)
    example = (folder / "package-examples-Cargo.lock").read_bytes()
    require(sha(example) == inputs["example_lock_sha256"],
            "local packaged-example lock changed")
    add_lock(locks, example, "local-registry:packaged-examples")


def final_package_locks(source, package_sha, locks):
    index = json.loads((LAB / "authoritative-package/inventory.json").read_text(
        encoding="utf-8"))
    archive = Path(index["path"])
    require(index["commit"] == source and index["sha256"] == package_sha and
            index["vcs"]["git"]["sha1"] == source and archive.is_file() and
            sha(archive.read_bytes()) == package_sha,
            "final canonical archive identity mismatch")
    with tarfile.open(archive, mode="r:gz") as package:
        member = package.getmember("nbreq-0.3.0/Cargo.lock")
        require(member.isfile(), "canonical package lock is not regular")
        packaged_lock = package.extractfile(member).read()
    require(sha(packaged_lock) == index["files"]["Cargo.lock"],
            "canonical package lock inventory mismatch")
    add_lock(locks, packaged_lock, "final-source:canonical-package-Cargo.lock")
    add_lock(locks, source_file(source, "Cargo.lock"), "final-source:workspace-Cargo.lock")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, help="Exact 40-hex release commit")
    parser.add_argument("--package-sha", required=True, help="Exact 64-hex root .crate SHA256")
    args = parser.parse_args()
    require(len(args.source) == 40 and all(c in "0123456789abcdef" for c in args.source),
            "invalid source SHA")
    require(len(args.package_sha) == 64 and all(c in "0123456789abcdef" for c in args.package_sha),
            "invalid package SHA")
    require(not OUT.exists(), "audit output already exists")
    require(AUDITOR.is_file() and DATABASE.is_dir(), "audit binary or database unavailable")
    database_commit = subprocess.check_output(
        ["git", "-C", str(DATABASE), "rev-parse", "HEAD"], timeout=30
    ).decode().strip()
    require(database_commit == EXPECTED_DATABASE_COMMIT,
            "advisory database commit changed; new audit plan required")
    require(not subprocess.check_output(
        ["git", "-C", str(DATABASE), "status", "--porcelain"], timeout=30
    ).strip(), "advisory database has local changes")
    policy = (ROOT / ".cargo/audit.toml").read_bytes()
    require(sha(policy) == sha(source_file(args.source, ".cargo/audit.toml")),
            "audit policy differs from release source")
    settings = tomllib.loads(policy.decode("utf-8"))
    ignored = settings["advisories"]["ignore"]
    require(ignored == ["RUSTSEC-2026-0009"], "unexpected advisory ignore policy")
    locks = {}
    prior_candidate_run = prior_accepted_locks(locks)
    prior_digests = set(locks)
    ci_run = hosted_locks("ci", args.source, args.package_sha, locks)
    local_registry_locks(args.source, args.package_sha, locks)
    final_package_locks(args.source, args.package_sha, locks)
    final_digests = set(locks) - prior_digests
    OUT.mkdir()
    (OUT / "locks").mkdir()
    auditor_sha = sha(AUDITOR.read_bytes())
    database_log = subprocess.check_output(
        ["git", "-C", str(DATABASE), "log", "-1", "--format=%H %cI"], timeout=30
    ).decode().strip()
    input_record = dict(
        source=args.source, package_sha256=args.package_sha,
        prior_candidate_source=PRIOR_SOURCE, prior_candidate_package_sha256=PRIOR_PACKAGE_SHA,
        prior_candidate_run_id=prior_candidate_run,
        prior_candidate_scope="carried prior-source evidence; not a final-source candidate run",
        final_ci_run_id=ci_run, prior_accepted_locks=len(prior_digests),
        new_final_lock_digests=sorted(final_digests),
        advisory_database=str(DATABASE), advisory_database_commit=database_commit,
        database_identity_source="verified clean pinned local Git checkout; cargo-audit --no-fetch JSON may omit commit",
        advisory_database_commit_time=database_log,
        auditor=str(AUDITOR), auditor_sha256=auditor_sha,
        policy_sha256=sha(policy), ignored_advisories=ignored,
        distinct_locks=len(locks),
        locks=[dict(sha256=digest, origins=item["origins"])
               for digest, item in sorted(locks.items())],
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    )
    (OUT / "inputs.json").write_text(json.dumps(input_record, indent=2) + "\n", encoding="utf-8")
    environment = dict(os.environ, CARGO_NET_OFFLINE="true")
    failure = None
    receipts = []
    try:
        run(OUT, "auditor-version", [str(AUDITOR), "--version"], ROOT, environment, 30)
        version = (OUT / "auditor-version.log").read_text(encoding="utf-8").strip()
        require(version == "cargo-audit 0.22.2", "unexpected local cargo-audit version")
        for digest, item in sorted(locks.items()):
            path = OUT / "locks" / (digest + ".lock")
            path.write_bytes(item["data"])
            run(OUT, digest, [str(AUDITOR), "audit", "--db", str(DATABASE),
                              "--no-fetch", "--file", str(path), "--json"],
                ROOT, environment, 180)
            report = json.loads((OUT / (digest + ".log")).read_text(encoding="utf-8"))
            reported_commit = report["database"]["last-commit"]
            require(reported_commit in (None, database_commit) and
                    report["database"]["advisory-count"] == EXPECTED_ADVISORY_COUNT and
                    not report["vulnerabilities"]["found"] and
                    report["vulnerabilities"]["count"] == 0 and not report["warnings"] and
                    report["settings"]["ignore"] == ignored,
                    "RustSec findings/database/policy mismatch: " + digest)
            receipts.append(dict(sha256=digest, origins=item["origins"],
                                 report_sha256=sha((OUT / (digest + ".log")).read_bytes()),
                                 database_report_commit=reported_commit,
                                 advisory_count=report["database"]["advisory-count"],
                                 dependency_count=report["lockfile"]["dependency-count"]))
            (OUT / "progress.json").write_text(
                json.dumps(dict(completed=len(receipts), expected=len(locks), receipts=receipts), indent=2),
                encoding="utf-8",
            )
        require(sha(AUDITOR.read_bytes()) == auditor_sha and
                subprocess.check_output(["git", "-C", str(DATABASE), "rev-parse", "HEAD"],
                                        timeout=30).decode().strip() == database_commit and
                not subprocess.check_output(["git", "-C", str(DATABASE), "status", "--porcelain"],
                                            timeout=30).strip() and
                all(sha((OUT / "locks" / (digest + ".lock")).read_bytes()) == digest
                    for digest in locks), "audit inputs changed during scan")
    except BaseException as error:
        failure = repr(error)
    summary = dict(status="failed" if failure else "passed", failure=failure,
                   source=args.source, package_sha256=args.package_sha,
                   advisory_database_commit=database_commit, auditor_sha256=auditor_sha,
                   database_identity_source="verified clean pinned local Git checkout",
                   advisory_count=EXPECTED_ADVISORY_COUNT,
                   prior_candidate_source=PRIOR_SOURCE, final_ci_run_id=ci_run,
                   carried_prior_locks=len(prior_digests), new_final_locks=len(final_digests),
                   distinct_locks=len(locks), audited_locks=len(receipts), receipts=receipts,
                   ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in summary.items() if key != "receipts"}, indent=2))
    return 0 if failure is None else 1


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(SystemExit("audit interrupted")))
    raise SystemExit(main())
