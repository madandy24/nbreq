"""Read-only byte check of the tested unpacked crate against canonical inventory."""
import hashlib
import json
from pathlib import Path

lab = Path('C:/User/projects/nbreq/target/release-030-final-20260930')
inventory = json.loads((lab / 'authoritative-package/inventory.json').read_text())
extraction = json.loads((lab / 'packaged-tests/extraction.json').read_text())
root = Path(extraction['destination']) / 'nbreq-0.3.0'
assert extraction['archive_sha256'] == inventory['sha256']
assert extraction['archive_bytes'] == inventory['bytes']
assert extraction['source_commit'] == inventory['commit']
assert root.is_dir()

expected = inventory['files']
actual = {}
for path in root.rglob('*'):
    if path.is_dir() and not path.is_symlink():
        continue
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f'unexpected non-file or symlink: {path}')
    actual[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
added = sorted(actual.keys() - expected.keys())
removed = sorted(expected.keys() - actual.keys())
changed = sorted(name for name in actual.keys() & expected.keys()
                 if actual[name] != expected[name])
receipt = dict(status='passed' if not (added or removed or changed) else 'failed',
               source_commit=inventory['commit'], archive_path=inventory['path'],
               archive_sha256=inventory['sha256'], extraction_root=str(root),
               expected_file_count=len(expected), actual_file_count=len(actual),
               added=added, removed=removed, changed=changed)
(lab / 'postrun-extraction-identity.json').write_text(
    json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
if receipt['status'] != 'passed':
    raise SystemExit('post-run extracted source differs from canonical inventory')
print(f"verified {len(actual)} extracted files against canonical archive")
