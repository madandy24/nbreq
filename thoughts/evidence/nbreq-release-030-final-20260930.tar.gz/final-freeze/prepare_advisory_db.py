"""Clone and identify a fresh, bounded RustSec advisory-db snapshot.

The prior release lab and its pinned database are never changed. This writes
only ignored evidence in target/release-030-final-20260930.
"""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys


ROOT = Path("C:/User/projects/nbreq")
LAB = ROOT / "target/release-030-final-20260930"
DB = LAB / "advisory-db"
OFFICIAL_URL = "https://github.com/RustSec/advisory-db.git"
AUDITOR = ROOT / "target/tools/cargo-audit/bin/cargo-audit.exe"
POLICY = ROOT / ".cargo/audit.toml"
PRIOR_DB = ROOT / "target/release-030-20260929/advisory-db"
sys.path.insert(0, str(ROOT / "target/release-030-20260929"))
from owned_command import command  # noqa: E402


def git(*arguments, cwd=ROOT):
    return subprocess.check_output(["git", "-C", str(cwd), *arguments], timeout=30).decode().strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if DB.exists():
        raise RuntimeError("fresh advisory database path already exists")
    if (LAB / "advisory-db-snapshot.json").exists():
        raise RuntimeError("advisory database snapshot receipt already exists")
    if not AUDITOR.is_file() or not POLICY.is_file():
        raise RuntimeError("local auditor or committed policy unavailable")
    command(["git", "clone", "--depth", "1", OFFICIAL_URL, str(DB)], ROOT, LAB,
            "rustsec-clone", dict(os.environ, GIT_TERMINAL_PROMPT="0"), 180)
    remote = git("remote", "get-url", "origin", cwd=DB)
    commit = git("rev-parse", "HEAD", cwd=DB)
    commit_date = git("log", "-1", "--format=%cI", cwd=DB)
    clean = not git("status", "--porcelain", cwd=DB)
    version = subprocess.check_output([str(AUDITOR), "--version"], timeout=30).decode().strip()
    if remote != OFFICIAL_URL or not clean or version != "cargo-audit 0.22.2":
        raise RuntimeError("fresh RustSec source or local auditor identity mismatch")
    result = dict(source=OFFICIAL_URL, db_path=str(DB), commit=commit,
                  commit_date=commit_date, clean=clean,
                  prior_commit=git("rev-parse", "HEAD", cwd=PRIOR_DB),
                  auditor_path=str(AUDITOR), auditor_version=version,
                  auditor_sha256=sha(AUDITOR), policy_path=str(POLICY),
                  policy_sha256=sha(POLICY),
                  release_checkout_head=git("rev-parse", "HEAD"),
                  captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    output = LAB / "advisory-db-snapshot.json"
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(SystemExit("clone interrupted")))
    main()
