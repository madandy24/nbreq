"""Temporarily inspect one approved file's Git status under EOL policies; restore it."""
import json
from pathlib import Path
import subprocess

checkout = Path('C:/Users/andre/.codex/worktrees/nbreq-release-030/nbreq')
path = checkout / 'LICENSE-MIT'
name = 'LICENSE-MIT'
def git(*args):
    return subprocess.check_output(['git', '-c', f'safe.directory={checkout}',
                                    '-C', str(checkout), *args]).decode().strip()
before = path.read_bytes()
blob = subprocess.check_output(['git', '-c', f'safe.directory={checkout}',
                                '-C', str(checkout), 'show',
                                'ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08:' + name])
try:
    path.write_bytes(blob)
    result = dict(ordinary_status=git('status', '--porcelain', '--', name),
                  autocrlf_false_status=git('-c', 'core.autocrlf=false',
                                            'status', '--porcelain', '--', name),
                  diff=git('diff', '--numstat', '--', name),
                  diff_autocrlf_false=git('-c', 'core.autocrlf=false',
                                          'diff', '--numstat', '--', name),
                  index_oid=git('rev-parse', ':' + name),
                  working_clean_oid=git('hash-object', '--path', name, str(path)),
                  git_blob_oid=git('rev-parse', 'HEAD:' + name))
finally:
    path.write_bytes(before)
result['restored_status'] = git('status', '--porcelain', '--', name)
out = Path('C:/User/projects/nbreq/target/release-030-final-20260930/eol-status-diagnostic.json')
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
