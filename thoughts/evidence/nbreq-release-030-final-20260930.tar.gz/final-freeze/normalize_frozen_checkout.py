"""Restore 19 CRLF checkout files to exact release Git blobs, with byte receipts."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

LAB = Path('C:/User/projects/nbreq/target/release-030-final-20260930')
CHECKOUT = Path('C:/Users/andre/.codex/worktrees/nbreq-release-030/nbreq')
COMMIT = 'ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08'
CANONICAL_SHA = '193601f9a1616659afcd1802d3f904dded739a73ffc4786fffb828feb102f242'
FAILED_SHA = 'ead655049856a202a9a8f423f94d951a278c5fec27a47e5a73a19be208f9d7b9'
ALLOWED = {
    'LICENSE-APACHE',
    'LICENSE-MIT',
    'tests/fixtures/fuzz/native_dns_response/a.seed',
    'tests/fixtures/fuzz/native_dns_response/aaaa.seed',
    'tests/fixtures/fuzz/native_dns_response/cname.seed',
    'tests/fixtures/fuzz/native_dns_response/nxdomain.seed',
    'tests/fixtures/fuzz/native_dns_response/root-cname.seed',
    'tests/fixtures/fuzz/native_dns_response/truncated.seed',
    'tests/fixtures/fuzz/native_response_decoder/chunked.seed',
    'tests/fixtures/fuzz/native_response_decoder/close_delimited.seed',
    'tests/fixtures/fuzz/native_response_decoder/conflicting_length.seed',
    'tests/fixtures/fuzz/native_response_decoder/fixed.seed',
    'tests/fixtures/fuzz/native_response_decoder/informational.seed',
    'tests/fixtures/fuzz/native_response_decoder/malformed_chunk.seed',
    'tests/fixtures/fuzz/native_streaming_response_decoder/chunked_tiny_queue.seed',
    'tests/fixtures/fuzz/native_streaming_response_decoder/close_delimited.seed',
    'tests/fixtures/fuzz/native_streaming_response_decoder/discard_redirect.seed',
    'tests/fixtures/fuzz/native_streaming_response_decoder/fixed_tiny_queue.seed',
    'tests/fixtures/fuzz/native_streaming_response_decoder/no_body.seed',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    # One-command trust for this exact managed checkout; no Git config is changed.
    return subprocess.check_output(['git', '-c', f'safe.directory={CHECKOUT}',
                                    '-C', str(CHECKOUT), *args], timeout=60)


def staged_diff_clean():
    return subprocess.run(['git', '-c', f'safe.directory={CHECKOUT}', '-C', str(CHECKOUT),
                           'diff', '--cached', '--quiet', 'HEAD'],
                          timeout=60, check=False).returncode == 0


def index_map(raw):
    entries = {}
    for record in raw.split(b'\0'):
        if record:
            fields, name = record.split(b'\t', 1)
            mode, oid, stage = fields.split(b' ')
            if stage != b'0':
                raise RuntimeError('unmerged index entry')
            entries[name] = (mode, oid)
    return entries


def head_map(raw):
    entries = {}
    for record in raw.split(b'\0'):
        if record:
            fields, name = record.split(b'\t', 1)
            mode, kind, oid = fields.split(b' ')
            if kind != b'blob':
                raise RuntimeError('unexpected non-blob HEAD entry')
            entries[name] = (mode, oid)
    return entries


def snapshot():
    names = [name for name in git('ls-files', '-z').decode().split('\0') if name]
    return dict(commit=git('rev-parse', 'HEAD').decode().strip(),
                status=git('status', '--porcelain').decode(),
                files={name: sha((CHECKOUT / name).read_bytes()) for name in names})


def members(path):
    files = {}
    with tarfile.open(path) as bundle:
        for member in bundle:
            if not member.isfile() or member.name in files or not member.name.startswith('nbreq-0.3.0/'):
                raise RuntimeError('unexpected archive member: ' + member.name)
            files[member.name.removeprefix('nbreq-0.3.0/')] = bundle.extractfile(member).read()
    return files


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    if len(ALLOWED) != 19 or not CHECKOUT.is_dir():
        raise RuntimeError('unexpected checkout or allowed-path set')
    canonical_path = LAB / 'authoritative-package/build/package/nbreq-0.3.0.crate'
    failed_path = LAB / 'frozen-source/build/package/nbreq-0.3.0.crate'
    if sha(canonical_path.read_bytes()) != CANONICAL_SHA or sha(failed_path.read_bytes()) != FAILED_SHA:
        raise RuntimeError('canonical or failed archive identity changed')
    canonical = members(canonical_path)
    failed = members(failed_path)
    if canonical.keys() != failed.keys():
        raise RuntimeError('canonical and failed archive member sets differ')
    different = {name for name in canonical if canonical[name] != failed[name]}
    if different != ALLOWED:
        raise RuntimeError(f'archive difference paths not exactly allowed: {sorted(different)}')
    before = snapshot()
    index_before = git('ls-files', '-s', '-z')
    head_entries = head_map(git('ls-tree', '-r', '-z', 'HEAD'))
    if (before['commit'] != COMMIT or before['status'] or not staged_diff_clean() or
            index_map(index_before) != head_entries):
        raise RuntimeError('managed checkout is not clean at exact release commit')
    original = {}
    details = []
    for name in sorted(ALLOWED):
        path = CHECKOUT / name
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(CHECKOUT.resolve()):
            raise RuntimeError('unsafe checkout path: ' + name)
        git_blob = git('show', f'{COMMIT}:{name}')
        checked_out = path.read_bytes()
        expected = canonical[name]
        if (git_blob != expected or checked_out != failed[name] or
                b'\r\n' in expected or checked_out != expected.replace(b'\n', b'\r\n')):
            raise RuntimeError('not exact CRLF-only checkout normalization: ' + name)
        original[name] = checked_out
        details.append(dict(path=name, canonical_sha256=sha(expected),
                            failed_archive_sha256=sha(failed[name]),
                            checkout_before_sha256=sha(checked_out),
                            git_blob_sha256=sha(git_blob),
                            checkout_before_bytes=len(checked_out), canonical_bytes=len(expected)))
    common = dict(commit=COMMIT, checkout=str(CHECKOUT), canonical_archive_sha256=CANONICAL_SHA,
                  failed_archive_sha256=FAILED_SHA, reason='Windows checkout CRLF conversion only',
                  paths=details, other_tracked_file_count=len(before['files']) - len(ALLOWED))
    write_json(LAB / 'normalization-plan.json', dict(**common, status='validated', apply=False))
    if not args.apply:
        print(f'validated exact Git-blob normalization for {len(details)} files; no checkout writes')
        return
    written = []
    try:
        for name in sorted(ALLOWED):
            (CHECKOUT / name).write_bytes(canonical[name])
            written.append(name)
        before_refresh = snapshot()
        unstaged_diff = git('diff', '--numstat', '--', *sorted(ALLOWED))
        if unstaged_diff:
            raise RuntimeError('exact Git blob bytes produced a substantive diff')
        # Refresh index stat/EOL representation; blob OIDs and modes must remain unchanged.
        git('add', '--renormalize', '--', *sorted(ALLOWED))
        after = snapshot()
        index_after = git('ls-files', '-s', '-z')
        changed = {name for name in before['files'] if before['files'][name] != after['files'][name]}
        exact_bytes = all((CHECKOUT / name).read_bytes() == canonical[name] for name in ALLOWED)
        write_json(LAB / 'normalization-refresh-attempt.json', dict(commit=after['commit'],
            status=after['status'], changed_paths=sorted(changed),
            expected_paths=sorted(ALLOWED), exact_canonical_bytes=exact_bytes,
            status_before_index_refresh=before_refresh['status'],
            index_entries_unchanged=index_before == index_after,
            index_entries_equal_head=index_map(index_after) == head_entries,
            staged_diff_clean=staged_diff_clean(),
            all_other_tracked_files_unchanged=all(before['files'][name] == after['files'][name]
                for name in before['files'].keys() - ALLOWED)))
        if (after['commit'] != COMMIT or after['status'] or changed != ALLOWED or not exact_bytes or
                index_before != index_after or index_map(index_after) != head_entries or
                not staged_diff_clean()):
            raise RuntimeError('post-normalization checkout identity failed')
        write_json(LAB / 'frozen-checkout-normalization.json', dict(**common, status='passed', apply=True,
            tracked_file_count=len(after['files']), changed_paths=sorted(changed),
            all_other_tracked_files_unchanged=True, git_status_clean=True,
            index_entries_unchanged=True, index_entries_equal_head=True,
            staged_diff_clean=True,
            status_before_index_refresh=before_refresh['status'],
            previous_failed_attempt='normalization-first-attempt.json',
            previous_rollback='normalization-first-rollback.json',
            checkout_after_sha256={name: after['files'][name] for name in sorted(ALLOWED)}))
        print(f'normalized {len(details)} CRLF files to exact Git blob bytes; checkout clean')
    except BaseException:
        for name in written:
            (CHECKOUT / name).write_bytes(original[name])
        git('add', '--renormalize', '--', *sorted(ALLOWED))
        rolled_back = snapshot()
        write_json(LAB / 'normalization-refresh-rollback.json', dict(
            status='restored' if rolled_back == before else 'mismatch',
            checkout_clean=not rolled_back['status'],
            all_tracked_hashes_restored=rolled_back['files'] == before['files'],
            index_entries_restored=git('ls-files', '-s', '-z') == index_before,
            index_entries_equal_head=index_map(git('ls-files', '-s', '-z')) == head_entries,
            staged_diff_clean=staged_diff_clean(),
            commit=rolled_back['commit']))
        raise


if __name__ == '__main__':
    main()
