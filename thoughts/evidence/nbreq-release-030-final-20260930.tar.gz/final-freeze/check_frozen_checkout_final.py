"""Verify an exact-source publication checkout; packaging only, never publish."""
import argparse
import json
import os
from pathlib import Path
import subprocess

from release_gate import LAB, run, sha, write_json


def snapshot(checkout):
    def git(*args):
        return subprocess.check_output(['git', '-C', str(checkout), *args], timeout=60)
    names = git('ls-files', '-z').decode().split('\0')
    return dict(commit=git('rev-parse', 'HEAD').decode().strip(),
                status=git('status', '--porcelain').decode(),
                files={name: sha(checkout / name) for name in names if name})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkout', required=True)
    args = parser.parse_args()
    checkout = Path(args.checkout).resolve(strict=True)
    expected_checkout = Path('C:/Users/andre/.codex/worktrees/nbreq-release-030/nbreq').resolve()
    if checkout != expected_checkout:
        raise ValueError('unexpected managed checkout')
    canonical = json.loads((LAB / 'authoritative-package/inventory.json').read_text())
    expected_commit = 'ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08'
    if canonical['commit'] != expected_commit or sha(Path(canonical['path'])) != canonical['sha256']:
        raise ValueError('canonical package identity changed')
    normalization_path = LAB / 'frozen-checkout-normalization.json'
    normalization = json.loads(normalization_path.read_text(encoding='utf-8'))
    if (normalization['status'] != 'passed' or normalization['commit'] != expected_commit or
            len(normalization['changed_paths']) != 19 or not normalization['git_status_clean'] or
            not normalization['index_entries_unchanged'] or
            not normalization['index_entries_equal_head'] or
            not normalization['staged_diff_clean'] or
            not normalization['all_other_tracked_files_unchanged']):
        raise ValueError('frozen checkout normalization receipt is not accepted')
    out = LAB / 'frozen-source-final'
    out.mkdir(exist_ok=False)
    before = snapshot(checkout)
    write_json(out / 'source-before.json', before)
    if before['commit'] != expected_commit or before['status']:
        raise ValueError('frozen source is not the exact clean release commit')
    env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2', CARGO_NET_OFFLINE='true')
    env.pop('CARGO_BUILD_TARGET', None)
    env.pop('CARGO_TARGET_DIR', None)
    failure = None
    archive = out / 'build/package/nbreq-0.3.0.crate'
    try:
        run(out, 'compiler', ['rustup', 'run', 'stable', 'rustc', '-vV'], checkout, env, 30)
        run(out, 'frozen-package', ['rustup', 'run', 'stable', 'cargo', 'package', '--locked',
            '--offline', '--no-verify', '-p', 'nbreq', '--target-dir', str(out / 'build')],
            checkout, env, 300)
        if archive.read_bytes() != Path(canonical['path']).read_bytes():
            raise ValueError('frozen checkout archive differs from verified canonical bytes')
    except BaseException as error:
        failure = repr(error)
    after = snapshot(checkout)
    write_json(out / 'source-after.json', after)
    integrity = before == after
    receipt = dict(status='passed' if failure is None and integrity else 'failed',
        failure=failure, source=expected_commit, checkout=str(checkout),
        normalization_receipt=str(normalization_path),
        canonical_package_sha256=canonical['sha256'], source_hashes_unchanged=integrity,
        generated_path=str(archive), generated_sha256=sha(archive) if archive.is_file() else None,
        bytes=archive.stat().st_size if archive.is_file() else None,
        purpose='Packaging-only byte identity; compilation/tests are in the canonical gates',
        publication_authorized=False)
    write_json(out / 'summary.json', receipt)
    print(json.dumps(receipt, indent=2))
    if receipt['status'] != 'passed':
        raise SystemExit(failure or 'frozen source changed')


if __name__ == '__main__':
    main()
