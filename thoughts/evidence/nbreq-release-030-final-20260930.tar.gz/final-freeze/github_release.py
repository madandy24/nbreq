"""Dispatch/read the NBReq workflow using Git's configured credential helper; never log credentials."""
import argparse, json, os, subprocess
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, urlopen
from urllib.error import HTTPError

BASE='https://api.github.com/repos/madandy24/nbreq'
ROOT=Path('C:/User/projects/nbreq')
OUT=Path('C:/User/projects/nbreq/target/housekeeping-20260915/hosted')

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

def api(path,method='GET',data=None,binary=False):
    assert path.startswith('/') and not path.startswith('//')
    credential=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',
        text=True,cwd=ROOT,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never'),
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    if credential.returncode:
        raise RuntimeError('GitHub credential helper is unavailable; no credential output retained')
    fields=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)
    token=fields.get('password')
    if not token:
        raise RuntimeError('Credential helper returned no GitHub access token')
    request=Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,
        method=method,headers={'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28',
            'User-Agent':'nbreq-r5-checks','Authorization':'Bearer '+token})
    try:
        response=build_opener(NoRedirect).open(request,timeout=60)
        raw=response.read()
    except HTTPError as error:
        if error.code in (301,302,303,307,308) and binary:
            destination=error.headers['Location']
            assert urlsplit(destination).scheme=='https'
            # Signed archive downloads never receive the GitHub Authorization header.
            with urlopen(Request(destination,headers={'User-Agent':'nbreq-r5-checks'}),timeout=60) as response:
                return response.read()
        raise RuntimeError('GitHub API returned HTTP '+str(error.code)) from None
    return raw if binary else (json.loads(raw) if raw else None)


parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['preflight','dispatch','discover','status','download'])
parser.add_argument('--mode',choices=['candidate','published'],required=True)
parser.add_argument('--workflow',choices=['registry-release.yml','ci.yml'],default='registry-release.yml')
parser.add_argument('--sha')
parser.add_argument('--run',type=int)
parser.add_argument('--attempt',type=int)
args=parser.parse_args()
OUT=Path(__file__).resolve().parent/('hosted-'+('ci' if args.workflow=='ci.yml' else args.mode))
if args.attempt:
    OUT=OUT/('attempt-'+str(args.attempt))
OUT.mkdir(parents=True,exist_ok=True)
if args.action=='preflight':
    repository=api('/branches/main')
    print(json.dumps(dict(main=repository['commit']['sha'],protected=repository['protected'])))
elif args.action=='dispatch':
    assert args.sha and not (OUT/'dispatch.json').exists()
    assert api('/branches/main')['commit']['sha']==args.sha
    payload={'ref':'main'}
    if args.workflow=='registry-release.yml': payload['inputs']={'mode':args.mode}
    api('/actions/workflows/'+args.workflow+'/dispatches','POST',payload)
    (OUT/'dispatch.json').write_text(json.dumps(dict(sha=args.sha,mode=args.mode),indent=2))
    print('Accepted '+args.mode+' workflow at '+args.sha)
elif args.action=='discover':
    runs=api('/actions/workflows/'+args.workflow+'/runs?'+urlencode(dict(branch='main',per_page=20)))['workflow_runs']
    run=max((r for r in runs if r['head_sha']==args.sha),key=lambda r:r['id'])
    (OUT/'run.json').write_text(json.dumps(run,indent=2))
    print(json.dumps({k:run[k] for k in ['id','head_sha','status','conclusion','html_url']}))
elif args.action=='status':
    run=api('/actions/runs/'+str(args.run))
    jobs=api('/actions/runs/'+str(args.run)+'/jobs?per_page=100')['jobs']
    (OUT/'run.json').write_text(json.dumps(run,indent=2))
    (OUT/'jobs.json').write_text(json.dumps(jobs,indent=2))
    print(json.dumps(dict(run={k:run[k] for k in ['id','head_sha','status','conclusion','html_url']},jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion'],stage=[s['name'] for s in j['steps'] if s['status']=='in_progress']) for j in jobs]),indent=2))
else:
    run=api('/actions/runs/'+str(args.run))
    assert run['status']=='completed'
    logs=OUT/'logs.zip'
    assert not logs.exists()
    logs.write_bytes(api('/actions/runs/'+str(args.run)+'/logs',binary=True))
    artifacts=api('/actions/runs/'+str(args.run)+'/artifacts?per_page=100')['artifacts']
    (OUT/'artifacts.json').write_text(json.dumps(artifacts,indent=2))
    for artifact in artifacts:
        destination=OUT/('artifact-'+str(artifact['id'])+'.zip')
        assert not destination.exists() and not artifact['expired']
        destination.write_bytes(api('/actions/artifacts/'+str(artifact['id'])+'/zip',binary=True))
        print(artifact['name'],flush=True)
    print('Saved '+str(len(artifacts))+' registry artifacts',flush=True)

