"""Read public crates.io sparse-index records before a possible 0.3.0 release.

This uses three fixed unauthenticated HTTPS GETs and retains bounded raw
records. Absence of 0.3.0 is a point-in-time observation, not a reservation.
"""

import datetime
import hashlib
import json
from pathlib import Path
import signal
from urllib.request import Request, urlopen


LAB = Path("C:/User/projects/nbreq/target/release-030-final-20260930")
OUT = LAB / "public-index-preflight"
BASE = "https://index.crates.io"
MAX_BYTES = 2 * 1024 * 1024
EXPECTED = {
    "nbreq": None,
    "nbreq-winpoll": ("0.1.1", "9e4fc64245514209beb6e3feccb4b980e1c259546a9e07543e3529e1d7053696"),
    "nbreq-darwin": ("0.1.0", "31d7a69844b990331f85dc497f14d0b6a08f8ceaee402e7c6aa19919f3c839"),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sparse_path(name):
    require(len(name) >= 4 and name == name.lower(), "unsupported crate name")
    return name[:2] + "/" + name[2:4] + "/" + name


def fetch(name):
    url = BASE + "/" + sparse_path(name)
    request = Request(url, headers={"User-Agent": "nbreq-release-public-index-preflight/0.3",
                                    "Accept": "text/plain", "Cache-Control": "no-cache"})
    with urlopen(request, timeout=30) as response:
        require(response.status == 200 and response.url == url,
                "unexpected sparse-index response or redirect: " + name)
        data = response.read(MAX_BYTES + 1)
        headers = {key: response.headers.get(key) for key in ("Date", "ETag", "Last-Modified", "Age")}
    require(0 < len(data) <= MAX_BYTES, "empty or oversized index record: " + name)
    raw_path = OUT / "raw" / (name + ".jsonl")
    raw_path.write_bytes(data)
    entries = [json.loads(line) for line in data.splitlines() if line]
    require(entries and all(entry["name"].lower() == name for entry in entries),
            "unexpected sparse-index crate identity: " + name)
    versions = [entry["vers"] for entry in entries]
    require(len(set(versions)) == len(versions), "duplicate index version: " + name)
    expected = EXPECTED[name]
    if expected is None:
        require("0.3.0" not in versions, "nbreq 0.3.0 is already present in public index")
        selected = dict(v030_present=False, available_versions=versions)
    else:
        version, checksum = expected
        matches = [entry for entry in entries if entry["vers"] == version]
        require(len(matches) == 1 and matches[0]["cksum"] == checksum and
                matches[0]["yanked"] is False,
                "expected helper version/checksum/yank status mismatch: " + name)
        selected = dict(version=version, sha256=checksum, yanked=False)
    return dict(crate=name, index_url=url, response_url=url, headers=headers,
                raw_file=str(raw_path), raw_sha256=sha(data), raw_bytes=len(data),
                index_entries=len(entries), selected=selected,
                fetched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())


def main():
    require(not OUT.exists(), "public index preflight output already exists")
    (OUT / "raw").mkdir(parents=True)
    results = []
    error = None
    try:
        for name in EXPECTED:
            results.append(fetch(name))
    except BaseException as caught:
        error = repr(caught)
    summary = dict(status="passed" if error is None else "failed", error=error,
                   source="https://doc.rust-lang.org/cargo/reference/registry-index.html",
                   registry="sparse+https://index.crates.io/", results=results,
                   completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if error is None else 1


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(SystemExit("preflight interrupted")))
    raise SystemExit(main())
