"""Read-only inventory of outgoing Git blobs, including nested evidence archives."""
from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-pre-r5')
lab=Path('C:/User/projects/nbreq/target/pre-r5-20260915')
objects=subprocess.check_output(['git','rev-list','--objects','HEAD','--not','--remotes=origin'],cwd=root).decode().splitlines()
checked=[]
alerts=[]
private_material=[]
patterns={
    'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
    'github_token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
    'aws_access_key': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'cargo_token': rb'\bcio[a-zA-Z0-9]{30,}\b',
}
def inspect(path,data,depth=0):
    if path.endswith(('.tar.gz','.tgz','.crate')):
        assert depth < 5
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:*') as archive:
            for member in archive:
                if member.isfile():
                    inspect(path+'!'+member.name,archive.extractfile(member).read(),depth+1)
        return
    if path.lower().endswith(('.pas','.dfm','.dpr','.dll','.pfx','.p12','.ppk')):
        private_material.append(dict(path=path,bytes=len(data)))
    for kind,pattern in patterns.items():
        if re.search(pattern,data):
            alerts.append(dict(path=path,kind=kind))
    checked.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
for record in objects:
    fields=record.split(' ',1)
    if len(fields)!=2:
        continue
    oid,path=fields
    if subprocess.check_output(['git','cat-file','-t',oid],cwd=root).strip()!=b'blob':
        continue
    inspect(oid+':'+path,subprocess.check_output(['git','cat-file','blob',oid],cwd=root))
result=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    files_checked=len(checked),bytes_checked=sum(x['bytes'] for x in checked),
    secret_pattern_alerts=alerts,additional_material=private_material,files=checked,
    limitation='Bounded pattern and file inventory review; not a comprehensive secret detector')
(lab/'checkpoint-inventory.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
