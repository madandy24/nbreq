"""Seal explicitly selected pre-R5 evidence, excluding build trees; verify every member."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-pre-r5')
lab=Path('C:/User/projects/nbreq/target/pre-r5-20260915')
archive_path=root/'thoughts/evidence/nbreq-pre-r5-20260915.tar.gz'
manifest_path=root/'thoughts/evidence/nbreq_pre_r5_artifacts.json'
assert not archive_path.exists() and not manifest_path.exists()
packages=json.loads((lab/'packages-a/packages.json').read_text())
commit=packages['source_commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
assert json.loads((lab/'packages-a/result.json').read_text())['status']=='passed'
assert json.loads((lab/'consumers-a/result.json').read_text())['status']=='passed'
inputs=json.loads((lab/'consumers-a/inputs.json').read_text())['files']
for path,digest in inputs.items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
items={}
def add(name,path):
    assert name not in items
    items[name]=path.read_bytes()
for path in sorted(lab.iterdir()):
    if path.is_file() and path.suffix in ['.json','.log','.exit','.txt','.py','.html']:
        add('run/'+path.name,path)
for folder in ['pin-red','consumers-a']:
    for path in sorted((lab/folder).rglob('*')):
        relative=path.relative_to(lab/folder)
        if 'build' not in relative.parts and path.is_file():
            add(folder+'/'+relative.as_posix(),path)
for path in sorted((lab/'packages-a').iterdir()):
    if path.is_file():
        add('packages/'+path.name,path)
for name,info in packages['packages'].items():
    path=Path(info['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest()==info['sha256']
    add('packages/'+name,path)
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
for name in tracked:
    if name and not name.startswith('thoughts/'):
        add('source/'+name,root/name)
for name in ['thoughts/nbreq_pre_r5.md','thoughts/nbreq_020_release_plan.md']:
    add('source/'+name,root/name)
index={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in items.items()}
items['INDEX.json']=json.dumps(dict(source_commit=commit,files=index),indent=2).encode()
with tarfile.open(archive_path,'x:gz') as archive:
    for name,data in sorted(items.items()):
        entry=tarfile.TarInfo(name)
        entry.size=len(data)
        entry.mode=0o644
        archive.addfile(entry,io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    assert len(archive.getmembers())==len(items)
    for entry in archive:
        assert archive.extractfile(entry).read()==items[entry.name],entry.name
manifest=dict(archive=archive_path.name,bytes=archive_path.stat().st_size,
    sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest(),files=len(items),
    source_commit=commit,red_commit=(lab/'budget-red-commit.txt').read_text().strip(),
    registry_only=False,packages={name:{k:info[k] for k in ['sha256','bytes','commit']} for name,info in packages['packages'].items()},
    note='Budget red/green, dependency conflict, 24-stage Windows verifier, four fresh stable/MSRV consumers with locks, three verified packages, documentation link and outgoing-history inventory. Build trees excluded. Source snapshot matches validation input hashes; later report/tool README edits do not change crate inputs.')
manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(manifest,indent=2))
