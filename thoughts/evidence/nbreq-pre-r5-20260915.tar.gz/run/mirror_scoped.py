"""Mirror only checked pre-R5 files; preserve main's unrelated work and unreleased notices."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path('C:/User/projects/nbreq')
candidate = root/'target/worktrees/nbreq-pre-r5'
lab = root/'target/pre-r5-20260915'
baseline = json.loads((lab/'main-baseline.json').read_text())
for entry in baseline:
    assert hashlib.sha256((root/entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
def committed(ref, path):
    return subprocess.check_output(['git','show',ref+':'+path],cwd=candidate).decode()

updates = {}
for path in ['src/body_budget.rs','Cargo.toml','support/darwin/Cargo.toml',
             'support/winpoll/Cargo.toml','support/winpoll/README.md']:
    updates[path] = (candidate/path).read_bytes()
for path, heading, anchor in [('README.md','## Dependency versions','## Documentation'),
                              ('SECURITY.md','## Dependency updates','## Reviewed advisory exceptions'),
                              ('docs/getting-started.md','### Ambiguous HTTP response framing','## Manual driving and GUI loops')]:
    old = (root/path).read_text(encoding='utf-8')
    if path == 'docs/getting-started.md':
        base = committed('68649ee',path)
        base = base.replace('This guide targets NBReq 0.2. Add the dependency below to use the default native backend:',
            'This guide targets 0.2.0, currently unreleased. Until publication, use the project source;\n'
            'the versioned dependency below selects the 0.2 release once available. The native backend is\n'
            'enabled by default:')
        assert old == base
    new = (candidate/path).read_text(encoding='utf-8')
    assert heading not in old and old.count(anchor) == 1
    addition = new[new.index(heading):new.index(anchor)]
    updates[path] = old.replace(anchor,addition+anchor,1).encode()
for path in ['tools/release-consumer/pre_r5.py','tools/release-consumer/package_candidate.py']:
    assert not (root/path).exists(), path
    updates[path] = (candidate/path).read_bytes()
records = []
for path, data in updates.items():
    target = root/path
    before = hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None
    target.write_bytes(data)
    records.append(dict(path=path,before=before,after=hashlib.sha256(target.read_bytes()).hexdigest()))
assert hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest() == next(x['sha256'] for x in baseline if x['path']=='Cargo.lock')
(lab/'main-mirror.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print('Mirrored',len(records),'checked files; Cargo.lock unchanged')
