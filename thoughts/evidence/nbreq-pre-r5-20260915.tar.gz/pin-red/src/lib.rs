//! Resolution-only proof that a consumer can request a newer compatible Mio release.
