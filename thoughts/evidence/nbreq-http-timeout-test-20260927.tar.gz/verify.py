"""Focused timeout-test release checks; local loopback only, no publication."""
import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import time

from owned_command import command, sha, write


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    inputs = ['tests/http_adversarial.rs', 'src/backend/native_http/tests.rs',
              'Cargo.toml', 'Cargo.lock']
    hashes = {name: sha(root / name) for name in inputs}
    for name in inputs:
        target = out / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((root / name).read_bytes())
    write(out / 'inputs.json', dict(files=hashes, platform=platform.platform(),
        head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()))
    env = dict(os.environ)
    env.pop('RUST_TEST_THREADS', None)
    env.pop('CARGO_BUILD_TARGET', None)
    steps = [
        ('stable-version', ['rustc', '+stable', '-vV']),
        ('msrv-version', ['rustc', '+1.85.0', '-vV']),
        ('default-http', ['cargo', '+stable', 'test', '--locked', '--offline', '--test', 'http_adversarial']),
        ('native-http', ['cargo', '+stable', 'test', '--locked', '--offline', '--no-default-features', '--features', 'native', '--test', 'http_adversarial']),
        ('bundle-http', ['cargo', '+stable', 'test', '--locked', '--offline', '--no-default-features', '--features', 'bundled-roots', '--test', 'http_adversarial']),
        ('all-http', ['cargo', '+stable', 'test', '--locked', '--offline', '--all-features', '--test', 'http_adversarial']),
        ('msrv-http', ['cargo', '+1.85.0', 'test', '--locked', '--offline', '--all-features', '--test', 'http_adversarial']),
        ('clippy', ['cargo', '+stable', 'clippy', '--locked', '--offline', '--all-features', '--all-targets', '--', '-D', 'warnings']),
        ('format', ['cargo', '+stable', 'fmt', '--check']),
    ]
    relevant = [
        'native_http_spawned_requests_classify_inactivity_and_total_timeouts',
        'total_timeout_before_first_drive_never_connects_and_fixture_joins',
        'stalled_response_fixture_stops_without_a_connection',
        'stalled_response_fixture_rejects_an_incomplete_request_head',
    ]
    for toolchain in ['stable', '1.85.0']:
        for name in relevant:
            steps.append((toolchain + '-' + name, ['cargo', '+' + toolchain,
                'test', '--locked', '--offline', '--all-features', '--lib',
                'backend::native_http::tests::' + name, '--', '--exact']))
    started, failure, completed = time.monotonic(), None, []
    try:
        for label, argv in steps:
            command(argv, root, out, label, env, 600)
            completed.append(label)
    except BaseException as error:
        failure = repr(error)
    final_hashes = {name: sha(root / name) for name in inputs}
    if final_hashes != hashes:
        failure = (failure + '; ' if failure else '') + 'inputs changed during verification'
    write(out / 'result.json', dict(status='failed' if failure else 'passed',
        failure=failure, completed=completed, inputs=hashes,
        elapsed_seconds=time.monotonic() - started))
    if failure:
        raise RuntimeError(failure)
    print('All focused verification steps passed.', flush=True)


if __name__ == '__main__':
    main()
