"""Two waves of two overlapping copies of the final HTTP integration executable."""
import concurrent.futures
import json
import os
from pathlib import Path

from owned_command import command, sha, write


def main():
    lab = Path(__file__).resolve().parent
    root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
    out = lab / 'overlapping-runs'
    out.mkdir(exist_ok=False)
    evidence = json.loads((lab / 'final-verification' / 'result.json').read_text())
    assert evidence['status'] == 'passed'
    hashes = evidence['inputs']
    assert all(sha(root / name) == digest for name, digest in hashes.items())
    env = dict(os.environ)
    env.pop('RUST_TEST_THREADS', None)
    env.pop('CARGO_BUILD_TARGET', None)
    command(['cargo', '+stable', 'test', '--locked', '--offline', '--all-features',
             '--test', 'http_adversarial', '--no-run', '--message-format=json'],
            root, out, 'executable', env, 300)
    artifacts = []
    for line in (out / 'executable.log').read_text(encoding='utf-8').splitlines():
        if line.startswith('{'):
            item = json.loads(line)
            if (item.get('reason') == 'compiler-artifact'
                    and item['target']['name'] == 'http_adversarial'
                    and item.get('executable')):
                artifacts.append(Path(item['executable']))
    assert len(artifacts) == 1, artifacts
    binary = artifacts[0]
    binary_hash = sha(binary)
    write(out / 'identity.json', dict(binary=str(binary), sha256=binary_hash, inputs=hashes))

    def run(label):
        run_out = out / label
        run_out.mkdir()
        command([str(binary)], root, run_out, 'http-tests', env, 120)
        log = (run_out / 'http-tests.log').read_text(encoding='utf-8')
        assert '16 passed; 0 failed;' in log
        return label

    completed = []
    for wave in range(2):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(run, f'wave-{wave}-run-{index}') for index in range(2)]
            completed.extend(future.result() for future in futures)
    assert sha(binary) == binary_hash
    assert all(sha(root / name) == digest for name, digest in hashes.items())
    write(out / 'result.json', dict(status='passed', completed=completed,
        binary_sha256=binary_hash, inputs=hashes, tests_per_run=16))
    print('Four overlapping HTTP integration runs passed.', flush=True)


if __name__ == '__main__':
    main()
