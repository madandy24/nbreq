"""Retain reviewed timeout-test sources, logs and manifests; exclude executable binaries."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

from owned_command import sha, write


def main():
    lab = Path(__file__).resolve().parent
    root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
    verification = json.loads((lab / 'final-verification' / 'result.json').read_text())
    repeats = json.loads((lab / 'overlapping-runs' / 'result.json').read_text())
    assert verification['status'] == repeats['status'] == 'passed'
    hashes = verification['inputs']
    assert repeats['inputs'] == hashes
    assert all(sha(root / name) == digest for name, digest in hashes.items())
    base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    diff = subprocess.check_output(['git', 'diff', '--', 'tests/http_adversarial.rs',
                                    'src/backend/native_http/tests.rs'], cwd=root)
    (lab / 'final-test-changes.diff').write_bytes(diff)
    (lab / 'native_http_tests.original.rs').write_bytes(subprocess.check_output(
        ['git', 'show', 'HEAD:src/backend/native_http/tests.rs'], cwd=root))
    summary = dict(
        base=base, scope='Test-only repair; production source and dependency graph unchanged.',
        red='Compiled controlled delayed-owner reproduction: Total timeout succeeds, old request-arrival assertion fails. Does not establish exact historical scheduling path.',
        green='Manual buffered GET observes parsed head, then selected real timeout, reservation release and peer EOF/reset before shutdown. Spawned smoke uses one intended clock and bounded waiter.',
        verification=verification, overlapping_runs=repeats,
        limitations='Windows x64 only for this test repair. Real-time setup headroom remains; no injected clock or new remote-platform/Wine run. Historical failed result is retained, not relabeled.',
    )
    write(lab / 'summary.json', summary)
    allowed_suffixes = {'.rs', '.log', '.txt', '.json', '.toml', '.lock', '.py', '.diff'}
    files = []
    for path in lab.rglob('*'):
        relative = path.relative_to(lab)
        if len(relative.parts) > 1 and relative.parts[0] not in {'final-verification', 'overlapping-runs'}:
            continue
        if path.is_file() and path.suffix in allowed_suffixes:
            assert not path.is_symlink() and lab in path.resolve().parents
            files.append(path)
    archive = root / 'thoughts/evidence/nbreq-http-timeout-test-20260927.tar.gz'
    assert not archive.exists(), 'never overwrite an earlier evidence archive'
    manifest = {path.relative_to(lab).as_posix(): dict(bytes=path.stat().st_size, sha256=sha(path))
                for path in sorted(files)}
    with tarfile.open(archive, 'w:gz') as output:
        for path in sorted(files):
            output.add(path, arcname=path.relative_to(lab).as_posix(), recursive=False)
    with tarfile.open(archive, 'r:gz') as check:
        members = check.getmembers()
        assert len(members) == len(manifest)
        for member in members:
            assert member.isfile() and member.name in manifest
            data = check.extractfile(member).read()
            assert len(data) == manifest[member.name]['bytes']
            assert hashlib.sha256(data).hexdigest() == manifest[member.name]['sha256']
    write(root / 'thoughts/evidence/nbreq_http_timeout_test_artifacts.json',
          dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
               members=len(manifest), summary=summary, files=manifest))
    print(json.dumps(dict(archive=str(archive), bytes=archive.stat().st_size,
                         sha256=sha(archive), members=len(manifest))), flush=True)


if __name__ == '__main__':
    main()
