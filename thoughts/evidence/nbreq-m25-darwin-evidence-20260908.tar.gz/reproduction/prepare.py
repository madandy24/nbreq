from pathlib import Path
import hashlib, io, json, tarfile

out = Path(__file__).parent
files = {}
with tarfile.open('thoughts/evidence/nbreq-m24-retention-20260908-b.tar.gz') as prior:
    for m in prior.getmembers():
        name = m.name.removeprefix('nbreq/')
        if m.isfile() and not name.startswith('m24-'):
            files[name] = prior.extractfile(m).read()
# This gate varies only the Darwin manifest from the verified M2.4 production source.
files['support/darwin/Cargo.toml'] = Path('support/darwin/Cargo.toml').read_bytes()
files['m25-remote.sh'] = (out/'remote.sh').read_bytes().replace(b'\r\n', b'\n')
manifest = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
files['m25-source.sha256'] = manifest
bundle = out/'nbreq-m25-darwin-20260908.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle, 'w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo('nbreq/'+name)
        info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
record=dict(path=str(bundle.resolve()),sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256(manifest).hexdigest())
(out/'bundle.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
