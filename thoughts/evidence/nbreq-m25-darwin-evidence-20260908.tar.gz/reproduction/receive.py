from pathlib import Path
import base64, io, json, sys, tarfile

host, bridge, request = sys.argv[1:]
receipt=Path('C:/User/SecuritasNew/gds/scripts/sessions')/bridge/'results'/(request+'.json')
result=json.loads(receipt.read_text(encoding='utf-8-sig'))
assert result['status']=='completed' and result['ok'] and result['exit_code']==0
data=base64.b64decode(''.join(result['output'].split()),validate=True)
out=Path(__file__).parent/host
out.mkdir(exist_ok=True)
(out/'evidence.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for m in archive.getmembers():
        assert m.isfile(),m.name
        dest=(out/m.name).resolve()
        assert dest.is_relative_to(out.resolve())
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(archive.extractfile(m).read())
assert (out/'run.exit').read_text().strip()=='0'
for log in sorted(out.glob('*.log')):
    for line in log.read_text(encoding='utf-8').splitlines():
        if 'test result:' in line or '_PASS' in line:
            print(host,log.name,line)
