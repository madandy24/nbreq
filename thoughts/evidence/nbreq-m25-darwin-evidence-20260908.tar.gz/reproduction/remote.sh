#!/bin/sh
set -eu
lab=$1
cache=$2
case "$lab" in */nbreq-m25-darwin-20260908) ;; *) exit 2 ;; esac
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$cache"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export RUSTUP_TOOLCHAIN=stable
trap 'code=$?; printf "%s\n" "$code" > "$lab/run.exit"' EXIT
cd "$lab/nbreq"
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m25-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
cargo update --offline -p core-foundation --precise 0.10.0
cargo update --offline --manifest-path support/darwin/Cargo.toml -p core-foundation --precise 0.10.0
cargo tree --locked --offline -i core-foundation > "$lab/core-foundation-tree.log"
cargo clean --offline -p nbreq
cargo clean --offline --manifest-path support/darwin/Cargo.toml -p nbreq-darwin
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    cargo test --locked --offline --manifest-path support/darwin/Cargo.toml > "$lab/darwin-$toolchain.log" 2>&1
    cargo test --locked --offline --all-features --lib > "$lab/nbreq-$toolchain.log" 2>&1
    printf 'M25_DARWIN_LOWER_PATCH_PASS %s\n' "$toolchain"
done
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m25-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows if name not in ("Cargo.lock", "support/darwin/Cargo.lock")); print("SOURCE_UNCHANGED_EXCEPT_LOCKS_PASS")'
printf 'M25_HOST_PASS\n'
