import hashlib, json, os, subprocess, tarfile, time
from pathlib import Path
ROOT=Path('C:/User/projects/nbreq')
LAB=ROOT/'target/release-021-20260927/intel-tls-diagnostic'
COPY=LAB/'copy'
ENV=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'target/docs-021-20260927/build'),PYTHONDONTWRITEBYTECODE='1')
paths=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
def hashes():
    return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if p and p.endswith(('.rs','.toml','.lock'))}
before=hashes()
(LAB/'source-before.json').write_text(json.dumps(before,indent=2))
(LAB/'watchdog.diff').write_bytes(subprocess.check_output(['git','diff','--','tests/tcp_tls.rs'],cwd=ROOT))
with tarfile.open(LAB/'diagnostic.tar.gz') as archive:
    archive.extractall(COPY,filter='data')
current=(ROOT/'tests/tcp_tls.rs').read_text()
original=subprocess.check_output(['git','show','HEAD:tests/tcp_tls.rs'],cwd=ROOT,text=True)
results=[]
def run(name,cwd,toolchain,args,expected=0):
    command=['rustup','run',toolchain,'cargo',*args]
    print('START',name,flush=True)
    start=time.time()
    with (LAB/(name+'.log')).open('wb') as log:
        result=subprocess.run(command,cwd=cwd,env=dict(ENV,RUSTUP_TOOLCHAIN=toolchain),stdout=log,stderr=subprocess.STDOUT,timeout=600)
    receipt=dict(name=name,cwd=str(cwd),command=command,exit=result.returncode,expected_exit=expected,elapsed_seconds=time.time()-start)
    results.append(receipt)
    (LAB/'results.json').write_text(json.dumps(results,indent=2))
    print('END',receipt,flush=True)
    assert result.returncode==expected,receipt
def inject(source,mode):
    start=source.index('fn one_byte_receive_window_preserves_more_than_64k_of_tls_plaintext()')
    end=source.index('\n#[test]',start)
    fragment=source[start:end]
    if 'for expected_byte in expected {' in fragment:
        fragment=fragment.replace('for expected_byte in expected {','for (received, expected_byte) in expected.into_iter().enumerate() {')
    if mode=='slow':
        fragment=fragment.replace('let mut byte = [0_u8; 1];','if received > 0 && received % 8192 == 0 {\n            eprintln!("LAB_SLOW bytes={received}");\n            std::thread::sleep(Duration::from_secs(2));\n        }\n        let mut byte = [0_u8; 1];')
    else:
        fragment=fragment.replace('TcpRead::Pending => {','TcpRead::Pending => {\n                    if received >= 8192 { continue; }',1)
    return source[:start]+fragment+source[end:]
testargs=['test','--locked','--offline','--no-default-features','--features','native,test-support','--test','tcp_tls','one_byte_receive_window_preserves_more_than_64k_of_tls_plaintext','--','--exact','--nocapture']
try:
    for name,source,mode,expected in [('old-slow',original,'slow',101),('new-slow',current,'slow',0),('new-stalled-drive',current,'stall',101)]:
        injected=inject(source,mode)
        (COPY/'tests/tcp_tls.rs').write_text(injected)
        (LAB/(name+'.rs')).write_text(injected)
        run(name,COPY,'stable',testargs,expected)
    run('stable-verifier',ROOT,'stable',['run','--locked','--offline','--manifest-path','tools/xtask/Cargo.toml','--','verify','--offline'])
    run('msrv-clippy',ROOT,'1.85.0',['clippy','--locked','--offline','--all-features','--all-targets','--','-D','warnings'])
    run('msrv-tls-tests',ROOT,'1.85.0',['test','--locked','--offline','--all-features','--test','tcp_tls','--test','tcp_tls_api'])
finally:
    after=hashes()
    (LAB/'source-after.json').write_text(json.dumps(after,indent=2))
    (LAB/'summary.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),results=results,source_hashes_unchanged=before==after,source_after_sha256=hashlib.sha256((ROOT/'tests/tcp_tls.rs').read_bytes()).hexdigest(),limitation='Original hosted15s failure had no progress counters; root cause unknown. Local controlled pacing/stall checks validate watchdog behavior only.'),indent=2))
