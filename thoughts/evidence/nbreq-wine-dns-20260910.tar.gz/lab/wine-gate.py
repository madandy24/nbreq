from pathlib import Path
import hashlib,json,os,subprocess

root=Path(__file__).resolve().parent
expected=json.loads((root/'inputs.json').read_text())
for name,sha in expected.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
prefix=Path('/tmp/nbreq-wine-dns-lab-20260910/prefix')
environment=dict(os.environ,WINEPREFIX=str(prefix),WINEARCH='win32',WINEDEBUG='-all')
results=[]
print(subprocess.check_output(['wine','--version'],text=True).strip(),flush=True)
try:
    for features in ('default','native'):
        command=['python3',str(root/'run.py'),'--binary',str(root/('probe-'+features+'.exe')),
            '--wine','wine','--prefix',str(prefix),'--out',str(root/features)]
        print(features,flush=True)
        result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
        (root/(features+'.log')).write_bytes(result.stdout)
        print(result.stdout.decode(errors='replace'),flush=True)
        results.append(dict(features=features,exit_code=result.returncode))
        assert result.returncode==0,features
    result=subprocess.run(['wine',str(root/'helper-tests.exe'),'--test-threads=1'],env=environment,
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
    (root/'helper-tests.log').write_bytes(result.stdout)
    assert result.returncode==0 and b'test result: ok. 13 passed' in result.stdout
    print(result.stdout.decode(errors='replace'),flush=True)
    (root/'results.json').write_text(json.dumps(dict(status='passed',results=results,inputs=expected),indent=2))
finally:
    # This explicit prefix belongs only to these tests. Do not stop any other Wine prefix.
    subprocess.run(['wineserver','-k'],env=environment,timeout=15,check=True)
print('wine gate passed; private prefix stopped',flush=True)
