from pathlib import Path
import json,os,subprocess,time

root=Path(__file__).resolve().parents[2]
lab=root/'target/wine-dns'
binary=lab/'root-build/debug/deps/nbreq-aef15adb6a7d1bfe.exe'
tests=[
    'backend::native_http::tests::native_http_stalled_response_classifies_inactivity_and_total_timeouts',
    'dns_wiring_tests::search_total_timeout_during_a_later_candidate_does_not_promote_a_negative',
    'dns_wiring_tests::public_tcp_fallback_completes_and_classifies_bad_tcp_replies',
    'tcp::tests::hostname_cancel_at_dns_handoff_cannot_publish_or_leak_a_socket',
    'tcp::tests::hostname_dns_negatives_and_operational_failures_keep_their_contract',
    'tcp::tests::native_hostname_connect_uses_the_existing_resolver_and_reactor',
]
results=[]
for index,test in enumerate(tests):
    start=time.monotonic()
    with (lab/('focused-failure-'+str(index)+'.log')).open('wb') as log:
        command=[str(binary),test,'--exact','--nocapture','--test-threads=1']
        process=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        try: code=process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],check=True,stdout=log,stderr=subprocess.STDOUT)
            process.wait(timeout=10)
            code='timeout'
    result=dict(test=test,exit_code=code,seconds=time.monotonic()-start)
    results.append(result)
    (lab/'focused-failures.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(result),flush=True)
