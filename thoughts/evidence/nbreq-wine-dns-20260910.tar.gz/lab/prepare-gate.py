from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[2]
lab=root/'target/wine-dns'
files={
    'probe-default.exe':lab/'probe-default.exe',
    'probe-native.exe':lab/'probe-native.exe',
    'helper-tests.exe':lab/'helper-build/i686-pc-windows-msvc/debug/deps/nbreq_winpoll-2647f4afea7ed245.exe',
    'bcryptprimitives.dll':lab/'shim-build/Release/bcryptprimitives.dll',
    'run.py':root/'target/worktrees/nbreq-wine-dns/tools/wine-dns-probe/run.py',
    'wine-gate.py':lab/'wine-gate.py',
}
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in files.items()}
(lab/'inputs.json').write_text(json.dumps(manifest,indent=2))
files['inputs.json']=lab/'inputs.json'
with tarfile.open(lab/'wine-gate-20260910.tar.gz','w:gz') as archive:
    for name,path in files.items(): archive.add(path,arcname=name,recursive=False)
print(json.dumps(manifest,indent=2))
print('bundle SHA256',hashlib.sha256((lab/'wine-gate-20260910.tar.gz').read_bytes()).hexdigest())
