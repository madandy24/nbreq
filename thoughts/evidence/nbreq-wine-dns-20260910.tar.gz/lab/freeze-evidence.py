from pathlib import Path
import hashlib, io, json, subprocess, tarfile

root = Path(__file__).resolve().parents[2]
lab = root / 'target/wine-dns'
fix = root / 'target/worktrees/nbreq-wine-dns'
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=fix, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=fix)
files = {}

def add(name, path):
    assert name not in files, name
    files[name] = Path(path).read_bytes()

for path in lab.iterdir():
    if path.is_file() and path.suffix in {'.log', '.json', '.py', '.exit', '.gz'}:
        add('lab/' + path.name, path)
for folder in ['wine-evidence', 'native-default', 'native-native']:
    for path in (lab / folder).rglob('*'):
        if path.is_file():
            add('lab/' + path.relative_to(lab).as_posix(), path)
add('binaries/probe-red.exe', lab / 'probe-build/i686-pc-windows-msvc/debug/nbreq-wine-dns-probe.exe')
assert hashlib.sha256(files['binaries/probe-red.exe']).hexdigest() == '510d219331fb54b86dbac280945e23c23b6b912f2c7d61b2c67faa69e0133e95'

packages = {}
for name in ['nbreq-winpoll-0.1.1', 'nbreq-0.2.0']:
    path = lab / ('package-build/package/' + name + '.crate')
    data = path.read_bytes()
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        vcs = json.loads(archive.extractfile(name + '/.cargo_vcs_info.json').read())
        assert vcs['git']['sha1'] == commit and not vcs['git'].get('dirty')
        packages[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                          'file_count': len(archive.getnames()), 'vcs': vcs}
    add('packages/' + path.name, path)

changed = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=fix, text=True).splitlines()
for name in changed:
    files['source/' + name] = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=fix)
for path in (fix / 'experiments/wine5-bcryptprimitives').iterdir():
    if path.is_file() and path.suffix in {'.c', '.def', '.md', '.txt'}:
        add('shim-source/' + path.name, path)
files['source/fix.patch'] = subprocess.check_output(['git', 'show', '--format=fuller', '--binary', commit], cwd=fix)

bridge = Path('C:/User/SecuritasNew/gds/scripts/sessions/putty_bridge/results')
ids = ['044001-fe6c989f', '044248-81c83d03', '044326-c7777a66', '044505-c9be540c',
       '044532-b19fad99', '044924-2e223428', '045054-7ff52402', '045202-a55229d5',
       '045426-b30b25fe', '045611-d0fba918', '045745-201affdb', '045850-d6b0f583',
       '050448-568f0a6b', '050851-80b1a31a', '051015-d845ed2c', '051235-d52dcc9c']
for suffix in ids:
    path = bridge / ('20260910-' + suffix + '.json')
    add('bridge/' + path.name, path)

destination = root / 'thoughts/evidence/nbreq-wine-dns-20260910.tar.gz'
with tarfile.open(destination, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
entries = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
           for name, data in sorted(files.items())]
with tarfile.open(destination) as archive:
    assert len(archive.getnames()) == len(entries)
    for entry in entries:
        assert hashlib.sha256(archive.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
manifest = {'date': '2026-09-10', 'archive': destination.name,
            'bytes': destination.stat().st_size, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
            'checkpoint': {'fix_commit': commit, 'base_commit': '7693d6cf6f702432235df4001b8ef1731d70a25e',
                           'wine': '5.0 (Ubuntu 5.0-3ubuntu1)', 'process_architecture': 'Windows i686 MSVC debug',
                           'linux_kernel': '5.4.0-216-generic x86_64', 'original_deployed_gds_dll': 'unidentified',
                           'native_windows_verifier_steps': 24, 'helper_tests': 13,
                           'actual_wine_default_and_native_only_probes': 'passed',
                           'registry_only': False, 'published': False, 'gds_acceptance': 'pending'},
            'packages': packages, 'file_count': len(entries), 'files': entries}
(destination.parent / 'nbreq_wine_dns_artifacts.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'files'}, indent=2))
