from pathlib import Path, PurePosixPath
import hashlib, json, re, tarfile

root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent
policy=root/'target/consumer-policy-20260927'
entries={}
hashes=json.loads((policy/'evidence-hashes.json').read_text())
for name,digest in hashes.items():
    path=(policy/name).resolve()
    assert path.is_relative_to(policy.resolve()) and path.is_file()
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    entries['policy/'+name]=path
entries['policy/evidence-hashes.json']=policy/'evidence-hashes.json'
summary=json.loads((policy/'summary.json').read_text())
for name,digest in summary['source_hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
passed=json.loads((lab/'full-verifier-quiet/summary.json').read_text())
assert passed['status']=='passed' and passed['steps']==30
for directory in ['full-verifier','smtp-quiet-check','full-verifier-quiet']:
    for path in (lab/directory).rglob('*'):
        if path.is_file():
            assert path.suffix in ['.json','.log']
            entries['release/'+path.relative_to(lab).as_posix()]=path
for name in ['full_verify.py','full_verify_quiet.py','smtp_quiet_check.py','owned_command.py',
             'publication_command.py','validate_matrix.py','check_published_docs.py',
             'retain_policy_checkpoint.py']:
    entries['release/'+name]=lab/name
inputs=json.loads((lab/'full-verifier-quiet/inputs.json').read_text())
assert inputs['files']==json.loads((lab/'full-verifier/inputs.json').read_text())['files']
for name,digest in inputs['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16})')
for name,path in entries.items():
    assert not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
    assert not secret.search(path.read_bytes()),name
destination=root/'thoughts/evidence/nbreq-consumer-policy-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz') as bundle:
    for name,path in entries.items(): bundle.add(path,arcname=name,recursive=False)
member_hashes={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in entries.items()}
with tarfile.open(destination) as bundle:
    members=bundle.getmembers()
    assert len(members)==len(entries) and all(m.isfile() for m in members)
    assert {m.name:hashlib.sha256(bundle.extractfile(m).read()).hexdigest() for m in members}==member_hashes
record=dict(archive=destination.name,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
    bytes=destination.stat().st_size,regular_members=len(entries),summary=summary,
    full_verifier=passed,smtp_timing_observation='Earlier full run failed seven SMTP tests; unchanged default-parallel SMTP passed twice and full verifier passed once on a quiet build queue. Contention remains a hypothesis.',
    members=member_hashes)
(root/'thoughts/evidence/nbreq_consumer_policy_021_artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['archive','sha256','bytes','regular_members']},indent=2))
