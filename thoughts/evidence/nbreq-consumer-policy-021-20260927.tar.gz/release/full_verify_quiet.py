from pathlib import Path
import hashlib, json, os, subprocess, sys
from owned_command import command

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq')
out = lab/'full-verifier-quiet'
out.mkdir(exist_ok=False)
env = dict(os.environ, CARGO_TARGET_DIR='C:/User/projects/nbreq/target/docs-021-20260927/build', RUSTUP_TOOLCHAIN='stable', CARGO_NET_OFFLINE='true')
files = subprocess.check_output(['git','ls-files','src','smtp/src','support','Cargo.toml','Cargo.lock','README.md','CHANGELOG.md','SECURITY.md','CONTRIBUTING.md','docs','smtp/README.md'],cwd=root,text=True).splitlines()
hashes = {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(out/'inputs.json').write_text(json.dumps(dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),files=hashes),indent=2))
command(['rustc','-Vv'],root,out,'compiler',env,30)
command(['cargo','run','--locked','--offline','--manifest-path','tools/xtask/Cargo.toml','--','verify','--offline'],root,out,'verify',env,1200)
log = (out/'verify.log').read_text(encoding='utf-8')
assert 'NBReq verification complete: all 30 steps passed' in log
assert hashes=={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(out/'summary.json').write_text(json.dumps(dict(status='passed',steps=30,source_hashes_unchanged=True,scope='Windows x86_64 stable; existing complete offline verifier'),indent=2))
print('Full verifier passed, source hashes unchanged.',flush=True)

