from pathlib import Path
import hashlib,json,os,subprocess
from owned_command import command
lab=Path(__file__).resolve().parent
root=Path('C:/User/projects/nbreq')
out=lab/'smtp-quiet-check'
out.mkdir(exist_ok=False)
files=subprocess.check_output(['git','ls-files','src','smtp','Cargo.toml','Cargo.lock'],cwd=root,text=True).splitlines()
hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(out/'inputs.json').write_text(json.dumps(hashes,indent=2))
env=dict(os.environ,CARGO_TARGET_DIR='C:/User/projects/nbreq/target/docs-021-20260927/build',
         RUSTUP_TOOLCHAIN='stable',CARGO_NET_OFFLINE='true')
assert 'RUST_TEST_THREADS' not in env
for n in [1,2]:
    command(['cargo','test','--locked','--offline','--package','nbreq-smtp','--all-targets'],
            root,out,'parallel-'+str(n),env,180)
    log=(out/('parallel-'+str(n)+'.log')).read_text()
    assert '33 passed; 0 failed' in log and '7 passed; 0 failed' in log
assert hashes=={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(out/'result.json').write_text(json.dumps(dict(status='passed',repeats=2,
    test_threads='default parallel, unchanged',code_unchanged=True,
    scope='Unchanged tests, after agent-managed competing builds completed; earlier failure preserved'),indent=2))
print('Both unchanged parallel SMTP runs passed.')
