from pathlib import Path
from html.parser import HTMLParser
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,re,urllib.request
from urllib.parse import urlsplit

lab=Path(__file__).resolve().parent
class Page(HTMLParser):
    def __init__(self): super().__init__();self.links=[];self.ids=[];self.words=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='a' and attrs.get('href'):self.links.append(attrs['href'])
        if attrs.get('id'):self.ids.append(attrs['id'])
    def handle_data(self,text):self.words.append(text)

def get(url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'nbreq-021-release-doc-check'}),timeout=45) as response:
        data=response.read();assert response.status==200
        if urlsplit(url).netloc in ['docs.rs','github.com']:
            assert response.url.rstrip('/')==url.rstrip('/'), (url,response.url)
        return data,dict(url=url,status=response.status,final_url=response.url,
                         sha256=hashlib.sha256(data).hexdigest())

readme_url='https://static.crates.io/readmes/nbreq/nbreq-0.2.1.html'
docs_url='https://docs.rs/nbreq/0.2.1/nbreq/'
readme_data,readme_receipt=get(readme_url)
docs_data,docs_receipt=get(docs_url)
(lab/'published-readme.html').write_bytes(readme_data)
(lab/'published-docs.html').write_bytes(docs_data)
readme=Page();readme.feed(readme_data.decode())
docs=Page();docs.feed(docs_data.decode())
visible=' '.join(readme.words)
assert readme.ids.index('user-content-highlights')<readme.ids.index('user-content-start-with-a-get')
assert readme.ids[-1]=='user-content-history'
assert len(re.findall(r'\bcurl\b',visible,re.I))==1
assert '0.2.1' in visible and 'currently unreleased' not in visible
assert 'rust-version-and-dependency-selection' in docs.ids
assert 'yoke-derive' in ' '.join(docs.words)
immutable='https://github.com/madandy24/nbreq/blob/v0.2.1/'
assert immutable+'examples/README.md' in docs.links
assert immutable+'docs/tcp-tls.md' in docs.links
assert '../examples/README.md' not in docs.links
targets=[immutable+name for name in ['docs/getting-started.md','examples/README.md',
    'docs/migrating-to-0.2.md','docs/tcp-tls.md']]
targets += [docs_url+name for name in ['struct.Engine.html','struct.Resolver.html',
    'struct.TcpConnector.html','struct.TlsOptions.html','struct.TlsConnection.html','enum.TlsTrust.html']]
with ThreadPoolExecutor(max_workers=3) as pool:
    receipts=list(pool.map(lambda url:get(url)[1],targets))
record=dict(status='passed',readme=readme_receipt,docs=docs_receipt,
    highlights_before_get=True,history_last=True,curl_mentions=1,
    compiler_workaround_visible=True,fetched_targets=receipts)
(lab/'published-docs-verified.json').write_text(json.dumps(record,indent=2)+'\n')
print('Published README, compatibility guidance, TLS API and versioned source links verified.')
