"""Bounded core-only dry run/publication after explicit release gates."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, tarfile
from owned_command import command

p=argparse.ArgumentParser()
p.add_argument('action',choices=['dry-run','publish'])
p.add_argument('--source',required=True)
a=p.parse_args()
root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==a.source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
out=lab/a.action
out.mkdir(exist_ok=False)
target=lab/'publication-build'
argv=['cargo','publish','--locked','--registry','crates-io','-p','nbreq','--target-dir',str(target)]
if a.action=='dry-run':argv.insert(2,'--dry-run')
else:
    expected=json.loads((lab/'final-root-candidate.json').read_text())
    assert expected['source_commit']==a.source and expected['dry_run_passed']
    candidate=json.loads((lab/'candidate-matrix-verified.json').read_text())
    assert candidate['source']==a.source and candidate['mode']=='candidate' and candidate['status']=='passed'
    ci=json.loads((lab/'hosted-ci/run.json').read_text())
    assert ci['head_sha']==a.source and ci['conclusion']=='success' and ci['status']=='completed'
    assert ci['path']=='.github/workflows/ci.yml'
    jobs=json.loads((lab/'hosted-ci/jobs.json').read_text())
    assert len(jobs)==10 and all(j['conclusion']=='success' for j in jobs)
    packaged=json.loads((lab/'package-final/result.json').read_text())
    assert packaged['status']=='passed' and packaged['commit']==a.source
    assert packaged['package_sha256']==expected['sha256']
    assert expected['archives']
    for name in expected['archives']:
        path=Path(name).resolve()
        assert path.is_relative_to(target.resolve()) and path.is_file()
        assert hashlib.sha256(path.read_bytes()).hexdigest()==expected['sha256']
        with tarfile.open(path) as bundle:
            vcs=json.load(bundle.extractfile('nbreq-0.2.1/.cargo_vcs_info.json'))
            assert vcs['git']['sha1']==a.source and not vcs['git'].get('dirty',False)
command(argv,root,out,'cargo-'+a.action,dict(os.environ,RUSTUP_TOOLCHAIN='stable'),900)
paths=list((target/'package').rglob('nbreq-0.2.1.crate'))
assert paths
hashes={hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
assert len(hashes)==1, 'Publication staging produced differing package bytes'
digest=next(iter(hashes))
with tarfile.open(paths[0]) as bundle:
    vcs=json.load(bundle.extractfile('nbreq-0.2.1/.cargo_vcs_info.json'))
    assert vcs['git']['sha1']==a.source and not vcs['git'].get('dirty',False)
if a.action=='dry-run':
    inventory=json.loads((lab/'package-final/inventory.json').read_text())
    assert inventory['package_sha256']==digest, 'Dry-run package differs from locally verified archive'
    record=dict(source_commit=a.source,sha256=digest,bytes=paths[0].stat().st_size,
                archives=[str(p) for p in paths],registry_helpers=True,dry_run_passed=True)
    (lab/'final-root-candidate.json').write_text(json.dumps(record,indent=2)+'\n')
else:assert digest==expected['sha256']
print(a.action+' passed; exact core archive '+digest)
