"""Verify hosted consumer receipts and audit their distinct locks; never publish."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, tomllib, zipfile
from owned_command import command

p=argparse.ArgumentParser()
p.add_argument('--mode',choices=['candidate','published'],required=True)
p.add_argument('--source',required=True)
p.add_argument('--package-sha')
a=p.parse_args()
root=Path('C:/User/projects/nbreq')
lab=Path(__file__).resolve().parent
hosted=lab/('hosted-'+a.mode)
run=json.loads((hosted/'run.json').read_text())
jobs=json.loads((hosted/'jobs.json').read_text())
assert run['head_sha']==a.source and run['conclusion']=='success'
assert len(jobs)==8 and all(j['conclusion']=='success' for j in jobs)
artifacts=json.loads((hosted/'artifacts.json').read_text())
assert len(artifacts)==8
registry='registry+https://github.com/rust-lang/crates.io-index'
records=[]; locks={}; tests=negative=example_count=0
for artifact in artifacts:
    path=hosted/('artifact-'+str(artifact['id'])+'.zip')
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        inputs_name=next(n for n in names if n.endswith('inputs.json'))
        prefix=inputs_name[:-len('inputs.json')]
        inputs=json.loads(z.read(inputs_name))
        result=json.loads(z.read(prefix+'result.json'))
        steps=json.loads(z.read(prefix+'steps.json'))
        assert inputs['mode']==a.mode and result['status']=='passed'
        assert result['steps']==len(steps) and all(s['passed'] for s in steps)
        assert result['registry_only']==(a.mode=='published') and result['support_from_registry']
        assert inputs['package_vcs']['git']['sha1']==a.source
        assert not inputs['package_vcs']['git'].get('dirty',False)
        assert result['archive_sha256']==inputs['archive_sha256']
        if a.mode=='published': assert a.package_sha==inputs['archive_sha256']
        for name,digest in inputs['test_source_files'].items():
            data=subprocess.check_output(['git','show',a.source+':tools/release-consumer/'+name.replace('\\','/')],cwd=root)
            assert digest in {hashlib.sha256(data).hexdigest(),hashlib.sha256(data.replace(b'\n',b'\r\n')).hexdigest()}
        assert len(result['cases'])==2
        expected_steps=21
        for case in result['cases']:
            packages=case['packages']
            assert packages['nbreq']==dict(version='0.2.1',source=registry if a.mode=='published' else None)
            for helper,(version,digest) in inputs['helper_hashes'].items():
                assert packages[helper]==dict(version=version,source=registry)
            assert packages['webpki-roots']['source']==registry
            lock_data=z.read(prefix+case['label']+'/Cargo.lock')
            assert hashlib.sha256(lock_data).hexdigest()==case['lock_sha256']
            policy=json.loads(z.read(prefix+case['label']+'/consumer-policy.json'))
            initial=z.read(prefix+case['label']+'/Cargo.initial.lock')
            assert policy['status']=='selected'
            assert policy['initial']['sha256']==hashlib.sha256(initial).hexdigest()
            assert policy['selected']['sha256']==case['lock_sha256']
            version=tuple(map(int,re.search(r'^release: (\d+)\.(\d+)\.(\d+)',policy['rustc'],re.M).groups()))
            expected_steps+=1
            if version<(1,87,0):
                expected_steps+=1
                assert policy['route']=='compatibility-selected' and policy['command']
                assert policy['command'][-4:]==['-p','yoke-derive','--precise','0.8.2']
                assert next(x for x in policy['selected']['packages'] if x['name']=='yoke-derive')['version']=='0.8.2'
                assert {x['name'] for x in policy['removed']+policy['added']} <= {'yoke-derive','synstructure'}
            else:
                assert policy['route']=='fresh' and policy['command'] is None
                assert policy['initial']['sha256']==policy['selected']['sha256']
            lock=tomllib.loads(lock_data.decode())
            if a.mode=='published':
                entry=next(x for x in lock['package'] if x['name']=='nbreq')
                assert entry['checksum']==a.package_sha and entry['source']==registry
            locks[case['lock_sha256']]=lock_data
            for mode in ['default','native','minimal','test-support','bundled-roots']:
                label=case['label']+'-'+mode
                step=next(s for s in steps if s['label']==label)
                assert step['exit_code']==0
                log=z.read(prefix+label+'.log')
                counts=re.findall(rb'test result: ok\. (\d+) passed; 0 failed',log)
                assert len(counts)==1 and int(counts[0])>0
                tests+=int(counts[0])
                if mode=='bundled-roots': assert b'v021::bundled_roots_policy_is_explicit ... ok' in log
            for suffix in ['resolver-absent','testing-absent']:
                step=next(s for s in steps if s['label']==case['label']+'-'+suffix)
                assert step['exit_code']==101 and b'unresolved import' in z.read(prefix+step['label']+'.log')
                negative+=1
        assert len(steps)==expected_steps
        example_lock=z.read(prefix+'package-examples-Cargo.lock')
        assert hashlib.sha256(example_lock).hexdigest()==inputs['example_lock_sha256']
        assert inputs['example_dependency_route']=='unchanged packaged Cargo.lock with --locked; not a fresh consumer graph'
        locks[inputs['example_lock_sha256']]=example_lock
        examples=json.loads(z.read(prefix+'examples/results.json'))
        assert len(examples)==18 and all(e['passed'] for e in examples)
        assert all(e['exit_code']==(1 if e['label']=='response-limit-failure' else 0) for e in examples)
        example_count+=len(examples)
        records.append(dict(name=artifact['name'],sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            platform=inputs['platform'],machine=inputs['machine'],toolchains=inputs['toolchains'],
            archive_sha256=inputs['archive_sha256'],cases=result['cases']))
out=lab/(a.mode+'-lock-audits')
out.mkdir(exist_ok=False)
audits=[]
for digest,data in locks.items():
    lock=out/(digest+'.lock'); lock.write_bytes(data)
    command([str(root/'target/tools/cargo-audit/bin/cargo-audit.exe'),'audit',
        '--db',str(lab/'advisory-db'),'--no-fetch','--file',str(lock),'--json'],
        root,out,digest,dict(os.environ),180)
    report=json.loads((out/(digest+'.log')).read_text())
    assert not report['vulnerabilities']['found'] and not report['warnings']
    audits.append(digest)
record=dict(status='passed',source=a.source,mode=a.mode,jobs=8,consumer_graphs=16,
    tests=tests,negative_probes=negative,examples=example_count,audited_locks=audits,
    artifacts=records,run_url=run['html_url'])
(lab/(a.mode+'-matrix-verified.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='artifacts'},indent=2))
