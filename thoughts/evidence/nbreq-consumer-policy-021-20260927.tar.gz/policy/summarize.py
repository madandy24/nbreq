from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('C:/User/projects/nbreq')
lab=Path(__file__).parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def policy_summary(folder):
    data=json.loads((folder/'consumer-policy.json').read_text())
    assert data['status']=='selected'
    assert digest(folder/'Cargo.initial.lock')==data['initial']['sha256']
    assert digest(folder/'Cargo.lock')==data['selected']['sha256']
    if data['route']=='fresh':
        assert data['command'] is None and data['initial']['sha256']==data['selected']['sha256']
    else:
        assert next(p for p in data['selected']['packages'] if p['name']=='yoke-derive')['version']=='0.8.2'
    return {key:data[key] for key in ['route','rustc','command','removed','added']}|dict(initial_sha256=data['initial']['sha256'],selected_sha256=data['selected']['sha256'])
assert json.loads((lab/'pre-r5/result.json').read_text())['status']=='passed'
assert json.loads((lab/'package-run/inputs.json').read_text())['status']=='passed'
cases={}
for tc in ['1.85.0','stable','1.87.0']:
    for case in ['fresh','mio-coexist']:
        label=tc+'-'+case
        row=policy_summary(lab/'pre-r5'/label)
        counts={}
        for mode in ['default','native','minimal','test-support','bundled-roots']:
            log=(lab/'pre-r5'/(label+'-'+mode+'.log')).read_text()
            count=re.search(r'test result: ok\. (\d+) passed; 0 failed;',log)
            assert count
            counts[mode]=int(count[1])
        row['tests']=counts
        cases[label]=row
archive_cases={}
for tc in ['1.85.0','stable']:
    for kind in ['consumer','consumer-011']:
        archive_cases[tc+'-'+kind]=policy_summary(lab/'package-run'/(tc+'-'+kind))
archive_inputs=json.loads((lab/'package-run/inputs.json').read_text())
assert digest(lab/'package-run/package-examples-Cargo.lock')==archive_inputs['example_lock_sha256']
assert json.loads((lab/'package-run/examples/summary.json').read_text())['executions']==18
owned=['tools/release-consumer/consumer_policy.py','tools/release-consumer/test_consumer_policy.py','tools/release-consumer/pre_r5.py','tools/release-consumer/registry.py','tools/release-consumer/run.py','tools/release-consumer/README.md','.github/workflows/ci.yml','.github/workflows/registry-release.yml']
for p in owned:
    target=lab/'source'/p
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/p,target)
shutil.copy2(root/'target/version-021-20260927/package/packages.json',lab/'historical-package-inventory.json')
summary=dict(status='passed',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_hashes={p:digest(root/p) for p in owned},pre_r5=cases,pre_r5_tests=252,archive_runner=archive_cases,archive_runner_tests=90,archive_example_executions=18,archive_example_toolchain='1.85.0',archive_example_lock_route=archive_inputs['example_dependency_route'],archive_provenance='Existing frozen 9e81021 version-rehearsal packages; tooling validation only, not final release candidate',policy_regressions=json.loads((lab/'policy-regressions.json').read_text()),limits=['Windows x64 only','No core manifest or library dependency changes','Registry runner updated/reviewed; final registry candidate execution owned by root','No commits or publication'])
(lab/'summary.json').write_text(json.dumps(summary,indent=2))
files={}
for base,dirs,names in os.walk(lab):
    dirs[:]=[d for d in dirs if d not in ['build','__pycache__']]
    for name in names:
        p=Path(base)/name
        if name!='evidence-hashes.json':files[p.relative_to(lab).as_posix()]=digest(p)
(lab/'evidence-hashes.json').write_text(json.dumps(files,indent=2))
print('Summary saved; evidence files:',len(files))
