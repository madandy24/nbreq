from pathlib import Path
import argparse
import hashlib
import importlib.util
import json

parser = argparse.ArgumentParser()
parser.add_argument('--before-plain', required=True, type=Path)
parser.add_argument('--before-meter', required=True, type=Path)
parser.add_argument('--after-plain', required=True, type=Path)
parser.add_argument('--after-meter', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--source', required=True)
args = parser.parse_args()
spec = importlib.util.spec_from_file_location('m1_runner', 'tools/f5-observe/memory/run.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
args.output.mkdir(parents=True, exist_ok=False)
binaries = {version: {mode: getattr(args, version + '_' + mode).resolve() for mode in ('plain', 'meter')} for version in ('before', 'after')}
sources = dict(before='36886e7d54643a8aa60cae9c6f9f099c90a44d65d3dee246ae3b56334e1aa4ed', after=args.source)
provenance = dict(host=runner.host_info(), sources=sources, binaries={version: {mode: dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for mode, path in values.items()} for version, values in binaries.items()})
(args.output / 'provenance.json').write_text(json.dumps(provenance, indent=2))
workloads = [(protocol, size, False) for protocol in ('http', 'https') for size in (1024, 51200)] + [('https', 51200, True)]
results = []
for repetition in range(3):
    for protocol, size, extended in workloads:
        modes = ['plain', 'meter'] if repetition % 2 == 0 else ['meter', 'plain']
        for mode in modes:
            versions = ['before', 'after'] if repetition % 2 == 0 else ['after', 'before']
            for version in versions:
                name = f'{version}-{protocol}-c32-b{size}-{"extended" if extended else "normal"}-{mode}-r{repetition + 1}'
                case = runner.run_case(binaries[version]['plain'], binaries[version][mode], args.output / name, sources[version], protocol, 32, size, 16, extended)
                assert case['client']['instrumented'] == (mode == 'meter')
                case.update(case=name, repetition=repetition + 1, version=version)
                results.append(case)
                print('PASS', name, flush=True)
(args.output / 'results.json').write_text(json.dumps(results, indent=2))
print('M2_COMPARE_PASS', len(results), flush=True)
