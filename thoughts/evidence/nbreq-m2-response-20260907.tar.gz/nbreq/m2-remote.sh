#!/bin/sh
set -eu
lab=$1
previous=$2
scope=$3
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$previous/target"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
trap 'code=$?; printf "%s\n" "$code" > "$lab/run.exit"' EXIT
cd "$lab/nbreq"
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m2-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    rustc --version
    cargo run --locked --offline --manifest-path tools/xtask/Cargo.toml -- verify --offline > "$lab/verify-$toolchain.log" 2>&1
    tail -n 2 "$lab/verify-$toolchain.log"
done
if test "$scope" = measure; then
    export RUSTUP_TOOLCHAIN=stable
    mkdir "$lab/bin"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/plain"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/meter"
    source_hash=$(python3 -c 'import hashlib,pathlib; print(hashlib.sha256(pathlib.Path("m2-source.sha256").read_bytes()).hexdigest())')
    before="${previous%-b}-c"
    python3 m2-compare.py --before-plain "$before/bin/plain" --before-meter "$before/bin/meter" --after-plain "$lab/bin/plain" --after-meter "$lab/bin/meter" --output "$lab/comparison" --source "$source_hash"
fi
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m2-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
printf 'M2_HOST_PASS\n'
