import hashlib,sys,tarfile
from pathlib import Path,PurePosixPath
a,r=map(Path,sys.argv[1:3])
assert hashlib.sha256(a.read_bytes()).hexdigest()==sys.argv[3]
with tarfile.open(a) as f:
 m=f.getmembers()
 assert len(m)==12 and len({x.name for x in m})==12
 for x in m:
  p=PurePosixPath(x.name)
  assert x.isfile() and not p.is_absolute() and '..' not in p.parts and '\\' not in x.name
 r.mkdir(exist_ok=False)
 for x in m:
  p=r/x.name
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as w:w.write(f.extractfile(x).read())
print('Verified archive; extracted '+str(r))
