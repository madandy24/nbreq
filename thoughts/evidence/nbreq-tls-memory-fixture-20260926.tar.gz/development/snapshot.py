"""Archive only the committed loopback fixture, observer, tests and small helpers."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
a = p.parse_args()
root = a.root.resolve()
lab = Path(__file__).resolve().parent
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
exact = {'tools/tcp-tls-probe/memory.py', 'tools/tcp-tls-probe/test_memory.py',
         'tools/tcp-tls-probe/README.md', 'tools/release-soak/process_sample.py'}
inputs = {}
for name in sorted(tracked):
    if not name or not (name in exact or name.startswith('tools/tcp-tls-fixture/')):
        continue
    path = root / name
    assert not path.is_symlink() and root in path.resolve().parents and path.is_file()
    assert not any(part in ('target', '__pycache__', '.git') for part in Path(name).parts)
    inputs[name] = path.read_bytes()
for source, name in [('fixture-platform.py', 'fixture-platform.py'), ('collect.py', 'fixture-collect.py'),
                     ('test_platform.py', 'test_platform.py')]:
    inputs[name] = (lab / source).read_bytes()
manifest = dict(commit=commit, purpose='Rust loopback TLS fixture memory follow-up; sampled NBReq clients reused separately',
                files={name: hashlib.sha256(data).hexdigest() for name, data in inputs.items()})
payload = json.dumps(manifest, indent=2).encode('utf-8')
archive = lab / ('nbreq-tls-fixture-' + commit[:12] + '-source.tar.gz')
with tarfile.open(archive, 'x:gz', compresslevel=9) as bundle:
    for name, data in list(inputs.items()) + [('fixture-source.json', payload)]:
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode = len(data), 0o644
        bundle.addfile(entry, io.BytesIO(data))
summary = dict(commit=commit, source=hashlib.sha256(payload).hexdigest(),
               archive=str(archive), files=len(inputs), source_bytes=sum(map(len, inputs.values())),
               archive_bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(lab / (commit[:12] + '-source.json')).write_bytes(payload)
(lab / (commit[:12] + '-snapshot.json')).write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
