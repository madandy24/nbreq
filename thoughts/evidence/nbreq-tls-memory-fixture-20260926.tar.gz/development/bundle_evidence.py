"""Bundle only bounded fixture source, test logs and client observation evidence."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--commit', required=True)
p.add_argument('--gate', action='append', required=True)
p.add_argument('--failed-gate', action='append', default=[])
a = p.parse_args()
root, lab = a.root.resolve(), Path(__file__).resolve().parent
inputs = {}


def include(path, name):
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 32 * 1024 * 1024
    assert name not in inputs
    data = path.read_bytes()
    assert (b'-----BEGIN ' + b'PRIVATE KEY-----') not in data, name
    assert (b'-----BEGIN RSA ' + b'PRIVATE KEY-----') not in data, name
    inputs[name] = data


def tree(folder, prefix):
    assert folder.is_dir(), folder
    def walking_error(error):
        raise error

    for current, dirs, files in os.walk(folder, onerror=walking_error):
        assert not any((Path(current) / name).is_symlink() for name in dirs), current
        dirs[:] = sorted(d for d in dirs if not d.startswith('build') and d not in ('certs', '__pycache__', '.git'))
        for name in sorted(files):
            file = Path(current) / name
            if file.suffix in ('.json', '.jsonl', '.log', '.txt', '.md'):
                assert folder.resolve() in file.resolve().parents
                include(file, prefix + '/' + file.relative_to(folder).as_posix())


def snapshot(commit):
    assert len(commit) == 40 and all(c in '0123456789abcdef' for c in commit), commit
    short = commit[:12]
    source_path = lab / (short + '-source.json')
    snapshot_path = lab / (short + '-snapshot.json')
    source_bytes = source_path.read_bytes()
    source = json.loads(source_bytes)
    record = json.loads(snapshot_path.read_text(encoding='utf-8'))
    assert source['commit'] == record['commit'] == commit, commit
    assert hashlib.sha256(source_bytes).hexdigest() == record['source'], commit
    archive_path = lab / ('nbreq-tls-fixture-' + short + '-source.tar.gz')
    archive_bytes = archive_path.read_bytes()
    assert len(archive_bytes) == record['archive_bytes'], archive_path
    assert hashlib.sha256(archive_bytes).hexdigest() == record['sha256'], archive_path
    return record, archive_path


def verify_retrieved(folder, result):
    manifest_path = folder / 'evidence-manifest.json'
    if not manifest_path.exists():
        return False
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    assert manifest['result'] == result, manifest_path
    assert isinstance(manifest['files'], dict), manifest_path
    actual = {}
    for path in folder.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file() and folder.resolve() in path.resolve().parents, path
        if path == manifest_path:
            continue
        assert path.suffix in ('.json', '.jsonl', '.log', '.txt'), path
        relative = path.relative_to(folder).as_posix()
        assert path.stat().st_size <= 32 * 1024 * 1024, path
        actual[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == manifest['files'], manifest_path
    return True


def gate(name, status, expected=None):
    assert '/' not in name and '\\' not in name and not name.startswith('.'), name
    folder = lab / name
    assert folder.is_dir() and not folder.is_symlink(), folder
    result = json.loads((folder / 'result.json').read_text(encoding='utf-8'))
    host = json.loads((folder / 'host.json').read_text(encoding='utf-8'))
    assert result['status'] == status, result
    own_snapshot, own_archive = snapshot(host['commit'])
    assert result['source'] == host['source'] == own_snapshot['source'], name
    if expected is not None:
        assert own_snapshot['commit'] == expected['commit'], name
        assert own_snapshot['source'] == expected['source'], name
    if not verify_retrieved(folder, result):
        # Only the locally produced Windows gate lacks a retrieval manifest.
        assert name.startswith('windows-') and host['platform'].startswith('Windows'), name
    tree(folder, name)
    return dict(name=name, status=status, commit=own_snapshot['commit'],
                source=own_snapshot['source']), own_archive


selected, selected_archive = snapshot(a.commit)
final_gates, historical_failed_gates = [], []
source_archives = {selected_archive}
for name in a.gate:
    record, source_archive = gate(name, 'passed', selected)
    final_gates.append(record)
    source_archives.add(source_archive)
for name in a.failed_gate:
    record, source_archive = gate(name, 'failed')
    historical_failed_gates.append(record)
    source_archives.add(source_archive)
for file in sorted(lab.iterdir()):
    if file.is_file() and file.suffix in ('.log', '.json', '.txt', '.py'):
        include(file, 'development/' + file.name)
for name in ('supervisor-denied-red', 'reviewer-helper-failure', 'worker-checks'):
    if (lab / name).is_dir():
        tree(lab / name, name)
for source_archive in sorted(source_archives):
    include(source_archive, 'source/' + source_archive.name)
archive = root / 'thoughts' / 'evidence' / 'nbreq-tls-memory-fixture-20260926.tar.gz'
index = archive.with_name('nbreq_tls_memory_fixture_artifacts.json')
assert not archive.exists() and not index.exists()
manifest = dict(fixture_commit=a.commit, fixture_source=selected['source'],
                final_gates=final_gates, historical_failed_gates=historical_failed_gates,
                files={name: dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
                       for name, data in sorted(inputs.items())})
payload = json.dumps(manifest, indent=2).encode('utf-8')
with tarfile.open(archive, 'x:gz', compresslevel=9) as output:
    for name, data in sorted(list(inputs.items()) + [('manifest.json', payload)]):
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode = len(data), 0o644
        output.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as output:
    assert len(output.getmembers()) == len(inputs) + 1
    for name, expected in manifest['files'].items():
        assert hashlib.sha256(output.extractfile(name).read()).hexdigest() == expected['sha256']
summary = dict(fixture_commit=a.commit, archive=archive.name, bytes=archive.stat().st_size,
               sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), files=len(inputs),
               uncompressed_bytes=sum(map(len, inputs.values())),
               excludes=['executables', 'build trees', 'private keys', 'credentials', 'GDS source'], manifest=manifest)
index.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in summary.items() if key != 'manifest'}, indent=2))
