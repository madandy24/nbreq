"""Synthetic, no-network integrity checks for the final evidence bundle."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


HELPER = Path(__file__).with_name('bundle_evidence.py')
FINAL = 'a' * 40
OLD = 'b' * 40


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


class BundleProof(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.lab = self.base / 'lab'
        self.lab.mkdir()
        shutil.copyfile(HELPER, self.lab / 'bundle_evidence.py')
        self.root = self.base / 'root'
        (self.root / 'thoughts' / 'evidence').mkdir(parents=True)
        self.final_source = self.snapshot(FINAL)
        self.gate = self.evidence('windows-final', 'passed', FINAL, self.final_source, retrieved=False)

    def snapshot(self, commit):
        source_path = self.lab / (commit[:12] + '-source.json')
        write_json(source_path, {'commit': commit, 'files': {}})
        source_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
        archive = self.lab / ('nbreq-tls-fixture-' + commit[:12] + '-source.tar.gz')
        archive.write_bytes(b'bounded synthetic archived source ' + commit.encode())
        write_json(self.lab / (commit[:12] + '-snapshot.json'), {
            'commit': commit, 'source': source_hash, 'archive': str(archive),
            'archive_bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        })
        return source_hash

    def evidence(self, name, status, commit, source, retrieved):
        folder = self.lab / name
        folder.mkdir()
        result = {'status': status, 'source': source}
        host = {'commit': commit, 'source': source,
                'platform': 'Windows-synthetic' if name.startswith('windows-') else 'Linux-synthetic'}
        write_json(folder / 'result.json', result)
        write_json(folder / 'host.json', host)
        (folder / 'job.log').write_text('synthetic evidence\n', encoding='utf-8')
        if retrieved:
            files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in folder.iterdir() if p.is_file()}
            write_json(folder / 'evidence-manifest.json', {'result': result, 'files': files})
        return folder

    def bundle(self, *extra):
        return subprocess.run([sys.executable, '-B', str(self.lab / 'bundle_evidence.py'),
                               '--root', str(self.root), '--commit', FINAL,
                               '--gate', 'windows-final', *extra], capture_output=True, text=True)

    def test_correct_final_gate_bundles(self):
        outcome = self.bundle()
        self.assertEqual(outcome.returncode, 0, outcome.stderr)

    def test_wrong_passing_source_is_rejected(self):
        write_json(self.gate / 'result.json', {'status': 'passed', 'source': '0' * 64})
        self.assertNotEqual(self.bundle().returncode, 0)

    def test_corrupted_retrieved_file_is_rejected(self):
        remote = self.evidence('remote', 'passed', FINAL, self.final_source, retrieved=True)
        (remote / 'job.log').write_text('tampered evidence\n', encoding='utf-8')
        self.assertNotEqual(self.bundle('--gate', 'remote').returncode, 0)

    def test_stale_embedded_manifest_result_is_rejected(self):
        remote = self.evidence('remote', 'passed', FINAL, self.final_source, retrieved=True)
        manifest = json.loads((remote / 'evidence-manifest.json').read_text())
        manifest['result'] = {'status': 'failed', 'source': self.final_source}
        write_json(remote / 'evidence-manifest.json', manifest)
        self.assertNotEqual(self.bundle('--gate', 'remote').returncode, 0)

    def test_historical_failed_gate_uses_its_own_snapshot(self):
        old_source = self.snapshot(OLD)
        self.evidence('historical', 'failed', OLD, old_source, retrieved=True)
        outcome = self.bundle('--failed-gate', 'historical')
        self.assertEqual(outcome.returncode, 0, outcome.stderr)


if __name__ == '__main__':
    unittest.main()
