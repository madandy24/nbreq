"""No-network regressions for evidence preservation and owned-child cleanup."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location('fixture_platform', Path(__file__).with_name('fixture-platform.py'))
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


class PlatformTests(unittest.TestCase):
    def test_duplicate_run_cannot_replace_terminal_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            out = Path(folder)
            (out / 'run.token').write_text('original attempt')
            (out / 'result.json').write_text('{"status":"passed"}')
            (out / 'host.json').write_text('original host')
            before = {p.name: p.read_bytes() for p in out.iterdir()}
            argv = ['platform.py', 'run', '--root', str(out), '--out', str(out),
                    '--probe', str(out / 'not-run'), '--probe-sha256', '0' * 64]
            with mock.patch.object(sys, 'argv', argv), self.assertRaises(FileExistsError):
                gate.main()
            self.assertEqual(before, {p.name: p.read_bytes() for p in out.iterdir()})

    def _child_failure(self, mode):
        with tempfile.TemporaryDirectory() as folder:
            out = Path(folder)
            children = []
            real_popen, real_write = subprocess.Popen, gate.write

            def launch(*args, **kwargs):
                child = real_popen(*args, **kwargs)
                children.append(child)
                return child

            def write(path, value):
                if mode == 'metadata' and path.name == 'command.json':
                    raise OSError('injected command metadata write failure')
                real_write(path, value)

            expected = OSError if mode == 'metadata' else subprocess.TimeoutExpired
            with mock.patch.object(gate.subprocess, 'Popen', side_effect=launch), \
                    mock.patch.object(gate, 'write', side_effect=write), self.assertRaises(expected):
                gate.command([sys.executable, '-B', '-c', 'import time; time.sleep(60)'],
                             out, out, mode, dict(gate.os.environ), 0.2 if mode == 'timeout' else 60)
            self.assertTrue(children)
            self.assertIsNotNone(children[0].poll(), 'owned child was not reaped')
            result = json.loads((out / (mode + '.result.json')).read_text())
            self.assertIn('failure', result)
            self.assertNotEqual(result.get('exit_code'), 0)

    def test_metadata_failure_reaps_already_started_child(self):
        self._child_failure('metadata')

    def test_command_timeout_reaps_owned_child(self):
        self._child_failure('timeout')

    @unittest.skipUnless(os.name == 'nt', 'Windows process-tree fallback regression')
    def test_denied_taskkill_still_reaps_the_owned_process_handle(self):
        with mock.patch.object(gate.subprocess, 'run', return_value=subprocess.CompletedProcess([], 5)):
            self._child_failure('timeout')

    @unittest.skipUnless(os.name == 'nt', 'Windows cleanup diagnostics regression')
    def test_broken_cleanup_log_cannot_prevent_owned_handle_kill(self):
        child = subprocess.Popen([sys.executable, '-B', '-c', 'import time; time.sleep(60)'])
        try:
            broken_log = mock.Mock()
            broken_log.write.side_effect = OSError('injected full log')
            with mock.patch.object(gate.subprocess, 'run', return_value=subprocess.CompletedProcess([], 5)):
                gate.stop(child, broken_log)
            self.assertIsNotNone(child.poll())
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=5)

    @unittest.skipIf(os.name == 'nt', 'POSIX owned-process-group regression')
    def test_term_exiting_leader_does_not_leave_term_ignoring_descendant(self):
        with tempfile.TemporaryDirectory() as folder:
            out = Path(folder)
            pid_file = out / 'grandchild.pid'
            grandchild = ('import os,signal,time; from pathlib import Path; '
                          'signal.signal(signal.SIGTERM, signal.SIG_IGN); '
                          'Path({!r}).write_text(str(os.getpid())); time.sleep(60)').format(str(pid_file))
            parent = ('import subprocess,sys,time; '
                      'subprocess.Popen([sys.executable, "-B", "-c", {!r}]); '
                      'time.sleep(60)').format(grandchild)
            descendant = None
            try:
                with self.assertRaises(subprocess.TimeoutExpired):
                    gate.command([sys.executable, '-B', '-c', parent], out, out,
                                 'group-timeout', dict(os.environ), 2)
                self.assertTrue(pid_file.is_file(), 'descendant did not start')
                descendant = int(pid_file.read_text())
                deadline = time.monotonic() + 3
                while True:
                    check = subprocess.run(['ps', '-o', 'stat=', '-p', str(descendant)],
                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                           text=True, timeout=2, check=False)
                    state = check.stdout.strip()
                    if not state or state.startswith('Z'):
                        break  # Dead; orphan reaping is the host init process's responsibility.
                    self.assertLess(time.monotonic(), deadline, 'owned group descendant survived cleanup')
                    time.sleep(0.05)
            finally:
                if descendant is None and pid_file.is_file():
                    descendant = int(pid_file.read_text())
                if descendant is not None:
                    try:
                        os.kill(descendant, signal.SIGKILL)
                    except ProcessLookupError:
                        pass


if __name__ == '__main__':
    unittest.main(verbosity=2)
