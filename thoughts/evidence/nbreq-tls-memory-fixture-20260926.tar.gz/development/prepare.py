import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile

archive, root = map(Path, sys.argv[1:3])
assert hashlib.sha256(archive.read_bytes()).hexdigest() == sys.argv[3]
with tarfile.open(archive, 'r:gz') as bundle:
    members = bundle.getmembers()
    assert len(members) == 12
    assert len({m.name for m in members}) == 12
    for item in members:
        name = PurePosixPath(item.name)
        assert item.isfile() and not name.is_absolute() and '..' not in name.parts and '\\' not in item.name
    root.mkdir(parents=True, exist_ok=False)
    for item in members:
        target = root / item.name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as file:
            file.write(bundle.extractfile(item).read())
manifest = root / 'fixture-source.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == sys.argv[4]
for name, expected in json.loads(manifest.read_text())['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
print('Verified 11 source files at ' + str(root))
