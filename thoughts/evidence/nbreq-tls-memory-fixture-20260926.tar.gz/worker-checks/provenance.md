Windows worker smoke provenance

These are development checks of the Rust memory fixture and Python observer on Windows. The root's frozen Windows run and ARM/Linux observations are authoritative for final comparison.

Worktree: C:\User\projects\nbreq\target\worktrees\nbreq-smtp, branch codex/nbreq-smtp, base HEAD 3f841be6680c586058b5a36e2a54cc2dfd22fe40; working source was uncommitted.
Host compiler: rustc 1.97.1 (8bab26f4f 2026-07-14), cargo 1.97.1 (c980f4866 2026-06-30), x86_64-pc-windows-msvc.
Client: locally built Windows debug probe from this worktree, SHA256 80DD90501E45687B41AE5169AACD15AD9A87C718AA6CED9B9171EC339BBA5132. This is not the frozen ARM/Linux probe.
Rust fixture: locally built Windows debug binary, SHA256 B3AC1304231F5B3B9B9D11143F6D13C891EE771DB8759606921BF267DB92CB78.
Source SHA256 at copy time: src/main.rs 40B35385C3896477F986A819C101F7BA71C1EC28299BEE9406AAF747400A42EA; fixture Cargo.toml 6F033970012732816672DD54B46A32F62DDCDB652F5EFBD438BF2F4CFB7E7046; fixture Cargo.lock 25597EECF98D0B2E51E6B1F171F7C34242249EDAA24A8B32DDC63A320D1902E3; observer memory.py 5BAA4ABC5ADC5B4356E35EEBE294A7DA378B2B2705B712DD3CC30770AC98C29F.
The fixture binary was built before a whitespace-only cargo fmt pass; the current Rust source hash therefore differs from the binary's direct source snapshot, while behavior is unchanged. The subsequent checks.log includes passing format, process tests, and strict clippy against the formatted source.
windows-smoke-tls12: observer using --tls-version 1.2; both 16 and 32 connection runs passed, with client exit code zero.
windows-smoke-tls13: observer using --tls-version 1.3; both 16 and 32 connection runs passed, with client exit code zero.
Retained files are raw probe and fixture logs, ready and terminal JSON, public DER root, per-process samples, phase records and summary reports. No private keys or executables are included.
