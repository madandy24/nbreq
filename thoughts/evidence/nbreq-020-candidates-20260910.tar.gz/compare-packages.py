from pathlib import Path
import tarfile,json,hashlib,subprocess

root=Path(__file__).resolve().parents[2]
lab=root/'target/release-020-candidates'

def contents(path):
    with tarfile.open(path) as archive:
        return {member.name.split('/',1)[1]:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                for member in archive.getmembers() if member.isfile()}

before=contents(root/'target/release-020/package-build-b/package/nbreq-0.2.0.crate')
after=contents(lab/'root-package/package/nbreq-0.2.0.crate')
changes={name:dict(before=before.get(name),after=after.get(name))
         for name in sorted(before.keys()|after.keys()) if before.get(name)!=after.get(name)}
expected={'.cargo_vcs_info.json','README.md','SECURITY.md','docs/getting-started.md',
          'docs/migrating-to-0.2.md','src/backend/native_dns/tests.rs'}
assert set(changes)==expected, list(changes)
source=root/'target/worktrees/nbreq-0.2.0-release'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip()
assert (root/'Cargo.lock').read_bytes()==(source/'Cargo.lock').read_bytes()
(lab/'root-package-delta.json').write_text(json.dumps(changes,indent=2)+'\n')
print('Only archive VCS identity, four public docs and Windows DNS fixtures differ from R1 package B.')
print('Root Cargo.lock unchanged; isolated candidate clean.')
