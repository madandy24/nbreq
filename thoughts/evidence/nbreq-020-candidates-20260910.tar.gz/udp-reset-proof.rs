use std::io::ErrorKind;
use std::net::UdpSocket;
use std::time::Duration;

fn main() {
    let fixture = UdpSocket::bind("127.0.0.1:0").unwrap();
    fixture.set_read_timeout(Some(Duration::from_secs(2))).unwrap();
    let old_client = UdpSocket::bind("127.0.0.1:0").unwrap();
    let closed_port = old_client.local_addr().unwrap();
    drop(old_client);
    fixture.send_to(b"late reply", closed_port).unwrap();
    let mut buffer = [0; 64];
    let error = fixture.recv_from(&mut buffer).unwrap_err();
    assert_eq!(error.kind(), ErrorKind::ConnectionReset);
    assert_eq!(error.raw_os_error(), Some(10054));
    println!("Closed client produces Windows UDP error 10054 as expected.");
    let next_client = UdpSocket::bind("127.0.0.1:0").unwrap();
    next_client.send_to(b"next query", fixture.local_addr().unwrap()).unwrap();
    let (length, peer) = fixture.recv_from(&mut buffer).unwrap();
    assert_eq!(&buffer[..length], b"next query");
    assert_eq!(peer, next_client.local_addr().unwrap());
    println!("The same fixture socket still receives the next client's query.");
}
