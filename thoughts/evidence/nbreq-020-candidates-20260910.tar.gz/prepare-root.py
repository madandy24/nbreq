from pathlib import Path
import hashlib,json,shutil,subprocess

root=Path(__file__).resolve().parents[2]
lab=root/'target/release-020-candidates'
candidate=root/'target/worktrees/nbreq-0.2.0-release'
manifest=json.loads((root/'target/release-020/source-manifest.json').read_text())
copied={}
for name,expected in manifest.items():
    if name.startswith('source/'):
        relative=name[len('source/'):]
    elif name.startswith('consumer/'):
        relative='tools/release-consumer/'+name[len('consumer/'):]
    else: continue
    source=root/relative
    assert hashlib.sha256(source.read_bytes()).hexdigest()==expected,relative
    destination=candidate/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,destination)
    copied[relative]=expected

# Carry only the release/memory records that accompany this session's accepted work.
records=['thoughts/gds_memory_handoff.md','thoughts/nbreq_memory_plan.md',
    'thoughts/nbreq_020_release_plan.md','thoughts/nbreq_020_consumer_readiness.md',
    'thoughts/nbreq_m25_gds_conversion.md','thoughts/nbreq_m3_memory_controls.md',
    'thoughts/nbreq_m4_gds_admission.md']
for pattern in ('nbreq-020-*','nbreq-m25-*','nbreq-m3-*','nbreq_020_*','nbreq_m25_*','nbreq_m3_*','nbreq_m4_*'):
    records.extend(p.relative_to(root).as_posix() for p in (root/'thoughts/evidence').glob(pattern) if p.is_file())
for relative in sorted(set(records)):
    source=root/relative
    destination=candidate/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,destination)
    copied[relative]=hashlib.sha256(source.read_bytes()).hexdigest()
(lab/'copied-source-manifest.json').write_text(json.dumps(copied,indent=2)+'\n')
print('Copied and verified',len(copied),'scoped files. F5 and the main index/checkout were not changed.')
