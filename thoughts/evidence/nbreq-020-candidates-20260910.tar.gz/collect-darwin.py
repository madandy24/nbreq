from pathlib import Path
import base64, hashlib, json, tarfile

lab = Path(__file__).resolve().parent
bridges = Path('C:/User/SecuritasNew/gds/scripts/sessions')
for host, bridge, request in [
    ('intel', 'putty_bridge_intel_mac', '20260910-042438-ef54f93f'),
    ('arm', 'putty_bridge_scaleway_nbreq', '20260910-042439-ef7d9993'),
]:
    raw = (bridges/bridge/'results'/(request+'.json')).read_bytes()
    result = json.loads(raw)
    assert result['status'] == 'completed' and result['ok'] and result['exit_code'] == 0
    lines = result['output'].splitlines()
    expected = lines[0].split()[0]
    archive = base64.b64decode(''.join(lines[1:]), validate=True)
    assert hashlib.sha256(archive).hexdigest() == expected
    destination = lab/('darwin-'+host+'-evidence.tar.gz')
    destination.write_bytes(archive)
    (lab/('darwin-'+host+'-collection.json')).write_bytes(raw)
    with tarfile.open(destination) as source:
        for member in source.getmembers():
            assert member.isfile() and '/' not in member.name and '\\' not in member.name
            target = lab/('darwin-'+host)/member.name
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(source.extractfile(member).read())
    for label in ('stable-test', '1.85.0-test'):
        assert 'test result: ok. 5 passed' in (lab/('darwin-'+host)/(label+'.log')).read_text()
    print(host, len(archive), expected, 'all logs verified')
