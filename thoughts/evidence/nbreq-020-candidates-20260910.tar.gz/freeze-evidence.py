from pathlib import Path
import hashlib,json,subprocess,tarfile,tomllib

root=Path(__file__).resolve().parents[2]
lab=root/'target/release-020-candidates'
hash_file=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
consumer=json.loads((lab/'consumer/results.json').read_text())
assert consumer and all(item['passed'] for item in consumer)
assert (lab/'consumer.exit').read_text().strip()=='0'
assert 'all 24 steps passed' in (lab/'root-verifier-fixed.log').read_text()
for name in ('nbreq-0.2.0-release','nbreq-darwin-0.1.0-release'):
    worktree=root/'target/worktrees'/name
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=worktree).strip()
check=dict(root_commit=json.loads((lab/'root-package-identity.json').read_text())['commit'],
    darwin_commit=json.loads((lab/'expected.json').read_text())['commit'],
    native_windows_verifier_steps=24,consumer_commands=len(consumer),consumer_test_executions=64,
    feature_probes=8,examples=7,toolchains=['stable','1.85.0'],
    consumer_lock_sha256=hash_file(lab/'consumer/consumer-Cargo.lock'),
    previous_consumer_lock_sha256=hash_file(root/'target/release-020/consumer-c/consumer-Cargo.lock'),
    registry_only=False,wine_finding='W-01: Rust panic, user to supply details; unresolved',
    new_runtime_changes=False,publication_authorized=False,published=False)
previous=tomllib.loads((root/'target/release-020/consumer-c/consumer-Cargo.lock').read_text())
current=tomllib.loads((lab/'consumer/consumer-Cargo.lock').read_text())
def versions(lock): return {p['name']:p['version'] for p in lock['package']}
before,after=versions(previous),versions(current)
check['consumer_dependency_resolution']='fresh cached index, not fresh online resolution'
check['consumer_lock_delta']={name:dict(previous_online=before.get(name),current_cached=after.get(name))
    for name in before.keys()|after.keys() if before.get(name)!=after.get(name)}
assert check['consumer_lock_delta']=={
    'bitflags':dict(previous_online='2.13.2',current_cached='2.13.0'),
    'combine':dict(previous_online='4.6.8',current_cached='4.6.7')}
assert (lab/'consumer-advisory.exit').read_text().strip()=='0'
advisories=json.loads((lab/'consumer-advisory.json').read_text(encoding='utf-8-sig'))
assert not advisories['vulnerabilities']['found'] and not advisories['warnings']
check['cached_consumer_advisory']='no vulnerabilities/warnings against the earlier frozen database; yanked check disabled'
(lab/'checkpoint-checks.json').write_text(json.dumps(check,indent=2)+'\n')

files={}
for path in lab.iterdir():
    if path.is_file() and path.suffix in ('.py','.json','.log','.exit','.rs','.txt','.gz'):
        files[path.name]=path
for name in ('darwin-intel','darwin-arm','consumer'):
    for path in (lab/name).rglob('*'):
        relative=path.relative_to(lab)
        if path.is_file() and not set(relative.parts).intersection(('build','target','__pycache__')):
            files[relative.as_posix()]=path
for name in ('root-package/package/nbreq-0.2.0.crate','darwin-package/package/nbreq-darwin-0.1.0.crate'):
    files['packages/'+Path(name).name]=lab/name
manifest={name:dict(bytes=path.stat().st_size,sha256=hash_file(path)) for name,path in sorted(files.items())}
destination=root/'thoughts/evidence/nbreq-020-candidates-20260910.tar.gz'
with tarfile.open(destination,'w:gz') as archive:
    for name,path in sorted(files.items()): archive.add(path,arcname=name,recursive=False)
with tarfile.open(destination) as archive:
    assert set(archive.getnames())==set(manifest)
    for entry in archive:
        assert hashlib.sha256(archive.extractfile(entry).read()).hexdigest()==manifest[entry.name]['sha256']
summary=dict(date='2026-09-10',archive=destination.name,bytes=destination.stat().st_size,
    sha256=hash_file(destination),checkpoint=check,files=manifest)
(root/'thoughts/evidence/nbreq_020_candidate_artifacts.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key!='files'},indent=2))
print('Archived and reverified',len(files),'files; both candidate worktrees remain clean.')
