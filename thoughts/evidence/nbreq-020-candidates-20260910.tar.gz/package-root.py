from pathlib import Path
import subprocess, json, hashlib, tarfile

root = Path(__file__).resolve().parents[2]
lab = root/'target/release-020-candidates'
source = root/'target/worktrees/nbreq-0.2.0-release'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source).strip()
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
darwin = source/'support/darwin'
command = ['cargo','package','--manifest-path',str(source/'Cargo.toml'),'-p','nbreq',
    '--locked','--offline','--target-dir',str(lab/'root-package'),
    '--config','patch.crates-io.nbreq-darwin.path='+json.dumps(darwin.as_posix())]
with (lab/'root-package-workspace-support.log').open('wb') as log:
    result = subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert result.returncode == 0, 'root package failed; inspect root-package.log'
package = lab/'root-package/package/nbreq-0.2.0.crate'
with tarfile.open(package) as archive:
    vcs = json.load(archive.extractfile('nbreq-0.2.0/.cargo_vcs_info.json'))
    assert vcs['git']['sha1'] == commit and not vcs['git'].get('dirty',False)
    names = archive.getnames()
    assert all('/thoughts/' not in name and '/tools/' not in name for name in names)
identity = dict(commit=commit,sha256=hashlib.sha256(package.read_bytes()).hexdigest(),
    bytes=package.stat().st_size,files=len(names),vcs=vcs,command=command,
    registry_only=False,support_override=str(darwin))
(lab/'root-package-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity,indent=2))
