"""Verify one supplied Darwin archive on a Mac; no registry publication."""
from pathlib import Path,PurePosixPath
import hashlib,json,subprocess,tarfile,time

root=Path(__file__).resolve().parent
package=root/'nbreq-darwin-0.1.0.crate'
expected=json.loads((root/'expected.json').read_text())
assert hashlib.sha256(package.read_bytes()).hexdigest()==expected['sha256']
with tarfile.open(package) as archive:
    for member in archive.getmembers():
        relative=PurePosixPath(member.name)
        assert member.isfile() and not relative.is_absolute() and '..' not in relative.parts
        destination=root.joinpath(*relative.parts)
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(archive.extractfile(member).read())
source=root/'nbreq-darwin-0.1.0'
vcs=json.loads((source/'.cargo_vcs_info.json').read_text())
assert vcs['git']['sha1']==expected['commit'] and not vcs['git'].get('dirty',False)
results=[]
for toolchain in ('stable','1.85.0'):
    for action in ('test','clippy') if toolchain=='stable' else ('test',):
        args=['rustup','run',toolchain,'cargo',action,'--locked','--offline','--all-targets']
        if action=='clippy': args+=['--','-D','warnings']
        label=toolchain+'-'+action
        print(label,flush=True)
        with (root/(label+'.log')).open('wb') as log:
            result=subprocess.run(args,cwd=source,stdout=log,stderr=subprocess.STDOUT,timeout=300)
        results.append(dict(label=label,command=args,exit_code=result.returncode))
        (root/'results.json').write_text(json.dumps(results,indent=2))
        assert result.returncode==0,label
        if action=='test': assert 'test result: ok. 5 passed' in (root/(label+'.log')).read_text()
print(json.dumps(dict(status='passed',expected=expected,results=results)),flush=True)
