import json
import sys
from pathlib import Path
from statistics import median

MIB = 1024 ** 2
ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('target/m1')
HOSTS = {
    'Windows x64': ROOT / 'windows-baseline-c',
    'Windows x86': ROOT / 'windows-x86-baseline-c',
    'Linux x64': ROOT / 'linux-evidence/baseline',
    'Intel Mac': ROOT / 'intel-evidence/baseline',
    'ARM Mac': ROOT / 'arm-evidence/baseline',
}
ARCHIVED = {
    'Windows x64': ROOT / 'windows/baseline-x64',
    'Windows x86': ROOT / 'windows/baseline-x86',
    'Linux x64': ROOT / 'linux/baseline',
    'Intel Mac': ROOT / 'intel/baseline',
    'ARM Mac': ROOT / 'arm/baseline',
}

def phase(case, name):
    return next(value for value in case['phases'] if value['phase'] == name)

def stats(values):
    values = [value for value in values if value is not None]
    return dict(min=min(values), median=median(values), max=max(values)) if values else None

def peak(case, field):
    values = [value['process']['sampled_peaks'].get(field) for value in case['phases']]
    return max(value for value in values if value is not None) if any(value is not None for value in values) else None

summary = {}
for host, folder in HOSTS.items():
    if not (folder / 'results.json').exists():
        folder = ARCHIVED[host]
    path = folder / 'results.json'
    if not path.exists():
        continue
    cases = json.loads(path.read_text())
    assert all(case['valid'] for case in cases)
    assert all(child['joined'] and child['exit_code'] == 0 and not child['forced']
               for case in cases for child in case['cleanup'])
    groups = sorted({(case['protocol'], case['client']['connections'], case['client']['body_bytes'],
                      case['client']['extended']) for case in cases})
    report = dict(cases=len(cases), provenance=json.loads((folder / 'provenance.json').read_text()), groups=[])
    for protocol, count, size, extended in groups:
        selected = [case for case in cases if (case['protocol'], case['client']['connections'],
                    case['client']['body_bytes'], case['client']['extended']) == (protocol, count, size, extended)]
        plain = [case for case in selected if not case['client']['instrumented']]
        meter = [case for case in selected if case['client']['instrumented']]
        assert len(plain) == len(meter) == 3
        row = dict(protocol=protocol, connections=count, body_bytes=size, extended=extended,
                   peak_rss=stats([peak(case, 'rss') for case in plain]),
                   peak_private=stats([peak(case, 'private') for case in plain]),
                   peak_heap=stats([max(value['allocation']['peak_live'] for value in case['phases']) for case in meter]),
                   steady_rps=stats([phase(case, 'steady')['requests_per_second'] for case in plain]),
                   steady_p95_ms=stats([phase(case, 'steady')['latency_p95_ms'] for case in plain]),
                   phases={})
        for name in [value['phase'] for value in selected[0]['phases']]:
            p = [phase(case, name) for case in plain]
            m = [phase(case, name) for case in meter]
            row['phases'][name] = {
                'rss_peak': stats([value['process']['sampled_peaks']['rss'] for value in p]),
                'rss_end': stats([value['process']['end']['rss'] for value in p]),
                'private_peak': stats([value['process']['sampled_peaks'].get('private') for value in p]),
                'private_end': stats([value['process']['end'].get('private') for value in p]),
                'heap_peak': stats([value['allocation']['peak_live'] for value in m]),
                'heap_end': stats([value['allocation']['live_after'] for value in m]),
                'allocation_calls': stats([value['allocation']['allocations'] + value['allocation']['reallocations'] for value in m]),
                'bytes_requested': stats([value['allocation']['bytes_requested'] for value in m]),
                'cpu_seconds': stats([value['process']['cpu_seconds'] for value in p]),
                'wall_ms': stats([value['wall_ms'] for value in p]),
                'samples': stats([value['process']['samples'] for value in p]),
            }
        row['fixture_rss_peak'] = stats([case['fixture_process']['sampled_peaks']['rss'] for case in plain])
        row['fixture_cpu_seconds'] = stats([case['fixture_process']['cpu_seconds'] for case in plain])
        report['groups'].append(row)
    summary[host] = report
    print(host, 'cases', len(cases))
    for row in report['groups']:
        if row['connections'] == 32 and row['body_bytes'] == 51200:
            print(row['protocol'], 'extended', row['extended'],
                  'rss max %.2f' % (row['peak_rss']['max']/MIB),
                  'private max', None if row['peak_private'] is None else round(row['peak_private']['max']/MIB,2),
                  'heap max %.2f' % (row['peak_heap']['max']/MIB),
                  'steady rps %.0f' % row['steady_rps']['median'],
                  'p95 %.2f ms' % row['steady_p95_ms']['median'])
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2))
