import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path('target/m1')
output = Path('thoughts/evidence')
output.mkdir(parents=True, exist_ok=True)
source = root / 'nbreq-m1-baseline-c.tar.gz'
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'd7707cc6bb170f3fafc64999c6642976fddb4b0c65e53b243bf12046a7d26a1f'
(output / 'nbreq-m1-source-c.tar.gz').write_bytes(source.read_bytes())
(output / 'nbreq_m1_summary.json').write_bytes((root / 'summary.json').read_bytes())
files = {}
for host, folder in [('linux', 'linux-evidence'), ('intel', 'intel-evidence'), ('arm', 'arm-evidence')]:
    base = root / folder
    for path in sorted(base.rglob('*')):
        if path.is_file():
            files[host + '/' + path.relative_to(base).as_posix()] = path.read_bytes()
for folder, name in [('windows-baseline-c', 'baseline-x64'), ('windows-x86-baseline-c', 'baseline-x86'),
                     ('runner-tests-c', 'runner-tests')]:
    base = root / folder
    for path in sorted(base.rglob('*')):
        if path.is_file():
            files['windows/' + name + '/' + path.relative_to(base).as_posix()] = path.read_bytes()
for name in ['windows-verify.log', 'windows-verify-b.log', 'windows-verify-c.log',
             'windows-x86-check.log', 'tls-roots-c.log', 'tls-roots-x86-c.log',
             'runner-tests-c.log', 'windows-clippy-c.log', 'windows-build-c.log',
             'windows-baseline-c.log', 'windows-x86-baseline-c.log', 'windows-hardware.json']:
    files['windows/' + name] = (root / name).read_bytes()
for name in ['meter-red.log', 'meter-green.log', 'tls-roots-red.log', 'tls-roots-green.log',
             'tls-carry-red.log', 'tls-carry-green.log']:
    files['red-green/' + name] = (root / name).read_bytes()
for name in ['analyse.py', 'write-report.py', 'check-frozen.py', 'make-bundle.py', 'run-c.sh',
             'roots-check.sh', 'collect.py', 'read-evidence.py', 'archive-evidence.py']:
    files['scripts/' + name] = (root / name).read_bytes()
for generation in ['baseline-b', 'baseline-c']:
    files['metadata/bundle-' + generation + '.json'] = (root / ('bundle-' + generation + '.json')).read_bytes()
    with tarfile.open(root / ('nbreq-m1-' + generation + '.tar.gz'), 'r:gz') as archive:
        files['metadata/source-' + generation + '.sha256'] = archive.extractfile('nbreq/m1-source.sha256').read()
files['summary.json'] = (root / 'summary.json').read_bytes()
files['REPRODUCE.md'] = b'''# Evidence layout\n\nEach host has baseline results/provenance, per-case events and cleanup receipts, and gate logs.\nThe Windows full verifier log ending in -c used production source B; final fixture C has separate targeted logs.\nThe gates-b folders preserve both remote full verifier runs and preliminary diagnostics.\nOnly the final baseline folders are performance evidence.\n\nFrom the extracted evidence directory, regenerate aggregates with:\n\n    python scripts/analyse.py .\n\nFrom the NBReq checkout, regenerate the report using the extracted summary:\n\n    python /absolute/evidence/scripts/write-report.py /absolute/evidence/summary.json\n\nThe source C archive and observer README contain workload reproduction commands.\nMANIFEST.sha256 verifies each archived file; the external artifact receipt verifies this archive.\n'''
files['metadata/scope.json'] = json.dumps(dict(
    source_manifest='36886e7d54643a8aa60cae9c6f9f099c90a44d65d3dee246ae3b56334e1aa4ed',
    final_cases=276, windows_x64=120, windows_x86=12, linux_x64=120, intel_mac=12, arm_mac=12,
    full_verifiers='Windows x64 + stable/MSRV on all three remote hosts, production source B',
    final_fixture_checks='C changes only two generated-certificate fixtures; final targeted checks on all hosts',
    baseline='C only; prior failed runs are included as diagnostics, never as performance evidence'), indent=2).encode()
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['MANIFEST.sha256'] = manifest
destination = output / 'nbreq-m1-evidence-20260905.tar.gz'
with tarfile.open(destination, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination, 'r:gz') as archive:
    for line in archive.extractfile('MANIFEST.sha256').read().decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest, name
receipts = {path.name: dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for path in [output/'nbreq-m1-source-c.tar.gz', destination, output/'nbreq_m1_summary.json']}
(output / 'nbreq_m1_artifacts.json').write_text(json.dumps(receipts, indent=2))
print(json.dumps(dict(files=len(files), artifacts=receipts)))
