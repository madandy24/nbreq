import hashlib
from pathlib import Path
import tarfile

with tarfile.open('target/m1/nbreq-m1-baseline-c.tar.gz', 'r:gz') as archive:
    manifest = archive.extractfile('nbreq/m1-source.sha256').read()
    assert hashlib.sha256(manifest).hexdigest() == '36886e7d54643a8aa60cae9c6f9f099c90a44d65d3dee246ae3b56334e1aa4ed'
    for row in manifest.decode().splitlines():
        digest, name = row.split('  ', 1)
        data = archive.extractfile('nbreq/' + name).read()
        assert hashlib.sha256(data).hexdigest() == digest
        current = (Path('target/m1/roots-check.sh').read_bytes().replace(b'\r\n', b'\n')
                   if name == 'm1-roots-check.sh' else Path(name).read_bytes())
        assert current == data, name
print('LOCAL_SOURCE_MANIFEST_PASS', len(manifest.decode().splitlines()))
