#!/bin/sh
set -eu
lab=$1
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export RUSTUP_TOOLCHAIN=stable
export CARGO_TARGET_DIR="$lab/target"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
trap 'code=$?; printf "%s\n" "$code" > "$lab/roots.exit"' EXIT
cd "$lab/nbreq"
rustc --version
cargo fetch --locked
cargo test --locked --offline --test tls_roots
cargo test --offline --manifest-path tools/f5-observe/memory/meter/Cargo.toml
printf 'ROOTS_AND_METER_PASS\n'
