import base64
import hashlib
from pathlib import Path
import sys
import tarfile

lab = Path(sys.argv[1]).resolve()
previous = Path(sys.argv[2]).resolve()
if (lab / 'run.exit').read_text().strip() != '0' or 'M1_HOST_PASS' not in (lab / 'run.log').read_text():
    raise RuntimeError('final job did not pass')
archive = lab / 'evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as out:
    for name in ('run.log', 'run.exit', 'run-c.sh'):
        out.add(lab / name, arcname=name)
    for folder in ('baseline', 'runner-tests'):
        for path in sorted((lab / folder).rglob('*')):
            if path.is_file():
                out.add(path, arcname=path.relative_to(lab))
    for name in ('run.log', 'run.exit', 'verify-stable.log', 'verify-1.85.0.log'):
        out.add(previous / name, arcname='gates-b/' + name)
data = archive.read_bytes()
print('EVIDENCE_SHA256=' + hashlib.sha256(data).hexdigest())
print('EVIDENCE_BYTES=' + str(len(data)))
print('EVIDENCE_BASE64=' + base64.b64encode(data).decode('ascii'))
