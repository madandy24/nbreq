import base64
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

receipt = Path(sys.argv[1])
destination = Path(sys.argv[2]).resolve()
result = json.loads(receipt.read_text(encoding='utf-8-sig'))
assert result['status'] == 'completed' and result['ok'] and result['exit_code'] == 0
lines = dict(line.split('=', 1) for line in result['output'].splitlines() if line.startswith('EVIDENCE_'))
data = base64.b64decode(lines['EVIDENCE_BASE64'], validate=True)
assert len(data) == int(lines['EVIDENCE_BYTES'])
digest = hashlib.sha256(data).hexdigest()
assert digest == lines['EVIDENCE_SHA256']
destination.mkdir(parents=True, exist_ok=False)
destination.with_suffix('.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    for member in archive.getmembers():
        assert member.isfile(), member.name
        path = (destination / member.name).resolve()
        path.relative_to(destination)  # Reject absolute/traversing archive names.
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(archive.extractfile(member).read())
print(json.dumps(dict(folder=str(destination), bytes=len(data), sha256=digest)))
