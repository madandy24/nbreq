from pathlib import Path
import hashlib
import io
import json
import subprocess
import sys
import tarfile

out = Path('target/m1')
generation = sys.argv[1]
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')
prefixes = ('src/', 'tests/', 'support/', 'examples/', 'docs/', 'tools/xtask/', 'tools/f5-observe/')
roots = {'Cargo.toml', 'Cargo.lock', 'README.md', 'SECURITY.md', 'LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.html', '.gitignore', 'rustfmt.toml'}
files = {name: Path(name).read_bytes() for name in names if (name in roots or name.startswith(prefixes)) and Path(name).is_file() and '/target/' not in name and '/__pycache__/' not in name}
for name in ('Cargo.lock', 'tools/f5-observe/memory/Cargo.lock', 'tools/f5-observe/memory/meter/Cargo.lock'):
    files[name] = Path(name).read_bytes()
files['m1-roots-check.sh'] = (out / 'roots-check.sh').read_bytes().replace(b'\r\n', b'\n')
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['m1-source.sha256'] = manifest
path = out / f'nbreq-m1-{generation}.tar.gz'
with tarfile.open(path, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo('nbreq/' + name)
        info.size = len(data)
        info.mode = 0o755 if name.endswith('.sh') else 0o644
        archive.addfile(info, io.BytesIO(data))
result = dict(path=str(path.resolve()), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), manifest_sha256=hashlib.sha256(manifest).hexdigest(), files=len(files))
(out / f'bundle-{generation}.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
