# Evidence layout

Each host has baseline results/provenance, per-case events and cleanup receipts, and gate logs.
The Windows full verifier log ending in -c used production source B; final fixture C has separate targeted logs.
The gates-b folders preserve both remote full verifier runs and preliminary diagnostics.
Only the final baseline folders are performance evidence.

From the extracted evidence directory, regenerate aggregates with:

    python scripts/analyse.py .

From the NBReq checkout, regenerate the report using the extracted summary:

    python /absolute/evidence/scripts/write-report.py /absolute/evidence/summary.json

The source C archive and observer README contain workload reproduction commands.
MANIFEST.sha256 verifies each archived file; the external artifact receipt verifies this archive.
