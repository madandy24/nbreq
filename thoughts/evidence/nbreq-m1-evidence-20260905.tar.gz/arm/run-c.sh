#!/bin/sh
set -eu
lab=$1
previous=$2
scope=$3
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$previous/target"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
trap 'code=$?; printf "%s\n" "$code" > "$lab/run.exit"' EXIT
cd "$lab/nbreq"
attempts=0
while ! test -f "$previous/run.exit"; do
    attempts=$((attempts + 1))
    if test "$attempts" -gt 600; then echo 'previous lab did not finish'; exit 1; fi
    sleep 2
done
for toolchain in stable 1.85.0; do
    grep 'NBReq verification complete: all 24 steps passed' "$previous/verify-$toolchain.log"
done
python3 - "$previous/nbreq" <<'PY'
import hashlib, pathlib, sys
rows=[line.split('  ',1) for line in pathlib.Path('m1-source.sha256').read_text().splitlines()]
assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows)
old=pathlib.Path(sys.argv[1])
changed=[name for digest,name in rows if (old/name).read_bytes()!=pathlib.Path(name).read_bytes()]
assert set(changed)=={'tests/tls_roots.rs','tools/f5-observe/memory/src/fixture.rs'}, changed
print('SOURCE_MANIFEST_PASS',len(rows),'PRODUCTION_MATCHES_B',changed)
PY
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    rustc --version
    cargo test --locked --offline --test tls_roots
    cargo clippy --locked --offline --test tls_roots -- -D warnings
    cargo clippy --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --all-targets --all-features -- -D warnings
done
export RUSTUP_TOOLCHAIN=stable
mkdir -p "$lab/bin"
cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml
cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/plain"
cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter
cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin/meter"
python3 tools/f5-observe/memory/test_runner.py --plain "$lab/bin/plain" --meter "$lab/bin/meter" --output "$lab/runner-tests"
if test "$scope" = full; then
    python3 tools/f5-observe/memory/run.py --plain "$lab/bin/plain" --meter "$lab/bin/meter" --output "$lab/baseline" --source 36886e7d54643a8aa60cae9c6f9f099c90a44d65d3dee246ae3b56334e1aa4ed
else
    python3 tools/f5-observe/memory/run.py --plain "$lab/bin/plain" --meter "$lab/bin/meter" --output "$lab/baseline" --source 36886e7d54643a8aa60cae9c6f9f099c90a44d65d3dee246ae3b56334e1aa4ed --smoke
fi
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m1-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
printf 'M1_HOST_PASS\n'
