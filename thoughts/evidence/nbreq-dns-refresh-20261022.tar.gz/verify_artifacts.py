"""Validate retained CI receipts, including exact registry bytes after publication."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

LAB = Path(__file__).resolve().parent

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run', type=int, required=True)
    p.add_argument('--version', required=True)
    p.add_argument('--mode', choices=['ci', 'candidate', 'published'], required=True)
    a = p.parse_args()
    folder = LAB / f'run-{a.run}'
    identity = json.loads((LAB / f'package-{a.version}' / 'identity.json').read_text())
    run = json.loads((folder / 'run.json').read_text())
    jobs = json.loads((folder / 'jobs.json').read_text())
    tested_commit = identity['commit']
    if a.mode != 'published' and (LAB / f'package-{a.version}/doc-only-carryforward.json').exists():
        from doc_carryforward import verify
        tested_commit = verify(a.version)
    assert run['head_sha'] == tested_commit
    assert run['conclusion'] == 'success' and all(j['conclusion'] == 'success' for j in jobs)
    assert len(jobs) == (10 if a.mode == 'ci' else 8)
    artifacts = json.loads((folder / 'artifacts.json').read_text())
    receipts = []
    for item in artifacts:
        if not item['name'].startswith(('consumers-', 'registry-')):
            continue
        path = folder / f"artifact-{item['id']}.zip"
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert item['digest'] == 'sha256:' + digest
        with zipfile.ZipFile(path) as z:
            prefix = 'nbreq-consumers/' if a.mode == 'ci' else ''
            def read(name):
                return json.loads(z.read(name))
            result = read(prefix + 'result.json')
            steps = read(prefix + 'steps.json')
            assert result['status'] == 'passed' and all(s['passed'] for s in steps)
            assert result['steps'] == len(steps)
            examples = 'nbreq-examples/' if a.mode == 'ci' else 'examples/'
            sample_results = read(examples + 'results.json')
            assert len(sample_results) == 18 and all(s['passed'] for s in sample_results)
            receipt = dict(artifact=item['name'], artifact_sha256=digest, steps=len(steps), examples=18)
            if a.mode == 'ci':
                assert result['cases'] == 2
            else:
                inputs = read('inputs.json')
                assert inputs['package_vcs']['git']['sha1'] == tested_commit
                assert inputs['mode'] == a.mode
                assert result['support_from_registry'] and inputs['support_from_registry']
                assert result['registry_only'] == inputs['registry_only'] == (a.mode == 'published')
                assert len(result['cases']) == 2
                digest = inputs['archive_sha256']
                assert result['archive_sha256'] == digest
                if a.mode == 'published':
                    assert digest == identity['sha256']
                dns = [s for s in steps if '-packaged-dns-' in s['label']]
                assert len(dns) == (4 if 'Windows' in item['name'] else 2)
                for s in dns:
                    count = 53 if s['label'].endswith('-native') else 57
                    assert f'test result: ok. {count} passed; 0 failed' in z.read(s['label'] + '.log').decode()
                for case in result['cases']:
                    lock = z.read(case['label'] + '/Cargo.lock')
                    assert hashlib.sha256(lock).hexdigest() == case['lock_sha256']
                    assert case['packages']['nbreq']['version'] == a.version
                    assert case['support_from_registry']
                    if a.mode == 'published':
                        assert case['registry_only']
                        assert case['packages']['nbreq']['source'].startswith('registry+')
                if 'Windows' in item['name']:
                    assert len([s for s in steps if s['label'].endswith('-native-x86')]) == 2
                receipt.update(archive_sha256=digest, canonical_archive=digest == identity['sha256'], dns_cases=len(dns))
            receipts.append(receipt)
    assert len(receipts) == 8
    (folder / 'verified-artifacts.json').write_text(json.dumps(dict(status='passed', run=a.run,
        version=a.version, mode=a.mode, receipts=receipts), indent=2))
    print(f'{a.version} {a.mode}: eight artifacts validated, including all steps and 18 examples each')

if __name__ == '__main__':
    main()
