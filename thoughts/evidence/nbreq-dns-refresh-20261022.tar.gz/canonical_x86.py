"""Run DNS regressions from each exact canonical package with the GDS architecture."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import tempfile

ROOT = Path('C:/User/projects/nbreq')
LAB = Path(__file__).resolve().parent
records = []
work = Path(tempfile.mkdtemp(prefix='nbreq-dns-canonical-')).resolve()
for version in ['0.3.1', '0.2.2']:
    folder = LAB / ('package-' + version)
    identity = json.loads((folder / 'identity.json').read_text())
    archive = Path(identity['archive'])
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == identity['sha256']
    with tarfile.open(archive) as package:
        for member in package.getmembers():
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts
            assert name.parts[0] == 'nbreq-' + version
            path = work.joinpath(*name.parts).resolve()
            assert path.is_relative_to(work)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(package.extractfile(member).read())
    manifest = work / ('nbreq-' + version) / 'Cargo.toml'
    for mode, flags in [('native', ['--no-default-features', '--features', 'native']), ('default', [])]:
        label = 'canonical-' + version + '-x86-' + mode + '-isolated'
        print(label, flush=True)
        command = ['cargo', 'test', '--locked', '--offline', '--manifest-path', str(manifest),
            '--target-dir', str(ROOT / 'target'), '--target', 'i686-pc-windows-msvc', *flags,
            '--lib', 'backend::native_dns::tests', '--', '--test-threads=1']
        with (LAB / (label + '.log')).open('xb') as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=900)
        records.append(dict(version=version, mode=mode, archive_sha256=identity['sha256'],
            command=command, exit_code=result.returncode))
        (LAB / 'canonical-x86-isolated.json').write_text(json.dumps(records, indent=2))
        if result.returncode:
            print((LAB / (label + '.log')).read_text(errors='replace')[-6000:])
            raise RuntimeError(label + ' failed')
print('All exact-package x86 DNS checks passed', flush=True)
