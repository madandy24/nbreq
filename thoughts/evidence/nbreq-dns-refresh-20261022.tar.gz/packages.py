"""Verify frozen source and prepare canonical registry-helper archives and dry runs."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time
import tomllib

ROOT = Path('C:/User/projects/nbreq')
LAB = Path(__file__).resolve().parent

def git(source, *args):
    return subprocess.check_output(['git', *args], cwd=source)

def run(label, argv, source, out):
    print(label, flush=True)
    started = time.monotonic()
    with (out / (label + '.log')).open('xb') as log:
        result = subprocess.run(argv, cwd=source, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    (out / (label + '.json')).write_text(json.dumps(dict(argv=argv, cwd=str(source),
        exit_code=result.returncode, elapsed_s=time.monotonic() - started), indent=2))
    if result.returncode:
        print((out / (label + '.log')).read_text(errors='replace')[-6000:])
        raise RuntimeError(label + ' failed')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('version', choices=['0.2.2', '0.3.1'])
    args = parser.parse_args()
    version = args.version
    source = ROOT if version == '0.3.1' else ROOT / '.tmp/dns-refresh-022'
    out = LAB / ('package-' + version)
    if out.exists():
        assert not list(out.iterdir()), 'Never overwrite an existing package attempt'
    else:
        out.mkdir()
    assert not git(source, 'status', '--porcelain').strip()
    commit = git(source, 'rev-parse', 'HEAD').decode().strip()
    # Use exact Git bytes for packaged files regardless of Windows checkout newline rules.
    names = git(source, 'ls-files', '-z').decode().split('\0')
    index_before = git(source, 'ls-files', '-s', '-z')
    normalized = []
    for name in names:
        if not name or not (name.startswith(('src/', 'tests/', 'examples/', 'docs/'))
                           or name in ['README.md', 'CHANGELOG.md', 'SECURITY.md', 'THIRD_PARTY_LICENSES.html',
                                       'LICENSE-APACHE', 'LICENSE-MIT', 'Cargo.toml', 'Cargo.lock']):
            continue
        payload = git(source, 'show', 'HEAD:' + name)
        path = source / name
        if path.read_bytes() != payload:
            path.write_bytes(payload)
            normalized.append(name)
    if normalized:
        git(source, 'add', '--renormalize', '--', *normalized)
    assert git(source, 'ls-files', '-s', '-z') == index_before, 'Normalization must not change index objects'
    assert subprocess.run(['git', 'diff', '--cached', '--quiet', 'HEAD'], cwd=source).returncode == 0
    (out / 'normalization.json').write_text(json.dumps(dict(commit=commit, paths=normalized,
        index_objects_unchanged=True), indent=2))
    assert not git(source, 'status', '--porcelain').strip()
    target = out / 'build'
    run('package', ['cargo', 'package', '--locked', '-p', 'nbreq', '--target-dir', str(target)], source, out)
    archive = target / 'package' / ('nbreq-' + version + '.crate')
    checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
    with tarfile.open(archive) as package:
        prefix = 'nbreq-' + version + '/'
        entries = package.getmembers()
        assert all(e.isfile() and e.name.startswith(prefix) for e in entries)
        vcs = json.load(package.extractfile(prefix + '.cargo_vcs_info.json'))
        assert vcs['git']['sha1'] == commit and not vcs['git'].get('dirty', False)
        manifest = tomllib.loads(package.extractfile(prefix + 'Cargo.toml').read().decode())
        assert manifest['package']['version'] == version and 'patch' not in manifest
        for name, required in [('rustls', '0.23.46'), ('rustls-webpki', '0.103.16'), ('webpki-roots', '1.0.10')]:
            assert manifest['dependencies'][name]['version'] == required
        assert 'dep:rustls-webpki' in manifest['features']['native']
        for cfg, name, required in [('cfg(windows)', 'nbreq-winpoll', '0.1.1'),
                                    ('cfg(target_os = "macos")', 'nbreq-darwin', '0.1.0')]:
            dep = manifest['target'][cfg]['dependencies'][name]
            assert dep['version'] == required and 'path' not in dep
        inventory = {e.name[len(prefix):]: hashlib.sha256(package.extractfile(e).read()).hexdigest() for e in entries}
    record = dict(version=version, source=str(source), commit=commit, archive=str(archive),
                  sha256=checksum, bytes=archive.stat().st_size, files=inventory)
    (out / 'identity.json').write_text(json.dumps(record, indent=2))
    run('publish-dry-run', ['cargo', 'publish', '--dry-run', '--locked', '--registry', 'crates-io',
                           '-p', 'nbreq', '--target-dir', str(target)], source, out)
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == checksum
    dry_archives = list((target / 'package').rglob('nbreq-' + version + '.crate'))
    assert dry_archives and all(hashlib.sha256(p.read_bytes()).hexdigest() == checksum for p in dry_archives)
    assert not git(source, 'status', '--porcelain').strip()
    (out / 'result.json').write_text(json.dumps(dict(status='passed', version=version, commit=commit, sha256=checksum), indent=2))
    print(json.dumps(dict(version=version, commit=commit, sha256=checksum, members=len(inventory))))

if __name__ == '__main__':
    main()
