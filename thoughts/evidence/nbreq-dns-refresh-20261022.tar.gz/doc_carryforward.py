"""Prove an encoding-only package delta before carrying forward runtime validation."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

LAB = Path(__file__).resolve().parent

def verify(version):
    folder = LAB / f'package-{version}'
    final = json.loads((folder / 'identity.json').read_text())
    old = json.loads((LAB / f'package-{version}-before-doc-correction' / 'identity.json').read_text())
    old_archive = LAB / f'package-{version}-before-doc-correction/build/package/nbreq-{version}.crate'
    assert hashlib.sha256(old_archive.read_bytes()).hexdigest() == old['sha256']
    assert hashlib.sha256(Path(final['archive']).read_bytes()).hexdigest() == final['sha256']
    def members(path):
        with tarfile.open(path) as z:
            assert all(m.isfile() for m in z.getmembers())
            return {m.name: z.extractfile(m).read() for m in z.getmembers()}
    before, after = members(old_archive), members(final['archive'])
    assert before.keys() == after.keys()
    changed = sorted(k for k in before if before[k] != after[k])
    assert changed == [f'nbreq-{version}/.cargo_vcs_info.json', f'nbreq-{version}/CHANGELOG.md']
    name = f'nbreq-{version}/CHANGELOG.md'
    assert before[name].replace(b'\x97', bytes.fromhex('e28094')) == after[name]
    after[name].decode('utf8')
    names = subprocess.check_output(['git', 'diff', '--name-only', old['commit'], final['commit']], cwd=final['source'], text=True).splitlines()
    assert names == ['CHANGELOG.md']
    assert (LAB / 'verify-022-doc-correction-exit.txt').read_text().strip() == '0'
    result = dict(status='passed', tested_commit=old['commit'], release_commit=final['commit'],
                  tested_archive_sha256=old['sha256'], release_archive_sha256=final['sha256'],
                  changed_members=changed, unchanged_runtime_and_dependencies=True)
    (folder / 'doc-only-carryforward.json').write_text(json.dumps(result, indent=2))
    return old['commit']

if __name__ == '__main__':
    print(verify('0.2.2'))
