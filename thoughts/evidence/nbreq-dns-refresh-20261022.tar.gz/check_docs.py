import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.request import Request, urlopen

LAB = Path(__file__).resolve().parent
ROOT = LAB.parent.parent

def fetch(url):
    with urlopen(Request(url, headers={'User-Agent': 'nbreq-release-documentation-check'}), timeout=45) as r:
        return r.geturl(), r.read()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('version')
    a = p.parse_args()
    identity = json.loads((LAB / f'package-{a.version}' / 'identity.json').read_text())
    out = LAB / f'docs-{a.version}'
    out.mkdir(exist_ok=True)
    results = []
    paths = ['README.md', 'docs/getting-started.md', 'docs/tcp-tls.md', 'examples/README.md']
    if a.version.startswith('0.3'):
        paths.append('docs/migrating-to-0.3.md')
    for path in paths:
        url = f'https://raw.githubusercontent.com/madandy24/nbreq/v{a.version}/{path}'
        final, data = fetch(url)
        expected = subprocess.check_output(['git', 'show', identity['commit'] + ':' + path], cwd=ROOT)
        assert data == expected
        results.append(dict(url=url, final=final, sha256=hashlib.sha256(data).hexdigest(), matches_release=True))
    pages = ['index.html', 'struct.Engine.html', 'struct.RequestOptions.html', 'struct.StreamRequest.html',
             'struct.TcpConnectRequest.html', 'struct.TlsOptions.html', 'struct.ResolveRequest.html', 'enum.TlsTrust.html']
    for page in pages:
        url = f'https://docs.rs/nbreq/{a.version}/nbreq/{page}'
        print(url, flush=True)
        final, data = fetch(url)
        assert f'/nbreq/{a.version}/nbreq/' in final
        assert b'<title>' in data and b' - Rust</title>' in data
        results.append(dict(url=url, final=final, sha256=hashlib.sha256(data).hexdigest(), rustdoc=True))
    (out / 'result.json').write_text(json.dumps(dict(status='passed', version=a.version, results=results), indent=2))
    print(f'{a.version}: immutable guides match the release; all eight versioned rustdoc pages are live')

if __name__ == '__main__':
    main()
