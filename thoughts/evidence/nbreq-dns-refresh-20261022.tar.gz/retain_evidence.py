"""Build a bounded, hash-checked release evidence archive, excluding build caches."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

LAB = Path(__file__).resolve().parent
ROOT = LAB.parent.parent
DEST = ROOT / 'thoughts/evidence'

def main():
    name = 'nbreq-dns-refresh-20261022.tar.gz'
    payload = {}
    def add(path):
        key = path.relative_to(LAB).as_posix()
        payload[key] = path.read_bytes()
    for path in LAB.iterdir():
        if path.is_file() and path.suffix in ['.py', '.log', '.json', '.txt']:
            add(path)
        elif path.is_dir() and path.name.startswith(('audit-', 'docs-', 'publication-', 'security-recheck')):
            for child in path.rglob('*'):
                if child.is_file():
                    add(child)
        elif path.is_dir() and path.name.startswith('run-'):
            for child in path.iterdir():
                if child.is_file() and (child.suffix == '.json' or child.name == 'logs.zip' or
                                      (child.name.startswith('artifact-') and 'attempt-1' not in path.name) or
                                      (child.suffix == '.log' and not (path / 'logs.zip').exists())):
                    add(child)
        elif path.is_dir() and path.name.startswith('package-'):
            for child in path.iterdir():
                if child.is_file():
                    add(child)
            for child in (path / 'build/package').glob('nbreq-*.crate'):
                add(child)
    inventory = {name: dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)) for name, data in sorted(payload.items())}
    payload['inventory.json'] = json.dumps(inventory, indent=2).encode()
    archive = DEST / name
    assert not archive.exists(), 'Do not overwrite accepted evidence'
    with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
        for key, data in sorted(payload.items()):
            info = tarfile.TarInfo(key)
            info.size = len(data)
            info.mtime = 0
            info.mode = 0o644
            tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers()) == len(payload)
        for item in tar.getmembers():
            assert item.isfile() and tar.extractfile(item).read() == payload[item.name]
    result = dict(archive=name, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                  bytes=archive.stat().st_size, regular_members=len(payload),
                  inventory_sha256=hashlib.sha256(payload['inventory.json']).hexdigest(),
                  releases={v: json.loads((LAB / f'publication-{v}/result.json').read_text()) for v in ['0.2.2', '0.3.1']})
    (DEST / 'nbreq_dns_refresh_artifacts.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
