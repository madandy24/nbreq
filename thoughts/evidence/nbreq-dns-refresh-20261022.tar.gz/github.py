"""Bounded GitHub release checks; credentials remain in memory and never enter logs."""
import argparse
import json
import os
from pathlib import Path
import subprocess
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, urlopen

ROOT = Path('C:/User/projects/nbreq')
LAB = Path(__file__).resolve().parent
BASE = 'https://api.github.com/repos/madandy24/nbreq'

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

def api(path, method='GET', data=None, binary=False):
    assert path.startswith('/') and not path.startswith('//')
    result = subprocess.run(['git', 'credential', 'fill'], input='protocol=https\nhost=github.com\n\n',
        text=True, cwd=ROOT, env=dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never'),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode:
        raise RuntimeError('GitHub credential helper unavailable; credential output suppressed')
    fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
    token = fields.get('password')
    if not token:
        raise RuntimeError('GitHub credential helper returned no access token')
    req = Request(BASE + path, data=json.dumps(data).encode() if data is not None else None,
        method=method, headers={'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28',
            'User-Agent': 'nbreq-dns-release-checks', 'Authorization': 'Bearer ' + token})
    try:
        with build_opener(NoRedirect).open(req, timeout=45) as response:
            raw = response.read()
    except HTTPError as error:
        if binary and error.code in (301, 302, 303, 307, 308):
            destination = error.headers['Location']
            assert urlsplit(destination).scheme == 'https'
            with urlopen(Request(destination, headers={'User-Agent': 'nbreq-dns-release-checks'}), timeout=45) as response:
                return response.read()
        raise RuntimeError('GitHub API returned HTTP ' + str(error.code)) from None
    return raw if binary else (json.loads(raw) if raw else None)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['inspect', 'dispatch', 'runs', 'status', 'download', 'cancel'])
    parser.add_argument('--ref')
    parser.add_argument('--workflow', choices=['ci.yml', 'registry-release.yml'])
    parser.add_argument('--mode', choices=['candidate', 'published'])
    parser.add_argument('--run', type=int)
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.action == 'inspect':
        repo = api('/actions/workflows')
        print(json.dumps({'workflows': [{'name': w['name'], 'path': w['path'], 'state': w['state']} for w in repo['workflows']]}))
    elif args.action == 'dispatch':
        assert args.ref and args.workflow
        payload = {'ref': args.ref}
        if args.mode:
            payload['inputs'] = {'mode': args.mode}
        marker = LAB / ('dispatch-' + args.ref.replace('/', '-') + '-' + args.workflow + '-' + str(args.mode) + '-attempt-' + str(args.attempt) + '.json')
        with marker.open('x') as stream:
            json.dump(payload, stream)
        api('/actions/workflows/' + args.workflow + '/dispatches', 'POST', payload)
        print('Accepted ' + args.workflow + ' on ' + args.ref + ' ' + str(args.mode))
    elif args.action == 'runs':
        data = api('/actions/runs?' + urlencode({'branch': args.ref, 'per_page': 25}))
        print(json.dumps([{k: r[k] for k in ['id', 'name', 'head_sha', 'head_branch', 'status', 'conclusion', 'html_url']} for r in data['workflow_runs']], indent=2))
    else:
        assert args.run
        run = api('/actions/runs/' + str(args.run))
        if args.action == 'cancel':
            if run['status'] != 'completed':
                api('/actions/runs/' + str(args.run) + '/cancel', 'POST')
            print('Stopped obsolete checks for ' + str(args.run))
            return
        jobs = api('/actions/runs/' + str(args.run) + '/jobs?per_page=100')['jobs']
        out = LAB / ('run-' + str(args.run))
        out.mkdir(exist_ok=True)
        (out / 'run.json').write_text(json.dumps(run, indent=2))
        (out / 'jobs.json').write_text(json.dumps(jobs, indent=2))
        print(json.dumps({'run': {k: run[k] for k in ['id', 'head_sha', 'status', 'conclusion', 'html_url']},
            'jobs': [{'name': j['name'], 'status': j['status'], 'conclusion': j['conclusion'],
                      'active': [s['name'] for s in j['steps'] if s['status'] == 'in_progress']} for j in jobs]}, indent=2))
        if args.action == 'download':
            if run['status'] == 'completed':
                (out / 'logs.zip').write_bytes(api('/actions/runs/' + str(args.run) + '/logs', binary=True))
            else:
                for job in jobs:
                    if job['status'] == 'completed':
                        (out / ('job-' + str(job['id']) + '.log')).write_bytes(api('/actions/jobs/' + str(job['id']) + '/logs', binary=True))
            artifacts = api('/actions/runs/' + str(args.run) + '/artifacts?per_page=100')['artifacts']
            (out / 'artifacts.json').write_text(json.dumps(artifacts, indent=2))
            for item in artifacts:
                assert not item['expired']
                (out / ('artifact-' + str(item['id']) + '.zip')).write_bytes(api('/actions/artifacts/' + str(item['id']) + '/zip', binary=True))
            print('Downloaded logs and ' + str(len(artifacts)) + ' artifacts')

if __name__ == '__main__':
    main()
