"""Run the required local gates serially; keep every command and result."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('C:/User/projects/nbreq')
LAB = Path(__file__).resolve().parent
records = []

def run(label, argv, cwd):
    print(label, flush=True)
    start = time.monotonic()
    with (LAB / (label + '.log')).open('xb') as log:
        result = subprocess.run(argv, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    records.append(dict(label=label, argv=argv, cwd=str(cwd), exit_code=result.returncode,
                        elapsed_s=time.monotonic() - start))
    (LAB / 'local-checks.json').write_text(json.dumps(records, indent=2))
    if result.returncode:
        print((LAB / (label + '.log')).read_text(errors='replace')[-6000:])
        raise RuntimeError(label + ' failed; evidence retained')

for version, source in [('031', ROOT), ('022', ROOT / '.tmp/dns-refresh-022')]:
    if version == '022':
        run('license-' + version, ['cargo', 'about', 'generate', '--frozen', '--workspace', '--all-features',
            '--fail', '--output-file', 'THIRD_PARTY_LICENSES.html', 'about.hbs'], source)
    run('verify-' + version + '-full', ['cargo', 'run', '--locked', '--offline', '--manifest-path',
        'tools/xtask/Cargo.toml', '--', 'verify', '--offline'], source)
    for mode, flags in [('native', ['--no-default-features', '--features', 'native']), ('default', [])]:
        run('dns-' + version + '-x86-' + mode, ['cargo', 'test', '--locked', '--offline', '--target',
            'i686-pc-windows-msvc', *flags, '--lib', 'backend::native_dns::tests', '--', '--test-threads=1'], source)
    run('consumer-policy-' + version, ['python', 'tools/release-consumer/test_consumer_policy.py'], source)
    run('diff-check-' + version, ['git', 'diff', '--check'], source)
print('All local gates passed', flush=True)
