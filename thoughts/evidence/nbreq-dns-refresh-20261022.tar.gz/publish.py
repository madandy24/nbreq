"""One-shot publication of an accepted DNS fix; verify the registry result before returning."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen

LAB = Path(__file__).resolve().parent

def fetch(url):
    with urlopen(Request(url, headers={'User-Agent': 'nbreq-dns-release-verification'}), timeout=45) as response:
        return response.read()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('version', choices=['0.2.2', '0.3.1'])
    parser.add_argument('--ci', type=int, required=True)
    parser.add_argument('--candidate', type=int, required=True)
    parser.add_argument('--allow-pending-apple-silicon', action='store_true')
    args = parser.parse_args()
    identity = json.loads((LAB / ('package-' + args.version) / 'identity.json').read_text())
    accepted = json.loads((LAB / ('package-' + args.version) / 'result.json').read_text())
    source = Path(identity['source'])
    commit = identity['commit']
    assert accepted['status'] == 'passed' and accepted['sha256'] == identity['sha256']
    validated_commit = commit
    if (LAB / ('package-' + args.version) / 'doc-only-carryforward.json').exists():
        from doc_carryforward import verify
        validated_commit = verify(args.version)
    pending = []
    for run_id, count in [(args.ci, 10), (args.candidate, 8)]:
        folder = LAB / ('run-' + str(run_id))
        run = json.loads((folder / 'run.json').read_text())
        jobs = json.loads((folder / 'jobs.json').read_text())
        assert run['head_sha'] == validated_commit and len(jobs) == count
        for job in jobs:
            if job['conclusion'] == 'success':
                assert (folder / 'logs.zip').is_file() or (folder / ('job-' + str(job['id']) + '.log')).is_file()
                continue
            assert args.allow_pending_apple_silicon, 'Every gate must pass unless the owner-approved ARM deferral applies'
            assert 'Apple Silicon' in job['name'] or 'ARM Mac' in job['name']
            assert job['status'] in ('queued', 'in_progress'), 'A real failure is not a pending platform check'
            pending.append(dict(run=run_id, name=job['name'], status=job['status']))
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == commit
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source).strip()
    assert hashlib.sha256(Path(identity['archive']).read_bytes()).hexdigest() == identity['sha256']
    for packaged in identity['files']:
        name = 'Cargo.toml' if packaged == 'Cargo.toml.orig' else packaged
        path = source / name
        if path.is_file():
            committed = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=source)
            assert path.read_bytes() == committed, 'Release file bytes changed: ' + name
    version_url = 'https://crates.io/api/v1/crates/nbreq/' + args.version
    try:
        fetch(version_url)
    except HTTPError as error:
        if error.code != 404:
            raise
    else:
        raise RuntimeError('Version already exists; verify it instead of resubmitting')
    out = LAB / ('publication-' + args.version)
    out.mkdir(exist_ok=False)
    argv = ['cargo', 'publish', '--locked', '--registry', 'crates-io', '-p', 'nbreq',
            '--target-dir', str(LAB / ('package-' + args.version) / 'build')]
    (out / 'submission.json').write_text(json.dumps(dict(argv=argv, cwd=str(source), commit=commit,
        sha256=identity['sha256'], pending_apple_silicon=pending), indent=2))
    print('Publishing accepted NBReq ' + args.version + ' at ' + commit, flush=True)
    with (out / 'cargo-publish.log').open('xb') as log:
        result = subprocess.run(argv, cwd=source, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    (out / 'exit-code.json').write_text(json.dumps({'exit_code': result.returncode}))
    if result.returncode:
        print((out / 'cargo-publish.log').read_text(errors='replace')[-5000:])
        raise RuntimeError('Publication failed or is ambiguous; inspect registry before any retry')
    for attempt in range(12):
        try:
            version = json.loads(fetch(version_url))['version']
            payload = fetch(version_url + '/download')
            break
        except HTTPError as error:
            if error.code != 404 or attempt == 11:
                raise
            time.sleep(5)
    assert version['num'] == args.version and not version['yanked']
    assert version['checksum'] == hashlib.sha256(payload).hexdigest() == identity['sha256']
    (out / ('nbreq-' + args.version + '.crate')).write_bytes(payload)
    (out / 'registry.json').write_text(json.dumps(version, indent=2))
    index = fetch('https://index.crates.io/nb/re/nbreq').decode()
    entries = [json.loads(line) for line in index.splitlines()]
    entry = next(e for e in entries if e['vers'] == args.version)
    assert entry['cksum'] == identity['sha256'] and not entry['yanked']
    (out / 'index.json').write_text(json.dumps(entry, indent=2))
    (out / 'result.json').write_text(json.dumps(dict(status='published', version=args.version,
        commit=commit, sha256=identity['sha256']), indent=2))
    print('Verified registry API, sparse index and exact downloaded archive for ' + args.version, flush=True)

if __name__ == '__main__':
    main()
