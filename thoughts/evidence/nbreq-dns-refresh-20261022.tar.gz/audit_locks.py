"""Audit each distinct selected root, example and consumer lock against official RustSec data."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tomllib
import zipfile

ROOT = Path('C:/User/projects/nbreq')
LAB = Path(__file__).resolve().parent
AUDITOR = ROOT / 'target/tools/cargo-audit/bin/cargo-audit.exe'
DB = LAB / 'advisory-db'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runs', type=int, nargs='+', required=True)
    parser.add_argument('--label', required=True)
    args = parser.parse_args()
    assert hashlib.sha256(AUDITOR.read_bytes()).hexdigest() == '963960fb3c8707a433e85a9e7bb49b05e2dc4585ae898983e3e665dc19d169e5'
    database = subprocess.check_output(['git', '-C', str(DB), 'rev-parse', 'HEAD'], text=True).strip()
    remote = subprocess.check_output(['git', 'ls-remote', 'https://github.com/RustSec/advisory-db', 'HEAD'], text=True).split()[0]
    assert remote == database, 'Refresh the advisory database before auditing'
    assert not subprocess.check_output(['git', '-C', str(DB), 'status', '--porcelain']).strip()
    policy = tomllib.loads((ROOT / '.cargo/audit.toml').read_text())
    assert policy['advisories']['ignore'] == ['RUSTSEC-2026-0009']
    out = LAB / ('audit-' + args.label)
    out.mkdir(exist_ok=False)
    locks = {}
    def add(data, origin):
        assert tomllib.loads(data.decode())['package']
        key = hashlib.sha256(data).hexdigest()
        if key not in locks:
            locks[key] = dict(data=data, origins=[])
        locks[key]['origins'].append(origin)
    for source in [ROOT, ROOT / '.tmp/dns-refresh-022']:
        add((source / 'Cargo.lock').read_bytes(), str(source / 'Cargo.lock'))
    for run_id in args.runs:
        folder = LAB / ('run-' + str(run_id))
        for path in folder.glob('artifact-*.zip'):
            with zipfile.ZipFile(path) as archive:
                for name in archive.namelist():
                    if PurePosixPath(name).name in ('Cargo.lock', 'package-examples-Cargo.lock'):
                        add(archive.read(name), str(path) + ':' + name)
    receipts = []
    for key, item in sorted(locks.items()):
        lock = out / (key + '.lock')
        lock.write_bytes(item['data'])
        result = subprocess.run([str(AUDITOR), 'audit', '--db', str(DB), '--no-fetch', '--file', str(lock), '--json'],
            cwd=ROOT, env=dict(os.environ, CARGO_NET_OFFLINE='true'), stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, timeout=180)
        (out / (key + '.json')).write_bytes(result.stdout)
        (out / (key + '.stderr')).write_bytes(result.stderr)
        report = json.loads(result.stdout)
        assert result.returncode == 0 and not report['vulnerabilities']['found'] and not report['warnings'], key
        assert report['settings']['ignore'] == ['RUSTSEC-2026-0009']
        receipts.append(dict(sha256=key, origins=item['origins'], report_sha256=hashlib.sha256(result.stdout).hexdigest()))
    (out / 'result.json').write_text(json.dumps(dict(status='passed', database_commit=database,
        runs=args.runs, distinct_locks=len(locks), receipts=receipts), indent=2))
    print(str(len(locks)) + ' distinct selected lockfiles passed the security audit.', flush=True)

if __name__ == '__main__':
    main()
