"""Verify and bundle the final portable TLS appendix. Never modifies input evidence."""
import argparse
import base64
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile
import tempfile

FINAL_COMMIT = "e4edec8d508c36f70f8c52e6026f93dc36e5c601"
FINAL_SOURCE = "804625c1ae8fd03d19c8a28ed0db6528d9290639f1aa8ca04e83fe550dbeed74"
FINAL_ARCHIVE = "573408108462253bbb309daa59d19faa08126d6d0a4dca07edbb258e5c0682d9"
PREVIOUS_ARCHIVE = "1c55af61848529b848dacaed9b4ecd4ef6aa78b12cbeb7863880ca61365db321"
REQUIRED = {"initial-wine", "initial-linux-failure", "linux-final", "intel-final", "arm-final",
            "windows-final", "windows-x86-final", "wine-final"}
ALLOWED = {".json", ".jsonl", ".log", ".txt", ".py", ".rs", ".toml", ".lock", ".md"}
CAP = 32 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def safe_name(name):
    parts = PurePosixPath(name).parts
    require(bool(parts) and not PurePosixPath(name).is_absolute() and
            ".." not in parts and "\\" not in name and ":" not in name,
            "unsafe evidence name: " + name)
    return name


def local(root, name):
    safe_name(name)
    path = root / name
    require(root in path.resolve().parents, "path outside lab: " + name)
    relative = path.relative_to(root)
    cursor = root
    for part in relative.parts:
        cursor = cursor / part
        require(not cursor.is_symlink(), "symlink in evidence path: " + name)
    return path


def read(path, cap=CAP):
    require(path.is_file() and not path.is_symlink(), "missing/nonregular input: " + str(path))
    require(path.stat().st_size <= cap, "oversize input: " + str(path))
    blob = path.read_bytes()
    require(len(blob) <= cap, "input grew beyond limit")
    return blob


def load(path):
    return json.loads(read(path))


def check_payload(name, blob):
    require(PurePosixPath(name).suffix.lower() not in (".exe", ".dll", ".so", ".dylib", ".pdb", ".key"), "binary/key payload selected")
    require(not blob.startswith((b"MZ", b"\x7fELF")), "executable payload selected")
    # Match actual PEM blocks, including blocks embedded in a log. Source-code
    # strings naming the marker are not a persisted key block.
    require(not re.search(rb"(?m)^-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----\r?$", blob), "private key selected")


def walk(root, selected=False):
    require(root.is_dir() and not root.is_symlink(), "missing evidence directory: " + str(root))
    result = {}
    def fail(error):
        raise error
    for directory, dirs, names in os.walk(root, followlinks=False, onerror=fail):
        for name in dirs + names:
            require(not (Path(directory) / name).is_symlink(), "symlink in evidence directory")
        if selected:
            dirs[:] = sorted(d for d in dirs if not d.startswith("build") and
                             d not in ("bin", "certs", "__pycache__", ".git", "source"))
        for name in sorted(names):
            path = Path(directory) / name
            if selected and path.suffix not in ALLOWED:
                continue
            result[path.relative_to(root).as_posix()] = read(path)
    return result


def archive(path, expected, manifest_name, extracted=None, executable_input=False):
    blob = read(path, 256 * 1024 * 1024)
    require(digest(blob) == expected, "archive hash mismatch: " + str(path))
    files = {}
    with tarfile.open(fileobj=io.BytesIO(blob)) as bundle:
        members = bundle.getmembers()
        require(len(members) <= 10000, "too many archive members")
        total = 0
        for member in members:
            name = safe_name(member.name)
            require(member.isfile() and name not in files, "duplicate/nonfile archive member")
            total += member.size
            require(0 <= member.size <= CAP and total <= 256 * 1024 * 1024,
                    "archive expansion limit exceeded")
            files[name] = bundle.extractfile(member).read()
    require(manifest_name in files, "missing archive manifest")
    metadata = json.loads(files[manifest_name])
    require(set(files) == set(metadata["files"]) | {manifest_name}, "archive manifest file set mismatch")
    for name, value in metadata["files"].items():
        require(digest(files[name]) == value.lower(), "archive member hash mismatch: " + name)
    if extracted is not None:
        actual = walk(extracted)
        if executable_input:
            # Only the verified Wine app-local compatibility shim may be extra.
            shim = actual.pop("bin/bcryptprimitives.dll", None)
            if shim is not None:
                require(digest(shim) == "92d437dc538ef6ddfae7fc0b2140ec407a6dacfb0c899ec67a6812e84387de86", "unexpected Wine shim")
            # Running the local Python launcher can create bytecode beside its source.
            for name in list(actual):
                if re.fullmatch(r"__pycache__/[^/]+\.pyc", name):
                    del actual[name]
        require(actual == files, "extracted evidence differs from exact archive file set")
    if manifest_name == "evidence-manifest.json":
        require(metadata["result"] == json.loads(files["result.json"]), "stale embedded evidence result")
    return metadata, files, blob


def check_source(record, source, commit, label):
    require(record.get("source") == source and record.get("commit") == commit,
            label + " source/commit mismatch")


def check_log(blob, expected):
    text = blob.decode("utf-8", errors="replace")
    actual = re.findall(r"test result: (ok|FAILED)\.\s+(\d+) passed;\s+(\d+) failed", text)
    require(actual == [(status, str(passed), str(failed)) for status, passed, failed in expected],
            "test result counts differ: " + repr(actual))


def successful_steps(files, steps, prefix=""):
    for step in steps:
        record = json.loads(files[prefix + step + ".result.json"])
        require(record.get("exit_code") == 0 and not record.get("failure"), "failed command step: " + prefix + step)


def live_success(files, prefix="", label_prefix=""):
    for mode, message in (("imaps", "verified IMAPS greeting, CAPABILITY, and LOGOUT from cavesvr3.caverock.com:993"),
                          ("smtp", "verified SMTP STARTTLS, protected EHLO, and QUIT from cavesvr3.caverock.com:25")):
        label = label_prefix + mode
        successful_steps(files, [label], prefix)
        log = files[prefix + label + ".log"].decode("utf-8", errors="replace")
        require("TLS trust: BundledMozilla" in log and message in log, "verified live protocol evidence missing")


def record_checks(files, entry):
    for name, expected in entry.get("json_checks", {}).items():
        record = json.loads(files[safe_name(name)])
        for key, value in expected.items():
            require(record.get(key) == value, "JSON expectation mismatch: " + name + ":" + key)
    for name, expected in entry.get("log_counts", {}).items():
        check_log(files[safe_name(name)], expected)
    for name, snippets in entry.get("log_contains", {}).items():
        text = files[safe_name(name)].decode("utf-8", errors="replace")
        require(all(s in text for s in snippets), "missing log evidence: " + name)


def gate_files(lab, entry):
    folder = local(lab, entry["folder"])
    if entry.get("archive"):
        _, files, _ = archive(local(lab, entry["archive"]), entry["archive_sha256"],
                              "evidence-manifest.json", folder)
    else:
        require(entry.get("local_windows") is True, "only local Windows gates may lack retrieval manifests")
        files = walk(folder, selected=True)
        require({n: digest(b) for n, b in files.items()} == entry["files"], "local gate inventory mismatch")
    record_checks(files, entry)
    return files


def receipt_payloads(receipt, evidence_archives):
    output = receipt.get("output", "")
    require(isinstance(output, str), "unexpected bridge output type")
    for line in output.splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            require('"base64"' not in line, "unparsed encoded bridge payload")
            continue
        if isinstance(value, dict) and "base64" in value:
            require(value.get("sha256") in evidence_archives, "receipt embeds an unapproved archive")
            chunk = base64.b64decode(value["base64"], validate=True)
            require(digest(chunk) == value["chunk_sha256"], "bridge chunk hash mismatch")
            original = evidence_archives[value["sha256"]]
            count = (len(original) + 256 * 1024 - 1) // (256 * 1024)
            part = value["part"]
            require(type(part) is int and 0 <= part < count and value["parts"] == count,
                    "invalid bridge archive part")
            require(chunk == original[part * 256 * 1024:(part + 1) * 256 * 1024], "bridge payload differs from verified evidence")


def verify(lab, spec):
    selected = {}
    def add(name, blob, archive_payload=False):
        safe_name(name)
        require(name not in selected, "duplicate appendix member: " + name)
        require(len(blob) <= 256 * 1024 * 1024, "oversize appendix member")
        if not archive_payload:
            require(PurePosixPath(name).suffix in ALLOWED, "disallowed appendix payload: " + name)
            check_payload(name, blob)
        selected[name] = blob
    previous = local(lab, spec["previous_archive"]["path"])
    require(spec["previous_archive"]["sha256"] == PREVIOUS_ARCHIVE, "unexpected native checkpoint archive")
    require(spec["qualifications"] == {
        "previous_windows_parallel_http": "The earlier full 30-step parallel Windows gate passed. An extra parallel bundle-only run failed an HTTP request-arrival timing assertion; serial bundle-only/MSRV passed without repairing that timing test. Later targeted passes do not replace this qualification.",
        "previous_arm_live_smtp": "The earlier ARM live SMTP timeout remains qualified in the unchanged native checkpoint; its stage and cause are unknown, and later targeted TLS suites do not erase it.",
        "diagnostic": "All 24 diagnostic application tests passed; three immediate-drop runs recorded ENOTCONN and only one wait-control run recorded final shutdown. This is syscall causal evidence, not a failing public-read reproduction or proof of an observed reset."
    }, "historical qualifications missing or altered")
    require(digest(read(previous, 256 * 1024 * 1024)) == spec["previous_archive"]["sha256"],
            "previous evidence archive changed")
    sources = {}
    for entry in spec["sources"]:
        meta, files, blob = archive(local(lab, entry["archive"]), entry["archive_sha256"],
                                     "portable-source.json", local(lab, entry["folder"]))
        identity = digest(files["portable-source.json"])
        require(meta["commit"] == entry["commit"] and identity == entry["manifest_sha256"],
                "source manifest identity mismatch")
        sources[entry["id"]] = (identity, meta["commit"], meta)
        for name, payload in files.items():
            check_payload(name, payload)
        add("sources/" + Path(entry["archive"]).name, blob, archive_payload=True)
    require(sources["final"][:2] == (FINAL_SOURCE, FINAL_COMMIT), "unexpected final source")
    final_entry = next(e for e in spec["sources"] if e["id"] == "final")
    require(final_entry["archive_sha256"] == FINAL_ARCHIVE, "unexpected final archive")

    binaries = {}
    for entry in spec["binaries"]:
        meta, files, _ = archive(local(lab, entry["archive"]), entry["archive_sha256"],
                                   "binary-manifest.json", local(lab, entry["folder"]), True)
        source, commit, _ = sources[entry["source_id"]]
        check_source(meta, source, commit, "binary manifest")
        require(meta["target"] == "i686-pc-windows-msvc" and meta["pe_machine"] == "0x014c", "wrong PE target")
        for name in ("nbreq", "portable_tls", "probe"):
            image = files["bin/" + name + ".exe"]
            pe = int.from_bytes(image[0x3c:0x40], "little")
            require(image[:2] == b"MZ" and image[pe:pe+6] == b"PE\0\0\x4c\x01", "wrong PE binary")
        binaries[entry["id"]] = digest(files["binary-manifest.json"])
        for name, blob in files.items():
            if PurePosixPath(name).suffix in ALLOWED:
                add("binaries/" + entry["id"] + "/" + name, blob)

    roles = [entry["role"] for entry in spec["gates"]]
    require(set(roles) == REQUIRED and len(roles) == len(REQUIRED), "missing/duplicate gate roles")
    gate_records = {}
    for entry in spec["gates"]:
        role = entry["role"]
        files = gate_files(lab, entry)
        record = json.loads(files["result.json"])
        source, commit, _ = sources[entry["source_id"]]
        check_source(record, source, commit, role)
        if role.endswith("final"):
            require(entry["source_id"] == "final", "final gate uses historical source")
        if role == "initial-wine":
            require(entry["source_id"] == "initial" and entry.get("binary_id") == "initial", "initial Wine lineage mismatch")
        if role == "initial-linux-failure":
            require(entry["source_id"] == "pre-fix", "initial Linux lineage mismatch")
        require(record["status"] == ("failed" if role == "initial-linux-failure" else "passed"),
                "wrong gate status: " + role)
        if "host.json" in files:
            check_source(json.loads(files["host.json"]), source, commit, role + " host")
        if entry.get("binary_id"):
            require(record["manifest_sha256"] == binaries[entry["binary_id"]], "gate binary identity mismatch")
            if role.endswith("final"):
                require(entry["binary_id"] == "final", "final gate uses historical binaries")
        if role in ("windows-x86-final", "wine-final"):
            require(entry.get("binary_id") == "final", "missing final binary binding")
            require(record["steps"] == (["wine-version"] if role == "wine-final" else []) +
                    ["portable-public", "portable-bundle-proof", "final-write-shutdown", "live-imaps", "live-smtp"],
                    "missing Win32 checks")
            successful_steps(files, record["steps"])
            live_success(files, label_prefix="live-")
            for name, count in (("portable-public", 10), ("portable-bundle-proof", 3), ("final-write-shutdown", 2)):
                check_log(files[name + ".log"], [["ok", count, 0]])
        if role == "linux-final":
            live = json.loads(files["live/result.json"])
            check_source(live, source, commit, "Linux live")
            require(live["status"] == "passed" and live["steps"] == ["imaps", "smtp"], "Linux live incomplete")
            require(live["probe_sha256"] == record["binaries"]["probe"]["sha256"], "Linux live probe mismatch")
            live_success(files, prefix="live/")
            for step in ("stable-verify", "bundle-only-tests", "msrv-tests", "probe-clippy", "probe-release"):
                require(json.loads(files[step + ".result.json"])["exit_code"] == 0, "Linux full gate incomplete")
            require({"stable-verify.log", "bundle-only-tests.log", "msrv-tests.log"} <= set(entry["log_counts"]), "Linux suite expectations missing")
        if role in ("intel-final", "arm-final", "windows-final"):
            require(record["steps"] == ["stable-compiler", "fetch", "format", "native-only", "all-features", "clippy", "msrv-compiler", "msrv"], "affected suite incomplete")
            for step in record["steps"]:
                require(json.loads(files[step + ".result.json"])["exit_code"] == 0, "affected command failed")
            for step, count in (("native-only", 395 if role == "windows-final" else 390),
                                ("all-features", 448 if role == "windows-final" else 443),
                                ("msrv", 448 if role == "windows-final" else 443)):
                check_log(files[step + ".log"], [["ok", n, 0] for n in (count, 10, 22, 5, 4)])
        require(entry.get("log_counts"), "gate must specify reviewed exact test counts: " + role)
        for name, blob in files.items():
            add("gates/" + role + "/" + name, blob)
        gate_records[role] = record

    attachment_ids = [e["id"] for e in spec["attachments"]]
    require(set(attachment_ids) == {"red", "green", "diagnostic", "diagnostic-helper", "win32-build", "local-pipeline"}
            and len(attachment_ids) == 6, "required appendix attachments missing/duplicated")
    for entry in spec["attachments"]:
        if entry.get("archive"):
            _, files, _ = archive(local(lab, entry["archive"]), entry["archive_sha256"],
                                   "evidence-manifest.json", local(lab, entry["folder"]))
        else:
            files = {name: read(local(lab, entry["folder"] + "/" + name)) for name in entry["files"]}
            require({name: digest(blob) for name, blob in files.items()} == entry["files"], "attachment hash mismatch")
        record_checks(files, entry)
        if entry["id"] == "win32-build":
            result = json.loads(files["result.json"])
            check_source(result, FINAL_SOURCE, FINAL_COMMIT, "Win32 build")
            binary_entry = next(e for e in spec["binaries"] if e["id"] == "final")
            require(result["status"] == "passed" and result["sha256"] == binary_entry["archive_sha256"], "Win32 build mismatch")
        for name, blob in files.items():
            add("appendix/" + entry["id"] + "/" + name, blob)

    # Tie saved runtime red, focused green, and the actual syscall trace to the source lineage.
    red = load(local(lab, "tls-final-shutdown-red/red-checkpoint.json"))
    require((red["exit_code"], red["passed"], red["failed"]) == (101, 1, 1), "missing compiled regression red")
    for entry in red["files"]:
        copied = local(lab, "tls-final-shutdown-red/" + Path(entry["copy"]).name)
        require(digest(read(copied)) == entry["sha256"].lower(), "red snapshot mismatch")
        if entry["path"] == "src/backend/native_http.rs":
            require(entry["sha256"].lower() == sources["pre-fix"][2]["files"][entry["path"]], "red implementation is not pre-fix source")
    green = load(local(lab, "tls-final-shutdown-green/verification-summary.json"))
    require(green["status"] == "passed" and green["source_unchanged"] is True and
            green["counts"] == {"causal": 2, "owner_including_causal": 12, "tcp_tls": 22, "tcp_tls_api": 5, "portable_tls": 10},
            "focused green incomplete")
    for name, value in green["files"].items():
        require(sources["final"][2]["files"][name] == value, "focused green source differs from final source")
        copy = local(lab, "tls-final-shutdown-green/" + name.replace("/", "__"))
        require(digest(read(copy)) == value, "saved focused green copy differs from final source")
    diag = load(local(lab, "shutdown-race/linux-diagnostic/manifest.json"))
    require(diag["source_manifest_sha256"] == sources["pre-fix"][0] and diag["completed"] is True and
            diag["final_source_verified"] is True and diag["compiled_source_before"] == diag["compiled_source_after"] and
            diag["binary_sha256"] == diag["binary_final_sha256"], "diagnostic integrity incomplete")
    require(len(diag["results"]) == 24 and all(r["exit_code"] == 0 for r in diag["results"]), "unexpected diagnostic outcomes")
    require(diag["helper_sha256"] == digest(read(local(lab, "shutdown-race/run_diagnostic.py"))), "diagnostic helper mismatch")
    diagnostic_files = walk(local(lab, "shutdown-race/linux-diagnostic"))
    failures = [name for name, blob in diagnostic_files.items() if re.fullmatch(r"immediate-drop-\d+\.log", name)
                and b"io_kind: Some(NotConnected)" in blob]
    require(set(failures) == {"immediate-drop-1.log", "immediate-drop-2.log", "immediate-drop-10.log"}, "unexpected diagnostic syscall evidence")
    state = b"peer_close=true local_close=true app_inflight=0 app_occupancy=0 wire_pending=0 tls_wants_write=false"
    for name in failures:
        require(state in diagnostic_files[name], "diagnostic guard state missing")
        prefix = name[:-4] + ".strace"
        require(any(b"ENOTCONN" in blob for name, blob in diagnostic_files.items() if name.startswith(prefix)), "matching syscall trace missing")

    package = spec["package"]
    folder = local(lab, package["folder"])
    files = walk(folder, selected=True)
    require({name: digest(blob) for name, blob in files.items()} == package["files"], "package evidence inventory mismatch")
    result, inventory = json.loads(files["result.json"]), json.loads(files["inventory.json"])
    require(result["status"] == "passed" and result["commit"] == FINAL_COMMIT and inventory["commit"] == FINAL_COMMIT,
            "package source/status mismatch")
    crate_blob = read(local(lab, package["crate"]), 256 * 1024 * 1024)
    require(digest(crate_blob) == package["sha256"] == result["package_sha256"] == inventory["package_sha256"], "package hash mismatch")
    with tarfile.open(fileobj=io.BytesIO(crate_blob)) as bundle:
        actual = {}
        for member in bundle.getmembers():
            name = safe_name(member.name)
            require(member.isfile() and name not in actual and member.size <= CAP, "invalid package member")
            blob = bundle.extractfile(member).read()
            check_payload(name, blob)
            actual[name] = digest(blob)
        require(actual == inventory["files"], "package inventory mismatch")
        vcs = json.load(bundle.extractfile("nbreq-0.2.0/.cargo_vcs_info.json"))
        require(vcs == inventory["vcs"] and vcs["git"]["sha1"] == FINAL_COMMIT and not vcs["git"].get("dirty"), "dirty/wrong package commit")
    for label, count in (("packaged-public-tests", 10), ("packaged-bundle-proof", 3), ("packaged-close-regressions", 5), ("packaged-final-shutdown", 2)):
        check_log(files[label + ".log"], [["ok", count, 0]])
    require(result["steps"] == ["compiler", "package", "packaged-public-tests", "packaged-bundle-proof", "packaged-close-regressions", "packaged-final-shutdown", "consumer-resolve", "consumer-default", "consumer-tree-default", "consumer-bundle", "consumer-tree-bundle"], "package/consumer steps incomplete")
    successful_steps(files, result["steps"])
    for label, enabled in (("consumer-default", "false"), ("consumer-bundle", "true")):
        require(("consumer trust construction passed; bundled-roots=" + enabled).encode() in files[label + ".log"], "consumer success evidence missing")
    require(digest(files["consumer-Cargo.lock"]) == "db49facebca64dec39ab37dadda16465fde74a001881d63a0fb578c332a8ae1e", "independent consumer graph changed")
    record_checks(files, package)
    for name, blob in files.items():
        add("package/" + name, blob)
    add("package/nbreq-e4edec8.crate", crate_blob, archive_payload=True)
    inventory_spec = spec["receipt_inventory"]
    inventory_blob = read(local(lab, inventory_spec["path"]))
    require(digest(inventory_blob) == inventory_spec["sha256"], "receipt inventory changed")
    inventory = json.loads(inventory_blob)
    expected_receipts = {(queue, identity) for queue, ids in inventory.items() for identity in ids}
    require(len(expected_receipts) == sum(len(ids) for ids in inventory.values()), "duplicate receipt inventory entry")
    require({(e["queue"], e["id"]) for e in spec["receipts"]} == expected_receipts and
            len(spec["receipts"]) == len(expected_receipts), "missing/duplicate bridge receipt")
    evidence_archives = {}
    for entry in spec["gates"] + spec["attachments"]:
        if entry.get("archive"):
            evidence_archives[entry["archive_sha256"]] = read(local(lab, entry["archive"]), 256 * 1024 * 1024)
    for entry in spec["receipts"]:
        blob = read(local(lab, entry["path"]))
        require(digest(blob) == entry["sha256"], "bridge receipt changed")
        receipt = json.loads(blob.decode("utf-8-sig"))
        require(receipt["id"] == entry["id"] and receipt["status"] in ("completed", "failed"), "incorrect/incomplete receipt")
        receipt_payloads(receipt, evidence_archives)
        add("receipts/" + safe_name(entry["queue"]) + "/" + Path(entry["path"]).name, blob)
    require(spec["receipts"], "bridge receipts missing")
    add("receipts/inventory.json", inventory_blob)
    return selected, {"final_commit": FINAL_COMMIT, "final_source": FINAL_SOURCE,
                      "previous_archive": spec["previous_archive"], "gates": gate_records,
                      "qualifications": spec["qualifications"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--index", type=Path)
    args = parser.parse_args()
    lab = Path(__file__).resolve().parent
    spec_bytes = read(args.spec.resolve())
    spec = json.loads(spec_bytes)
    selected, summary = verify(lab, spec)
    selected["appendix-inputs.json"] = spec_bytes
    selected["bundle_appendix.py"] = read(Path(__file__).resolve())
    selected["test_bundle_appendix.py"] = read(lab / "test_bundle_appendix.py")
    selected["appendix-integrity-tests.log"] = read(lab / "appendix-integrity-tests.log")
    metadata = json.dumps({"summary": summary, "files": {name: digest(blob) for name, blob in sorted(selected.items())}}, indent=2).encode()
    if args.archive:
        output = args.archive.resolve()
        require(lab in output.parents and not output.exists(), "archive must be a new lab path")
        index = args.index.resolve() if args.index else None
        if index is not None:
            require(lab in index.parents and not index.exists() and index != output, "index must be a separate new lab path")
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(prefix=".appendix-", suffix=".tmp", dir=output.parent, delete=False) as handle:
                temporary = Path(handle.name)
                with tarfile.open(fileobj=handle, mode="w:gz", compresslevel=9) as bundle:
                    for name, blob in list(sorted(selected.items())) + [("evidence-manifest.json", metadata)]:
                        item = tarfile.TarInfo(name)
                        item.size, item.mode = len(blob), 0o644
                        bundle.addfile(item, io.BytesIO(blob))
                handle.flush()
                os.fsync(handle.fileno())
            # Atomic publication that fails if another process created the name.
            os.link(temporary, output)
        finally:
            if temporary is not None:
                temporary.unlink()
        identity = {"archive": output.name, "sha256": digest(read(output, 256 * 1024 * 1024)),
                    "bytes": output.stat().st_size, "files": len(selected) + 1,
                    "spec_sha256": digest(spec_bytes), "helper_sha256": digest(selected["bundle_appendix.py"]),
                    "summary": summary}
        if index is not None:
            with index.open("x", encoding="utf-8") as handle:
                json.dump(identity, handle, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
        print(json.dumps(identity))
    else:
        require(args.index is None, "index requires archive publication")
        print(json.dumps({"status": "verified", "files": len(selected) + 1, "final_commit": FINAL_COMMIT}))


if __name__ == "__main__":
    main()
