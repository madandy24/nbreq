"""Run frozen Win32 portable verification on native Windows or the existing Wine5 prefix."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import struct

import owned_command as supervisor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--wine', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest_path = root / 'binary-manifest.json'
    manifest_bytes = manifest_path.read_bytes()
    identity = hashlib.sha256(manifest_bytes).hexdigest()
    manifest = json.loads(manifest_bytes)
    assert manifest['target'] == 'i686-pc-windows-msvc' and manifest['pe_machine'] == '0x014c'

    def verify():
        assert not manifest_path.is_symlink() and supervisor.sha(manifest_path) == identity
        for name, expected in manifest['files'].items():
            path = root / name
            assert not path.is_symlink() and root in path.resolve().parents
            assert supervisor.sha(path) == expected, name
        for name in ('nbreq', 'portable_tls', 'probe'):
            blob = (root / 'bin' / (name + '.exe')).read_bytes()
            assert blob[:2] == b'MZ'
            offset = struct.unpack_from('<I', blob, 0x3c)[0]
            assert blob[offset:offset + 4] == b'PE\0\0'
            assert struct.unpack_from('<H', blob, offset + 4)[0] == 0x14c

    verify()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env, prefix_args, shim_copy, failure = dict(os.environ), [], None, None
    steps = []
    host = dict(platform=platform.platform(), machine=platform.machine(), python=platform.python_version(),
                started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                manifest_sha256=identity, source=manifest['source'], commit=manifest['commit'],
                compiler=manifest['rustc'], target=manifest['target'])

    def run(label, argv, timeout=180, tests=None):
        supervisor.command(argv, root, out, label, env, timeout)
        if tests is not None:
            log = (out / (label + '.log')).read_text(encoding='utf-8', errors='replace')
            actual = re.findall(r'test result: ok\.\s+(\d+) passed;\s+0 failed', log)
            assert actual == [str(tests)], (label, actual, tests)
        steps.append(label)

    try:
        if args.wine:
            prefix = Path('/tmp/nbreq-wine-dns-lab-20260910/prefix')
            with (prefix / 'system.reg').open('rb') as registry:
                assert re.search(rb'(?m)^#arch=win32\s*$', registry.read(4096))
            shim = Path('/tmp/nbreq-wine-dns-gate-final-20260910/bcryptprimitives.dll')
            digest = '92d437dc538ef6ddfae7fc0b2140ec407a6dacfb0c899ec67a6812e84387de86'
            assert supervisor.sha(shim) == digest
            shim_copy = root / 'bin' / 'bcryptprimitives.dll'
            with shim.open('rb') as source, shim_copy.open('xb') as destination:
                shutil.copyfileobj(source, destination)
            assert supervisor.sha(shim_copy) == digest
            env.update(WINEPREFIX=str(prefix), WINEARCH='win32', WINEDEBUG='-all')
            prefix_args = [str(args.wine)]
            host.update(wine=str(args.wine), wineprefix=str(prefix), prefix_arch='win32', shim_sha256=digest)
            run('wine-version', [str(args.wine), '--version'], 15)
        supervisor.write(out / 'host.json', host)
        run('portable-public', prefix_args + [str(root / 'bin/portable_tls.exe'), '--test-threads=1',
                                             '--nocapture'], tests=10)
        run('portable-bundle-proof', prefix_args + [str(root / 'bin/nbreq.exe'), 'portable_tests',
                                                   '--test-threads=1', '--nocapture'], tests=3)
        for mode, port in [('imaps', '993'), ('smtp', '25')]:
            run('live-' + mode, prefix_args + [str(root / 'bin/probe.exe'), mode,
                'cavesvr3.caverock.com', port, '--bundled-roots'], 60)
    except BaseException as error:
        failure = repr(error)
    finally:
        try:
            verify()
            if shim_copy is not None:
                assert not shim_copy.is_symlink() and supervisor.sha(shim_copy) == digest
        except BaseException as error:
            failure = (failure + '; ' if failure else '') + 'final integrity: ' + repr(error)
        result = dict(status='failed' if failure else 'passed', failure=failure, steps=steps, **host)
        supervisor.write(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


if __name__ == '__main__':
    def terminate(_signal, _frame):
        raise SystemExit('Win32 verification received SIGTERM')
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
