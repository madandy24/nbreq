"""Bounded lab-only instrumentation; never modifies --source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

OWNED_OUT = None
SNAPSHOT = None
SNAPSHOT_HASHES = None
BINARY = None
BINARY_HASH = None


def inventory(root):
    files = {}
    for directory, dirs, names in os.walk(root, followlinks=False,
                                          onerror=lambda error: (_ for _ in ()).throw(error)):
        for name in dirs + names:
            if (Path(directory) / name).is_symlink():
                raise RuntimeError("symlink in diagnostic source")
        for name in names:
            path = Path(directory) / name
            files[path.relative_to(root).as_posix()] = sha(path)
    return files


def verify_executed():
    after = inventory(SNAPSHOT)
    if after != SNAPSHOT_HASHES:
        raise RuntimeError("copied source changed during diagnostic")
    if BINARY is not None and sha(BINARY) != BINARY_HASH:
        raise RuntimeError("diagnostic executable changed during run")
    return after

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized_sha(path):
    return hashlib.sha256(path.read_text(encoding="utf-8").encode()).hexdigest()


def replace_once(path, old, new):
    text = path.read_text(encoding="utf-8")
    if text.count(old) != 1:
        raise RuntimeError("instrumentation marker not unique: " + str(path))
    path.write_text(text.replace(old, new), encoding="utf-8")


def run(command, cwd, env, output, timeout, cap=4194304):
    with output.open("wb") as log:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        record = {"command": command, "pid": process.pid}
        try:
            until = time.monotonic() + timeout
            while process.poll() is None:
                trace_size = sum(p.stat().st_size for p in output.parent.glob(output.stem + ".strace*"))
                if time.monotonic() > until or output.stat().st_size > cap or trace_size > 16777216:
                    raise RuntimeError("command deadline/output bound: " + str(command))
                time.sleep(0.05)
            record["exit_code"] = process.wait()
            return record["exit_code"]
        except BaseException as error:
            record["failure"] = repr(error)
            raise
        finally:
            if "failure" in record:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=5)
            output.with_suffix(".result.json").write_text(json.dumps(record, indent=2))
            for trace in output.parent.glob(output.stem + ".strace*"):
                if trace.is_file() and not trace.is_symlink():
                    trace.rename(trace.with_name(trace.name + ".log"))


def verify_source(source, expected):
    identity = source / "portable-source.json"
    if sha(identity) != expected["manifest_sha256"]:
        raise RuntimeError("unexpected frozen source manifest")
    manifest = json.loads(identity.read_text())
    for name, digest in manifest["files"].items():
        path = source / name
        if path.is_symlink() or source not in path.resolve().parents or sha(path) != digest:
            raise RuntimeError("source identity mismatch: " + name)
    return manifest


def main():
    global OWNED_OUT, SNAPSHOT, SNAPSHOT_HASHES, BINARY, BINARY_HASH
    def terminate(signum, frame):
        raise RuntimeError("supervisor received termination signal")
    signal.signal(signal.SIGTERM, terminate)
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--attempts", type=int, default=12)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.attempts <= 50:
        parser.error("attempts must be 1..50")
    source, out = args.source.resolve(), args.out.resolve()
    if source == out or source in out.parents or out in source.parents:
        parser.error("source and output must be disjoint")
    if out.exists():
        parser.error("output must be new")
    expected = json.loads(Path(__file__).with_name("source-identity.json").read_text())
    checked = verify_source(source, expected)
    out.mkdir(parents=True)
    OWNED_OUT = out
    snapshot = out / "source"
    snapshot.mkdir()
    for name in ("Cargo.toml", "Cargo.lock", "README.md"):
        shutil.copy2(source / name, snapshot / name)
    for name in ("src", "tests", "support", "smtp", "examples", "docs"):
        shutil.copytree(source / name, snapshot / name,
                        ignore=shutil.ignore_patterns("target", ".git"))
    backend = snapshot / "src/backend/native_http.rs"
    replace_once(backend, """            self.reactor
                .shutdown_write(slot)
                .map_err(native_transport_error)?;
            live.write_shutdown = true;""", """            let shutdown_result = self.reactor.shutdown_write(slot);
            eprintln!("NBREQ_DIAG_FINAL_SHUTDOWN peer_close={} local_close={} app_inflight={} app_occupancy={} wire_pending={} tls_wants_write={} protocol={:?} result={:?}",
                live.peer_close_notify, live.local_close_notify, live.plaintext_inflight,
                live.transport.owner.send_occupancy(), live.wire_pending.len(),
                live.tls.wants_write(), live.tls.protocol_version(), shutdown_result);
            shutdown_result.map_err(native_transport_error)?;
            live.write_shutdown = true;""")
    fixture = snapshot / "tests/support/portable_tls_fixture.rs"
    replace_once(fixture, """            let _ = stream.flush();
            Ok(version)""", """            let close_flush = stream.flush();
            eprintln!("NBREQ_DIAG_SERVER_CLOSE protocol={version:?} flush={close_flush:?}");
            if version == ProtocolVersion::TLSv1_2
                && std::env::var_os("NBREQ_DIAG_WAIT_RECIPROCAL").is_some()
            {
                let mut byte = [0_u8; 1];
                let reciprocal = stream.read(&mut byte);
                eprintln!("NBREQ_DIAG_SERVER_RECIPROCAL {reciprocal:?}");
            }
            Ok(version)""")
    integration = snapshot / "tests/portable_tls.rs"
    replace_once(integration, """fn trusted_starttls_uses_supplied_roots_in_both_run_modes_and_tls_versions() {
    let identity = Identity::new("127.0.0.1", Invalid::None);
    for (manual, protocol) in [(false, Protocol::Tls12), (true, Protocol::Tls13)] {""", """fn trusted_starttls_uses_supplied_roots_in_both_run_modes_and_tls_versions() {
    let identity = Identity::new("127.0.0.1", Invalid::None);
    for (manual, protocol) in [(false, Protocol::Tls12)] {""")
    manifest = {"source": str(source), "checked_source": checked,
                "source_manifest_sha256": expected["manifest_sha256"],
                "helper_sha256": sha(Path(__file__)),
                "instrumented": {str(p.relative_to(snapshot)): sha(p)
                                 for p in (backend, fixture, integration)},
                "note": "No production fix. Wait mode is causal control, not remedy.",
                "results": []}
    SNAPSHOT = snapshot
    SNAPSHOT_HASHES = inventory(snapshot)
    manifest["compiled_source_before"] = SNAPSHOT_HASHES
    def save():
        (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    save()
    if args.prepare_only:
        verify_source(source, expected)
        manifest["compiled_source_after"] = verify_executed()
        save()
        return
    if not sys.platform.startswith("linux"):
        raise RuntimeError("execution is Linux-only; use --prepare-only for local review")
    env = dict(os.environ, CARGO_TARGET_DIR=str(out / "build"), CARGO_INCREMENTAL="0",
               CARGO_BUILD_JOBS="2", CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0")
    env.pop("NBREQ_DIAG_WAIT_RECIPROCAL", None)
    env.pop("CARGO_BUILD_TARGET", None)
    env.pop("RUST_TEST_THREADS", None)
    cargo = str(Path.home() / ".cargo/bin/cargo")
    env["PATH"] = str(Path(cargo).parent) + os.pathsep + env.get("PATH", "")
    overall = time.monotonic() + 300
    build = [cargo, "+stable", "test", "--locked", "--offline", "--no-default-features",
             "--features", "native", "--test", "portable_tls", "--no-run", "--message-format=json"]
    run([str(Path(cargo).with_name("rustc")), "+stable", "-vV"], snapshot, env, out / "compiler.log", 10)
    code = run(build, snapshot, env, out / "build.log", 180, 33554432)
    if code:
        raise RuntimeError("build failed: " + str(code))
    executables = []
    for line in (out / "build.log").read_text(errors="replace").splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if item.get("reason") == "compiler-artifact" and item.get("target", {}).get("name") == "portable_tls" and item.get("executable"):
            executables.append(item["executable"])
    if len(set(executables)) != 1:
        raise RuntimeError("expected one compiled test executable")
    test = [executables[0], "trusted_starttls_uses_supplied_roots_in_both_run_modes_and_tls_versions",
            "--exact", "--nocapture", "--test-threads=1"]
    BINARY = Path(executables[0])
    BINARY_HASH = sha(BINARY)
    manifest["binary_sha256"] = BINARY_HASH
    manifest["strace_available"] = shutil.which("strace")
    for mode in ("immediate-drop", "wait-reciprocal"):
        current_env = dict(env)
        if mode == "wait-reciprocal":
            current_env["NBREQ_DIAG_WAIT_RECIPROCAL"] = "1"
        for attempt in range(args.attempts):
            remaining = overall - time.monotonic()
            if remaining <= 0:
                raise RuntimeError("overall 300-second deadline")
            label = mode + "-" + str(attempt)
            command = test
            if manifest["strace_available"]:
                command = [manifest["strace_available"], "-ff", "-tt", "-e", "trace=network,close",
                           "-o", str(out / (label + ".strace"))] + test
            code = run(command, snapshot, current_env, out / (label + ".log"), min(12, remaining))
            manifest["results"].append({"mode": mode, "attempt": attempt, "exit_code": code,
                                        "log": label + ".log"})
            save()
    manifest["completed"] = True
    verify_source(source, expected)
    manifest["final_source_verified"] = True
    manifest["compiled_source_after"] = verify_executed()
    manifest["binary_final_sha256"] = sha(BINARY)
    save()
    (out / "result.json").write_text(json.dumps({"status": "completed", "purpose": "causal diagnosis; test failures are observations", "source": expected["manifest_sha256"], "results": manifest["results"]}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        # Keep partial command/results evidence and verify original source even on failure.
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument("--source", type=Path)
        parser.add_argument("--out", type=Path)
        args, _ = parser.parse_known_args()
        if OWNED_OUT is not None:
            result = {"completed": False, "failure": repr(error)}
            try:
                expected = json.loads(Path(__file__).with_name("source-identity.json").read_text())
                result["final_source"] = verify_source(args.source.resolve(), expected)
                result["final_source_verified"] = True
                if SNAPSHOT_HASHES is not None:
                    result["compiled_source_after"] = verify_executed()
                if BINARY is not None:
                    result["binary_final_sha256"] = sha(BINARY)
            except BaseException as integrity_error:
                result["final_source_error"] = repr(integrity_error)
            (OWNED_OUT / "failure.json").write_text(json.dumps(result, indent=2))
            (OWNED_OUT / "result.json").write_text(json.dumps({"status": "failed", **result}, indent=2))
        raise
