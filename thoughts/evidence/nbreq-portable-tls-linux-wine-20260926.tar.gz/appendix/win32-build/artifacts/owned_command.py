"""Bounded Rust-fixture checks and client-only observations; no external connections."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for data in iter(lambda: file.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def write(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def verify(root):
    path = root / 'fixture-source.json'
    manifest = json.loads(path.read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        source = root / name
        if source.is_symlink() or root not in source.resolve().parents or sha(source) != expected:
            raise RuntimeError('source identity mismatch: ' + name)
    return sha(path), manifest


def stop(child, log):
    def note(message):
        try:
            log.write((message + '\n').encode('utf-8'))
        except (OSError, ValueError):
            pass  # Evidence failure must never prevent owned-process cleanup.

    if os.name == 'nt':
        if child.poll() is None:
            try:
                result = subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'],
                                        stdout=log, stderr=subprocess.STDOUT, timeout=15, check=False)
                if result.returncode:
                    note('Process-tree stop failed; using the owned process handle.')
            except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                note('Process-tree stop error: ' + repr(error))
            if child.poll() is None:
                child.kill()
    else:
        # The observer and its fixture/client inherit this owned process group.
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
        # The leader exiting does not prove every member of its owned group exited.
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    child.wait(timeout=15)


def command(argv, root, out, label, env, timeout):
    print(label, flush=True)
    started = time.monotonic()
    record = dict(command=argv, cwd=str(root), timeout_seconds=timeout)
    with (out / (label + '.log')).open('xb') as log:
        child = subprocess.Popen(argv, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=os.name != 'nt')
        try:
            write(out / 'command.json', dict(label=label, pid=child.pid, **record))
            record['exit_code'] = child.wait(timeout=timeout)
        except BaseException as error:
            record['failure'] = repr(error)
            stop(child, log)
            raise
        finally:
            record['exit_code'] = child.returncode
            record['elapsed_seconds'] = time.monotonic() - started
            write(out / (label + '.result.json'), record)
    if record['exit_code']:
        raise RuntimeError(label + ' failed: exit ' + str(record['exit_code']))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['launch', 'run'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--probe', type=Path, required=True)
    parser.add_argument('--probe-sha256', required=True)
    parser.add_argument('--msrv', action='store_true')
    args = parser.parse_args()
    root, out, probe = (p.resolve() for p in (args.root, args.out, args.probe))
    if args.mode == 'launch':
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, '-B', str(Path(__file__).resolve()), 'run',
                '--root', str(root), '--out', str(out), '--probe', str(probe),
                '--probe-sha256', args.probe_sha256]
        if args.msrv:
            argv.append('--msrv')
        with (out / 'job.log').open('xb') as log:
            child = None
            try:
                child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log,
                                         stderr=log, start_new_session=os.name != 'nt', close_fds=True)
                record = dict(command=argv, pid=child.pid, out=str(out))
                write(out / 'launch.json', record)
            except BaseException:
                if child is not None:
                    stop(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0

    out.mkdir(parents=True, exist_ok=True)
    # A duplicate run must fail before it can replace prior host/result records.
    with (out / 'run.token').open('xb') as token:
        token.write(json.dumps(dict(pid=os.getpid(), root=str(root))).encode('utf-8'))
    failure, source, fixture_hash = None, None, None
    started = time.monotonic()
    try:
        source, manifest = verify(root)
        if probe.is_symlink() or not probe.is_file() or sha(probe) != args.probe_sha256:
            raise RuntimeError('existing client probe identity mismatch')
        write(out / 'host.json', dict(platform=platform.platform(), machine=platform.machine(),
                                     python=sys.version, source=source, commit=manifest['commit'],
                                     client_probe=str(probe), client_probe_sha256=sha(probe),
                                     started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        env = dict(os.environ)
        env['PATH'] = str(Path.home() / '.cargo' / 'bin') + os.pathsep + env.get('PATH', '')
        env.update(CARGO_TARGET_DIR=str(out / 'build'), CARGO_BUILD_JOBS='2',
                   CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
        suffix = '.exe' if os.name == 'nt' else ''
        cargo = str(Path.home() / '.cargo' / 'bin' / ('cargo' + suffix))
        rustc = str(Path(cargo).with_name('rustc' + suffix))
        package = ['--manifest-path', 'tools/tcp-tls-fixture/Cargo.toml']
        command([rustc, '+stable', '-vV'], root, out, 'stable-compiler', env, 30)
        command([cargo, '+stable', 'fetch', '--locked'] + package, root, out, 'fetch', env, 300)
        command([sys.executable, '-B', 'test_platform.py'], root, out, 'supervisor-tests', env, 90)
        command([sys.executable, '-B', '-m', 'unittest', 'discover', '-s',
                 'tools/tcp-tls-probe', '-p', 'test_memory.py', '-v'],
                root, out, 'observer-tests', env, 120)
        command([cargo, '+stable', 'test', '--locked', '--offline'] + package,
                root, out, 'fixture-tests', env, 600)
        command([cargo, '+stable', 'clippy', '--locked', '--offline'] + package +
                ['--all-targets', '--', '-D', 'warnings'], root, out, 'fixture-clippy', env, 600)
        if args.msrv:
            command([rustc, '+1.85.0', '-vV'], root, out, 'msrv-compiler', env, 30)
            command([cargo, '+1.85.0', 'test', '--locked', '--offline'] + package,
                    root, out, 'msrv-tests', env, 600)
        command([cargo, '+stable', 'build', '--locked', '--offline', '--release'] + package,
                root, out, 'fixture-release', env, 600)
        fixture = out / 'build' / 'release' / ('tcp-tls-fixture' + suffix)
        fixture_hash = sha(fixture)
        for version in ('1.2', '1.3'):
            command([sys.executable, '-B', 'tools/tcp-tls-probe/memory.py',
                     '--binary', str(probe), '--fixture-binary', str(fixture),
                     '--out', str(out / ('memory-' + version)), '--tls-version', version],
                    root, out, 'observe-' + version, env, 420)
    except BaseException as error:
        failure = repr(error)
    finally:
        try:
            final_source, _ = verify(root)
            if final_source != source or sha(probe) != args.probe_sha256:
                raise RuntimeError('source/client identity changed during checks')
            if fixture_hash is not None and sha(fixture) != fixture_hash:
                raise RuntimeError('server fixture changed during checks')
        except BaseException as error:
            failure = (failure + '; ' if failure else '') + 'final integrity: ' + repr(error)
    result = dict(status='failed' if failure else 'passed', failure=failure,
                  source=source, probe_sha256=args.probe_sha256, fixture_sha256=fixture_hash,
                  elapsed_seconds=time.monotonic() - started)
    write(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


if __name__ == '__main__':
    def terminate(_signum, _frame):
        raise SystemExit('platform supervisor received SIGTERM')
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
