use nbreq::{Engine, EngineConfig, ErrorKind, TlsTrust};
fn main() {
    let default = EngineConfig::spawned();
    assert_eq!(default.tls_trust(), TlsTrust::Platform);
    let _platform = Engine::new(default).expect("platform construction");
    let der = include_bytes!("../../nbreq-0.2.0/tests/fixtures/portable-trust/cavesvr3-chain-2.der");
    let _supplied = Engine::new(EngineConfig::spawned()
        .with_tls_trust(TlsTrust::SuppliedRootsOnly)
        .with_additional_tls_root_certificate(der.to_vec())).expect("supplied construction");
    let bundled = Engine::new(EngineConfig::spawned().with_tls_trust(TlsTrust::BundledMozilla));
    if cfg!(feature = "bundled-roots") { assert!(bundled.is_ok()); }
    else { assert_eq!(bundled.err().expect("missing optional feature").kind(), ErrorKind::Unsupported); }
    println!("consumer trust construction passed; bundled-roots={}", cfg!(feature = "bundled-roots"));
}
