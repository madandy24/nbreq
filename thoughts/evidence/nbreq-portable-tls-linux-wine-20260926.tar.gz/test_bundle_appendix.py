"""Focused integrity failures for the evidence appendix verifier; no production edits."""
import io
import base64
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

import bundle_appendix as b


class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="appendix-proof-", dir=Path(__file__).parent)
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def fixture(self, stale=False):
        result = {"status": "passed", "source": "old", "commit": "old-commit"}
        files = {"result.json": json.dumps(result).encode(), "test.log": b"test result: ok. 2 passed; 0 failed\n"}
        metadata = {"result": {**result, "status": "failed"} if stale else result,
                    "files": {n: b.digest(v) for n, v in files.items()}}
        files["evidence-manifest.json"] = json.dumps(metadata).encode()
        folder = self.root / "extracted"
        folder.mkdir()
        path = self.root / "evidence.tar.gz"
        with tarfile.open(path, "x:gz") as archive:
            for name, blob in files.items():
                entry = tarfile.TarInfo(name)
                entry.size = len(blob)
                archive.addfile(entry, io.BytesIO(blob))
                (folder / name).write_bytes(blob)
        return path, b.digest(path.read_bytes()), folder

    def test_valid_retrieval_preserves_historical_identity(self):
        path, digest, folder = self.fixture()
        metadata, _, _ = b.archive(path, digest, "evidence-manifest.json", folder)
        b.check_source(metadata["result"], "old", "old-commit", "historical")

    def test_wrong_final_source_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "source/commit mismatch"):
            b.check_source({"source": "old", "commit": b.FINAL_COMMIT}, b.FINAL_SOURCE, b.FINAL_COMMIT, "final")

    def test_extracted_file_tamper_is_rejected(self):
        path, digest, folder = self.fixture()
        (folder / "test.log").write_text("changed")
        with self.assertRaisesRegex(ValueError, "exact archive file set"):
            b.archive(path, digest, "evidence-manifest.json", folder)

    def test_extra_extracted_file_is_rejected(self):
        path, digest, folder = self.fixture()
        (folder / "unexpected.txt").write_text("extra")
        with self.assertRaisesRegex(ValueError, "exact archive file set"):
            b.archive(path, digest, "evidence-manifest.json", folder)

    def test_stale_embedded_result_is_rejected(self):
        path, digest, folder = self.fixture(stale=True)
        with self.assertRaisesRegex(ValueError, "stale embedded"):
            b.archive(path, digest, "evidence-manifest.json", folder)

    def test_wrong_archive_hash_is_rejected(self):
        path, _, folder = self.fixture()
        with self.assertRaisesRegex(ValueError, "archive hash mismatch"):
            b.archive(path, "0" * 64, "evidence-manifest.json", folder)

    def test_incomplete_test_count_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "counts differ"):
            b.check_log(b"test result: ok. 1 passed; 0 failed", [["ok", 2, 0]])

    def test_failed_step_cannot_hide_behind_passing_summary(self):
        files = {"result.json": b'{"status":"passed"}',
                 "live-smtp.result.json": b'{"exit_code":1}',
                 "live-smtp.log": b"TLS trust: BundledMozilla\nverified SMTP STARTTLS"}
        with self.assertRaisesRegex(ValueError, "failed command step"):
            b.successful_steps(files, ["live-smtp"])

    def test_zero_exit_with_recorded_failure_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "failed command step"):
            b.successful_steps({"consumer.result.json": b'{"exit_code":0,"failure":"timeout"}'}, ["consumer"])

    def test_unapproved_encoded_receipt_archive_is_rejected(self):
        blob = b"MZnot-allowed"
        payload = dict(base64=base64.b64encode(blob).decode(), sha256=b.digest(blob),
                       chunk_sha256=b.digest(blob), part=0, parts=1)
        with self.assertRaisesRegex(ValueError, "unapproved archive"):
            b.receipt_payloads({"output": json.dumps(payload)}, {})

    def test_encoded_receipt_matches_verified_archive_bytes(self):
        blob = b"verified evidence archive bytes"
        payload = dict(base64=base64.b64encode(blob).decode(), sha256=b.digest(blob),
                       chunk_sha256=b.digest(blob), part=0, parts=1)
        b.receipt_payloads({"output": json.dumps(payload)}, {b.digest(blob): blob})
        payload["base64"] = base64.b64encode(b"tampered").decode()
        payload["chunk_sha256"] = b.digest(b"tampered")
        with self.assertRaisesRegex(ValueError, "differs from verified evidence"):
            b.receipt_payloads({"output": json.dumps(payload)}, {b.digest(blob): blob})

    def test_duplicate_member_is_rejected(self):
        path = self.root / "duplicate.tar.gz"
        with tarfile.open(path, "x:gz") as archive:
            for _ in range(2):
                member = tarfile.TarInfo("result.json")
                member.size = 2
                archive.addfile(member, io.BytesIO(b"{}"))
        with self.assertRaisesRegex(ValueError, "duplicate/nonfile"):
            b.archive(path, b.digest(path.read_bytes()), "evidence-manifest.json")


if __name__ == "__main__":
    unittest.main(verbosity=2)
