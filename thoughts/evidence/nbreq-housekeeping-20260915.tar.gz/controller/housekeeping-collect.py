from pathlib import Path, PurePosixPath
import hashlib, io, json, re, subprocess, tarfile

main=Path('C:/User/projects/nbreq')
root=main/'target/worktrees/nbreq-r5'
work=main/'target/housekeeping-20260915'
final=work/'final-check'
assert json.loads((final/'result.json').read_text())['status']=='passed'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert json.loads((final/'result.json').read_text())['source_commit']==commit
snapshot=json.loads((work/'snapshot.json').read_text())['commit']
expected={
    'SECURITY.md','docs/getting-started.md','docs/migrating-to-0.2.md',
    'thoughts/nbreq_020_release_plan.md','thoughts/nbreq_housekeeping.md',
    'thoughts/nbreq_memory_plan.md','tools/f5-observe/README.md',
    'tools/f5-observe/compare.py','tools/f5-observe/src/main.rs'}
actual=set(subprocess.check_output(['git','diff','--name-only',snapshot,commit],cwd=root,text=True).splitlines())
assert actual==expected,actual
files={}
def add(path,name):
    assert name not in files
    assert path.is_file()
    files[name]=path
for name in ['main-before.json','main-status-before.txt','snapshot.json','reconciliation.json','inherited-archive-audit.json']:
    add(work/name,'checkpoint/'+name)
for name in ['housekeeping-snapshot.py','housekeeping-reconcile.py','housekeeping-tools-check.py','housekeeping-final-check.py','housekeeping-collect.py','housekeeping-audit.py']:
    add(main/'target'/name,'controller/'+name)
for directory in ['tools-check','tools-check-b']:
    for path in sorted((work/directory).rglob('*')):
        if path.is_file() and path.suffix in {'.json','.log','.stderr','.txt'}:
            add(path,directory+'/'+path.relative_to(work/directory).as_posix())
for directory in [final,final/'local-examples',final/'packages',final/'consumers',final/'consumers/examples']:
    for path in sorted(directory.iterdir()):
        if path.is_file() and (path.suffix in {'.json','.log','.lock'} or path.name.endswith('Cargo.lock')):
            add(path,'final-check/'+path.relative_to(final).as_posix())
for path in sorted((final/'packages/build/package').glob('*.crate')):
    add(path,'packages/'+path.name)
inputs=['Cargo.toml','Cargo.lock','.gitignore','.github/workflows/ci.yml',
    'tools/f5-observe/Cargo.toml','tools/f5-observe/Cargo.lock','tools/f5-observe/src/main.rs',
    'tools/f5-observe/v011/Cargo.toml','tools/f5-observe/v011/Cargo.lock',
    'tools/f5-observe/memory/Cargo.toml','tools/f5-observe/memory/Cargo.lock',
    'tools/f5-observe/memory/run.py','tools/f5-observe/memory/src/client.rs',
    'tools/release-consumer/run.py','tools/release-consumer/package_candidate.py',
    'tools/release-consumer/check_examples.py']
for rel in inputs:
    add(root/rel,'inputs/'+rel)
record=dict(schema='nbreq-housekeeping-evidence-v1',source_commit=commit,
    snapshot_commit=snapshot,snapshot_branch='codex/main-before-housekeeping-20260915',
    snapshot_file_count=313,snapshot_changed_paths=147,
    intentional_differences_from_snapshot=sorted(expected),unchanged_core_inputs=81,
    validation=json.loads((final/'result.json').read_text()),
    packages=json.loads((final/'packages/packages.json').read_text()),
    registry_only=False,performance_claim=False,files={})
secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
for name,path in files.items():
    data=path.read_bytes()
    assert not secret.search(data),'Credential-shaped data in '+name
    assert len(data)<15_000_000,(name,len(data))
    record['files'][name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
archive=root/'thoughts/evidence/nbreq-housekeeping-20260915.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as bundle:
    for name,path in sorted(files.items()):
        data=path.read_bytes()
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
        bundle.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as bundle:
    members=bundle.getmembers()
    assert len(members)==len(files)
    for entry in members:
        assert entry.isfile() and not PurePosixPath(entry.name).is_absolute() and '..' not in PurePosixPath(entry.name).parts
        assert hashlib.sha256(bundle.extractfile(entry).read()).hexdigest()==record['files'][entry.name]['sha256']
record.update(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),file_count=len(files))
(root/'thoughts/evidence/nbreq_housekeeping_artifacts.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:record[key] for key in ['source_commit','archive','bytes','sha256','file_count']}))
