from pathlib import Path
import hashlib, json, subprocess

main=Path('C:/User/projects/nbreq')
root=main/'target/worktrees/nbreq-r5'
out=main/'target/housekeeping-20260915'
snapshot=json.loads((out/'snapshot.json').read_text())['commit']
adopt=[
 '.gitignore','tools/f5-observe/Cargo.lock','tools/f5-observe/memory/run.py',
 'tools/f5-observe/memory/src/client.rs','thoughts/nbreq_020_consumer_readiness.md',
 'thoughts/nbreq_memory_plan.md','thoughts/nbreq_wine_dns.md','thoughts/project_nbreq_followup_plan.html',
 'thoughts/evidence/nbreq-020-candidates-20260910.tar.gz',
 'thoughts/evidence/nbreq-wine-dns-20260910.tar.gz',
 'thoughts/evidence/nbreq_020_candidate_artifacts.json',
 'thoughts/evidence/nbreq_wine_dns_artifacts.json','thoughts/nbreq_020_clean_candidates.md',
]
record={}
for rel in adopt:
    path=root/rel
    blob=subprocess.check_output(['git','show',snapshot+':'+rel],cwd=main)
    record[rel]=dict(previous=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None,
                    adopted=hashlib.sha256(blob).hexdigest(),snapshot=snapshot)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(blob)
for manifest in ['nbreq_020_candidate_artifacts.json','nbreq_wine_dns_artifacts.json']:
    meta=json.loads((root/'thoughts/evidence'/manifest).read_text())
    archive=root/'thoughts/evidence'/meta['archive']
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['sha256']
    assert archive.stat().st_size==meta['bytes']
sourcefiles=subprocess.check_output(['git','ls-files','-z','src','tests','support','Cargo.toml','Cargo.lock'],cwd=root).decode().rstrip('\0').split('\0')
for rel in sourcefiles:
    expected=subprocess.check_output(['git','show',snapshot+':'+rel],cwd=main)
    actual=(root/rel).read_bytes()
    assert actual.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n'),rel
(out/'reconciliation.json').write_text(json.dumps(dict(adopted=record,unchanged_core_files=len(sourcefiles)),indent=2))
print(f'Adopted {len(adopt)} main files; verified {len(sourcefiles)} unchanged core inputs and both historical archives')
