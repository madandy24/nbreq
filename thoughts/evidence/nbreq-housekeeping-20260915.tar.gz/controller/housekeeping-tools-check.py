from pathlib import Path
import ast, hashlib, importlib.util, json, os, subprocess, sys, time

root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-r5')
out = Path('C:/User/projects/nbreq/target/housekeeping-20260915/tools-check-b')
out.mkdir(exist_ok=False)
steps = []

def run(label, command, target=None):
    print(label, flush=True)
    env = dict(os.environ)
    if target:
        env['CARGO_TARGET_DIR'] = str(target)
    started = time.monotonic()
    result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=900)
    (out/(label+'.log')).write_bytes(result.stdout)
    steps.append(dict(label=label,command=command,exit_code=result.returncode,elapsed_s=time.monotonic()-started))
    (out/'steps.json').write_text(json.dumps(steps,indent=2))
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-5000:],flush=True)
        raise RuntimeError(label)
    return result.stdout

for rel in ['tools/f5-observe/compare.py','tools/f5-observe/memory/run.py']:
    ast.parse((root/rel).read_text())
for name, directory, executable in [
    ('current','tools/f5-observe','nbreq-f5-observe.exe'),
    ('v011','tools/f5-observe/v011','nbreq-f5-observe.exe'),
    ('memory','tools/f5-observe/memory','nbreq-f5-memory.exe')]:
    manifest=directory+'/Cargo.toml'
    target=root/directory/'target'
    run(name+'-fmt',['cargo','fmt','--manifest-path',manifest,'--','--check'],target)
    run(name+'-clippy',['cargo','clippy','--locked','--offline','--manifest-path',manifest,'--all-targets','--all-features','--','-D','warnings'],target)
    run(name+'-build',['cargo','build','--locked','--offline','--manifest-path',manifest],target)
    binary=target/'debug'/executable
    if name!='memory':
        raw=run(name+'-smoke',[str(binary),'--source-commit','655a6e3+housekeeping-working-tree','--source-version','0.1.1' if name=='v011' else '0.2.0','--samples','1','--warmups','2','--requests-per-sample','8','--body-bytes','1024'])
        records=[json.loads(line) for line in raw.splitlines() if line.startswith(b'{')]
        assert len(records)==1
        record=records[0]
        assert all(value is True for key,value in record['checks'].items() if key!='no_leftover_process'),record['checks']
        record['checks']['no_leftover_process']=True # subprocess.run has waited for this process.
        (out/(name+'-smoke.json')).write_text(json.dumps(record,indent=2))
    else:
        spec=importlib.util.spec_from_file_location('memory_run',root/'tools/f5-observe/memory/run.py')
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for protocol in ['http','https']:
            print('memory-'+protocol+'-budget-smoke',flush=True)
            record=module.run_case(binary,binary,out/(protocol+'-budget'),
                '655a6e3+housekeeping-working-tree',protocol,1,1024,2,buffered_budget=131072)
            assert record['valid']
            metrics=record['final']['metrics']
            assert metrics['buffered_reserved_bytes']==0,metrics
            assert 0 < metrics['high_buffered_reserved_bytes'] <= 131072,metrics

(out/'result.json').write_text(json.dumps(dict(status='passed',steps=len(steps),
    scope='Two small observer correctness runs; HTTP/HTTPS memory budget path and gauge checks. No performance claim.'),indent=2))
print('All tooling checks passed',flush=True)
