from pathlib import Path
import hashlib, json, subprocess

root=Path('C:/User/projects/nbreq')
out=root/'target/housekeeping-20260915'
out.mkdir(exist_ok=False)
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
assert git('branch','--show-current').decode().strip()=='main'
assert git('rev-parse','HEAD').decode().strip()=='2c382b7c6f66124c9458fef75d92244950fc7762'
assert not git('diff','--cached','--name-only'), 'Preserve an unexpected preexisting index'
branch='codex/main-before-housekeeping-20260915'
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=root).returncode==1
paths=set(git('ls-files','-z','--cached','--others','--exclude-standard').decode().rstrip('\0').split('\0'))
files={}
for rel in sorted(paths):
    p=root/rel
    if p.is_file():
        assert root.resolve() in p.resolve().parents
        files[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'main-before.json').write_text(json.dumps(dict(head=git('rev-parse','HEAD').decode().strip(),branch=branch,files=files),indent=2))
status=git('status','--porcelain=v1','-uall')
(out/'main-status-before.txt').write_bytes(status)
subprocess.run(['git','switch','-c',branch],cwd=root,check=True)
# These exact repository paths were inventoried; ignored outputs are not staged.
subprocess.run(['git','add','--all','--',*sorted(paths)],cwd=root,check=True)
subprocess.run(['git','commit','-m','Preserve main working state before release reconciliation'],cwd=root,check=True)
commit=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain=v1','-uall')
(out/'snapshot.json').write_text(json.dumps(dict(branch=branch,commit=commit,files=len(files)),indent=2))
print(json.dumps(dict(snapshot=commit,branch=branch,files=len(files)),indent=2))
# All main-only content is now recoverable from the snapshot commit; leave the old main selected.
subprocess.run(['git','switch','main'],cwd=root,check=True)
assert not git('status','--porcelain=v1','-uall')
