from pathlib import Path
import hashlib, json, os, subprocess, sys, time

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-r5')
out=Path('C:/User/projects/nbreq/target/housekeeping-20260915/final-check')
out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
steps=[]
def run(label,command,timeout=1800):
    print(label,flush=True)
    started=time.monotonic()
    result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    (out/(label+'.log')).write_bytes(result.stdout)
    steps.append(dict(label=label,command=command,exit_code=result.returncode,elapsed_s=time.monotonic()-started))
    (out/'steps.json').write_text(json.dumps(steps,indent=2))
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:],flush=True)
        raise RuntimeError(label)
    print(label+' passed',flush=True)
    return result.stdout

versions=run('versions',['rustup','show'])
run('verifier',['cargo','run','--locked','--offline','--manifest-path','tools/xtask/Cargo.toml','--','verify','--offline'])
run('build-examples',['cargo','build','--locked','--offline','--examples'])
run('local-examples',[sys.executable,'tools/release-consumer/check_examples.py','--bin-dir',str(root/'target/debug/examples'),'--out',str(out/'local-examples')])
run('packages',[sys.executable,'tools/release-consumer/package_candidate.py','--out',str(out/'packages')])
packages=out/'packages/build/package'
run('packaged-consumers',[sys.executable,'tools/release-consumer/run.py',
    '--package',str(packages/'nbreq-0.2.0.crate'),
    '--darwin-package',str(packages/'nbreq-darwin-0.1.0.crate'),
    '--winpoll-package',str(packages/'nbreq-winpoll-0.1.1.crate'),
    '--out',str(out/'consumers'),'--offline','--toolchains','stable','1.85.0'])
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
(out/'result.json').write_text(json.dumps(dict(status='passed',source_commit=commit,registry_only=False,
    package_overrides='Exact locally frozen Darwin/winpoll archives, not registry-only proof',
    steps=steps),indent=2))
print('Final local verification passed at '+commit,flush=True)
