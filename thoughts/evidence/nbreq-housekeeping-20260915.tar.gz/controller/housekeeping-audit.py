from pathlib import Path, PurePosixPath
from collections import Counter
import hashlib, io, json, re, subprocess, tarfile

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-r5')
work=Path('C:/User/projects/nbreq/target/housekeeping-20260915')
remote='bdf5db590e4da6ee5a1534f408a370787453cff5'
names=['nbreq-r5-technical-20260915.tar.gz','nbreq-wine-dns-20260910.tar.gz','nbreq-020-candidates-20260910.tar.gz']
secret=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
results=[]
for name in names:
    path=root/'thoughts/evidence'/name
    record=dict(archive=name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),credential_shape_matches=[],files=0,nested_files=0,extensions={})
    suffixes=Counter()
    def inspect(blob,prefix='',depth=0):
        assert depth<5
        with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
            seen=set()
            for member in archive.getmembers():
                memberpath=PurePosixPath(member.name)
                assert not memberpath.is_absolute() and '..' not in memberpath.parts
                assert member.name not in seen
                seen.add(member.name)
                if member.isdir():
                    continue
                assert member.isfile(),(name,member.name,'not a regular file or directory')
                location=prefix+member.name
                record['nested_files' if depth else 'files']+=1
                suffixes[memberpath.suffix]+=1
                content=archive.extractfile(member).read()
                if secret.search(content):
                    record['credential_shape_matches'].append(location)
                if member.name.endswith(('.tar.gz','.crate')):
                    inspect(content,location+'!/',depth+1)
    inspect(path.read_bytes())
    record['extensions']=dict(suffixes)
    results.append(record)
(work/'inherited-archive-audit.json').write_text(json.dumps(dict(remote_r5=remote,archives=results),indent=2))
print(json.dumps(results,indent=2))
