#!/bin/sh
set -eu
lab=/Users/m1/nbreq-m2-response-20260907
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR=/Users/m1/nbreq-m1-20260905-b/target
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export RUSTUP_TOOLCHAIN=1.85.0
trap 'code=$?; printf "%s\n" "$code" > "$lab/verified-final.exit"' EXIT
cd "$lab/nbreq"
cp "$lab/verify-final-1.85.0.log" "$lab/verify-final-1.85.0-first-failure.log"
for iteration in 1 2 3 4 5; do
    cargo test --locked --offline --features native,test-support --lib backend::native_http::tests::cancel_and_shutdown_wake_blocked_upload_producers -- --exact --nocapture > "$lab/arm-stream-recheck-$iteration.log" 2>&1
done
"$lab/runner-1.85.0/debug/nbreq-xtask" verify --offline > "$lab/verify-final-1.85.0.log" 2>&1
python3 - "$lab" <<'PY'
import pathlib,sys,hashlib
lab=pathlib.Path(sys.argv[1])
log=(lab/'verify-final-1.85.0.log').read_text()
assert 'NBReq verification root: '+str(lab/'nbreq') in log.splitlines()[0]
assert 'test response_body_tests::m2_response_clone_shares_immutable_body_storage ... ok' in log
assert 'NBReq verification complete: all 24 steps passed' in log
rows=[line.split('  ',1) for line in pathlib.Path('m2-source.sha256').read_text().splitlines()]
assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows)
print('ARM_UNCHANGED_SOURCE_MSRV_PASS')
print(log.splitlines()[-1])
PY
