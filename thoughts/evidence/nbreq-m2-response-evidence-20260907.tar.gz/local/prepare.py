from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

out = Path('target/m2')
names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')
prefixes = ('src/', 'tests/', 'support/', 'examples/', 'docs/', 'tools/xtask/', 'tools/f5-observe/')
roots = {'Cargo.toml', 'Cargo.lock', 'README.md', 'SECURITY.md', 'LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.html', '.gitignore', 'rustfmt.toml'}
files = {name: Path(name).read_bytes() for name in names if (name in roots or name.startswith(prefixes)) and Path(name).is_file() and '/target/' not in name and '/__pycache__/' not in name}
for name in ('Cargo.lock', 'tools/f5-observe/memory/Cargo.lock', 'tools/f5-observe/memory/meter/Cargo.lock'):
    files[name] = Path(name).read_bytes()
with tarfile.open('thoughts/evidence/nbreq-m1-source-c.tar.gz') as old:
    prior = {member.name.removeprefix('nbreq/'): old.extractfile(member).read() for member in old.getmembers() if member.isfile()}
changed = sorted(name for name, data in files.items() if prior.get(name) != data)
expected = ['docs/getting-started.md', 'src/body.rs', 'src/client.rs', 'src/lib.rs', 'src/registry.rs', 'src/response_body_tests.rs', 'src/types.rs']
assert changed == expected, changed
for name in ('remote.sh', 'compare.py'):
    files['m2-' + name] = (out / name).read_bytes().replace(b'\r\n', b'\n')
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
files['m2-source.sha256'] = manifest
path = out / 'nbreq-m2-response-20260907.tar.gz'
with tarfile.open(path, 'w:gz') as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo('nbreq/' + name)
        info.size = len(data)
        info.mode = 0o755 if name.endswith('.sh') else 0o644
        archive.addfile(info, io.BytesIO(data))
result = dict(path=str(path.resolve()), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), manifest_sha256=hashlib.sha256(manifest).hexdigest(), files=len(files), changed_from_m1_c=changed)
(out / 'bundle.json').write_text(json.dumps(result, indent=2))
(out / 'source.sha256').write_bytes(manifest)
print(json.dumps(result))
