from pathlib import Path
import base64
import hashlib
import io
import json
import sys
import tarfile

lab = Path(sys.argv[1]).resolve()
assert lab.name == 'nbreq-m2-response-20260907'
assert (lab / 'verified-final.exit').read_text().strip() == '0'
for toolchain in ['stable','1.85.0']:
    log=(lab / f'verify-final-{toolchain}.log').read_text()
    assert f'NBReq verification root: {lab}/nbreq' in log.splitlines()[0]
    assert 'test response_body_tests::m2_response_clone_shares_immutable_body_storage ... ok' in log
    assert 'NBReq verification complete: all 24 steps passed' in log
files = {p.relative_to(lab).as_posix():p.read_bytes() for p in lab.glob('*.log')}
for name in ['run.exit','verified-current.exit','verified-final.exit','nbreq/m2-source.sha256']:
    files[name]=(lab/name).read_bytes()
if (lab/'comparison-final').exists():
    cases=json.loads((lab/'comparison-final/results.json').read_text())
    assert len(cases)==60 and all(c['valid'] for c in cases)
    assert all(child['joined'] and child['exit_code']==0 and not child['forced'] for c in cases for child in c['cleanup'])
    prior=json.loads((lab.parent/'nbreq-m1-20260905-c/baseline/provenance.json').read_text())
    current=json.loads((lab/'comparison-final/provenance.json').read_text())
    assert all(prior['binaries'][mode]['sha256']==current['binaries']['before'][mode]['sha256'] for mode in ['plain','meter'])
    for p in (lab/'comparison-final').rglob('*'):
        if p.is_file(): files[p.relative_to(lab).as_posix()]=p.read_bytes()
manifest=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
files['evidence.sha256']=manifest
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
payload=buf.getvalue()
print('M2_ARCHIVE_SHA256',hashlib.sha256(payload).hexdigest())
print('M2_ARCHIVE_BASE64',base64.b64encode(payload).decode())
