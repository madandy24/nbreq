from pathlib import Path
import base64
import hashlib
import io
import json
import re
import sys
import tarfile

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
assert receipt['ok'] and receipt['exit_code']==0 and receipt['status']=='completed'
payload = base64.b64decode(re.search(r'M2_ARCHIVE_BASE64 ([A-Za-z0-9+/=]+)',receipt['output']).group(1), validate=True)
expected = re.search(r'M2_ARCHIVE_SHA256 ([a-f0-9]{64})',receipt['output']).group(1)
assert hashlib.sha256(payload).hexdigest()==expected
destination = Path(sys.argv[2]).resolve()
destination.mkdir(parents=True,exist_ok=False)
files = {}
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    for member in archive.getmembers():
        assert member.isfile()
        target=(destination/member.name).resolve()
        assert target.is_relative_to(destination)
        data=archive.extractfile(member).read()
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        files[member.name]=data
for line in files['evidence.sha256'].decode().splitlines():
    digest,name=line.split('  ',1)
    assert hashlib.sha256(files[name]).hexdigest()==digest
destination.with_suffix('.tar.gz').write_bytes(payload)
print('EVIDENCE_RECEIVED',len(files),len(payload),expected,str(destination))
