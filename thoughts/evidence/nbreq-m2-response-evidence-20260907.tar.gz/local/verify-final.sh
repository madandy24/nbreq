#!/bin/sh
set -eu
lab=$1
previous=$2
scope=$3
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$previous/target"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
trap 'code=$?; printf "%s\n" "$code" > "$lab/verified-final.exit"' EXIT
cd "$lab/nbreq"
attempt=0
while ! test -f "$lab/run.exit" || ! test -f "$lab/verified-current.exit"; do
    attempt=$((attempt + 1))
    test "$attempt" -le 600
    sleep 2
done
# The copied source has archive timestamps. Old cached crate artifacts can survive relocation
# even when unit tests rebuild: discard NBReq's artifacts, retaining dependency caches/baselines.
export RUSTUP_TOOLCHAIN=stable
cargo clean --offline -p nbreq
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    CARGO_TARGET_DIR="$lab/runner-$toolchain" cargo build --locked --offline --manifest-path tools/xtask/Cargo.toml
    "$lab/runner-$toolchain/debug/nbreq-xtask" verify --offline > "$lab/verify-final-$toolchain.log" 2>&1
    python3 - "$lab" "$toolchain" <<'PY'
import pathlib, sys
lab=pathlib.Path(sys.argv[1])
log=(lab/('verify-final-'+sys.argv[2]+'.log')).read_text()
assert 'NBReq verification root: '+str(lab/'nbreq') in log.splitlines()[0], log[:500]
assert 'test response_body_tests::m2_response_clone_shares_immutable_body_storage ... ok' in log
assert 'test registry::tests::m2_callback_extraction_is_unique_before_and_after_activation ... ok' in log
assert 'NBReq verification complete: all 24 steps passed' in log
print('CURRENT_ROOT_AND_M2_TESTS_PASS',sys.argv[2])
print(log.splitlines()[-1])
PY
done
if test "$scope" = measure; then
    export RUSTUP_TOOLCHAIN=stable
    cargo clean --offline --manifest-path tools/f5-observe/memory/Cargo.toml -p nbreq-f5-memory
    mkdir "$lab/bin-final"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin-final/plain"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter
    cp "$CARGO_TARGET_DIR/release/nbreq-f5-memory" "$lab/bin-final/meter"
    source_hash=$(python3 -c 'import hashlib,pathlib; print(hashlib.sha256(pathlib.Path("m2-source.sha256").read_bytes()).hexdigest())')
    before="${previous%-b}-c"
    python3 m2-compare.py --before-plain "$before/bin/plain" --before-meter "$before/bin/meter" --after-plain "$lab/bin-final/plain" --after-meter "$lab/bin-final/meter" --output "$lab/comparison-final" --source "$source_hash"
fi
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m2-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
printf 'M2_FINAL_HOST_PASS\n'
