import json
import sys
from pathlib import Path
from statistics import median

root = Path(sys.argv[1])
cases = json.loads((root / 'results.json').read_text())
assert len(cases) == 60
assert all(c['valid'] for c in cases)
assert all(p['joined'] and p['exit_code'] == 0 and not p['forced'] for c in cases for p in c['cleanup'])

def phase(c, name):
    return next(p for p in c['phases'] if p['phase'] == name)

def spread(values):
    return dict(min=min(values), median=median(values), max=max(values))

rows = []
for protocol, size, extended in sorted({(c['protocol'], c['client']['body_bytes'], c['client']['extended']) for c in cases}):
    row = dict(protocol=protocol, body_bytes=size, extended=extended)
    for version in ['before', 'after']:
        selected = [c for c in cases if c['protocol'] == protocol and c['client']['body_bytes'] == size and c['client']['extended'] == extended and c['version'] == version]
        plain = [c for c in selected if not c['client']['instrumented']]
        meter = [c for c in selected if c['client']['instrumented']]
        assert len(plain) == len(meter) == 3
        row[version] = dict(
            rustc=plain[0]['client']['rustc'],
            rps=spread([phase(c, 'steady')['requests_per_second'] for c in plain]),
            p95_ms=spread([phase(c, 'steady')['latency_p95_ms'] for c in plain]),
            requested_bytes_per_request=spread([phase(c, 'steady')['allocation']['bytes_requested'] / phase(c, 'steady')['completed'] for c in meter]),
            allocation_calls_per_request=spread([(phase(c, 'steady')['allocation']['allocations'] + phase(c, 'steady')['allocation']['reallocations']) / phase(c, 'steady')['completed'] for c in meter]),
            peak_heap=max(p['allocation']['peak_live'] for c in meter for p in c['phases']),
            peak_rss=max(p['process']['sampled_peaks']['rss'] for c in plain for p in c['phases']),
            peak_private=max((p['process']['sampled_peaks'].get('private') or 0) for c in plain for p in c['phases']),
            phases={name: dict(heap_peak=spread([phase(c, name)['allocation']['peak_live'] for c in meter]), heap_end=spread([phase(c, name)['allocation']['live_after'] for c in meter])) for name in ['burst_retained', 'released_idle', 'shutdown_idle'] + (['large_transfer_retained', 'post_large_idle'] if extended else [])},
        )
    rows.append(row)
output = dict(cases=len(cases), groups=rows, provenance=json.loads((root / 'provenance.json').read_text()))
(root.parent / (root.name + '-summary.json')).write_text(json.dumps(output, indent=2))
for r in rows:
    b, a = r['before'], r['after']
    print(r['protocol'], r['body_bytes'], 'extended' if r['extended'] else 'ordinary')
    print('  requested KiB/req', round(b['requested_bytes_per_request']['median']/1024,2), '->', round(a['requested_bytes_per_request']['median']/1024,2), 'calls/req', round(b['allocation_calls_per_request']['median'],2), '->', round(a['allocation_calls_per_request']['median'],2))
    print('  RPS', {v: {k:round(x) for k,x in r[v]['rps'].items()} for v in ['before','after']})
    print('  peak heap MiB', round(b['peak_heap']/1048576,3),'->',round(a['peak_heap']/1048576,3))
    if r['extended']:
        print('  4MiB phase heap peak', {v: round(r[v]['phases']['large_transfer_retained']['heap_peak']['max']/1048576,3) for v in ['before','after']})
        print('  4MiB held heap', {v: round(r[v]['phases']['large_transfer_retained']['heap_end']['median']/1048576,3) for v in ['before','after']})
