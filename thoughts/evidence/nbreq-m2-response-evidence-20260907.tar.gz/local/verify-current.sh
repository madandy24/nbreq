#!/bin/sh
set -eu
lab=$1
previous=$2
export PATH="$HOME/.cargo/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export CARGO_TARGET_DIR="$previous/target"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
trap 'code=$?; printf "%s\n" "$code" > "$lab/verified-current.exit"' EXIT
cd "$lab/nbreq"
attempt=0
while ! test -f "$lab/run.exit"; do
    attempt=$((attempt + 1))
    test "$attempt" -le 600
    sleep 2
done
test "$(cat "$lab/run.exit")" = 0
for toolchain in stable 1.85.0; do
    export RUSTUP_TOOLCHAIN=$toolchain
    # xtask embeds CARGO_MANIFEST_DIR: never reuse its binary across checkouts.
    CARGO_TARGET_DIR="$lab/runner-$toolchain" cargo build --locked --offline --manifest-path tools/xtask/Cargo.toml
    runner="$lab/runner-$toolchain/debug/nbreq-xtask"
    "$runner" verify --offline > "$lab/verify-m2-$toolchain.log" 2>&1
    python3 - "$lab" "$toolchain" <<'PY'
import pathlib, sys
lab=pathlib.Path(sys.argv[1])
log=(lab/('verify-m2-'+sys.argv[2]+'.log')).read_text()
assert 'NBReq verification root: '+str(lab/'nbreq') in log.splitlines()[0], log[:500]
assert 'test response_body_tests::m2_response_clone_shares_immutable_body_storage ... ok' in log
assert 'test registry::tests::m2_callback_extraction_is_unique_before_and_after_activation ... ok' in log
assert 'NBReq verification complete: all 24 steps passed' in log
print('CURRENT_ROOT_AND_M2_TESTS_PASS',sys.argv[2])
print(log.splitlines()[-1])
PY
done
python3 -c 'import hashlib,pathlib; rows=[line.split("  ",1) for line in pathlib.Path("m2-source.sha256").read_text().splitlines()]; assert all(hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest for digest,name in rows); print("SOURCE_MANIFEST_PASS",len(rows))'
printf 'M2_CURRENT_HOST_PASS\n'
