from pathlib import Path
import hashlib
import io
import json
import tarfile

root=Path('target/m2')
files={}
for name in ['windows-verify.log','windows-x86-ownership.log','ownership-red.log','shared-body-before-move.log','ownership-green.log','windows-build.log','windows-comparison.log','windows-comparison-summary.json','comparison-final-summary.json','bundle.json','source.sha256','prepare.py','compare.py','analyse.py','remote.sh','verify-current.sh','verify-final.sh','arm-msrv-rerun.sh','collect.py','receive.py','archive-evidence.py']:
    files['local/'+name]=(root/name).read_bytes()
for folder in ['windows-comparison','linux-evidence','intel-evidence','arm-evidence']:
    base=root/folder
    assert base.is_dir()
    for path in base.rglob('*'):
        if path.is_file(): files[folder+'/'+path.relative_to(base).as_posix()]=path.read_bytes()
for path in root.glob('bridge-*.json'):
    files['receipts/'+path.name]=path.read_bytes()
for folder in ['linux-evidence','intel-evidence','arm-evidence']:
    base=root/folder
    assert (base/'verified-final.exit').read_text().strip()=='0'
    for toolchain in ['stable','1.85.0']:
        log=(base/f'verify-final-{toolchain}.log').read_text()
        assert 'nbreq-m2-response-20260907/nbreq' in log.splitlines()[0]
        assert 'NBReq verification complete: all 24 steps passed' in log
        assert 'test response_body_tests::m2_response_clone_shares_immutable_body_storage ... ok' in log
assert 'NBReq verification complete: all 24 steps passed' in (root/'windows-verify.log').read_text()
for folder in [root/'windows-comparison',root/'linux-evidence/comparison-final']:
    cases=json.loads((folder/'results.json').read_text())
    assert len(cases)==60 and all(case['valid'] for case in cases)
    assert all(c['joined'] and c['exit_code']==0 and not c['forced'] for case in cases for c in case['cleanup'])
manifest=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
files['evidence.sha256']=manifest
out=Path('thoughts/evidence/nbreq-m2-response-evidence-20260907.tar.gz')
with tarfile.open(out,'w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
with tarfile.open(out) as archive:
    restored={member.name:archive.extractfile(member).read() for member in archive.getmembers()}
assert restored==files
source=Path('thoughts/evidence/nbreq-m2-response-20260907.tar.gz')
receipt=dict(evidence=dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),files=len(files),bytes=out.stat().st_size),source=dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest()),valid_comparison_cases=120,windows_verifiers=1,remote_verifiers=6,ownership_tests=13)
Path('thoughts/evidence/nbreq_m2_response_artifacts.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
