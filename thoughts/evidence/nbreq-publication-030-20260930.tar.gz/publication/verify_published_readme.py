"""Verify the live crates.io README independently while docs.rs builds."""
import datetime
import json
import re

from check_published_docs import Page, get
from publication_common import LAB, write_json


def main():
    url = 'https://static.crates.io/readmes/nbreq/nbreq-0.3.0.html'
    data, response = get(url)
    page = Page()
    page.feed(data.decode('utf-8'))
    visible = ' '.join(page.words)
    highlights_before_get = (page.ids.index('user-content-highlights') <
                             page.ids.index('user-content-start-with-a-get'))
    history_last = page.ids[-1] == 'user-content-history'
    curl_mentions = len(re.findall(r'\bcurl\b', visible, re.I))
    if (response['status'] != 200 or not highlights_before_get or not history_last or
            curl_mentions != 1 or '0.3.0' not in visible or
            'currently unreleased' in visible):
        raise RuntimeError('published 0.3.0 README differs from reviewed layout/content')
    (LAB / 'published-readme.html').write_bytes(data)
    receipt = dict(status='passed', version='0.3.0', response=response,
                   highlights_before_get=highlights_before_get,
                   history_last=history_last, curl_mentions=curl_mentions,
                   checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write_json(LAB / 'published-readme-verified.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
