"""Exact-source identities shared by the NBReq 0.3.0 publication checks."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

LAB = Path('C:/User/projects/nbreq/target/release-030-publication-20260930')
PROOF = Path('C:/User/projects/nbreq/target/release-030-final-20260930')
CHECKOUT = Path('C:/Users/andre/.codex/worktrees/nbreq-release-030/nbreq')
COMMIT = 'ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08'
VERSION = '0.3.0'
SHA256 = '193601f9a1616659afcd1802d3f904dded739a73ffc4786fffb828feb102f242'
BYTES = 414961
CANONICAL = PROOF / 'authoritative-package/build/package/nbreq-0.3.0.crate'
FROZEN = PROOF / 'frozen-source-final/build/package/nbreq-0.3.0.crate'
DRY_CRATE = PROOF / 'publish-dry-run/build/package/tmp-crate/nbreq-0.3.0.crate'
DRY_REGISTRY = PROOF / 'publish-dry-run/build/package/tmp-registry/nbreq-0.3.0.crate'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def git(*args, timeout=60):
    return subprocess.check_output(['git', '-c', f'safe.directory={CHECKOUT}',
                                    '-C', str(CHECKOUT), *args], timeout=timeout)


def git_clean():
    return (not git('status', '--porcelain') and
            subprocess.run(['git', '-c', f'safe.directory={CHECKOUT}', '-C', str(CHECKOUT),
                            'diff', '--cached', '--quiet', 'HEAD'],
                           timeout=60, check=False).returncode == 0)


def index_map(raw):
    entries = {}
    for record in raw.split(b'\0'):
        if record:
            fields, name = record.split(b'\t', 1)
            mode, oid, stage = fields.split(b' ')
            if stage != b'0':
                raise RuntimeError('unmerged index entry')
            entries[name] = (mode, oid)
    return entries


def head_map(raw):
    entries = {}
    for record in raw.split(b'\0'):
        if record:
            fields, name = record.split(b'\t', 1)
            mode, kind, oid = fields.split(b' ')
            if kind != b'blob':
                raise RuntimeError('unexpected non-blob HEAD entry')
            entries[name] = (mode, oid)
    return entries


def source_snapshot():
    if CHECKOUT.resolve() != Path('C:/Users/andre/.codex/worktrees/nbreq-release-030/nbreq').resolve():
        raise RuntimeError('unexpected managed checkout')
    names = [name for name in git('ls-files', '-z').decode().split('\0') if name]
    snapshot = dict(commit=git('rev-parse', 'HEAD').decode().strip(),
                    clean=git_clean(),
                    index_equals_head=index_map(git('ls-files', '-s', '-z')) ==
                                      head_map(git('ls-tree', '-r', '-z', 'HEAD')),
                    files={name: sha(CHECKOUT / name) for name in names})
    if snapshot['commit'] != COMMIT or not snapshot['clean'] or not snapshot['index_equals_head']:
        raise RuntimeError('frozen publication checkout is not exact clean source')
    accepted = read_json(PROOF / 'frozen-source-final/source-after.json')
    if accepted['commit'] != COMMIT or accepted['status'] or snapshot['files'] != accepted['files']:
        raise RuntimeError('frozen checkout raw file hashes differ from accepted package proof')
    return snapshot


def archive_members(path):
    files = {}
    with tarfile.open(path) as bundle:
        for member in bundle:
            if (not member.isfile() or member.name in files or
                    not member.name.startswith('nbreq-' + VERSION + '/')):
                raise RuntimeError('unexpected archive member: ' + member.name)
            files[member.name.removeprefix('nbreq-' + VERSION + '/')] = hashlib.sha256(
                bundle.extractfile(member).read()).hexdigest()
    return files


def verified_archives():
    inventory = read_json(PROOF / 'authoritative-package/inventory.json')
    if (inventory['commit'] != COMMIT or inventory['sha256'] != SHA256 or
            inventory['bytes'] != BYTES or inventory['files'] != archive_members(CANONICAL)):
        raise RuntimeError('canonical archive inventory mismatch')
    for path in (CANONICAL, FROZEN, DRY_CRATE, DRY_REGISTRY):
        if path.stat().st_size != BYTES or sha(path) != SHA256:
            raise RuntimeError('approved archive identity mismatch: ' + str(path))
    receipts = [PROOF / 'verify/summary.json', PROOF / 'package/summary.json',
                PROOF / 'packaged-tests/summary.json', PROOF / 'registry/summary.json',
                PROOF / 'publish-dry-run/summary.json', PROOF / 'frozen-source-final/summary.json',
                PROOF / 'postrun-extraction-identity.json',
                PROOF / 'frozen-checkout-normalization.json']
    for path in receipts:
        result = read_json(path)
        if result['status'] != 'passed':
            raise RuntimeError('approved proof no longer passed: ' + str(path))
    return dict(commit=COMMIT, bytes=BYTES, sha256=SHA256,
                archive_paths=[str(path) for path in (CANONICAL, FROZEN, DRY_CRATE, DRY_REGISTRY)],
                inventory_path=str(PROOF / 'authoritative-package/inventory.json'),
                proof_paths=[str(path) for path in receipts])
