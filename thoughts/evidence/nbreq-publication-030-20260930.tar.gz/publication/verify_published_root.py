"""Read-only crates.io API, sparse-index, and downloaded-byte verification."""
import datetime
import hashlib
import json
import time
import urllib.error
import urllib.request

from publication_common import (BYTES, CANONICAL, COMMIT, LAB, SHA256, VERSION,
                                archive_members, read_json, sha, source_snapshot,
                                verified_archives, write_json)


def get(url, accept='application/json'):
    request = urllib.request.Request(url, headers={
        'User-Agent': 'nbreq-030-published-identity-check', 'Accept': accept,
        'Cache-Control': 'no-cache', 'Pragma': 'no-cache'})
    with urllib.request.urlopen(request, timeout=60) as response:
        return response.read(), dict(status=response.status, final_url=response.url,
                                     date=response.headers.get('Date'),
                                     age=response.headers.get('Age'),
                                     etag=response.headers.get('ETag'))


def main():
    source_snapshot()
    verified_archives()
    api_url = 'https://crates.io/api/v1/crates/nbreq/0.3.0'
    index_url = 'https://index.crates.io/nb/re/nbreq'
    deadline = time.monotonic() + 600
    last_error = None
    while time.monotonic() < deadline:
        try:
            fresh = str(time.time_ns())
            api_raw, api_response = get(api_url + '?fresh=' + fresh)
            api = json.loads(api_raw)
            version = api['version']
            if (version['num'] != VERSION or version['checksum'] != SHA256 or
                    version['yanked']):
                raise RuntimeError('published API version/checksum/yank mismatch')
            index_raw, index_response = get(index_url + '?fresh=' + fresh)
            entries = [json.loads(line) for line in index_raw.splitlines() if line]
            entry = next(item for item in entries if item.get('vers') == VERSION)
            if entry['cksum'] != SHA256 or entry['yanked']:
                raise RuntimeError('published sparse-index checksum/yank mismatch')
            download_path = version['dl_path']
            if not download_path.startswith('/api/v1/crates/nbreq/0.3.0/download'):
                raise RuntimeError('unexpected crates.io version download path')
            published, download_response = get('https://crates.io' + download_path,
                                               'application/octet-stream')
            if len(published) != BYTES or hashlib.sha256(published).hexdigest() != SHA256:
                raise RuntimeError('downloaded published archive differs from approved bytes')
            download_file = LAB / 'nbreq-0.3.0-published.crate'
            with download_file.open('xb') as stream:
                stream.write(published)
            inventory = read_json(LAB.parent / 'release-030-final-20260930/'
                                  'authoritative-package/inventory.json')
            if archive_members(download_file) != inventory['files']:
                raise RuntimeError('downloaded archive member hashes differ from canonical')
            if published != CANONICAL.read_bytes():
                raise RuntimeError('downloaded archive bytes differ from canonical')
            write_json(LAB / 'published-api.json', api)
            write_json(LAB / 'published-index-entry.json', entry)
            (LAB / 'published-index.jsonl').write_bytes(index_raw)
            receipt = dict(status='passed', crate='nbreq', version=VERSION,
                source_commit=COMMIT, sha256=SHA256, bytes=BYTES,
                created_at=version['created_at'], yanked=False,
                api=dict(**api_response, sha256=hashlib.sha256(api_raw).hexdigest()),
                sparse_index=dict(**index_response,
                    sha256=hashlib.sha256(index_raw).hexdigest(), entries=len(entries)),
                download=dict(**download_response, path=str(download_file),
                    sha256=sha(download_file), bytes=download_file.stat().st_size),
                archive_members_match=True, canonical_bytes_match=True,
                checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            write_json(LAB / 'published-root.json', receipt)
            print(json.dumps(receipt, indent=2))
            return
        except (urllib.error.HTTPError, urllib.error.URLError, StopIteration) as error:
            last_error = repr(error)
            print('Waiting for registry propagation: ' + last_error, flush=True)
            time.sleep(15)
    raise RuntimeError('published version not visible within 600 seconds: ' + str(last_error))


if __name__ == '__main__':
    main()
