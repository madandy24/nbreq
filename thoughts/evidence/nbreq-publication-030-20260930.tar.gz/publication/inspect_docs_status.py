"""Read-only docs.rs version and build-queue status snapshot."""
import datetime
from html.parser import HTMLParser
import json
import urllib.error
import urllib.request

from publication_common import LAB, write_json


class Title(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_title = False
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag == 'title':
            self.in_title = True
    def handle_endtag(self, tag):
        if tag == 'title':
            self.in_title = False
    def handle_data(self, data):
        if self.in_title:
            self.parts.append(data)


def inspect(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'nbreq-030-docs-status'})
    try:
        response = urllib.request.urlopen(request, timeout=30)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        body = response.read()
        title = Title()
        title.feed(body.decode('utf-8', errors='replace'))
        text = ' '.join(body.decode('utf-8', errors='replace').split())
        match = text.lower().find('nbreq')
        return dict(url=url, status=response.status, final_url=response.url,
                    title=''.join(title.parts).strip(), body_excerpt=text[:500],
                    nbreq_context=text[max(0, match - 120):match + 200] if match >= 0 else None,
                    date=response.headers.get('Date'), age=response.headers.get('Age'))


def main():
    urls = ['https://docs.rs/nbreq/0.3.0/nbreq/',
            'https://docs.rs/crate/nbreq/0.3.0',
            'https://docs.rs/crate/nbreq/0.3.0/builds',
            'https://docs.rs/crate/nbreq/0.3.0/builds.json',
            'https://docs.rs/releases/queue?expand=1',
            'https://docs.rs/releases/failures']
    result = dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  pages=[inspect(url) for url in urls])
    write_json(LAB / 'docs-status-snapshot.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
