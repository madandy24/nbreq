"""Read-only versioned README, docs.rs, API-page, and tagged-source link checks."""
import datetime
import hashlib
from html.parser import HTMLParser
import json
import re
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from publication_common import LAB, PROOF, VERSION, read_json, write_json


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.links = []
        self.words = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get('id'):
            self.ids.append(attrs['id'])
        if tag == 'a' and attrs.get('href'):
            self.links.append(attrs['href'])

    def handle_data(self, data):
        self.words.append(data)


def get(url):
    request = urllib.request.Request(url, headers={
        'User-Agent': 'nbreq-030-published-doc-check', 'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'})
    with urllib.request.urlopen(request, timeout=45) as response:
        data = response.read()
        return data, dict(url=url, status=response.status, final_url=response.url,
                          sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def main():
    published = read_json(LAB / 'published-root.json')
    if published['status'] != 'passed' or published['version'] != VERSION:
        raise RuntimeError('published archive identity check must pass first')
    readme_url = 'https://static.crates.io/readmes/nbreq/nbreq-0.3.0.html'
    docs_url = 'https://docs.rs/nbreq/0.3.0/nbreq/'
    deadline = time.monotonic() + 900
    while True:
        try:
            readme_data, readme_receipt = get(readme_url)
            docs_data, docs_receipt = get(docs_url)
            if (readme_receipt['status'] != 200 or docs_receipt['status'] != 200 or
                    docs_receipt['final_url'].rstrip('/') != docs_url.rstrip('/')):
                raise RuntimeError('published README/docs.rs page not version-exact yet')
            break
        except (urllib.error.HTTPError, urllib.error.URLError, RuntimeError) as error:
            if time.monotonic() >= deadline:
                raise RuntimeError('published README/docs.rs not ready within 900 seconds') from error
            print('Waiting for published documentation: ' + repr(error), flush=True)
            time.sleep(20)
    readme = Page()
    readme.feed(readme_data.decode('utf-8'))
    docs = Page()
    docs.feed(docs_data.decode('utf-8'))
    visible_readme = ' '.join(readme.words)
    if (readme.ids.index('user-content-highlights') >=
            readme.ids.index('user-content-start-with-a-get') or
            readme.ids[-1] != 'user-content-history' or
            len(re.findall(r'\bcurl\b', visible_readme, re.I)) != 1 or
            '0.3.0' not in visible_readme or 'currently unreleased' in visible_readme):
        raise RuntimeError('published README content/layout differs from reviewed source')
    if ('rust-version-and-dependency-selection' not in docs.ids or
            'timeout-and-queue-defaults' not in docs.ids):
        raise RuntimeError('published rustdoc lacks reviewed guidance sections')
    immutable = 'https://github.com/madandy24/nbreq/blob/v0.3.0/'
    if immutable + 'examples/README.md' not in docs.links:
        raise RuntimeError('published rustdoc lacks versioned example link')
    inventory = read_json(PROOF / 'authoritative-package/inventory.json')
    targets = sorted({item['destination'].split('#', 1)[0]
                      for item in inventory['future_tag_links']})
    targets += [docs_url + name for name in (
        'struct.Engine.html', 'struct.RequestOptions.html', 'struct.Resolver.html',
        'struct.TcpConnector.html', 'struct.TcpConnectRequest.html',
        'struct.TlsOptions.html', 'struct.TlsConnection.html', 'enum.TlsTrust.html')]
    receipts = []
    for url in targets:
        data, receipt = get(url)
        if (receipt['status'] != 200 or not data or
                urlsplit(url).netloc in ('docs.rs', 'github.com') and
                receipt['final_url'].rstrip('/') != url.rstrip('/')):
            raise RuntimeError('versioned source/API link is not exact: ' + url)
        receipts.append(receipt)
    (LAB / 'published-readme.html').write_bytes(readme_data)
    (LAB / 'published-docs.html').write_bytes(docs_data)
    result = dict(status='passed', version=VERSION, readme=readme_receipt,
                  docs=docs_receipt, highlights_before_get=True,
                  history_last=True, curl_mentions=1,
                  versioned_source_and_api_targets=receipts,
                  checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write_json(LAB / 'published-docs-verified.json', result)
    print('Published README, rustdoc, API pages and versioned source links verified.', flush=True)


if __name__ == '__main__':
    main()
