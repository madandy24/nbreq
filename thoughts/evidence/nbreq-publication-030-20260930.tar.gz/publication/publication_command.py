"""One-shot, bounded core NBReq 0.3.0 Cargo publish; root executes --execute."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

from publication_common import (BYTES, CHECKOUT, COMMIT, LAB, SHA256,
                                read_json, sha, source_snapshot, verified_archives, write_json)


def stop_owned(process, stream):
    if os.name == 'nt' and process.poll() is None:
        try:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                           stdout=stream, stderr=subprocess.STDOUT, timeout=15, check=False)
        except (OSError, subprocess.TimeoutExpired):
            pass
        if process.poll() is None:
            process.kill()
    elif os.name != 'nt' and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
    process.wait(timeout=20)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', required=True)
    parser.parse_args()
    preflight_path = LAB / 'prepublish-preflight.json'
    preflight = read_json(preflight_path)
    age = (datetime.datetime.now(datetime.timezone.utc) -
           datetime.datetime.fromisoformat(preflight['checked_utc'])).total_seconds()
    if (preflight['status'] != 'passed' or not 0 <= age <= 900 or
            preflight['source_commit'] != COMMIT or preflight['canonical_sha256'] != SHA256 or
            preflight['canonical_bytes'] != BYTES or not preflight['remote_tag_absent'] or
            not preflight['remote_main_contains_release'] or
            preflight['public_api']['status'] != 404 or
            not preflight['sparse_index']['selected_version_absent']):
        raise RuntimeError('fresh exact-source public-absence preflight required')
    source_before = source_snapshot()
    verified_archives()
    argv = ['rustup', 'run', 'stable', 'cargo', 'publish', '--locked', '--registry',
            'crates-io', '-p', 'nbreq', '--target-dir', str(LAB / 'publication-build')]
    command = dict(argv=argv, cwd=str(CHECKOUT), timeout_seconds=900,
                   source_commit=COMMIT, source_file_count=len(source_before['files']),
                   source_snapshot_sha256=hashlib.sha256(json.dumps(source_before['files'],
                       sort_keys=True).encode()).hexdigest(),
                   preflight_path=str(preflight_path), preflight_sha256=sha(preflight_path),
                   canonical_sha256=SHA256, canonical_bytes=BYTES,
                   note='Cargo reads credentials internally; no credential values are logged')
    # Exclusive marker prevents an accidental second submission after any ambiguous result.
    with (LAB / 'publication-command.json').open('x', encoding='utf-8') as marker:
        json.dump(command, marker, indent=2)
        marker.write('\n')
    print('Starting one-shot Cargo publication from exact frozen release checkout.', flush=True)
    started = time.monotonic()
    failure = None
    with (LAB / 'cargo-publish.log').open('xb') as log:
        process = subprocess.Popen(argv, cwd=CHECKOUT, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=subprocess.STDOUT)
        command['pid'] = process.pid
        try:
            command['exit_code'] = process.wait(timeout=900)
        except BaseException as error:
            command['error'] = repr(error)
            stop_owned(process, log)
        finally:
            command['exit_code'] = process.returncode
            command['elapsed_seconds'] = time.monotonic() - started
            write_json(LAB / 'cargo-publish.result.json', command)
    if command['exit_code'] != 0 or 'error' in command:
        failure = 'Cargo publish did not complete successfully; inspect registry before any retry'
    generated = {}
    if failure is None:
        package_root = LAB / 'publication-build/package'
        for relative in ('tmp-crate/nbreq-0.3.0.crate',
                         'tmp-registry/nbreq-0.3.0.crate', 'nbreq-0.3.0.crate'):
            path = package_root / relative
            if path.is_file():
                generated[relative] = dict(path=str(path), bytes=path.stat().st_size,
                                           sha256=sha(path))
        if not generated or any(item['bytes'] != BYTES or item['sha256'] != SHA256
                                for item in generated.values()):
            failure = 'publication-generated archive differs from approved canonical bytes'
    try:
        source_after = source_snapshot()
        if source_after != source_before:
            failure = (failure + '; ' if failure else '') + 'frozen source changed during publication'
    except BaseException as error:
        failure = (failure + '; ' if failure else '') + 'source integrity: ' + repr(error)
    receipt = dict(status='submitted' if failure is None else 'needs_review',
                   failure=failure, source_commit=COMMIT, canonical_sha256=SHA256,
                   canonical_bytes=BYTES, cargo_exit_code=command['exit_code'],
                   generated=generated, source_hashes_unchanged=source_after == source_before
                   if 'source_after' in locals() else False,
                   registry_visibility_pending=True,
                   no_automatic_retry=True)
    write_json(LAB / 'publication-command-result.json', receipt)
    print(json.dumps(receipt, indent=2), flush=True)
    if failure:
        raise SystemExit(failure)


if __name__ == '__main__':
    main()
