"""Confirm the published-release audit can reuse the fresh, clean RustSec DB."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess

LAB = Path(__file__).resolve().parent
ROOT = Path("C:/User/projects/nbreq")
DATABASE = ROOT / "target/release-030-final-20260930/advisory-db"
SOURCE = "https://github.com/RustSec/advisory-db.git"
EXPECTED = "f23b768236fe2880e4cfa167da662cad8ca79240"
OUT = LAB / "advisory-db-freshness.json"


def command(*args):
    return subprocess.check_output(args, timeout=30, stderr=subprocess.PIPE).decode().strip()


def main():
    if OUT.exists():
        raise ValueError("freshness receipt already exists")
    remote = command("git", "-c", "http.sslBackend=openssl", "ls-remote", SOURCE, "HEAD")
    fields = remote.split()
    if len(fields) != 2 or fields[1] != "HEAD":
        raise ValueError("unexpected official RustSec HEAD response")
    local = command("git", "-C", str(DATABASE), "rev-parse", "HEAD")
    status = command("git", "-C", str(DATABASE), "status", "--porcelain")
    origin = command("git", "-C", str(DATABASE), "remote", "get-url", "origin")
    if fields[0] != EXPECTED or local != EXPECTED or status or origin.lower() != SOURCE.lower():
        raise ValueError("RustSec DB changed or local snapshot is not the clean official commit")
    record = {
        "status": "passed", "source": SOURCE, "remote_head": fields[0],
        "local_head": local, "local_clean": True, "local_origin": origin,
        "database_path": str(DATABASE),
        "checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "reuse_reason": "official upstream HEAD still equals prior clean audited DB commit",
    }
    OUT.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
