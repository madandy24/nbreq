"""Read-only, fail-closed preflight for publishing core NBReq 0.3.0."""
import datetime
import hashlib
import json
import subprocess
import time
import tomllib
import urllib.error
import urllib.request

from publication_common import (BYTES, CHECKOUT, COMMIT, LAB, SHA256, VERSION,
                                git, source_snapshot, verified_archives, write_json)


def public_get(url):
    request = urllib.request.Request(url, headers={
        'User-Agent': 'nbreq-030-publication-preflight',
        'Cache-Control': 'no-cache', 'Pragma': 'no-cache',
        'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            return response.status, response.read(), dict(response.headers), response.url
    except urllib.error.HTTPError as error:
        return error.code, error.read(), dict(error.headers), error.url


def main():
    source = source_snapshot()
    package = tomllib.loads((CHECKOUT / 'Cargo.toml').read_text(encoding='utf-8'))['package']
    if package['name'] != 'nbreq' or package['version'] != VERSION:
        raise RuntimeError('release checkout package identity mismatch')
    archives = verified_archives()

    lines = git('ls-remote', 'origin', 'refs/heads/main',
                'refs/tags/v0.3.0', 'refs/tags/v0.3.0^{}', timeout=45).decode().splitlines()
    refs = dict(line.split('\t', 1)[::-1] for line in lines)
    remote_main = refs.get('refs/heads/main')
    if not remote_main or any(name.startswith('refs/tags/v0.3.0') for name in refs):
        raise RuntimeError('remote main missing or v0.3.0 tag already exists')
    ancestor = subprocess.run(['git', '-c', f'safe.directory={CHECKOUT}', '-C', str(CHECKOUT),
                               'merge-base', '--is-ancestor', COMMIT, remote_main],
                              timeout=45, check=False).returncode == 0
    if not ancestor:
        raise RuntimeError('remote main does not contain the exact release commit')

    stamp = str(time.time_ns())
    api_url = 'https://crates.io/api/v1/crates/nbreq/0.3.0?fresh=' + stamp
    api_status, api_body, api_headers, api_final = public_get(api_url)
    if api_status != 404:
        raise RuntimeError(f'NBReq 0.3.0 API is not absent (HTTP {api_status})')
    index_url = 'https://index.crates.io/nb/re/nbreq?fresh=' + stamp
    index_status, index_body, index_headers, index_final = public_get(index_url)
    if index_status != 200:
        raise RuntimeError(f'NBReq sparse index unavailable (HTTP {index_status})')
    entries = [json.loads(line) for line in index_body.splitlines() if line]
    if any(entry.get('vers') == VERSION for entry in entries):
        raise RuntimeError('NBReq 0.3.0 already exists in the sparse index')
    (LAB / 'prepublish-sparse-index.jsonl').write_bytes(index_body)
    receipt = dict(status='passed', source_commit=COMMIT, checkout=str(CHECKOUT),
                   source_file_count=len(source['files']), source_clean=source['clean'],
                   index_equals_head=source['index_equals_head'],
                   canonical_sha256=SHA256, canonical_bytes=BYTES,
                   archive_identity=archives, remote_main=remote_main,
                   remote_main_contains_release=True, remote_tag_absent=True,
                   public_api=dict(status=api_status, url=api_final,
                       date=api_headers.get('Date'), age=api_headers.get('Age')),
                   sparse_index=dict(status=index_status, url=index_final,
                       sha256=hashlib.sha256(index_body).hexdigest(),
                       entries=len(entries), selected_version_absent=True,
                       date=index_headers.get('Date'), age=index_headers.get('Age')),
                   checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write_json(LAB / 'prepublish-preflight.json', receipt)
    print(json.dumps({key: receipt[key] for key in ('status', 'source_commit',
          'canonical_sha256', 'canonical_bytes', 'remote_main_contains_release',
          'remote_tag_absent', 'checked_utc')}, indent=2))


if __name__ == '__main__':
    main()
