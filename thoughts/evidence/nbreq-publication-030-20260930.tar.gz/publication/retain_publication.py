"""Plan a compact postpublication evidence archive; archive only after plan review.

The prior final-release archive is referenced by hash, not copied. Build trees,
the advisory checkout, and private bridge data are never enumerated.
"""

import argparse
import gzip
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile

LAB = Path(__file__).resolve().parent
ROOT = Path("C:/User/projects/nbreq")
sys.path.insert(0, str(ROOT / "target/release-030-final-20260930"))
from retain_final_release import add_file, nested_inventory, require, sha  # noqa: E402

SOURCE = "ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08"
PACKAGE_SHA = "193601f9a1616659afcd1802d3f904dded739a73ffc4786fffb828feb102f242"
PRIOR_ARCHIVE = ROOT / "thoughts/evidence/nbreq-release-030-final-20260930.tar.gz"
PRIOR_SHA = "fbceb2cfdf7c4132f6c22bf5431af4c9171adf22ce0a0a5b2c36b47b17438412"
PLAN = LAB / "retention-plan.json"
ARCHIVE = ROOT / "thoughts/evidence/nbreq-publication-030-20260930.tar.gz"
INDEX = ROOT / "thoughts/evidence/nbreq_publication_030_artifacts.json"
SINGLES = {
    "advisory-db-freshness.json", "check_db.py", "cargo-publish.log",
    "cargo-publish.result.json", "check_published_docs.py", "github_release.py",
    "nbreq-0.3.0-published.crate", "prepublish_preflight.py",
    "prepublish-preflight.json", "prepublish-sparse-index.jsonl",
    "docs-status-initial.json", "docs-status-snapshot.json", "inspect_docs_status.py",
    "publication_command.py", "publication_common.py", "publication-command.json",
    "publication-command-result.json", "published-api.json",
    "published-index-entry.json", "published-index.jsonl", "published-root.json",
    "published-tag.json", "scan_published_locks.py", "validate_matrix.py",
    "verify_published_root.py", "published-matrix-verified.json",
    "verify_tagged_links.py", "retain_publication.py", "published-artifact-inventory.json",
    "publication-review.json", "published-readme-verified.json",
    "published-readme.html", "published-docs-verified.json", "published-docs.html",
    "tagged-links-verified.json", "verify_published_readme.py",
    "validate-matrix-first-failure.txt", "validate-matrix-first-failure.diff",
}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def collect():
    require(PRIOR_ARCHIVE.is_file() and sha(PRIOR_ARCHIVE.read_bytes()) == PRIOR_SHA,
            "reviewed final-release archive changed")
    command = read_json(LAB / "publication-command-result.json")
    published = read_json(LAB / "published-root.json")
    tag = read_json(LAB / "published-tag.json")
    readme = read_json(LAB / "published-readme-verified.json")
    docs = read_json(LAB / "published-docs-verified.json")
    links = read_json(LAB / "tagged-links-verified.json")
    matrix = read_json(LAB / "published-matrix-verified.json")
    audit = read_json(LAB / "selected-lock-audit/summary.json")
    review = read_json(LAB / "publication-review.json")
    run = read_json(LAB / "hosted-published/run.json")
    artifacts = read_json(LAB / "hosted-published/artifacts.json")
    dispatch = read_json(LAB / "hosted-published/dispatch.json")
    require(command["status"] == "submitted" and command["cargo_exit_code"] == 0 and
            command["source_commit"] == SOURCE and command["canonical_sha256"] == PACKAGE_SHA and
            command["source_hashes_unchanged"], "publication command receipt mismatch")
    require(published["status"] == "passed" and published["source_commit"] == SOURCE and
            published["sha256"] == PACKAGE_SHA and published["bytes"] == 414961 and
            published["archive_members_match"] and published["canonical_bytes_match"] and
            sha((LAB / "nbreq-0.3.0-published.crate").read_bytes()) == PACKAGE_SHA,
            "published crate identity mismatch")
    require(tag["status"] == "passed" and tag["tag"] == "v0.3.0" and
            tag["source_commit"] == SOURCE and tag["object_type"] == "tag" and
            tag["remote_refs"]["refs/tags/v0.3.0"] == tag["tag_object"] and
            tag["remote_refs"]["refs/tags/v0.3.0^{}"] == SOURCE and
            tag["tag_object_text"].startswith("object " + SOURCE + "\ntype commit\ntag v0.3.0\n"),
            "published tag identity mismatch")
    require(readme["status"] == "passed" and readme["version"] == "0.3.0" and
            readme["response"]["status"] == 200 and
            readme["response"]["url"] == readme["response"]["final_url"] ==
            "https://static.crates.io/readmes/nbreq/nbreq-0.3.0.html" and
            sha((LAB / "published-readme.html").read_bytes()) ==
            readme["response"]["sha256"], "published README proof mismatch")
    require(docs["status"] == "passed" and docs["version"] == "0.3.0" and
            docs["docs"]["status"] == 200 and
            docs["docs"]["url"] == docs["docs"]["final_url"] ==
            "https://docs.rs/nbreq/0.3.0/nbreq/" and
            sha((LAB / "published-docs.html").read_bytes()) == docs["docs"]["sha256"] and
            docs["readme"]["sha256"] == readme["response"]["sha256"],
            "published docs.rs proof mismatch")
    require(links["status"] == "passed" and links["source_commit"] == SOURCE and
            links["tag"] == "v0.3.0" and links["tag_object"] == tag["tag_object"] and
            links["peeled_commit"] == SOURCE and
            len(links["versioned_source_links"]) == 4 and
            all(item["status"] == 200 and item["url"] == item["final_url"] and
                "/blob/v0.3.0/" in item["url"] for item in links["versioned_source_links"]),
            "tagged documentation links proof mismatch")
    require(dispatch == {"sha": SOURCE, "ref": "v0.3.0",
                         "resolved_commit": SOURCE, "mode": "published"} and
            run["id"] == matrix["run_id"] == audit["published_run_id"] and
            run["head_sha"] == SOURCE and run["head_branch"] == "v0.3.0" and
            run["event"] == "workflow_dispatch" and run["status"] == "completed" and
            run["conclusion"] == "success", "published hosted run identity mismatch")
    require(matrix["status"] == "passed" and matrix["mode"] == "published" and
            matrix["source"] == SOURCE and matrix["canonical_package_sha256"] == PACKAGE_SHA and
            matrix["jobs"] == 8 and matrix["consumer_graphs"] == 16 and
            matrix["positive_tests"] == 752 and matrix["negative_probes"] == 32 and
            matrix["v030_passes"] == 80 and matrix["examples"] == 144,
            "published matrix mismatch")
    require(audit["status"] == "passed" and audit["source"] == SOURCE and
            audit["canonical_package_sha256"] == PACKAGE_SHA and
            audit["audited_locks"] == audit["distinct_locks"] and
            audit["database_commit"] == "f23b768236fe2880e4cfa167da662cad8ca79240",
            "published lock audit mismatch")
    require(review["status"] == "passed" and review["scope"] == "publication-closeout" and
            review["publication_authorized"] is True and
            review["publication_completed"] is True and review["source"] == SOURCE and
            review["canonical_package_sha256"] == PACKAGE_SHA and
            review["published_run_id"] == run["id"], "publication review receipt mismatch")
    require(len(artifacts) == 8 and len({item["id"] for item in artifacts}) == 8,
            "published artifact count mismatch")
    files = {}
    for name in sorted(SINGLES):
        add_file(files, LAB / name, "publication/" + name)
    for name in ("dispatch.json", "run.json", "jobs.json", "artifacts.json", "logs.zip"):
        add_file(files, LAB / "hosted-published" / name, "publication/hosted-published/" + name)
    for item in artifacts:
        name = "artifact-" + str(item["id"]) + ".zip"
        add_file(files, LAB / "hosted-published" / name,
                 "publication/hosted-published/" + name)
    selected = read_json(LAB / "published-selected-locks/index.json")
    require(selected == matrix["selected_locks"] and len(selected) == matrix["selected_lock_count"],
            "selected lock inventory mismatch")
    add_file(files, LAB / "published-selected-locks/index.json",
             "publication/published-selected-locks/index.json")
    for item in selected:
        name = item["sha256"] + ".lock"
        add_file(files, LAB / "published-selected-locks" / name,
                 "publication/published-selected-locks/" + name)
    audit_inputs = read_json(LAB / "selected-lock-audit/inputs.json")
    require(len(audit_inputs["locks"]) == audit["distinct_locks"] and
            {item["sha256"] for item in audit_inputs["locks"]} ==
            {item["sha256"] for item in audit["receipts"]}, "audit lock inventory mismatch")
    for name in ("inputs.json", "summary.json", "progress.json", "auditor-version.log",
                 "auditor-version.result.json"):
        add_file(files, LAB / "selected-lock-audit" / name,
                 "publication/selected-lock-audit/" + name)
    for item in audit_inputs["locks"]:
        key = item["sha256"]
        for name in ("locks/" + key + ".lock", key + ".log", key + ".result.json"):
            add_file(files, LAB / "selected-lock-audit" / name,
                     "publication/selected-lock-audit/" + name)
    return files, {"path": "thoughts/evidence/" + PRIOR_ARCHIVE.name,
                   "sha256": PRIOR_SHA, "bytes": PRIOR_ARCHIVE.stat().st_size}


def inventory(files):
    rows = []
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        rows.append({"path": name, "source": str(path), "bytes": len(data),
                     "sha256": sha(data), "nested": nested_inventory(name, data)})
    return rows


def plan():
    require(not PLAN.exists(), "retention plan already exists")
    files, prior = collect()
    rows = inventory(files)
    record = {"source": SOURCE, "canonical_package_sha256": PACKAGE_SHA,
              "published_run_id": read_json(LAB / "published-matrix-verified.json")["run_id"],
              "prior_reviewed_release_archive": prior,
              "scope": "postpublication package, tag, registry-only consumers, and RustSec audit",
              "files": rows, "file_count": len(rows),
              "total_source_bytes": sum(row["bytes"] for row in rows),
              "excluded": "build/cache/unpacked/advisory DB/private bridge trees"}
    PLAN.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"plan": str(PLAN), "sha256": sha(PLAN.read_bytes()),
                      "files": len(rows), "bytes": record["total_source_bytes"]}, indent=2))


def archive(approved_plan_sha):
    require(re.fullmatch(r"[0-9a-f]{64}", approved_plan_sha) is not None and
            PLAN.is_file() and sha(PLAN.read_bytes()) == approved_plan_sha,
            "exact approved plan SHA is required")
    require(not ARCHIVE.exists() and not INDEX.exists(), "publication evidence already exists")
    record = read_json(PLAN)
    files, prior = collect()
    rows = inventory(files)
    require(rows == record["files"] and prior == record["prior_reviewed_release_archive"],
            "evidence changed after plan approval")
    internal = json.dumps({key: value for key, value in record.items() if key != "files"} |
                          {"files": [{key: value for key, value in row.items() if key != "source"}
                                     for row in rows]}, indent=2).encode() + b"\n"
    expected = {row["path"]: row["sha256"] for row in rows} | {"retained-files.json": sha(internal)}
    pending = LAB / "retention-pending.tar.gz"
    require(not pending.exists(), "pending publication archive already exists")
    with pending.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
            with tarfile.open(fileobj=gz, mode="w") as bundle:
                for name, data in ([(row["path"], files[row["path"]].read_bytes()) for row in rows]
                                   + [("retained-files.json", internal)]):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    bundle.addfile(info, io.BytesIO(data))
    with tarfile.open(pending, mode="r:gz") as bundle:
        members = bundle.getmembers()
        require(len(members) == len(expected) and {item.name for item in members} == set(expected),
                "publication archive member set mismatch")
        for item in members:
            require(item.isfile() and sha(bundle.extractfile(item).read()) == expected[item.name],
                    "publication archive read-back mismatch: " + item.name)
    os.replace(pending, ARCHIVE)
    index = {"archive": ARCHIVE.name, "sha256": sha(ARCHIVE.read_bytes()),
             "bytes": ARCHIVE.stat().st_size, "source": SOURCE,
             "canonical_package_sha256": PACKAGE_SHA,
             "published_run_id": record["published_run_id"],
             "approved_plan_sha256": approved_plan_sha,
             "regular_members": len(expected), "prior_reviewed_release_archive": prior}
    INDEX.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(index, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("plan", "archive"))
    parser.add_argument("--approved-plan-sha")
    args = parser.parse_args()
    if args.mode == "plan":
        require(args.approved_plan_sha is None, "plan does not take approved hash")
        plan()
    else:
        archive(args.approved_plan_sha)


if __name__ == "__main__":
    main()
