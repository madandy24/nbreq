"""Audit published consumer locks plus the accepted release lock set, without fetches.

The earlier ten locks are final-source evidence from the accepted prepublication
audit. Published-mode locks are newly selected from registry-only consumers.
"""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tomllib

LAB = Path(__file__).resolve().parent
ROOT = Path("C:/User/projects/nbreq")
FINAL = ROOT / "target/release-030-final-20260930"
sys.path.insert(0, str(FINAL))
from release_gate import run  # noqa: E402

SOURCE = "ae7bfeed7cc0bffa0e5e04cf16900496a1b66f08"
PACKAGE_SHA = "193601f9a1616659afcd1802d3f904dded739a73ffc4786fffb828feb102f242"
DATABASE = FINAL / "advisory-db"
DATABASE_SOURCE = "https://github.com/RustSec/advisory-db.git"
DATABASE_COMMIT = "f23b768236fe2880e4cfa167da662cad8ca79240"
AUDITOR = ROOT / "target/tools/cargo-audit/bin/cargo-audit.exe"
AUDITOR_SHA = "963960fb3c8707a433e85a9e7bb49b05e2dc4585ae898983e3e665dc19d169e5"
POLICY_SHA = "9678d7969dbc274721ac85ea7eb95507c4fd305a1f0cc50536988ccbe6b9a70d"
OUT = LAB / "selected-lock-audit"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def command(*args):
    return subprocess.check_output(args, timeout=30, stderr=subprocess.PIPE).decode().strip()


def add_lock(locks, data, origin):
    require(tomllib.loads(data.decode("utf-8")).get("package"), "empty lock " + origin)
    key = digest(data)
    if key in locks:
        require(locks[key]["data"] == data, "lock digest collision")
        locks[key]["origins"].append(origin)
    else:
        locks[key] = {"data": data, "origins": [origin]}


def collect_previous(locks):
    folder = FINAL / "selected-lock-audit"
    summary = json.loads((folder / "summary.json").read_text(encoding="utf-8"))
    inputs = json.loads((folder / "inputs.json").read_text(encoding="utf-8"))
    require(summary["status"] == "passed" and summary["source"] == SOURCE and
            summary["package_sha256"] == PACKAGE_SHA and
            summary["advisory_database_commit"] == DATABASE_COMMIT and
            summary["distinct_locks"] == summary["audited_locks"] == 10 and
            inputs["source"] == SOURCE and inputs["package_sha256"] == PACKAGE_SHA,
            "accepted final-source audit identity mismatch")
    listed = inputs["locks"]
    require(len(listed) == 10 and {v["sha256"] for v in listed} ==
            {v["sha256"] for v in summary["receipts"]}, "accepted lock list mismatch")
    for item in listed:
        key = item["sha256"]
        data = (folder / "locks" / (key + ".lock")).read_bytes()
        require(digest(data) == key and item["origins"], "accepted lock changed")
        add_lock(locks, data, "accepted-final-source:" + ",".join(item["origins"]))
    return len(listed)


def collect_published(locks):
    receipt = json.loads((LAB / "published-matrix-verified.json").read_text(encoding="utf-8"))
    require(receipt["status"] == "passed" and receipt["mode"] == "published" and
            receipt["source"] == SOURCE and
            receipt["canonical_package_sha256"] == PACKAGE_SHA and
            receipt["jobs"] == 8 and receipt["consumer_graphs"] == 16 and
            receipt["positive_tests"] == 752 and receipt["negative_probes"] == 32 and
            receipt["v030_passes"] == 80 and receipt["examples"] == 144,
            "published matrix receipt mismatch")
    folder = LAB / "published-selected-locks"
    index = json.loads((folder / "index.json").read_text(encoding="utf-8"))
    require(index == receipt["selected_locks"] and len(index) == receipt["selected_lock_count"],
            "published selected-lock index mismatch")
    for item in index:
        key = item["sha256"]
        data = (folder / (key + ".lock")).read_bytes()
        require(digest(data) == key and item["origins"], "published lock changed")
        add_lock(locks, data, "published-run-" + str(receipt["run_id"]) + ":" +
                 ",".join(item["origins"]))
    return receipt["run_id"]


def main():
    require(not OUT.exists(), "published audit output already exists")
    freshness = json.loads((LAB / "advisory-db-freshness.json").read_text(encoding="utf-8"))
    require(freshness["status"] == "passed" and freshness["remote_head"] ==
            freshness["local_head"] == DATABASE_COMMIT and freshness["local_clean"],
            "database freshness receipt mismatch")
    remote = command("git", "-c", "http.sslBackend=openssl", "ls-remote",
                     DATABASE_SOURCE, "HEAD").split()
    require(remote == [DATABASE_COMMIT, "HEAD"] and
            command("git", "-C", str(DATABASE), "rev-parse", "HEAD") == DATABASE_COMMIT and
            not command("git", "-C", str(DATABASE), "status", "--porcelain") and
            command("git", "-C", str(DATABASE), "remote", "get-url", "origin").lower() ==
            DATABASE_SOURCE.lower(), "official RustSec database changed")
    require(AUDITOR.is_file() and digest(AUDITOR.read_bytes()) == AUDITOR_SHA,
            "auditor identity mismatch")
    policy = (ROOT / ".cargo/audit.toml").read_bytes()
    committed_policy = subprocess.check_output(
        ["git", "show", SOURCE + ":.cargo/audit.toml"], cwd=ROOT, timeout=30)
    require(digest(policy) == POLICY_SHA and digest(policy) == digest(committed_policy),
            "audit policy identity mismatch")
    ignored = tomllib.loads(policy.decode("utf-8"))["advisories"]["ignore"]
    require(ignored == ["RUSTSEC-2026-0009"], "audit ignore policy mismatch")
    locks = {}
    prior_count = collect_previous(locks)
    prior_digests = set(locks)
    published_run = collect_published(locks)
    new_digests = sorted(set(locks) - prior_digests)
    OUT.mkdir()
    (OUT / "locks").mkdir()
    inputs = dict(source=SOURCE, canonical_package_sha256=PACKAGE_SHA,
                  published_run_id=published_run, accepted_previous_locks=prior_count,
                  distinct_locks=len(locks), new_published_lock_digests=new_digests,
                  database_source=DATABASE_SOURCE, database_commit=DATABASE_COMMIT,
                  database_path=str(DATABASE), auditor_sha256=AUDITOR_SHA,
                  policy_sha256=POLICY_SHA, ignored_advisories=ignored,
                  locks=[{"sha256": key, "origins": item["origins"]}
                         for key, item in sorted(locks.items())],
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / "inputs.json").write_text(json.dumps(inputs, indent=2) + "\n", encoding="utf-8")
    environment = dict(os.environ, CARGO_NET_OFFLINE="true")
    receipts = []
    failure = None
    try:
        run(OUT, "auditor-version", [str(AUDITOR), "--version"], ROOT, environment, 30)
        require((OUT / "auditor-version.log").read_text(encoding="utf-8").strip() ==
                "cargo-audit 0.22.2", "auditor version mismatch")
        for key, item in sorted(locks.items()):
            path = OUT / "locks" / (key + ".lock")
            path.write_bytes(item["data"])
            run(OUT, key, [str(AUDITOR), "audit", "--db", str(DATABASE),
                           "--no-fetch", "--file", str(path), "--json"],
                ROOT, environment, 180)
            raw = (OUT / (key + ".log")).read_bytes()
            report = json.loads(raw)
            require(report["database"]["last-commit"] in (None, DATABASE_COMMIT) and
                    report["database"]["advisory-count"] == 1277 and
                    not report["vulnerabilities"]["found"] and
                    report["vulnerabilities"]["count"] == 0 and not report["warnings"] and
                    report["settings"]["ignore"] == ignored,
                    "RustSec findings or identity mismatch: " + key)
            receipts.append(dict(sha256=key, origins=item["origins"],
                                 report_sha256=digest(raw),
                                 report_database_commit=report["database"]["last-commit"],
                                 advisory_count=report["database"]["advisory-count"]))
            (OUT / "progress.json").write_text(json.dumps({"completed": len(receipts),
                "expected": len(locks), "receipts": receipts}, indent=2), encoding="utf-8")
        require(command("git", "-C", str(DATABASE), "rev-parse", "HEAD") == DATABASE_COMMIT and
                not command("git", "-C", str(DATABASE), "status", "--porcelain") and
                digest(AUDITOR.read_bytes()) == AUDITOR_SHA and
                all(digest((OUT / "locks" / (key + ".lock")).read_bytes()) == key
                    for key in locks), "audit inputs changed during scan")
    except BaseException as error:
        failure = repr(error)
    summary = dict(status="failed" if failure else "passed", failure=failure,
                   source=SOURCE, canonical_package_sha256=PACKAGE_SHA,
                   published_run_id=published_run, database_commit=DATABASE_COMMIT,
                   database_identity_source="official upstream HEAD matched clean pinned local checkout",
                   accepted_previous_locks=prior_count, new_published_locks=len(new_digests),
                   distinct_locks=len(locks), audited_locks=len(receipts), receipts=receipts,
                   ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "receipts"}, indent=2))
    return 0 if failure is None else 1


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(SystemExit("audit interrupted")))
    raise SystemExit(main())
