"""Read-only exact annotated tag and immutable GitHub source-link verification."""
import datetime
import hashlib
import json
import urllib.request

from publication_common import COMMIT, LAB, PROOF, git, read_json, write_json


def main():
    refs = dict(line.split('\t', 1)[::-1] for line in git('ls-remote', 'origin',
        'refs/tags/v0.3.0', 'refs/tags/v0.3.0^{}', timeout=45).decode().splitlines())
    tag_object = refs.get('refs/tags/v0.3.0')
    peeled = refs.get('refs/tags/v0.3.0^{}')
    if not tag_object or tag_object == COMMIT or peeled != COMMIT:
        raise RuntimeError('remote v0.3.0 is not an annotated tag on exact release commit')
    inventory = read_json(PROOF / 'authoritative-package/inventory.json')
    targets = sorted({item['destination'].split('#', 1)[0]
                      for item in inventory['future_tag_links']})
    results = []
    for url in targets:
        request = urllib.request.Request(url, headers={'User-Agent': 'nbreq-030-tag-link-check'})
        with urllib.request.urlopen(request, timeout=45) as response:
            body = response.read()
            if response.status != 200 or response.url.rstrip('/') != url.rstrip('/') or not body:
                raise RuntimeError('versioned tag link is not exact: ' + url)
            results.append(dict(url=url, status=response.status, final_url=response.url,
                                bytes=len(body), sha256=hashlib.sha256(body).hexdigest()))
    result = dict(status='passed', source_commit=COMMIT, tag='v0.3.0',
                  tag_object=tag_object, peeled_commit=peeled,
                  versioned_source_links=results,
                  local_anchor_validation=PROOF / 'authoritative-package/inventory.json',
                  checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    result['local_anchor_validation'] = str(result['local_anchor_validation'])
    write_json(LAB / 'tagged-links-verified.json', result)
    print(json.dumps(dict(status=result['status'], tag_object=tag_object,
                          peeled_commit=peeled, links=len(results)), indent=2))


if __name__ == '__main__':
    main()
