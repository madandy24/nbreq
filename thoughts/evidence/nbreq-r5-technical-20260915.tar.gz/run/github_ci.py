"""Dispatch/read the NBReq workflow using Git's configured credential helper; never log credentials."""
import argparse, json, os, subprocess
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, urlopen
from urllib.error import HTTPError

BASE='https://api.github.com/repos/madandy24/nbreq'
ROOT=Path('C:/User/projects/nbreq/target/worktrees/nbreq-r5')
OUT=Path('C:/User/projects/nbreq/target/release-r5-20260915')

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

def api(path,method='GET',data=None,binary=False):
    assert path.startswith('/') and not path.startswith('//')
    credential=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',
        text=True,cwd=ROOT,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never'),
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    if credential.returncode:
        raise RuntimeError('GitHub credential helper is unavailable; no credential output retained')
    fields=dict(line.split('=',1) for line in credential.stdout.splitlines() if '=' in line)
    token=fields.get('password')
    if not token:
        raise RuntimeError('Credential helper returned no GitHub access token')
    request=Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,
        method=method,headers={'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28',
            'User-Agent':'nbreq-r5-checks','Authorization':'Bearer '+token})
    try:
        response=build_opener(NoRedirect).open(request,timeout=60)
        raw=response.read()
    except HTTPError as error:
        if error.code in (301,302,303,307,308) and binary:
            destination=error.headers['Location']
            assert urlsplit(destination).scheme=='https'
            # Signed archive downloads never receive the GitHub Authorization header.
            with urlopen(Request(destination,headers={'User-Agent':'nbreq-r5-checks'}),timeout=60) as response:
                return response.read()
        raise RuntimeError('GitHub API returned HTTP '+str(error.code)) from None
    return raw if binary else (json.loads(raw) if raw else None)

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('action',choices=['dispatch','discover','status','download'])
parser.add_argument('--sha')
parser.add_argument('--run',type=int)
args=parser.parse_args()
if args.action=='dispatch':
    assert args.sha
    dispatch_path=OUT/('dispatch-'+args.sha+'.json')
    assert not dispatch_path.exists()
    if (OUT/'dispatch.json').exists():
        assert json.loads((OUT/'dispatch.json').read_text())['sha'] != args.sha
    branch=api('/branches/codex%2Fr5-release')
    assert branch['commit']['sha']==args.sha
    api('/actions/workflows/ci.yml/dispatches','POST',{'ref':'codex/r5-release'})
    dispatch_path.write_text(json.dumps(dict(branch='codex/r5-release',sha=args.sha,status='accepted'),indent=2))
    print('Workflow dispatch accepted for '+args.sha)
elif args.action=='discover':
    query=urlencode(dict(branch='codex/r5-release',event='workflow_dispatch',per_page=10))
    runs=api('/actions/workflows/ci.yml/runs?'+query)['workflow_runs']
    matches=[r for r in runs if r['head_sha']==args.sha]
    (OUT/'discovered-runs.json').write_text(json.dumps(matches,indent=2))
    print(json.dumps([{k:r[k] for k in ['id','head_sha','status','conclusion','html_url']} for r in matches],indent=2))
elif args.action=='status':
    assert args.run
    run=api('/actions/runs/'+str(args.run))
    jobs=api('/actions/runs/'+str(args.run)+'/jobs?per_page=100')['jobs']
    (OUT/('hosted-'+str(args.run)+'-run.json')).write_text(json.dumps(run,indent=2))
    (OUT/('hosted-'+str(args.run)+'-jobs.json')).write_text(json.dumps(jobs,indent=2))
    print(json.dumps(dict(run={k:run[k] for k in ['id','head_sha','status','conclusion','html_url']},
        jobs=[{k:j[k] for k in ['id','name','status','conclusion']} for j in jobs]),indent=2))
else:
    assert args.run
    run=api('/actions/runs/'+str(args.run))
    assert run['status']=='completed'
    logs=OUT/('hosted-'+str(args.run)+'-logs.zip')
    assert not logs.exists()
    logs.write_bytes(api('/actions/runs/'+str(args.run)+'/logs',binary=True))
    artifacts=api('/actions/runs/'+str(args.run)+'/artifacts?per_page=100')['artifacts']
    (OUT/('hosted-'+str(args.run)+'-artifacts.json')).write_text(json.dumps(artifacts,indent=2))
    for artifact in artifacts:
        destination=OUT/('artifact-'+str(artifact['id'])+'.zip')
        assert not destination.exists() and not artifact['expired']
        destination.write_bytes(api('/actions/artifacts/'+str(artifact['id'])+'/zip',binary=True))
        print(artifact['name']+' -> '+destination.name)
    print('Saved hosted logs and '+str(len(artifacts))+' artifacts')
