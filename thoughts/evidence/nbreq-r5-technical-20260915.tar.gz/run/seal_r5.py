"""Seal R5 source and selected evidence, excluding build/cache/credential directories."""
from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile,zipfile

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-r5')
lab=Path('C:/User/projects/nbreq/target/release-r5-20260915')
commit='bdf5db590e4da6ee5a1534f408a370787453cff5'
summary=json.loads((lab/'final-hosted-summary.json').read_text())
assert summary['source_commit']==commit and summary['jobs_passed']==10
assert (lab/'windows-x86-patched-verify.exit').read_text(encoding='utf-8-sig').strip()=='0'
assert (lab/'audit-root-patched.exit').read_text(encoding='utf-8-sig').strip()=='0'
assert not subprocess.check_output(['git','diff',commit,'--','Cargo.toml','Cargo.lock','src','support','README.md','SECURITY.md','THIRD_PARTY_LICENSES.html','docs','examples'],cwd=root).strip()
items={}
def add(name,data):
    assert name not in items
    items[name]=data
for path in sorted(lab.iterdir()):
    if path.is_file() and path.suffix in ['.json','.log','.txt','.html','.exit','.zip','.py']:
        add('run/'+path.name,path.read_bytes())
for folder in ['rejected-rustls-02344','consumer-lock-audits']:
    for path in sorted((lab/folder).rglob('*')):
        if path.is_file():
            add('run/'+path.relative_to(lab).as_posix(),path.read_bytes())
for name in ['crates/rustls/RUSTSEC-2026-0285.md','crates/time/RUSTSEC-2026-0009.md']:
    add('advisories/'+name,(lab/'advisory-db'/name).read_bytes())
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=root,text=True).splitlines()
source={}
for name in paths:
    if name.startswith('thoughts/'):
        continue
    data=subprocess.check_output(['git','show',commit+':'+name],cwd=root)
    add('source/'+name,data)
    source[name]=hashlib.sha256(data).hexdigest()
add('source-manifest.json',json.dumps(dict(commit=commit,files=source),indent=2).encode())
patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
    rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
    rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b']
def inspect(name,data):
    if name.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for member in archive.namelist():
                if not member.endswith('/'):
                    inspect(name+'!'+member,archive.read(member))
    else:
        assert not any(re.search(pattern,data) for pattern in patterns),'Credential-pattern match in '+name
for name,data in items.items():
    inspect(name,data)
index={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in items.items()}
add('INDEX.json',json.dumps(index,indent=2).encode())
archive_path=root/'thoughts/evidence/nbreq-r5-technical-20260915.tar.gz'
manifest_path=root/'thoughts/evidence/nbreq_r5_artifacts.json'
assert not archive_path.exists() and not manifest_path.exists()
with tarfile.open(archive_path,'x:gz') as archive:
    for name,data in sorted(items.items()):
        entry=tarfile.TarInfo(name)
        entry.size=len(data)
        entry.mode=0o644
        archive.addfile(entry,io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    assert len(archive.getmembers())==len(items)
    for member in archive:
        assert archive.extractfile(member).read()==items[member.name]
manifest=dict(archive=archive_path.name,bytes=archive_path.stat().st_size,
    sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest(),files=len(items),source_commit=commit,
    initial_hosted_run=34930282926,passing_hosted_run=34930899817,
    consumer_cases=16,distinct_consumer_locks=2,consumer_test_executions=464,
    windows_x86_verifier='24/24, 107.003 seconds; initial failure retained with cause unconfirmed',
    advisory_database=summary['local_advisory_database'],registry_only=False,
    note='Technical R5 evidence before the owner README/examples refresh. Public hosted CI logs/artifacts, audited consumer locks, local red/green results and canonical Git source. Build/cache trees, Git credential material and main-before copies excluded.')
manifest_path.write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
