// Dependency-resolution probe only.
