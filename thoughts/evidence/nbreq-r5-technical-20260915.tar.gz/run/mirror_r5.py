"""Mirror scoped R5 changes after original-content checks; preserve main's owned differences."""
from pathlib import Path
import hashlib,json,subprocess,tomllib

main=Path('C:/User/projects/nbreq')
branch=main/'target/worktrees/nbreq-r5'
lab=main/'target/release-r5-20260915'
paths=subprocess.check_output(['git','diff','--name-only','620751b','HEAD'],cwd=branch,text=True).splitlines()
updates={}
for name in paths:
    if name=='thoughts/nbreq_r5_readiness.md':
        assert not (main/name).exists()
        updates[name]=(branch/name).read_bytes()
        continue
    base=subprocess.check_output(['git','show','620751b:'+name],cwd=branch).decode()
    actual=(main/name).read_text(encoding='utf-8')
    if name=='SECURITY.md':
        expected=base.replace('Only the latest published 0.x release is supported. Users of older 0.x releases may be asked to\nupgrade before receiving a fix. This policy will be revisited before 1.0.',
            'NBReq 0.1.1 is the latest published release. Mainline is the unreleased 0.2.0 development line.\nAs later 0.x versions are published, only the latest published 0.x release is supported; users of\nolder 0.x releases may be asked to upgrade before receiving a fix. This policy will be revisited\nbefore 1.0.')
        expected=expected.replace('`nbreq-darwin` support crates behind safe interfaces. Neither helper is intended as a standalone',
            '`nbreq-darwin` support crates behind safe interfaces. The latter is part of the unreleased 0.2\nline and must be published before that release. Neither helper is intended as a standalone')
        assert expected==actual,name
        candidate=(branch/name).read_text(encoding='utf-8')
        addition=candidate[candidate.index('NBReq 0.2 requires rustls'):candidate.index('## Reviewed advisory exceptions')]
        assert 'NBReq 0.2 requires rustls' not in actual
        updates[name]=actual.replace('## Reviewed advisory exceptions',addition+'## Reviewed advisory exceptions',1).encode()
    elif name=='tools/f5-observe/Cargo.lock':
        # Main has an older otherwise valid tool graph; update it in place after root is mirrored.
        before_f5=(main/name).read_bytes()
    else:
        assert actual==base,name
        updates[name]=(branch/name).read_bytes()
records=[]
for name,data in updates.items():
    target=main/name
    before=target.read_bytes() if target.exists() else None
    if before is not None:
        backup=lab/'main-before'/name
        backup.parent.mkdir(parents=True,exist_ok=True)
        assert not backup.exists()
        backup.write_bytes(before)
    target.write_bytes(data)
    records.append(dict(path=name,before=hashlib.sha256(before).hexdigest() if before is not None else None,
                        after=hashlib.sha256(data).hexdigest()))
backup=lab/'main-before/tools/f5-observe/Cargo.lock'
backup.parent.mkdir(parents=True,exist_ok=True)
assert not backup.exists()
backup.write_bytes(before_f5)
command=['cargo','update','--offline','--manifest-path','tools/f5-observe/Cargo.toml','-p','rustls','--precise','0.23.45']
result=subprocess.run(command,cwd=main,capture_output=True,timeout=120)
(lab/'main-f5-lock-update.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0
after_f5=(main/'tools/f5-observe/Cargo.lock').read_bytes()
def versions(data):
    return {(p['name'],p['version']) for p in tomllib.loads(data.decode())['package']}
removed=versions(before_f5)-versions(after_f5)
added=versions(after_f5)-versions(before_f5)
assert added=={('rustls','0.23.45'),('nbreq-winpoll','0.1.1')},added
assert removed=={('rustls','0.23.42'),('nbreq-winpoll','0.1.0'),('ipconfig','0.3.4'),('widestring','1.2.1'),('socket2','0.6.5')},removed
records.append(dict(path='tools/f5-observe/Cargo.lock',before=hashlib.sha256(before_f5).hexdigest(),
                    after=hashlib.sha256(after_f5).hexdigest(),note='Preserved otherwise different main tool versions'))
(lab/'main-mirror.json').write_text(json.dumps(records,indent=2))
print('Mirrored',len(records),'scoped files; preserved main release notices and unrelated tool versions')
