"""Validate final hosted source/results, audit distinct consumer locks, and inventory retained files."""
from pathlib import Path
import hashlib,json,subprocess,tomllib,zipfile

root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-r5')
lab=Path('C:/User/projects/nbreq/target/release-r5-20260915')
commit='bdf5db590e4da6ee5a1534f408a370787453cff5'
run_id=34930899817
run=json.loads((lab/f'hosted-{run_id}-run.json').read_text())
jobs=json.loads((lab/f'hosted-{run_id}-jobs.json').read_text())
assert run['head_sha']==commit and run['conclusion']=='success'
assert len(jobs)==10 and all(j['conclusion']=='success' for j in jobs)
artifacts=json.loads((lab/f'hosted-{run_id}-artifacts.json').read_text())
summary=[]
locks={}
audit_provenance=None
for artifact in artifacts:
    path=lab/('artifact-'+str(artifact['id'])+'.zip')
    with zipfile.ZipFile(path) as archive:
        names=archive.namelist()
        if artifact['name']=='advisory-evidence':
            report=json.loads(archive.read('cargo-audit.json'))
            assert not report['vulnerabilities']['found'] and not report['warnings']
            audit_provenance=archive.read('advisory-db.txt').decode()
            continue
        inputs=json.loads(archive.read('inputs.json'))
        result=json.loads(archive.read('result.json'))
        steps=json.loads(archive.read('steps.json'))
        assert inputs['commit']==commit and result['status']=='passed'
        assert result['steps']==17 and result['cases']==2 and len(steps)==17
        assert all(s['passed'] for s in steps)
        assert sum(s['exit_code']==101 for s in steps)==4
        for name,digest in inputs['files'].items():
            blob=subprocess.check_output(['git','show',commit+':'+name],cwd=root)
            assert digest in [hashlib.sha256(blob).hexdigest(),hashlib.sha256(blob.replace(b'\n',b'\r\n')).hexdigest()],(artifact['name'],name)
        cases=[]
        for name in names:
            if name.endswith('/Cargo.lock'):
                lock=archive.read(name)
                packages=tomllib.loads(lock.decode())['package']
                assert [p['version'] for p in packages if p['name']=='rustls']==['0.23.45']
                digest=hashlib.sha256(lock).hexdigest()
                locks[digest]=lock
                cases.append(dict(path=name,sha256=digest))
        assert len(cases)==2
        rustc_log=next(n for n in names if n.endswith('-rustc.log'))
        compiler=archive.read(rustc_log).decode().strip()
        summary.append(dict(job=artifact['name'],platform=inputs['platform'],machine=inputs['machine'],
            toolchains=inputs['toolchains'],rustc=compiler,steps=result['steps'],locks=cases,
            artifact_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert len(summary)==8 and audit_provenance
audit_dir=lab/'consumer-lock-audits'
audit_dir.mkdir(exist_ok=False)
audit_results=[]
for digest,lock in locks.items():
    lock_path=audit_dir/(digest+'.lock')
    lock_path.write_bytes(lock)
    command=['C:/User/projects/nbreq/target/tools/cargo-audit/bin/cargo-audit.exe','audit',
        '--db',str(lab/'advisory-db'),'--no-fetch','--file',str(lock_path),'--json']
    result=subprocess.run(command,cwd=root,capture_output=True,timeout=180)
    (audit_dir/(digest+'.json')).write_bytes(result.stdout)
    (audit_dir/(digest+'.stderr.log')).write_bytes(result.stderr)
    report=json.loads(result.stdout)
    assert result.returncode==0 and not report['vulnerabilities']['found'] and not report['warnings'],digest
    audit_results.append(dict(lock_sha256=digest,exit_code=result.returncode))
database=subprocess.check_output(['git','-C',str(lab/'advisory-db'),'log','-1','--format=%H %cI'],text=True).strip()
result=dict(source_commit=commit,hosted_run=run_id,hosted_url=run['html_url'],jobs_passed=10,
    consumer_jobs=summary,consumer_stages=136,consumer_test_executions=464,
    negative_feature_probes=32,distinct_consumer_locks=len(locks),consumer_audits=audit_results,
    local_advisory_database=database,hosted_advisory_provenance=audit_provenance,
    registry_only=False)
(lab/'final-hosted-summary.json').write_text(json.dumps(result,indent=2))
print('Verified 10 hosted jobs, 136 consumer stages, 16 cases and',len(locks),'distinct audited consumer locks')
print('Hosted advisory identity:',audit_provenance.strip())
