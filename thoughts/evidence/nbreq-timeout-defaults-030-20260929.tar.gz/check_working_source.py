from pathlib import Path
import hashlib, json, subprocess

lab = Path(__file__).resolve().parent
root = lab.parents[1]
raw = (lab/'timeout-source.json').read_bytes()
identity = hashlib.sha256(raw).hexdigest()
assert identity == 'af66faa1fa91b2ea096fca5b02b591c3b106129837695be151101a9b9f7e8fe9'
record = json.loads(raw)
for name, expected in record['files'].items():
    path = (lab if name in {'gate.py','owned_command.py'} else root)/name
    assert path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
result = dict(status='passed',source_manifest_sha256=identity,files=len(record['files']),
              baseline=record['baseline'],current_head=subprocess.check_output(
                  ['git','rev-parse','HEAD'],cwd=root,text=True).strip())
(lab/'working-source-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
