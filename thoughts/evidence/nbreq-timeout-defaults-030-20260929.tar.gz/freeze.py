"""Freeze the allowlisted NBReq source and bounded test harness only."""
from pathlib import Path
import hashlib, json, re, subprocess, tarfile

root = Path('C:/User/projects/nbreq')
lab = Path(__file__).resolve().parent
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
prefixes = ('src/', 'tests/', 'examples/', 'docs/', 'smtp/', 'support/', 'tools/xtask/', 'tools/release-consumer/')
top = {'Cargo.toml','Cargo.lock','README.md','CHANGELOG.md','CONTRIBUTING.md','SECURITY.md',
       'LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.html','about.hbs','about.toml','.cargo/audit.toml'}
files = {name:root/name for name in paths if (name in top or name.startswith(prefixes))
         and '/target/' not in name and '__pycache__' not in name}
files['gate.py'] = lab / 'gate.py'
files['owned_command.py'] = lab / 'owned_command.py'
assert all(path.is_file() and not path.is_symlink() for path in files.values())
suspect = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
for name, path in files.items():
    assert not suspect.search(path.read_bytes()), name
record = dict(baseline=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
              working_changes=True, files={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in files.items()})
raw = (json.dumps(record, indent=2)+'\n').encode()
identity = hashlib.sha256(raw).hexdigest()
manifest = lab / 'timeout-source.json'
manifest.write_bytes(raw)
archive = lab / ('nbreq-timeouts-'+identity[:12]+'.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as bundle:
    for name, path in files.items():
        bundle.add(path, arcname=name, recursive=False)
    bundle.add(manifest, arcname='timeout-source.json', recursive=False)
receipt = dict(archive=str(archive), sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
               bytes=archive.stat().st_size, regular_members=len(files)+1,
               source_manifest_sha256=identity, source_files=len(files))
(lab/'freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
