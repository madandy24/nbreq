# Independent review: NBReq 0.3.0 timeout defaults

Reviewed 2026-09-29. Accepted for implementation closeout, subject to the separate
final retained-archive inventory check. No release/publication approval is implied.
The reviewer read source, scripts, raw logs, metadata, locks and archives; ran no
Cargo commands and changed no tracked source.

## Source and documentation

The accepted working source is based on `b0e8f1910234fbce9b99e568c93eed12bdc8359f`.
Its manifest SHA256 is
`af66faa1fa91b2ea096fca5b02b591c3b106129837695be151101a9b9f7e8fe9`.
The 167-member source archive is 521793 bytes, SHA256
`09e8ca9307d1e743b801b20eec752c7bba6972777b7eb9984a481b0317ce182c`.
All manifest hashes, archive members and current source bytes were checked.

The constructor defaults and optional setters implement the agreed policy.
Explicit `None` disables a timer; `build()` preserves overrides. Fresh stream
builders omit the total cap, while conversion from `Request` and complete options
replacement preserve all options. Quiet established TCP/TLS has no read deadline;
write inactivity is active only for accepted pending output. Existing admission,
progress, backpressure, direct-TLS minimum-deadline and fresh STARTTLS semantics
remain unchanged. README, guides, migration notes and examples explain these
distinctions consistently. No actionable source or documentation findings remain.

All eight edited lockfiles change only the local NBReq version. Root manifest
changes are version 0.3.0 and migration-document inclusion; runtime dependency
ranges and helper versions remain unchanged. SMTP remains unpublished at 0.1.0.
The legacy consumer still selects actual registry 0.1.1.

## Actual host evidence

| Host | Stable compiler | Other compiler | Accepted result per compiler |
| --- | --- | --- | --- |
| Windows x86_64 MSVC | 1.97.1 | 1.85.0 | 30 verifier stages; 18 local example cases |
| Apple Silicon macOS | 1.98.0 | 1.85.0 | 30 verifier stages; 18 local example cases |
| Intel macOS | 1.98.0 | 1.85.0 | 30 verifier stages; 18 local example cases |
| Linux x86_64 GNU | 1.98.0 | 1.85.0 | 30 verifier stages; 18 local example cases |

Each raw log contains the correct frozen source root, all 30 ordered stages and
PASS records, successful command receipts, and 37 passing occurrences of the new
default tests across feature suites. Relevant existing TCP write/progress,
HTTP backpressure/redirect, DNS and TLS tiny-window regressions pass. Direct TLS
and STARTTLS example logs contain their expected protected-byte replies. The
response-limit example's nonzero exit is expected and checked.

ARM, Intel and Linux downloaded archives match their collection checksums and
all 69 extracted regular files per host (plus three safe directory entries).
Collection receipts identify the remote sessions and request IDs. Accepted
results bind the same manifest and report unchanged source. The current 166
frozen source/harness hashes were independently rechecked after Linux completed.

## Consumers and limits

Raw consumer evidence contains 44 successful steps: four compiler/graph cases,
20 feature runs, 188 passing tests, the new optional-timeout test passing in all
20 runs, and eight expected feature-gated E0432 import failures. Copied consumer
sources match the freeze. Metadata selects local NBReq 0.3.0 and local helpers,
the registry Mozilla-root dependency, and Mio 1.2.3 in coexistence cases.

Stable 1.97.1 retains unchanged fresh locks. Rust 1.85.0 uses the documented
compatibility selection: yoke-derive 0.8.3 to 0.8.2 plus required synstructure
0.13.2, with original locks retained; dependency-name disambiguation does not
change other package identities. This is local-source/helper-override proof,
not registry-only acceptance. The successful 115-entry Cargo package listing
includes the new migration guide; the initial separator assertion was a checker
issue, not a Cargo failure or package build.

New tests assert configuration, while existing controlled runtime tests exercise
the unchanged timer machinery. These checks do not wait literal 10/30/120-second
defaults. DNS examples are built but not run against live DNS; no live HTTPS,
mail delivery or new Wine validation is claimed.

The initial genuine test-lint failure and subsequent stale-xtask-cache failure
are retained and excluded from accepted results. The latter raw log points to
the old source directory. The accepted Windows run uses an isolated build root.
The harness SIGTERM fix invokes owned-process-tree cleanup. Export and proposed
retention scope exclude build trees, GDS source, raw bridge payloads and
credentials; reviewed source marker scans were clear. Final retention bytes and
inventory require their own post-collection check.
