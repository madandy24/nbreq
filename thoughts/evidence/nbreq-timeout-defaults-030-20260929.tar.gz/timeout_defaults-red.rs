//! Public timeout defaults and the existing ways to replace them.
//!
//! These assertions are deliberately independent of wall-clock scheduling: the
//! runtime deadline and backpressure paths have controlled-fixture coverage in
//! the HTTP, DNS, and TCP suites.

use std::net::SocketAddr;
use std::time::Duration;

use nbreq::{Request, RequestOptions, StreamRequest, TcpConnectRequest, TlsOptions};
#[cfg(feature = "resolver")]
use nbreq::ResolveRequest;

fn seconds(value: u64) -> Option<Duration> {
    Some(Duration::from_secs(value))
}

#[test]
fn buffered_http_options_and_request_sugar_have_finite_defaults() {
    let options = RequestOptions::default();
    assert_eq!(options.connect_timeout, seconds(10));
    assert_eq!(options.inactivity_timeout, seconds(30));
    assert_eq!(options.total_timeout, seconds(120));

    for request in [
        Request::get("https://example.test/").build().unwrap(),
        Request::post("https://example.test/").build().unwrap(),
    ] {
        assert_eq!(request.options(), &options);
    }
}

#[test]
fn buffered_http_explicit_options_replace_defaults_without_reintroducing_timers() {
    let mut disabled = RequestOptions::default();
    disabled.connect_timeout = None;
    disabled.inactivity_timeout = None;
    disabled.total_timeout = None;
    let request = Request::get("https://example.test/")
        .options(disabled.clone())
        .build()
        .unwrap();
    assert_eq!(request.options(), &disabled);

    let overridden = Request::get("https://example.test/")
        .connect_timeout(Duration::from_secs(2))
        .inactivity_timeout(Duration::from_secs(3))
        .total_timeout(Duration::from_secs(4))
        .build()
        .unwrap();
    assert_eq!(overridden.options().connect_timeout, seconds(2));
    assert_eq!(overridden.options().inactivity_timeout, seconds(3));
    assert_eq!(overridden.options().total_timeout, seconds(4));
}

#[test]
fn streaming_http_has_no_total_deadline_unless_selected() {
    let stream = StreamRequest::get("https://example.test/events")
        .build()
        .unwrap();
    assert_eq!(stream.options().connect_timeout, seconds(10));
    assert_eq!(stream.options().inactivity_timeout, seconds(30));
    assert_eq!(stream.options().total_timeout, None);

    let explicit = StreamRequest::get("https://example.test/events")
        .total_timeout(Duration::from_secs(7))
        .build()
        .unwrap();
    assert_eq!(explicit.options().total_timeout, seconds(7));

    // Conversion must preserve caller-selected buffered options rather than
    // silently switch a request to the streaming builder's defaults.
    let buffered = Request::get("https://example.test/events").build().unwrap();
    let converted = StreamRequest::from(buffered);
    assert_eq!(converted.options().total_timeout, seconds(120));
}

#[test]
#[cfg(feature = "resolver")]
fn public_dns_has_a_finite_total_deadline_that_can_be_replaced() {
    let default = ResolveRequest::hostname("example.test").build().unwrap();
    assert_eq!(default.total_timeout(), seconds(30));

    let overridden = ResolveRequest::hostname("example.test")
        .total_timeout(Duration::from_secs(8))
        .build()
        .unwrap();
    assert_eq!(overridden.total_timeout(), seconds(8));
}

#[test]
fn plain_tcp_bounds_establishment_and_pending_writes_but_not_idle_reads() {
    let literal: SocketAddr = "127.0.0.1:443".parse().unwrap();
    for request in [
        TcpConnectRequest::literal(literal).build().unwrap(),
        TcpConnectRequest::hostname("example.test", 443)
            .build()
            .unwrap(),
    ] {
        assert_eq!(request.connect_timeout(), seconds(10));
        assert_eq!(request.read_inactivity_timeout(), None);
        assert_eq!(request.write_inactivity_timeout(), seconds(30));
    }

    let overridden = TcpConnectRequest::literal(literal)
        .connect_timeout(Duration::from_secs(2))
        .read_inactivity_timeout(Duration::from_secs(3))
        .write_inactivity_timeout(Duration::from_secs(4))
        .build()
        .unwrap();
    assert_eq!(overridden.connect_timeout(), seconds(2));
    assert_eq!(overridden.read_inactivity_timeout(), seconds(3));
    assert_eq!(overridden.write_inactivity_timeout(), seconds(4));
}

#[test]
fn standalone_tls_handshake_retains_its_ten_second_bound() {
    let options = TlsOptions::new("example.test").unwrap();
    assert_eq!(options.timeout(), Duration::from_secs(10));
}
