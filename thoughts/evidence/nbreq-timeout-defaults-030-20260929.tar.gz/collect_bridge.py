from pathlib import Path, PurePosixPath
import argparse, base64, hashlib, json, tarfile

p = argparse.ArgumentParser()
p.add_argument('result', type=Path)
p.add_argument('host')
a = p.parse_args()
assert a.host in {'linux', 'intel', 'arm'}
lab = Path(__file__).resolve().parent
r = json.loads(a.result.read_text(encoding='utf-8-sig'))
assert r['status'] == 'completed' and r['ok'] and r['exit_code'] == 0
lines = r['output'].strip().splitlines()
expected = lines[0].split()[0]
assert len(expected) == 64
raw = base64.b64decode(''.join(lines[1:]), validate=True)
assert hashlib.sha256(raw).hexdigest() == expected
archive = lab / (a.host + '-evidence.tar.gz')
assert not archive.exists()
archive.write_bytes(raw)
out = lab / (a.host + '-evidence')
out.mkdir(exist_ok=False)
with tarfile.open(archive) as bundle:
    members = bundle.getmembers()
    assert sum(m.size for m in members) < 50_000_000
    for member in members:
        name = PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts
        assert '\\' not in member.name and ':' not in member.name
        assert 'build' not in name.parts and member.size < 20_000_000
        target = out / member.name
        assert target.resolve().is_relative_to(out.resolve())
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            assert member.isfile()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(bundle.extractfile(member).read())
receipt = dict(host=a.host, bridge_request_id=r['id'], session=r['session'],
               archive_sha256=expected, bytes=len(raw),
               result=json.loads((out/'result.json').read_text()))
(lab/(a.host+'-collection.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
