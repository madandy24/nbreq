from pathlib import Path, PurePosixPath
import hashlib, json, tarfile

lab = Path(__file__).resolve().parent
receipt = json.loads((lab/'freeze.json').read_text())
archive = Path(receipt['archive'])
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt['sha256']
out = lab / ('source-' + receipt['source_manifest_sha256'][:12])
out.mkdir(exist_ok=False)
with tarfile.open(archive) as bundle:
    members = bundle.getmembers()
    assert len(members) == receipt['regular_members']
    for member in members:
        name = PurePosixPath(member.name)
        assert member.isfile() and not name.is_absolute() and '..' not in name.parts
        assert '\\' not in member.name and ':' not in member.name
        target = out / member.name
        assert target.resolve().is_relative_to(out.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(bundle.extractfile(member).read())
print(out)
