# NBReq 0.3.0 timeout-default evidence, 2026-09-29

Baseline: b0e8f1910234fbce9b99e568c93eed12bdc8359f, plus the reviewed working
changes. The source identity for accepted runs is the SHA256 of
`timeout-source.json`: af66faa1fa91b2ea096fca5b02b591c3b106129837695be151101a9b9f7e8fe9.
The corresponding 167-member source archive is included for reproduction.

`summary.json` is derived from the actual host logs/receipts and external
consumer results. Each accepted platform run verifies source hashes before and
after running the 30-stage verifier and 18 local example checks with stable and
Rust 1.85.0. Compiler identity is in each `*-rustc.log`; "stable" is not a claim
that every machine installed the same compiler patch. Example DNS programs are
built, but the example runner does not execute live DNS/HTTPS. Tests use local
fixtures; no mail was sent and no new Wine execution is claimed by this pass.

`red.log` and `timeout_defaults-red.rs` preserve the baseline failure: four
default-policy assertions failed while two existing-behaviour controls passed.
The initial compile mistake is separately retained in `preflight-compile-error.log`.
`windows-04160b843210` records the first genuine test-lint failure. The next
attempt, `windows-af66faa1fa91`, reused a cached xtask binary with the previous
compile-time source directory; its log identifies that old path. Neither is
accepted as proof of the final source. `windows-af66faa1fa91-isolated` uses a
fresh build directory and is the accepted Windows run. Build outputs are omitted.

The new tests assert defaults and Duration/Some/None setter behaviour. Existing
controlled runtime tests exercise timeout expiry, progress, backpressure, DNS,
redirects, TCP writes and TLS. The test strategy does not wait literal 10/30/120
seconds for each new default, and does not claim a new timer implementation.

The external consumer matrix uses local root/Darwin/winpoll overrides, not a
published 0.3.0 package. Both fresh and Mio-coexistence cases exercise five feature
combinations per compiler; the new v030 test passes in all 20. Stable keeps fresh
dependency resolution. Rust 1.85 applies the existing documented compatibility
selection for yoke-derive; original and selected locks are retained. Package
listing verifies migration-guide inclusion, not registry-only package acceptance.

The owner authorised uploads and old NBReq cleanup on Linode. Only an inactive
7.4 GB build directory was deleted after path/process checks; old logs remained.
Bridge collection receipts identify the actual remote runs; approval tokens,
credentials, GDS source and build directories are excluded.

`retained-files.json` hashes each retained input. Publication of 0.3.0 remains
a separate maintainer action.
