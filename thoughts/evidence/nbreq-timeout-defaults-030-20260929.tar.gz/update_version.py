from pathlib import Path
import re, subprocess, tomllib

root = Path('C:/User/projects/nbreq')
def edit(name, pairs):
    path = root / name
    text = path.read_text(encoding='utf-8')
    for old, new in pairs:
        if new in text:
            continue
        assert old in text, (name, old)
        text = text.replace(old, new)
    path.write_text(text, encoding='utf-8', newline='\n')

edit('Cargo.toml', [('version = "0.2.1"', 'version = "0.3.0"'),
                   ('"/docs/migrating-to-0.2.md",', '"/docs/migrating-to-0.2.md",\n    "/docs/migrating-to-0.3.md",')])
edit('smtp/Cargo.toml', [('version = "0.2.1"', 'version = "0.3.0"')])
for name in ['tools/release-consumer/Cargo.toml', 'tools/release-consumer/package_candidate.py',
             'tools/release-consumer/registry.py', 'tools/release-consumer/run.py',
             'tools/release-consumer/README.md', '.github/workflows/registry-release.yml']:
    edit(name, [('0.2.1', '0.3.0')])
for name in ['tools/release-consumer/registry.py', 'tools/release-consumer/run.py']:
    edit(name, [('nbreq-021-', 'nbreq-030-')])

# Only local path-package identity changes. Historical registry graphs and saved
# evidence remain unchanged; no dependency re-resolution occurs here.
for name in subprocess.check_output(['git', 'ls-files', '*Cargo.lock'], cwd=root, text=True).splitlines():
    if name.startswith(('thoughts/', 'experiments/', 'vendor/')):
        continue
    path = root / name
    original = path.read_text(encoding='utf-8')
    parsed = tomllib.loads(original)
    entries = [p for p in parsed['package'] if p['name'] == 'nbreq' and 'source' not in p]
    if not entries:
        continue
    assert len(entries) == 1
    old = entries[0]['version']
    text, count = re.subn(r'(\[\[package\]\]\nname = "nbreq"\nversion = ")' + re.escape(old) + '"',
                          r'\g<1>0.3.0"', original)
    assert count == 1, name
    path.write_text(text, encoding='utf-8', newline='\n')
    print('Local package lock identity:', name)

edit('README.md', [('This guide covers NBReq 0.2.1.', 'This checkout targets NBReq 0.3.0 (unreleased).'),
                   ('nbreq = "0.2.1"', 'nbreq = "0.3.0"')])
edit('docs/getting-started.md', [('blob/v0.2.1/', 'blob/main/'),
    ('This guide targets NBReq 0.2.1.', 'This guide targets NBReq 0.3.0 (unreleased).'),
    ('nbreq = "0.2.1"', 'nbreq = "0.3.0"'),
    ('version = "0.2.1"', 'version = "0.3.0"'),
    ('NBReq 0.2.1 targets Rust', 'NBReq 0.3.0 targets Rust')])
edit('docs/tcp-tls.md', [('API in NBReq 0.2.1.', 'API in NBReq 0.3.0 (unreleased).'),
    ('NBReq 0.2.1 applies', 'NBReq applies'), ('version = "0.2.1"', 'version = "0.3.0"')])
edit('examples/README.md', [('API in NBReq 0.2.1.', 'API in NBReq 0.3.0.')])
edit('CONTRIBUTING.md', [('NBReq 0.2.1 or newer within the compatible line.', 'NBReq 0.3.0 or newer within the compatible line.')])
edit('smtp/README.md', [('requiring NBReq 0.2.1', 'requiring NBReq 0.3.0'), ('blob/v0.2.1/', 'blob/main/')])
edit('src/lib.rs', [('#![doc = include_str!("../docs/migrating-to-0.2.md")]',
                    '#![doc = include_str!("../docs/migrating-to-0.3.md")]\n#![doc = include_str!("../docs/migrating-to-0.2.md")]')])
print('Core, local consumers and development documentation target 0.3.0; no publication.')
