"""Retain bounded source, failures and actual host/consumer proof without builds."""
from pathlib import Path
import hashlib, json, re, tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[1]
identity = 'af66faa1fa91b2ea096fca5b02b591c3b106129837695be151101a9b9f7e8fe9'
folders = ['windows-04160b843210', 'windows-af66faa1fa91',
           'windows-af66faa1fa91-isolated', 'arm-evidence', 'intel-evidence', 'linux-evidence',
           'consumer-pre-r5-af66faa1fa91', 'consumer-pre-r5-supervisor-af66faa1fa91']
summary = dict(source_manifest_sha256=identity, hosts={}, consumers={})
for host, folder in [('Windows',folders[2]),('Apple Silicon','arm-evidence'),
                     ('Intel Mac','intel-evidence'),('Linux','linux-evidence')]:
    base = lab/folder
    result = json.loads((base/'result.json').read_text())
    assert result['status'] == 'passed' and result['source_unchanged']
    assert result['source_manifest_sha256'] == identity
    entry = dict(platform=result['platform'], machine=result['machine'], toolchains={})
    for compiler in ['stable','1.85.0']:
        log = (base/(compiler+'-verify.log')).read_text(errors='replace')
        assert 'NBReq verification complete: all 30 steps passed' in log
        assert 'source-04160b843210' not in log
        for stage in ['verify','examples-build','examples-run']:
            assert json.loads((base/(compiler+'-'+stage+'.result.json')).read_text())['exit_code'] == 0
        examples = json.loads((base/(compiler+'-examples')/'summary.json').read_text())
        assert examples['status'] == 'passed' and examples['executions'] == 18 and examples['local_only']
        entry['toolchains'][compiler] = dict(rustc=(base/(compiler+'-rustc.log')).read_text().splitlines()[0],
                                            verifier_stages=30, local_example_executions=18)
    summary['hosts'][host] = entry
consumer = lab/'consumer-pre-r5-af66faa1fa91'
assert json.loads((consumer/'result.json').read_text())['status'] == 'passed'
assert json.loads((lab/'consumer-pre-r5-supervisor-af66faa1fa91/result.json').read_text())['status'] == 'passed'
api_logs = [p for p in consumer.glob('*.log')
            if 'test v030::optional_timeout_api_and_stream_conversion_work_for_consumers ... ok'
            in p.read_text(errors='replace')]
assert len(api_logs) == 20
summary['consumers'] = dict(cases=4, feature_runs=20, optional_timeout_test_passes=20,
                           stable='fresh dependency resolution',
                           rust_1_85='documented compatibility-selected yoke-derive 0.8.2 lock',
                           registry_only=False)
(lab/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files = {}
for base in [lab/folder for folder in folders]:
    for path in base.rglob('*'):
        if path.is_file() and not any(part in {'build','target','__pycache__'} for part in path.relative_to(base).parts):
            files[path.relative_to(lab).as_posix()] = path
for path in lab.iterdir():
    if path.is_file() and (path.suffix in {'.py','.json','.log','.rs','.txt','.md'}
                          or path.name.startswith('nbreq-timeouts-') and path.name.endswith('.tar.gz')):
        if path.name not in {'retention-receipt.json','retained-files.json'}:
            files[path.name] = path
suspect = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
for name,path in files.items():
    assert not path.is_symlink() and path.stat().st_size < 20_000_000, name
    if path.suffix != '.gz':
        assert not suspect.search(path.read_bytes()), name
inventory = {name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
             for name,p in sorted(files.items())}
(lab/'retained-files.json').write_text(json.dumps(inventory,indent=2)+'\n')
files['retained-files.json'] = lab/'retained-files.json'
archive = root/'thoughts/evidence/nbreq-timeout-defaults-030-20260929.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9) as bundle:
    for name,path in sorted(files.items()):
        bundle.add(path,arcname=name,recursive=False)
receipt = dict(archive=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
               bytes=archive.stat().st_size, files=len(files))
(lab/'retention-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
