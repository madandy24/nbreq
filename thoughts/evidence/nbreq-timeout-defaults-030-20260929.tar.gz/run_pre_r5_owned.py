"""Run frozen pre-R5 consumers under the owned process-tree supervisor."""

import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys


LAB = Path(__file__).resolve().parent
ROOT = LAB / "source-af66faa1fa91"
OUT = LAB / "consumer-pre-r5-af66faa1fa91"
SUPERVISOR = LAB / "consumer-pre-r5-supervisor-af66faa1fa91"
EXPECTED_MANIFEST_SHA256 = "af66faa1fa91b2ea096fca5b02b591c3b106129837695be151101a9b9f7e8fe9"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_source():
    manifest_path = ROOT / "timeout-source.json"
    if sha256(manifest_path) != EXPECTED_MANIFEST_SHA256:
        raise RuntimeError("frozen source manifest changed")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if path.is_symlink() or ROOT not in path.resolve().parents or sha256(path) != expected:
            raise RuntimeError("frozen source changed: " + name)
    return manifest


def main():
    def terminate(_signum, _frame):
        raise SystemExit("consumer supervisor received SIGTERM")

    signal.signal(signal.SIGTERM, terminate)
    manifest = verify_source()
    if OUT.exists() or SUPERVISOR.exists():
        raise RuntimeError("consumer evidence directory already exists")
    SUPERVISOR.mkdir()
    module_spec = importlib.util.spec_from_file_location(
        "frozen_owned_command", ROOT / "owned_command.py"
    )
    owned = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(owned)
    environment = dict(os.environ)
    environment.update(
        CARGO_BUILD_JOBS="2",
        CARGO_INCREMENTAL="0",
        CARGO_PROFILE_DEV_DEBUG="0",
        CARGO_PROFILE_TEST_DEBUG="0",
    )
    command = [
        sys.executable,
        "-B",
        "tools/release-consumer/pre_r5.py",
        "--out",
        str(OUT),
        "--toolchains",
        "stable",
        "1.85.0",
    ]
    (SUPERVISOR / "inputs.json").write_text(
        json.dumps(
            {
                "frozen_manifest_sha256": EXPECTED_MANIFEST_SHA256,
                "manifest_baseline_commit": manifest["baseline"],
                "pre_r5_sha256": manifest["files"]["tools/release-consumer/pre_r5.py"],
                "v030_sha256": manifest["files"]["tools/release-consumer/src/v030.rs"],
                "meaning": "Local source/Darwin/winpoll overrides; not registry-only proof",
                "toolchains": ["stable", "1.85.0"],
                "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    failure = None
    try:
        owned.command(command, ROOT, SUPERVISOR, "pre-r5", environment, 7200)
    except BaseException as error:
        failure = repr(error)
    try:
        verify_source()
    except BaseException as error:
        failure = (failure + "; " if failure else "") + "final source: " + repr(error)
    result_path = OUT / "result.json"
    result = json.loads(result_path.read_text(encoding="utf-8")) if result_path.exists() else None
    summary = {
        "status": "passed" if failure is None and result and result.get("status") == "passed" else "failed",
        "failure": failure,
        "consumer_result": result,
        "frozen_manifest_sha256": EXPECTED_MANIFEST_SHA256,
        "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    (SUPERVISOR / "result.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary), flush=True)
    return 0 if summary["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
