"""Bounded exact-source timeout-default verification; no live service traffic."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, platform, signal, subprocess, sys, time
from owned_command import command, stop

def terminate(signum, _frame):
    raise SystemExit(128 + signum)

signal.signal(signal.SIGTERM, terminate)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify(root):
    path = root / 'timeout-source.json'
    value = json.loads(path.read_text())
    for name, expected in value['files'].items():
        source = root / name
        if source.is_symlink() or root not in source.resolve().parents or digest(source) != expected:
            raise RuntimeError('source mismatch: ' + name)
    return digest(path), value

p = argparse.ArgumentParser()
p.add_argument('action', choices=['launch', 'run'])
p.add_argument('--root', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--target', type=Path)
a = p.parse_args()
root, out = a.root.resolve(), a.out.resolve()
if a.action == 'launch':
    out.mkdir(parents=True, exist_ok=False)
    argv = [sys.executable, '-B', str(Path(__file__).resolve()), 'run', '--root', str(root), '--out', str(out)]
    if a.target:
        argv += ['--target', str(a.target.resolve())]
    with (out / 'job.log').open('xb') as log:
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                 start_new_session=os.name != 'nt', close_fds=True)
        try:
            receipt = dict(pid=child.pid, command=argv, out=str(out))
            (out / 'launch.json').write_text(json.dumps(receipt, indent=2))
        except BaseException:
            stop(child, log)
            raise
    print(json.dumps(receipt))
    sys.exit(0)

out.mkdir(parents=True, exist_ok=True)
with (out / 'run.token').open('x') as handle:
    handle.write(str(os.getpid()))
started = time.monotonic()
result = dict(status='failed', platform=platform.platform(), machine=platform.machine(),
              started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
try:
    identity, source = verify(root)
    result.update(source_manifest_sha256=identity, source_baseline=source['baseline'],
                  source_working_changes=True, source_files=len(source['files']))
    target = a.target.resolve() if a.target else out / 'build'
    env = dict(os.environ)
    env['PATH'] = str(Path.home() / '.cargo' / 'bin') + os.pathsep + env.get('PATH', '')
    env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUSTDOCFLAGS='-D warnings')
    env.pop('CARGO_BUILD_TARGET', None)
    for toolchain in ['stable', '1.85.0']:
        selected = dict(env, RUSTUP_TOOLCHAIN=toolchain)
        command(['rustc', '-vV'], root, out, toolchain+'-rustc', selected, 60)
        command(['cargo', '--version'], root, out, toolchain+'-cargo', selected, 60)
        command(['cargo', 'fetch', '--locked'], root, out, toolchain+'-fetch', selected, 300)
        command(['cargo', 'run', '--locked', '--offline', '--manifest-path', 'tools/xtask/Cargo.toml',
                 '--', 'verify', '--offline'], root, out, toolchain+'-verify', selected, 1200)
        command(['cargo', 'build', '--locked', '--offline', '--examples'], root, out,
                toolchain+'-examples-build', selected, 300)
        command([sys.executable, '-B', 'tools/release-consumer/check_examples.py', '--bin-dir',
                 str(target/'debug/examples'), '--out', str(out/(toolchain+'-examples'))],
                root, out, toolchain+'-examples-run', selected, 300)
    assert verify(root)[0] == identity
    result.update(status='passed', source_unchanged=True)
except BaseException as error:
    result['error'] = repr(error)
    raise
finally:
    result['elapsed_seconds'] = time.monotonic() - started
    (out / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
