from pathlib import Path
import hashlib,json,os,re,subprocess,sys
from urllib.parse import unquote,urlsplit
from owned_command import command
lab=Path(__file__).resolve().parent
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
out=lab/'focused'
env=dict(os.environ,CARGO_TARGET_DIR=str(out/'build'))
hashes=json.loads((out/'inputs.json').read_text())['documents']
documents=list(hashes)
blocks=re.findall(r'^```rust[^\n]*\n(.*?)^```',(root/'README.md').read_text(),re.M|re.S)
metadata=json.loads((out/'consumer-metadata.log').read_text())
entry=next(p for p in metadata['packages'] if p['name']=='nbreq')
for label in ['stable-readme','stable-tls-guide','msrv-readme','msrv-tls-guide','native-tls-guide','msrv-guides','msrv-smtp-readme']:
    assert json.loads((out/(label+'.result.json')).read_text())['exit_code']==0
assert hashes=={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in documents}
def run(label,args,cwd=root,timeout=300):
    command(args,cwd,out,label,env,timeout)
source=(lab/'check_docs.py').read_text()
exec(compile(source[source.index("run('package-list-dirty'"):],str(lab/'check_docs.py'),'exec'))
summary=json.loads((out/'summary.json').read_text())
summary['inventory_retry']='Initial list rejected uncommitted documentation; explicit --allow-dirty lists reviewed working files without packaging or publishing. Initial failure retained.'
(out/'summary.json').write_text(json.dumps(summary,indent=2))
