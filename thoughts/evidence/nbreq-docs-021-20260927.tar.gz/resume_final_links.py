from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote,urlsplit
import hashlib,json,re
lab=Path(__file__).resolve().parent
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
out=lab/'final-docs'
for label in ['formatting','stable-doctests','strict-doc-build','msrv-doctests']:
    assert json.loads((out/(label+'.result.json')).read_text())['exit_code']==0
initial=json.loads((lab/'full-verifier/inputs.json').read_text())['files']
changed=['src/tcp/mod.rs']
after=(out/'tcp-mod-after-correction.rs').read_bytes()
assert (root/'src/tcp/mod.rs').read_bytes()==after
source=(lab/'final_docs.py').read_text()
exec(compile(source[source.index('class Links('):],str(lab/'final_docs.py'),'exec'))
summary=json.loads((out/'summary.json').read_text())
summary['link_checker_correction']='First local validator decoded all fragments; rustdoc also uses literal percent-encoded impl IDs. Accept exact or decoded IDs. Generated docs were unchanged; no Cargo checks repeated for this validator correction.'
(out/'summary.json').write_text(json.dumps(summary,indent=2))
