from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
import hashlib, json, os, re
from owned_command import command

lab=Path(__file__).resolve().parent
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
out=lab/'final-docs'
out.mkdir(exist_ok=False)
full=json.loads((lab/'full-verifier/summary.json').read_text())
focused=json.loads((lab/'focused/summary.json').read_text())
assert full['status']==focused['status']=='passed'
initial=json.loads((lab/'full-verifier/inputs.json').read_text())['files']
changed=[name for name,digest in initial.items() if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest]
assert changed==['src/tcp/mod.rs'],changed
before=(lab/'tcp-mod-before-correction.rs').read_bytes()
assert hashlib.sha256(before).hexdigest()==initial['src/tcp/mod.rs']
after=(root/'src/tcp/mod.rs').read_bytes()
def executable(text):
    return '\n'.join(line for line in text.decode().splitlines() if not line.lstrip().startswith(('///','//!')))
assert executable(before)==executable(after)
(out/'tcp-mod-after-correction.rs').write_bytes(after)
env=dict(os.environ,CARGO_TARGET_DIR=str(lab/'build'),RUSTDOCFLAGS='-D warnings')
command(['cargo','+stable','fmt','--all','--','--check'],root,out,'formatting',env,60)
command(['cargo','+stable','test','--locked','--offline','--all-features','--doc','-p','nbreq'],root,out,'stable-doctests',env,300)
command(['cargo','+stable','doc','--locked','--offline','--all-features','--no-deps','-p','nbreq','-p','nbreq-smtp'],root,out,'strict-doc-build',env,300)
msrv_env=dict(env,CARGO_TARGET_DIR=str(lab/'focused/build'))
command(['cargo','+1.85.0','test','--locked','--offline','--all-features','--doc','-p','nbreq'],root,out,'msrv-doctests',msrv_env,300)

class Links(HTMLParser):
    def __init__(self,text):
        super().__init__(); self.ids=set(); self.links=[]; self.feed(text)
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:self.ids.add(attrs['id'])
        if tag=='a' and 'href' in attrs:self.links.append(attrs['href'])

docroot=lab/'build/doc'
checked=[]
cache={}
for name in ['nbreq/index.html','nbreq/struct.TcpConnectRequest.html','nbreq/enum.TcpConnectTarget.html','nbreq/struct.TcpConnector.html','nbreq_smtp/index.html']:
    page=docroot/name
    parsed=Links(page.read_text(encoding='utf-8'))
    cache[page]=parsed
    for href in parsed.links:
        url=urlsplit(href)
        if url.scheme or url.netloc:continue
        target=(page.parent/unquote(url.path)).resolve() if url.path else page
        assert target.is_relative_to(docroot) and target.is_file(),(name,href)
        if url.fragment:
            if target not in cache:cache[target]=Links(target.read_text(encoding='utf-8'))
            anchor=unquote(url.fragment)
            # rustdoc source links may select line ranges using client-side navigation.
            if '/src/' in target.as_posix() and re.fullmatch(r'\d+(?:-\d+)?',anchor):
                assert anchor.split('-')[0] in cache[target].ids,(name,href)
            else:assert anchor in cache[target].ids or url.fragment in cache[target].ids,(name,href)
        checked.append(dict(page=name,href=href))
current={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in initial}
assert [name for name in initial if current[name]!=initial[name]]==changed
assert (root/'src/tcp/mod.rs').read_bytes()==after
(out/'summary.json').write_text(json.dumps(dict(status='passed',full_checkpoint_comment_delta=changed,executable_code_unchanged=True,final_hashes=current,generated_links_checked=len(checked),links=checked,limitations=['Generated local links checked; future versioned external source URLs still require hosted release checks']),indent=2))
print('Final documentation and generated links passed.',flush=True)
