from pathlib import Path
import hashlib, json, os, re, subprocess, sys, tomllib
from urllib.parse import unquote, urlsplit
from owned_command import command

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
out = lab/'focused'
out.mkdir(exist_ok=False)
env = dict(os.environ,CARGO_TARGET_DIR=str(out/'build'))
documents = ['README.md','CHANGELOG.md','SECURITY.md','CONTRIBUTING.md','docs/getting-started.md','docs/migrating-to-0.2.md','docs/tcp-tls.md','smtp/README.md','examples/README.md','tools/release-consumer/README.md']
hashes = {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in documents}
(out/'inputs.json').write_text(json.dumps(dict(documents=hashes,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()),indent=2))
def run(label, args, cwd=root, timeout=300):
    command(args,cwd,out,label,env,timeout)

consumer = out/'consumer'
(consumer/'src/bin').mkdir(parents=True)
manifest = '''[package]
name = "nbreq-doc-snippet-checks"
version = "0.0.0"
edition = "2024"
rust-version = "1.85"
publish = false

[workspace]
resolver = "3"

[features]
default = ["native", "resolver"]
native = ["nbreq/native"]
resolver = ["native", "nbreq/resolver"]
bundled-roots = ["native", "nbreq/bundled-roots"]

[dependencies]
nbreq = { version = "0.2.1", default-features = false, path = ROOT }
'''.replace('ROOT',json.dumps(root.as_posix()))
(consumer/'Cargo.toml').write_text(manifest)
(consumer/'src/lib.rs').write_text('#![doc = include_str!('+json.dumps((root/'docs/tcp-tls.md').as_posix())+')]\n')
blocks = re.findall(r'^```rust[^\n]*\n(.*?)^```', (root/'README.md').read_text(),re.M|re.S)
assert len(blocks)>=4
scaffolds = []
for i, block in enumerate(blocks):
    scaffold = ''
    # README explicitly gives later snippets an existing spawned Engine and Duration import.
    if not re.search(r'\blet(?: mut)? engine\s*=',block):
        scaffold += 'let engine = nbreq::Engine::builder().build()?;\n'
    if not re.search(r'use std::time::(?:Duration|\{[^}]*Duration)',block):
        scaffold += 'use std::time::Duration;\n'
    generated = '#![allow(unused_imports)]\nfn main() -> Result<(), Box<dyn std::error::Error>> {\n'+scaffold+block+'\nOk(())\n}\n'
    path = consumer/'src/bin'/('readme_'+str(i)+'.rs')
    path.write_text(generated)
    scaffolds.append(dict(block=i,original_sha256=hashlib.sha256(block.encode()).hexdigest(),scaffold=scaffold,generated_sha256=hashlib.sha256(generated.encode()).hexdigest()))
(out/'readme-scaffolds.json').write_text(json.dumps(scaffolds,indent=2))
run('consumer-resolve',['cargo','+stable','generate-lockfile','--offline'],consumer)
run('consumer-metadata',['cargo','+stable','metadata','--locked','--offline','--all-features','--format-version','1'],consumer)
metadata=json.loads((out/'consumer-metadata.log').read_text())
entry=next(p for p in metadata['packages'] if p['name']=='nbreq')
assert entry['version']=='0.2.1' and entry['source'] is None and Path(entry['manifest_path'])==root/'Cargo.toml'
for toolchain,label in [('stable','stable'),('1.85.0','msrv')]:
    run(label+'-compiler',['rustc','+'+toolchain,'-Vv'],timeout=30)
    run(label+'-readme',['cargo','+'+toolchain,'check','--locked','--offline','--all-features','--bins'],consumer)
    run(label+'-tls-guide',['cargo','+'+toolchain,'test','--locked','--offline','--all-features','--doc'],consumer)
run('native-tls-guide',['cargo','+stable','test','--locked','--offline','--no-default-features','--features','native','--doc'],consumer)
run('msrv-guides',['cargo','+1.85.0','test','--locked','--offline','--all-features','--doc','-p','nbreq'])
run('msrv-smtp-readme',['cargo','+1.85.0','test','--locked','--offline','--doc','-p','nbreq-smtp'])
run('package-list-dirty',['cargo','+stable','package','--locked','--offline','--list','--allow-dirty','-p','nbreq'])
inventory=set((out/'package-list-dirty.log').read_text().replace('\\','/').splitlines())
def anchors(path):
    text=re.sub(r'^```.*?^```','',path.read_text(),flags=re.M|re.S)
    counts={}; result=set()
    for heading in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
        slug=re.sub(r'[^\w\- ]','',heading.lower()).replace(' ','-')
        n=counts.get(slug,0); counts[slug]=n+1
        result.add(slug+('-'+str(n) if n else ''))
    return result
links=[]; future=[]
for document in documents:
    for destination in re.findall(r'\]\(([^\s)]+)\)',(root/document).read_text()):
        url=urlsplit(destination)
        versioned=url.netloc=='github.com' and url.path.startswith('/madandy24/nbreq/blob/v0.2.1/')
        if url.scheme and not versioned:
            continue
        if versioned:
            target=root/unquote(url.path.split('/blob/v0.2.1/',1)[1])
            future.append(destination)
        else:
            target=((root/document).parent/unquote(url.path)).resolve() if url.path else root/document
        assert target.is_relative_to(root) and target.is_file(),(document,destination)
        relative=target.relative_to(root).as_posix()
        if document in inventory:
            assert relative in inventory,(document,destination,'outside package')
        if url.fragment and target.suffix=='.md':
            assert unquote(url.fragment) in anchors(target),(document,destination,'missing anchor')
        links.append(dict(document=document,destination=destination,target=relative))
assert hashes=={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in documents}
for document in documents:
    destination=out/'documents'/document
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((root/document).read_bytes())
summary=dict(status='passed',readme_blocks=len(blocks),links_checked=len(links),links=links,
             future_version_links=future,consumer_identity={k:entry[k] for k in ['version','source','manifest_path']},
             scope='Compilation/doctests plus local package inventory and Markdown anchors',
             limitations=['Future v0.2.1 links mapped to local files, not verified live before tag/publication','README network snippets compiled only','Offline cached consumer resolution, not fresh online registry acceptance'])
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:summary[k] for k in ['status','readme_blocks','links_checked','scope']}),flush=True)
