from pathlib import Path
import hashlib,json,subprocess,tarfile

lab=Path(__file__).resolve().parent
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
summaries={name:json.loads((lab/name/'summary.json').read_text()) for name in ['full-verifier','focused','final-docs']}
assert all(s['status']=='passed' for s in summaries.values())
for name,digest in summaries['final-docs']['final_hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
for name in changed:
    if name.startswith('thoughts/'):continue
    destination=lab/'final-source'/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((root/name).read_bytes())
(lab/'change.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=root))
files=[p for p in lab.iterdir() if p.is_file()]
for folder in ['full-verifier','focused','final-docs','final-source']:
    files.extend(p for p in (lab/folder).rglob('*') if p.is_file() and not any(part in ['build','target'] for part in p.relative_to(lab/folder).parts))
members={p.relative_to(lab).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
destination=root/'thoughts/evidence/nbreq-docs-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination,'w:gz') as archive:
    for p in sorted(files):archive.add(p,arcname=p.relative_to(lab).as_posix(),recursive=False)
with tarfile.open(destination) as archive:
    entries=archive.getmembers()
    assert all(m.isfile() for m in entries) and len(entries)==len(members)
    assert {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in entries}==members
index=dict(archive=destination.name,bytes=destination.stat().st_size,regular_members=len(members),
           sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
           full_verifier=summaries['full-verifier'],
           focused={k:v for k,v in summaries['focused'].items() if k!='links'},
           final_docs={k:v for k,v in summaries['final-docs'].items() if k not in ['links','final_hashes']},
           excluded='Build outputs and binaries; generated link inventory and exact documentation snapshots retained',members=members)
(root/'thoughts/evidence/nbreq_docs_021_artifacts.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:index[k] for k in ['archive','bytes','regular_members','sha256']},indent=2))
