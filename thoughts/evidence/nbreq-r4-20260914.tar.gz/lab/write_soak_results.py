import json
from pathlib import Path

lab = Path(__file__).resolve().parent
report = lab.parents[1]/'thoughts/nbreq_r4_reliability.md'
data = json.loads((lab/'analysis.json').read_text())
text = '''## Completed soak acceptance (2026-09-14)

All four 14,400-second default-capability observations passed. Each of 73,593 complete cycles
was re-read from the archived client event stream and checked for contiguous numbering,
exact expected refusal/cancellation accounting, zero quiescent gauges, bounded high-water
marks and consistent connection ownership. Across the four main Engines, 1,509,627 HTTP
operations were accepted and 147,186 standalone TCP exchanges completed. Final live-stream
shutdown is checked separately and is not included in those main-Engine pre-shutdown counts.
All child exits were unforced with readers and fixtures joined. No supervisor sampling/clock
anomaly or child stderr was recorded. Public-network rounds all passed.

| Host | Cycles | Accepted HTTP | Completed HTTP | Expected cancellations / refusals | TCP exchanges | Public rounds |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for row in data['archives']:
    if row['kind'] != 'four-hour-soak':
        continue
    f, m = row['final'], row['final']['metrics_before_shutdown']
    text += f"| {row['host']} | {f['cycles']:,} | {m['accepted']:,} | {m['completed']:,} | {m['cancelled']:,} / {m['failed']:,} | {m['tcp_accepted']:,} | {f['public_rounds']} |\n"
text += '''
These numbers describe the workload on each host, not comparative platform throughput.
All hosts reported the same peak accounted buffered capacity (2,113,536 bytes), streaming
reservation (16,384 bytes), TCP reservation (16,384 bytes), eight HTTP connections and ten
waiting requests. Final operation/body/stream/TCP/queue/waiter gauges were zero; six idle
HTTP connections remained immediately before the explicitly checked Engine shutdown.

Process measurements below cover the client only, with separate fixture processes. MiB means
1,048,576 bytes. Samples are nominally two seconds apart (largest observed gap below 2.21 s).
RSS/working set is not live Rust heap. Windows private bytes measure private commitment;
Linux private bytes sum resident Private_Clean/Private_Dirty; macOS private is unavailable.
The two private-byte measures are not equivalent.

| Host | Sampled peak RSS MiB | OS lifetime peak RSS MiB | Sampled peak private MiB | Hour 1 / 2 / 3 / 4 mean RSS MiB |
| --- | ---: | ---: | ---: | --- |
'''
fmt = lambda x: 'unavailable' if x is None else f'{x/1048576:.2f}'
for row in data['archives']:
    if row['kind'] != 'four-hour-soak':
        continue
    m = row['memory']
    text += f"| {row['host']} | {fmt(m['max_rss'])} | {fmt(m['max_lifetime_peak_rss'])} | {fmt(m['max_private'])} | {' / '.join(fmt(h['rss']['mean']) for h in m['hours'])} |\n"
text += '''
Windows mean private commitment by hour was 6.06 / 6.70 / 6.90 / 6.99 MiB. Its rate of growth
fell substantially; the last two hourly mean working sets differed by about 45 KiB. Linux RSS
was flat during the last two hours and private resident memory rose only about 7 KiB between
their means. ARM RSS increased gradually by roughly 184 KiB between the first and fourth
hourly means; Intel's last two means differed by about 7 KiB. This supports bounded resource
use during this workload. It does not prove zero slow leakage or acceptance on a 128/256 MB
device. The public network, allocator and OS remain part of these process observations.

The owner reports substantial other work on Windows during this run. Retain its correctness,
cleanup and process measurements, but treat Windows performance timings as observations from
a busy host. Prefer the separately obtained Linux comparison for timing interpretation; do
not invent an idle-host guarantee for either platform.

Windows x86 also passed the complete 24-stage verifier (178.927 s), 900 new fixture connections,
corruption/watchdog checks, 30-second default and 180-second native-only release rehearsals.
The entire verifier inherited `CARGO_BUILD_TARGET=i686-pc-windows-msvc`; logs show actual i686
test binaries. Its full preflight took 527.669 s. This is a short companion, not a four-hour x86
soak. Default/native binary hashes are retained in the archive and machine-readable analysis.

Every file in all five archives was hash-checked against its internal manifest before safe
extraction. `analyze_evidence.py` rechecks the cycle traces and computes hourly summaries.
Its first local attempt used the wrong preflight duration field name; the resulting KeyError
is retained as `analysis-initial-schema-error.log`. Correcting that post-processing field
did not change any test, binary, measurement or acceptance assertion.

| Archive under the R4 lab | Bytes | SHA256 |
| --- | ---: | --- |
'''
for row in data['archives']:
    text += f"| `{row['host']}-e78-evidence.tar.gz` | {row['bytes']:,} | `{row['sha256']}` |\n"
current = report.read_text(encoding='utf-8')
assert '## Completed soak acceptance' not in current
report.write_text(current.replace('## F5 reconciliation',text+'\n## F5 reconciliation'),encoding='utf-8')
