import hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
lab = Path(__file__).resolve().parent
work = lab.parent/'worktrees/nbreq-r4'
frozen = json.loads((lab/'frozen.json').read_text())
base = Path(frozen['directory'])
dest = lab/'comparison-source-a'
dest.mkdir(exist_ok=False)
runtime = json.loads((base/'r4-source.json').read_text())
for name, digest in runtime['files'].items():
    data = (base/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest
    path = dest/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
names = ['Cargo.toml','Cargo.lock','README.md','build.rs','run-windows.ps1','src/main.rs','compare.py',
         'v011/Cargo.toml','v011/Cargo.lock','v011/build.rs','v011/src/main.rs']
for name in names:
    target = dest/'tools/f5-observe'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((work/'tools/f5-observe'/name).read_bytes())
legacy = (dest/'tools/f5-observe/v011/Cargo.lock').read_text()
assert 'checksum = "dcce8e27aead7ca63e8d3d4f93d2cab59290e746cac2dfd92eec31b8517f9c90"' in legacy
files = {p.relative_to(dest).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.rglob('*')) if p.is_file()}
manifest = dict(runtime_source=frozen['source'],registry_version='0.1.1',registry_checksum='dcce8e27aead7ca63e8d3d4f93d2cab59290e746cac2dfd92eec31b8517f9c90',
                registry_commit=subprocess.check_output(['git','rev-list','-n','1','v0.1.1'],cwd=work,text=True).strip(),files=files)
encoded = json.dumps(manifest,indent=2).encode()+b'\n'
identity = hashlib.sha256(encoded).hexdigest()
(dest/'r4-compare-source.json').write_bytes(encoded)
archive = lab/('nbreq-r4-compare-'+identity[:12]+'.tar.gz')
with tarfile.open(archive,'w:gz') as out:
    for name in sorted(files):
        out.add(dest/name,arcname=name,recursive=False)
    out.add(dest/'r4-compare-source.json',arcname='r4-compare-source.json')
result = dict(source=identity,directory=str(dest),archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(files))
(lab/'compare-frozen.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
