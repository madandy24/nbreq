import json
from pathlib import Path
lab = Path(__file__).resolve().parent
report = lab.parents[1]/'thoughts/nbreq_r4_reliability.md'
data = json.loads((lab/'analysis.json').read_text())
text = '''## Completed comparison and R4 disposition

Windows, Linux and the owner-requested dedicated Apple Silicon comparison each completed all
36 launches. The longer Windows small-body follow-up adds ten passed launches. All 118
processes passed exact-byte/reuse/quiescence checks and exited unforced; every recorded binary
hash matches its build manifest. All four Clippy and four locked release-build steps passed
on each host. The source manifest is the same on all hosts; compiler versions differ, so
compare versions within a host only.

Plain timings below are medians of three launch medians (each launch contains three measured
samples). A negative change means less elapsed time for 0.2. Sample lengths differ by body:
4,096 requests for 1/64 KiB; 256 for 1 MiB. Raw nine samples and all launch ranges remain in
the evidence; instrumented timings are not mixed into this table.

| Host / Rust | Body | Current ms | 0.1.1 ms | Elapsed change |
| --- | --- | ---: | ---: | ---: |
'''
rows = data['remote_comparisons']+[data['comparison']]
for host in rows:
    for size,label in [(1024,'1 KiB'),(65536,'64 KiB'),(1048576,'1 MiB')]:
        a,b = [r for r in host['groups'] if r['body_bytes']==size]
        assert a['version']=='current' and b['version']=='v011'
        x,y = a['wall_ms_median_of_launch_medians'],b['wall_ms_median_of_launch_medians']
        version = host['platform']['rustc'].split()[1]
        text += f"| {host['host']} / {version} | {label} | {x:.2f} | {y:.2f} | {100*(x/y-1):+.1f}% |\n"
text += '''
The Windows 1 KiB longer follow-up above and the owner's concurrent-work disclosure qualify
its initial row. Linux's 1 KiB launch medians also overlap (current 193.70–234.74 ms, legacy
212.79–222.50 ms); this is not evidence of an actionable small-request regression. The
dedicated ARM medians are tighter (current 167.43–168.93 ms, legacy 176.34–177.31 ms).
No broad timing regression was demonstrated in the shared workload.

The large-body timing difference is substantial on Linux and ARM, but it compares the whole
released 0.1.1 implementation/graph with the current candidate. It does not isolate one memory
change or establish a general application speed-up. These are serial buffered loopback HTTP
requests with exact response inspection, not TLS, streaming, public-network latency or GDS
traffic. This is release regression evidence, not a performance promise or a new optimization
programme. The measured differences do not require a production change for R4.

Allocation instrumentation separately measures bytes allocated during the sample, including
any in-process fixture activity. These are allocation traffic, not live heap or peak process
memory. Median allocated bytes per request were:

| Host | Body | Current bytes/request | 0.1.1 bytes/request | Change |
| --- | --- | ---: | ---: | ---: |
'''
for host in rows:
    for size,label in [(1024,'1 KiB'),(65536,'64 KiB'),(1048576,'1 MiB')]:
        a,b = [r for r in host['groups'] if r['body_bytes']==size]
        x,y = a['allocated_bytes_per_request'],b['allocated_bytes_per_request']
        text += f"| {host['host']} | {label} | {x:,.0f} | {y:,.0f} | {100*(x/y-1):+.1f}% |\n"
text += '''
Lower allocation traffic does not guarantee lower RSS: for example ARM's 1 KiB plain launches
sampled about 8.0–8.1 MiB RSS for current versus 7.2 MiB for legacy, and Linux's 64 KiB private
resident peaks were slightly higher for current. The cause of those small process-footprint
differences was not profiled here. Larger buffered bodies showed lower sampled peak RSS on
all three hosts. Source, binary, allocator and process measures remain separate in `analysis.json`.

Remote comparison archives were SHA256-verified before safe extraction, and the embedded
source manifest hash, all result identities and all binary-manifest matches were checked:

| Host | Archive under the R4 lab | Bytes | SHA256 |
| --- | --- | ---: | --- |
'''
for host in data['remote_comparisons']:
    arc = host['archive']
    text += f"| {host['host']} | `{host['host']}-compare-033d-evidence.tar.gz` | {arc['bytes']:,} | `{arc['sha256']}` |\n"
text += '''
ARM's first collection command failed before packaging because the bridge dropped nested
double quotes in inline Python. The failed reply `20260914-082838-c69cf26f` is retained;
passing filenames/status as arguments fixed transport without changing or rerunning the
benchmark. Corrected pack `20260914-083039-3657de74` and Linux pack
`20260914-083133-f8176b75` passed. Remote jobs are complete; no further bridge work is needed.

**R4 is complete within its stated scope.** The original unbounded HTTP fixture is fixed with
retained red/green proof; the remaining historical DNS/TCP causes remain unconfirmed and
explicitly qualified. The complete unfiltered verifiers, 60 focused repetitions, four native
four-hour soaks, x86 companion and shared-path comparisons pass. M1–M3/R1 evidence plus this
slice covers the reconciled F5 work; it does not close GDS's M4 device/application acceptance.

The next release work is R5 on the final integrated candidate: exact-source CI/package,
advisory/license/documentation checks and final registry-only consumer/MSRV resolution after
the separately authorized support publications. Nothing has been published or pushed here.
The scoped runtime remains the Wine fix; R4 changes tests and unpublished tooling only.
The [artifact manifest](evidence/nbreq_r4_artifacts.json) and
[sealed archive](evidence/nbreq-r4-20260914.tar.gz) preserve the raw evidence and a dated report
snapshot. The archive excludes build trees/executables; source archives, toolchains and binary
hashes are retained. Pause the R4 heartbeat after this completed handoff.
'''
current = report.read_text(encoding='utf-8')
assert '## Completed comparison and R4 disposition' not in current
report.write_text(current+'\n'+text,encoding='utf-8')
