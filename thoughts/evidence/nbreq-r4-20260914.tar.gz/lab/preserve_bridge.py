import json, re, shutil
from pathlib import Path
lab = Path(__file__).resolve().parent
dest = lab/'bridge-results'
dest.mkdir(exist_ok=True)
requests = {}
for pattern in ['bridge-identities.json', 'uploads-e78.json', 'preflight-launches-e78.json', 'collector-uploads.json', 'polls-e78-*.json']:
    for path in lab.glob(pattern):
        if '-checked' in path.name:
            continue
        for item in json.loads(path.read_text(encoding='utf-8-sig')):
            requests[item['id']] = Path(item['root'])
for path in list(lab.glob('*-pack-request.json'))+list(lab.glob('*-pack-failed.json')):
    item = json.loads(path.read_text(encoding='utf-8-sig'))
    requests[item['id']] = Path(item['root'])
for prefix, bridge in [('arm-compare','putty_bridge_scaleway_nbreq'),('linux-compare','putty_bridge')]:
    for path in lab.glob(prefix+'*.txt'):
        identities = set(re.findall(r'\b\d{8}-\d{6}-[0-9a-f]{8}\b',path.read_text(encoding='utf-8-sig')))
        assert len(identities) == 1
        requests[identities.pop()] = Path('C:/User/SecuritasNew/gds/scripts/sessions')/bridge
for name, bridge in [('arm-soak-request.txt', 'putty_bridge_scaleway_nbreq'),
                     ('intel-final-preflight-poll.txt', 'putty_bridge_intel_mac'),
                     ('intel-soak-request.txt', 'putty_bridge_intel_mac'),
                     ('linux-latest-preflight-poll.txt', 'putty_bridge'),
                     ('linux-soak-request.txt', 'putty_bridge')]:
    path = lab/name
    if path.exists():
        requests[path.read_text(encoding='utf-8-sig').strip()] = Path('C:/User/SecuritasNew/gds/scripts/sessions')/bridge
for identity, root in requests.items():
    path = root/'results'/(identity+'.json')
    if path.exists():
        shutil.copyfile(path, dest/path.name)
print('Preserved '+str(len(list(dest.glob('*.json'))))+' completed bridge results.')
