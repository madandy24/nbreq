"""Fetch a completed R4 evidence archive through reviewed bridge commands, with resumable parts."""
import argparse, base64, hashlib, json, re, subprocess, time
from pathlib import Path

lab = Path(__file__).resolve().parent
script = Path('C:/User/SecuritasNew/gds/scripts/putty_bridge/New-PuttyBridgeRequest.ps1')
decoder = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))

def reply(root, identity):
    path = root/'results'/(identity+'.json')
    deadline = time.monotonic()+120
    while not path.exists() and time.monotonic() < deadline:
        time.sleep(0.5)
    if not path.exists():
        raise TimeoutError('Bridge reply pending; resume this exact request: '+identity)
    value = decoder(path)
    assert value['status'] == 'completed' and value['ok'] and value['exit_code'] == 0, value
    (lab/'bridge-results'/path.name).write_bytes(path.read_bytes())
    return json.loads(value['output'].strip())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pack', type=Path, required=True)
    parser.add_argument('--comparison', action='store_true')
    args = parser.parse_args()
    request = decoder(args.pack)
    root = Path(request['root'])
    summary = reply(root, request['id'])
    archive = summary['archive']
    assert re.fullmatch(r'/[A-Za-z0-9_./-]+', archive)
    suffix = 'comparison-evidence.tar.gz' if args.comparison else 'r4-evidence.tar.gz'
    assert archive == request['remote']+'/'+suffix
    assert summary['source'] == decoder(lab/('compare-frozen.json' if args.comparison else 'frozen.json'))['source']
    out = lab/('download-'+request['label']+('-comparison' if args.comparison else ''))
    out.mkdir(exist_ok=True)
    (out/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    count = (summary['bytes']+384*1024-1)//(384*1024)
    for part in range(count):
        marker = out/('part-'+str(part)+'.request.json')
        if marker.exists():
            identity = decoder(marker)['id']
        else:
            command = 'python3 /tmp/nbreq-r4-collect-20260914.py emit --archive '+archive+' --part '+str(part)
            queued = subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),
                                     '-BridgeRoot',str(root),'-Command',command,'-Reason',
                                     'Read one bounded chunk of completed R4 test evidence; SHA256 verifies transfer. No GDS data or host settings.'],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
            (out/('part-'+str(part)+'.queue.log')).write_text(queued.stdout, encoding='utf-8')
            assert queued.returncode == 0, queued.stdout
            identities = re.findall(r'\b\d{8}-\d{6}-[0-9a-f]{8}\b',queued.stdout)
            assert identities and len(set(identities)) == 1, queued.stdout
            identity = identities[0]
            marker.write_text(json.dumps(dict(id=identity, command=command)), encoding='utf-8')
        data = reply(root, identity)
        assert data['part'] == part and data['total_parts'] == count
        assert data['archive_sha256'] == summary['sha256']
        chunk = base64.b64decode(data['base64'], validate=True)
        assert hashlib.sha256(chunk).hexdigest() == data['chunk_sha256']
        (out/('part-'+str(part)+'.bin')).write_bytes(chunk)
        print(request['label']+' part '+str(part+1)+'/'+str(count)+' verified', flush=True)
    content = b''.join((out/('part-'+str(part)+'.bin')).read_bytes() for part in range(count))
    assert len(content) == summary['bytes'] and hashlib.sha256(content).hexdigest() == summary['sha256']
    dest = lab/(request['label']+('-compare-033d-evidence.tar.gz' if args.comparison else '-e78-evidence.tar.gz'))
    if dest.exists():
        assert dest.read_bytes() == content
    else:
        dest.write_bytes(content)
    print(json.dumps(dict(archive=str(dest), sha256=summary['sha256'], bytes=len(content))), flush=True)

if __name__ == '__main__':
    main()
