"""Preserve the scoped R4 lab evidence with per-file hashes; exclude build trees and executables."""
import hashlib, io, json, os, tarfile
from pathlib import Path

lab = Path(__file__).resolve().parent
root = lab.parents[1]
output = root/'thoughts/evidence/nbreq-r4-20260914.tar.gz'
assert not output.exists(), 'Never overwrite sealed evidence'
inputs = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink()
    assert name not in inputs
    inputs[name] = path
def tree(folder, prefix):
    for current, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith('build-') and d not in ['bin','__pycache__']]
        for name in sorted(files):
            p = Path(current)/name
            add(p, prefix+'/'+p.relative_to(folder).as_posix())

for p in sorted(lab.iterdir()):
    if p.is_file():
        add(p,'lab/'+p.name)
for name in ['bridge-results','smoke-a','smoke-b','smoke-c','harness-checks-c','harness-checks-d',
             'windows-compare-a','windows-compare-small-followup']:
    tree(lab/name,'lab/'+name)
for name in ['nbreq_r4_reliability.md','nbreq_020_release_plan.md']:
    add(root/'thoughts'/name,'reports/'+name)
add(root/'target/worktrees/nbreq-r4/tools/release-soak/collect.py','postprocessing/collect.py')
manifest = dict(schema='nbreq-r4-evidence-v1',
    runtime_source='e78b73b18d4c3b969f7e022a705b8c84146dab44d39a2d14cbe1893242936914',
    comparison_source='033d1fce1db88e8161f0ef4ab2ec5f30df613a97b39248fe8940d605bb17f9b1',
    files={name:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in sorted(inputs.items())})
encoded = json.dumps(manifest,indent=2).encode('utf-8')
with tarfile.open(output,'w:gz',compresslevel=9) as archive:
    for name,path in sorted(inputs.items()):
        archive.add(path,arcname=name,recursive=False)
    entry = tarfile.TarInfo('evidence-manifest.json')
    entry.size = len(encoded)
    archive.addfile(entry,io.BytesIO(encoded))
with tarfile.open(output) as archive:
    assert {m.name for m in archive.getmembers()} == set(inputs)|{'evidence-manifest.json'}
    for name,entry in manifest['files'].items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == entry['sha256']
summary = dict(archive=output.name,bytes=output.stat().st_size,sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
               files=len(inputs),runtime_source=manifest['runtime_source'],comparison_source=manifest['comparison_source'],
               note='Raw per-host archives, source snapshots, comparison measurements, failures and collector provenance; binaries excluded but hashes and toolchains retained.')
(output.parent/'nbreq_r4_artifacts.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary),flush=True)
