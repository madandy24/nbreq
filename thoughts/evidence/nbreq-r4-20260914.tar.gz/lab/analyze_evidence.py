"""Independently verify archived R4 files and summarize retained raw measurements."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import statistics as st
import tarfile

LAB = Path(__file__).resolve().parent
SOURCE = 'e78b73b18d4c3b969f7e022a705b8c84146dab44d39a2d14cbe1893242936914'
EXPECTED = {
    'windows': '21d90c26c138c853ab85072ed1b480ffecca2e567a4dd7d938794396da1d88c8',
    'mac-arm64': '4ff6d1f1890c3e994dc0c921dd7fb7d41fe11e69374a384aa9489578cb3d669a',
    'mac-x64': '2018038b6172f26f88409efbd56820facbf33f5c48d7fab8468e150125bdd663',
    'linux-x64': '598eb45d7343dca5f24db5e968fcb47c7cb9148288d38a434efbe5aa696f048f',
    'windows-x86': 'e485299d159885011277907237f0679ae85ac0bed45393039d3966c364283a33',
}

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def lines(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines() if s.strip()]

def check_metrics(m, cycle):
    expected = 1 + cycle // 10
    assert m['failed'] == expected and m['cancelled'] == 2*cycle+expected
    assert m['accepted'] == m['completed']+m['failed']+m['cancelled']
    assert m['tcp_accepted'] == 2*cycle and m['tcp_failed'] == m['dns_failed'] == 0
    assert all(m[k] == 0 for k in ['inflight','commands','callbacks','body_bytes','stream_bytes','tcp_bytes','tcp','resolves','waiters'])
    assert m['active'] == m['idle'] == m['opened']-m['closed']
    assert m['high_active'] <= 8 and m['high_body_bytes'] <= 4194304
    assert m['high_stream_bytes'] <= 65536 and m['high_tcp_bytes'] <= 32768

def memory(rows):
    result = {'samples': len(rows), 'max_sample_gap_s': max(b['elapsed_s']-a['elapsed_s'] for a,b in zip(rows,rows[1:]))}
    for key in ['rss','private','lifetime_peak_rss','cpu_seconds']:
        values = [r['values'][key] for r in rows if r['values'].get(key) is not None]
        result['max_'+key] = max(values) if values else None
    result['hours'] = []
    for hour in range(4):
        window = [r for r in rows if hour*3600 <= r['elapsed_s'] < (hour+1)*3600]
        item = {'hour': hour+1, 'samples': len(window)}
        for key in ['rss', 'private']:
            values = [r['values'][key] for r in window if r['values'].get(key) is not None]
            item[key] = dict(min=min(values), median=st.median(values), mean=st.mean(values), max=max(values)) if values else None
        result['hours'].append(item)
    return result

def archive(label, digest):
    path = LAB/(label+'-e78-evidence.tar.gz')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    dest = LAB/'collected'/label
    with tarfile.open(path) as source:
        members = source.getmembers()
        names = [m.name for m in members]
        assert len(names) == len(set(names))
        assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '\\' not in m.name
                   and '..' not in PurePosixPath(m.name).parts for m in members)
        manifest = json.load(source.extractfile('evidence-manifest.json'))
        assert manifest['source'] == SOURCE
        assert set(names) == set(manifest['files']) | {'evidence-manifest.json'}
        for member in members:
            data = source.extractfile(member).read()
            if member.name != 'evidence-manifest.json':
                assert member.name.startswith(('preflight/', 'soak/'))
                assert hashlib.sha256(data).hexdigest() == manifest['files'][member.name], member.name
            target = dest/member.name
            assert dest.resolve() in target.resolve().parents
            if target.exists():
                assert target.read_bytes() == data
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
    preflight = read(dest/'preflight/result.json')
    assert preflight['status'] == 'passed' and preflight['source'] == SOURCE
    result = dict(host=label, sha256=digest, bytes=path.stat().st_size, files=len(manifest['files']),
                  binaries=preflight['binaries'], preflight_elapsed_s=preflight['elapsed_seconds'])
    if label == 'windows-x86':
        result['kind'] = 'preflight-companion'
        for variant, seconds in [('default',30),('native',180)]:
            r = read(dest/('preflight/smoke-'+variant)/'result.json')
            assert r['status'] == 'passed' and r['metadata']['requested_seconds'] == seconds
            assert all(r['final']['checks'].values())
        return result
    result['kind'] = 'four-hour-soak'
    folder = dest/'soak/mixed'
    run = read(folder/'result.json')
    assert run['status'] == 'passed' and run['failure'] is None and run['final']['elapsed_s'] >= 14400
    assert run['metadata']['source'] == SOURCE and run['metadata']['binary_sha256'] == preflight['binaries']['default']['sha256']
    assert all(run['final']['checks'].values())
    assert all(c['exit_code'] == 0 and not c['forced'] and c['reader_joined'] for c in run['cleanup'])
    assert not (folder/'supervisor.jsonl').read_text().strip(), 'inspect supervisor anomaly before acceptance'
    for name in ['client','http','https','echo']:
        assert not (folder/(name+'.stderr')).read_text().strip(), 'inspect child stderr'
    events = lines(folder/'client.jsonl')
    ends = [e for e in events if e['event'] == 'cycle_end']
    assert [e['cycle'] for e in ends] == list(range(1,run['final']['cycles']+1))
    for event in ends:
        assert all(event['checks'].values())
        check_metrics(event['metrics'], event['cycle'])
    assert ends[-1]['metrics'] == run['final']['metrics_before_shutdown']
    public = [e for e in events if e['event'] == 'public_network_pass']
    assert len(public) == run['final']['public_rounds']
    result.update(final=run['final'], platform=run['metadata']['client'],
                  memory=memory(lines(folder/'process.jsonl')), verified_cycle_records=len(ends))
    return result

def compare(folder=None, host='windows'):
    folder = folder or LAB/'windows-compare-a'
    top, built = read(folder/'result.json'), read(folder/'build.json')
    assert top['status'] == 'passed' and top['runs'] == 36
    groups = []
    for body in [1024,65536,1048576]:
        for version in ['current','v011']:
            plain = [read(folder/(version+'-plain-'+str(body)+'-'+str(i))/'result.json') for i in range(3)]
            alloc = [read(folder/(version+'-alloc-'+str(body)+'-'+str(i))/'result.json') for i in range(3)]
            for row in plain+alloc:
                assert row['exit_code'] == 0 and not row['forced'] and all(row['inner']['checks'].values())
                key = version+('-alloc' if row['inner']['workload']['allocator_instrumented'] else '-plain')
                assert row['binary_sha256'] == built['binaries'][key]['sha256']
            requests = plain[0]['inner']['workload']['requests_per_sample']
            medians = [row['inner']['measures']['wall_ms']['median'] for row in plain]
            groups.append(dict(body_bytes=body, version=version, requests_per_sample=requests,
                               wall_ms_median_of_launch_medians=st.median(medians), wall_ms_launch_medians=medians,
                               plain_peak_rss=[row['sampled_peak_rss'] for row in plain],
                               plain_peak_private=[row['sampled_peak_private'] for row in plain],
                               allocations_per_request=st.median(row['inner']['measures']['allocations_per_sample']['median']/requests for row in alloc),
                               allocated_bytes_per_request=st.median(row['inner']['measures']['bytes_allocated_per_sample']['median']/requests for row in alloc)))
    platform = {k:v for k,v in plain[0]['inner']['platform'].items() if k != 'cargo_features'}
    return dict(host=host, source=top['source'], runs=36, groups=groups,
                platform=platform, features='current no-default-features:native; registry v0.1.1 no-default-features,native')

def remote_comparison(label):
    summary = read(LAB/('download-'+label+'-comparison')/'summary.json')
    path = LAB/(label+'-compare-033d-evidence.tar.gz')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == summary['sha256']
    assert summary['source'] == read(LAB/'compare-frozen.json')['source']
    dest = LAB/'collected'/(label+'-comparison')
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        assert len(names) == len(set(names))
        for m in members:
            assert (m.isfile() or m.isdir()) and not PurePosixPath(m.name).is_absolute()
            assert '\\' not in m.name and '..' not in PurePosixPath(m.name).parts
            if m.isdir():
                continue
            assert m.name.startswith('observations/compare/') or m.name in ['compare-build.log','compare-run.log','r4-compare-source.json']
            target = dest/m.name
            assert dest.resolve() in target.resolve().parents
            content = archive.extractfile(m).read()
            if target.exists():
                assert target.read_bytes() == content
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(content)
    assert hashlib.sha256((dest/'r4-compare-source.json').read_bytes()).hexdigest() == summary['source']
    result = compare(dest/'observations/compare',label)
    result['archive'] = summary
    return result

def small_followup():
    rows = read(LAB/'windows-compare-small-followup/result.json')
    assert rows['status'] == 'passed' and rows['runs'] == 10
    medians = {v:[] for v in ['current','v011']}
    for row in rows['records']:
        assert row['exit_code'] == 0 and not row['forced'] and all(row['inner']['checks'].values())
        medians[row['label'].split('-')[0]].append(row['inner']['measures']['wall_ms']['median'])
    return dict(launch_medians_ms=medians,paired_change_percent=[100*(a/b-1) for a,b in zip(medians['current'],medians['v011'])],
                median_change_percent=100*(st.median(medians['current'])/st.median(medians['v011'])-1))

if __name__ == '__main__':
    result = dict(source=SOURCE, archives=[archive(label,digest) for label,digest in EXPECTED.items()], comparison=compare(),
                  remote_comparisons=[remote_comparison(h) for h in ['mac-arm64','linux-x64']],windows_small_followup=small_followup())
    (LAB/'analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))
