from pathlib import Path
import subprocess
main = Path('C:/User/projects/nbreq')
work = main/'target/worktrees/nbreq-r4'
name = 'src/backend/native_http/tests.rs'
base = subprocess.check_output(['git', 'show', '149450d:'+name], cwd=work)
assert (main/name).read_bytes().replace(b'\r\n', b'\n') == base.replace(b'\r\n', b'\n'), 'main fixture changed independently'
(main/name).write_bytes((work/name).read_bytes())
names = subprocess.check_output(['git', 'ls-files', 'tools/release-soak'], cwd=work, text=True).splitlines()
for name in names:
    target = main/name
    assert not target.exists(), 'main tool already exists: '+name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((work/name).read_bytes())
print('Mirrored scoped fixture and '+str(len(names))+' tool files; unrelated files untouched.')
