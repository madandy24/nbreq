import hashlib, json, subprocess, tarfile
from pathlib import Path
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-r4')
lab = Path(__file__).resolve().parent
names = subprocess.check_output(['git', 'ls-files'], cwd=root, text=True).splitlines()
names = [n for n in names if not n.startswith(('thoughts/', 'experiments/', 'vendor/', 'fuzz/', 'tools/')) or n.startswith('tools/xtask/')]
names += [p.relative_to(root).as_posix() for p in (root/'tools/release-soak').rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'target' not in p.relative_to(root/'tools/release-soak').parts]
files = {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
manifest = json.dumps(dict(schema='nbreq-r4-source-v1', base='149450d6543376cdb8255b55d7eb286e98207f42', files=files), indent=2).encode()+b'\n'
identity = hashlib.sha256(manifest).hexdigest()
dest = lab/('source-'+identity[:12])
dest.mkdir(exist_ok=False)
for name in files:
    path = dest/name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((root/name).read_bytes())
(dest/'r4-source.json').write_bytes(manifest)
archive = lab/('nbreq-r4-'+identity[:12]+'.tar.gz')
with tarfile.open(archive, 'w:gz') as out:
    for name in sorted(files):
        out.add(dest/name, arcname=name, recursive=False)
    out.add(dest/'r4-source.json', arcname='r4-source.json', recursive=False)
result = dict(source=identity, directory=str(dest), archive=str(archive), archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), files=len(files))
(lab/'frozen.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
