"""Longer same-binary 1 KiB follow-up for the noisy first Windows comparison."""
import importlib.util
import json
from pathlib import Path

lab = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('r4_compare', lab/'comparison-source-a/tools/f5-observe/compare.py')
compare = importlib.util.module_from_spec(spec)
spec.loader.exec_module(compare)
identity, source = compare.verify_inputs()
built = compare.read(lab/'windows-compare-a/build.json')
assert built['source'] == identity
out = lab/'windows-compare-small-followup'
out.mkdir(exist_ok=False)
records = []
for repetition in range(5):
    versions = ['current','v011'] if repetition % 2 == 0 else ['v011','current']
    for version in versions:
        label = version+'-plain-1024-'+str(repetition)
        origin = 'manifest:'+source['runtime_source'] if version == 'current' else source['registry_commit']
        record = compare.observe(Path(built['binaries'][version+'-plain']['path']), out/label, label,
                                 '0.2.0' if version == 'current' else '0.1.1', origin, 1024,32768,False)
        assert record['binary_sha256'] == built['binaries'][version+'-plain']['sha256']
        records.append(record)
        print(label+' '+str(record['inner']['measures']['wall_ms']), flush=True)
(out/'result.json').write_text(json.dumps(dict(status='passed',source=identity,
    reason='Initial 1 KiB launch medians overlapped widely, with current median 17.5% slower. Retain both sets; use longer repetitions to investigate.',
    runs=10,records=records),indent=2),encoding='utf-8')
