"""Read retained R4 bridge replies and verify interim counters; never accepts a completed soak."""
import json
from pathlib import Path
import sys
import time

lab = Path(__file__).resolve().parent
source = json.loads((lab/'frozen.json').read_text(encoding='utf-8-sig'))['source']

def check(label, state, progress, sample=None):
    assert state['source'] == source, (label, 'source mismatch')
    if state['status'] != 'running':
        return dict(host=label, status=state['status'], action='inspect complete result and cleanup', result=state)
    assert progress['status'] == 'running'
    m = progress['metrics']
    cycle = progress['cycles']
    expected = 1 + cycle // 10
    assert cycle > 0 and m['failed'] == expected
    assert m['cancelled'] == 2*cycle+expected
    assert m['accepted'] == m['completed']+m['failed']+m['cancelled']
    assert m['tcp_accepted'] == 2*cycle and m['tcp_failed'] == 0 and m['dns_failed'] == 0
    assert all(m[key] == 0 for key in ['inflight','commands','callbacks','body_bytes','stream_bytes','tcp_bytes','tcp','resolves','waiters'])
    assert m['active'] == m['idle'] and m['high_active'] <= 8
    assert m['high_body_bytes'] <= 4*1024*1024 and m['high_stream_bytes'] <= 65536 and m['high_tcp_bytes'] <= 32768
    return dict(host=label, status='running', cycle=cycle, elapsed_s=progress['elapsed_s'],
                accepted=m['accepted'], expected_refusals=m['failed'], gauges='quiescent', latest_sample=sample)

results = []
root = lab/'windows-soak-e78'
results.append(check('Windows', json.loads((root/'status.json').read_text()),
                     json.loads((root/'mixed/progress.json').read_text()),
                     json.loads((root/'mixed/process.jsonl').read_text().splitlines()[-1])))
for request in json.loads((lab/sys.argv[1]).read_text(encoding='utf-8-sig')):
    path = Path(request['root'])/'results'/(request['id']+'.json')
    deadline = time.monotonic() + 20
    while not path.exists() and time.monotonic() < deadline:
        time.sleep(0.2)
    if not path.exists():
        raise TimeoutError('bridge reply still pending; do not replay request '+request['id'])
    reply = json.loads(path.read_text(encoding='utf-8-sig'))
    assert reply['ok'] and reply['status'] == 'completed' and reply['exit_code'] == 0
    (lab/'bridge-results'/path.name).write_bytes(path.read_bytes())
    remaining = reply['output'].strip()
    objects = []
    while remaining:
        value, offset = json.JSONDecoder().raw_decode(remaining)
        objects.append(value)
        remaining = remaining[offset:].strip()
    results.append(check(request['bridge'], objects[0], objects[1], objects[2] if len(objects)>2 else None))
(lab/(Path(sys.argv[1]).stem+'-checked.json')).write_text(json.dumps(results, indent=2), encoding='utf-8')
print(json.dumps(results, indent=2))
