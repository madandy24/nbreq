from pathlib import Path
import ast, hashlib, json, os, platform, shutil, subprocess, sys

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
sys.path.insert(0, str(lab))
from owned_command import command

assert not (lab/'summary.json').exists()
env = dict(os.environ, CARGO_TARGET_DIR=str(lab/'build'))
inputs = [p for p in root.joinpath('examples').rglob('*') if p.is_file()]
inputs += [root/p for p in ['Cargo.toml','Cargo.lock','tools/release-consumer/check_examples.py', 'tools/release-consumer/registry.py']]
hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
(lab/'inputs.json').write_text(json.dumps(dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), platform=platform.platform(), hashes=hashes),indent=2))
for p in ['tools/release-consumer/check_examples.py','tools/release-consumer/registry.py']:
    ast.parse((root/p).read_text(), filename=p)
commands = []
def run(label, argv, timeout=300):
    command(argv, root, lab, label, env, timeout)
    commands.append(label)

run('stable-version', ['rustc', '+stable', '-Vv'], 30)
run('msrv-version', ['rustc', '+1.85.0', '-Vv'], 30)
run('default-build', ['cargo','+stable','build','--locked','--offline','--examples'])
run('default-examples', [sys.executable,'-B','tools/release-consumer/check_examples.py','--bin-dir',str(lab/'build/debug/examples'),'--out',str(lab/'local-examples')], 180)
local = json.loads((lab/'local-examples/summary.json').read_text())
assert local['status']=='passed' and local['executions']==18 and local['local_only']
examples = [('C04-tcp-tls','verified TLS to 127.0.0.1; echoed 24 protected bytes'), ('C05-tcp-starttls','upgraded the same socket; echoed 24 protected bytes')]
flags = ['--example',examples[0][0],'--example',examples[1][0]]
binary_hashes = {}
for mode, toolchain, features in [('native','stable',['--no-default-features','--features','native']), ('msrv','1.85.0',[])]:
    run(mode+'-build',['cargo','+'+toolchain,'build','--locked','--offline',*flags,*features])
    for example, expected in examples:
        path = lab/'build/debug/examples'/(example+'.exe')
        binary_hashes[mode+'-'+example] = hashlib.sha256(path.read_bytes()).hexdigest()
        label = mode+'-'+example
        run(label, [str(path)], 45)
        assert expected in (lab/(label+'.log')).read_text()
run('clippy',['cargo','+stable','clippy','--locked','--offline',*flags,'--','-D','warnings'])
run('formatting',['cargo','+stable','fmt','--all','--','--check'],60)
assert hashes == {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
for p in inputs:
    destination = lab/'source'/p.relative_to(root)
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,destination)
summary = dict(status='passed',commands=commands,local_example_executions=18,
               extra_tls_executions=4,binary_hashes=binary_hashes,
               scope='Windows x86_64, local fixtures; default all examples plus native-only and Rust 1.85 TLS examples',
               limitations=['No live public-network checks or remote-platform rerun','No production/fixture runtime changes; final packaged release checks remain separate'])
(lab/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary),flush=True)
