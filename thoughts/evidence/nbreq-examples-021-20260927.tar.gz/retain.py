from pathlib import Path
import hashlib, json, subprocess, tarfile

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
summary = json.loads((lab/'summary.json').read_text())
assert summary['status']=='passed'
inputs = json.loads((lab/'inputs.json').read_text())
for name, expected in inputs['hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected, name
changes = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
for name in changes:
    if name.startswith('thoughts/'):
        continue
    assert name.startswith(('examples/','docs/','tools/release-consumer/')), name
    destination = lab/'source'/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((root/name).read_bytes())
(lab/'change.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=root))
files = [p for p in lab.iterdir() if p.is_file()]
files += [p for p in (lab/'local-examples').iterdir() if p.is_file()]
files += [p for p in (lab/'source').rglob('*') if p.is_file()]
members = {p.relative_to(lab).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
archive_path = root/'thoughts/evidence/nbreq-examples-021-20260927.tar.gz'
assert not archive_path.exists()
with tarfile.open(archive_path,'w:gz') as archive:
    for p in sorted(files):
        archive.add(p,arcname=p.relative_to(lab).as_posix(),recursive=False)
with tarfile.open(archive_path) as archive:
    entries = archive.getmembers()
    assert all(m.isfile() for m in entries) and len(entries)==len(members)
    assert {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in entries}==members
index = dict(archive=archive_path.name,bytes=archive_path.stat().st_size,regular_members=len(members),
             sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest(),summary=summary,
             base_commit=inputs['base_commit'],excluded='Build output and binaries; executed binary hashes are retained',members=members)
(root/'thoughts/evidence/nbreq_examples_021_artifacts.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:index[k] for k in ['archive','bytes','regular_members','sha256']},indent=2))
