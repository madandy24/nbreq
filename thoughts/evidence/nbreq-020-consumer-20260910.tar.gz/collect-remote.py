from pathlib import Path,PurePosixPath
import base64,hashlib,json,tarfile,sys

lab=Path(__file__).resolve().parent
for item in json.loads((lab/'bridge-collections.json').read_text(encoding='utf-8-sig')):
    request=Path(item['requestPath'])
    result_path=request.parent.parent/'results'/request.name
    if not result_path.is_file():
        print(item['bridge']+': collection pending')
        continue
    result=json.loads(result_path.read_text(encoding='utf-8-sig'))
    assert result['ok'] and result['status']=='completed' and result['exit_code']==0, result['output']
    lines=result['output'].strip().splitlines()
    digest=lines[0].split()[0].lower()
    data=base64.b64decode(''.join(lines[1:]),validate=True)
    assert hashlib.sha256(data).hexdigest()==digest
    name=item['bridge']
    archive_path=lab/(name+'-evidence.tar.gz')
    if archive_path.exists(): assert archive_path.read_bytes()==data
    else: archive_path.write_bytes(data)
    destination=lab/name
    destination.mkdir(exist_ok=True)
    with tarfile.open(archive_path,'r:gz') as archive:
        for member in archive.getmembers():
            relative=PurePosixPath(member.name)
            assert member.isfile() and not relative.is_absolute() and '..' not in relative.parts
            target=destination.joinpath(*relative.parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            contents=archive.extractfile(member).read()
            if target.exists(): assert target.read_bytes()==contents
            else: target.write_bytes(contents)
    status=json.loads((destination/'evidence/status.json').read_text())
    print(json.dumps(dict(bridge=name,sha256=digest,status=status['status'],steps=status['steps']),indent=2))
