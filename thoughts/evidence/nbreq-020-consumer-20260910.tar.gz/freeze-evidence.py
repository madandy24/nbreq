from pathlib import Path
import hashlib,json,re,tarfile

root=Path(__file__).resolve().parents[2]
lab=root/'target/release-020'
destination=root/'thoughts/evidence/nbreq-020-consumer-20260910.tar.gz'
assert not destination.exists()
manifest=json.loads((lab/'source-manifest.json').read_text())
for name,digest in manifest.items():
    if name.startswith('source/'): path=root/name[len('source/'):]
    elif name.startswith('consumer/'): path=root/'tools/release-consumer'/name[len('consumer/'):]
    elif name.startswith('packages/'): path=lab/'package-build-b/package'/name[len('packages/'):]
    else: path=lab/name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,name

windows=json.loads((lab/'consumer-c/inputs.json').read_text())
assert windows['status']=='passed'
assert all(item['passed'] for item in json.loads((lab/'consumer-c/results.json').read_text()))
assert 'all 24 steps passed' in (lab/'windows-verifier.log').read_text()
platforms={'windows':dict(verifier_toolchain='1.97.1',consumer_toolchains=['1.97.1','1.85.0'],consumer=windows)}
for name in ('putty_bridge','putty_bridge_intel_mac','putty_bridge_scaleway_nbreq'):
    out=lab/name/'evidence'
    status=json.loads((out/'status.json').read_text())
    assert status['status']=='passed' and all(step['exit_code']==0 for step in status['steps'])
    consumer=json.loads((out/'consumer/inputs.json').read_text())
    assert consumer['status']=='passed' and consumer['packages']==windows['packages']
    assert all(item['passed'] for item in json.loads((out/'consumer/results.json').read_text()))
    assert json.loads((lab/name/'source-manifest.json').read_text())==manifest
    verifiers={}
    for tc in ('stable','1.85.0'):
        text=(out/(tc+'-verify.log')).read_text()
        matches=re.findall(r'all 24 steps passed in ([\d.]+)s',text)
        assert len(matches)==1
        verifiers[tc]=float(matches[0])
    platforms[name]=dict(platform=json.loads((out/'platform.json').read_text()),verifier_seconds=verifiers,consumer=consumer)

items={}
for path in lab.iterdir():
    if path.is_file() and path.name!='linux-inspection.json': items[path.name]=path
for directory in ('before','consumer-a','consumer-b','consumer-c'):
    for path in (lab/directory).rglob('*'):
        if path.is_file() and not set(path.relative_to(lab/directory).parts).intersection(('build','target','__pycache__')):
            items[path.relative_to(lab).as_posix()]=path
for directory in ('package-build','package-build-b'):
    for path in (lab/directory/'package').glob('*.crate'):
        items[path.relative_to(lab).as_posix()]=path
with tarfile.open(destination,'w:gz') as archive:
    for name,path in sorted(items.items()): archive.add(path,arcname=name,recursive=False)
artifact=dict(date='2026-09-10',archive=destination.name,sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
              bytes=destination.stat().st_size,files=len(items),packages=windows['packages'],platforms=platforms,
              registry_gate_closed=False,publication_performed=False,source_manifest_verified=True,
              scope='R1 documentation/examples and R2 independent consumer rehearsal; explicit Darwin support override')
artifact['full_verifiers']=7
artifact['consumer_suite_test_executions']=256
artifact['feature_import_checks']=32
artifact['packaged_example_runs']=28
artifact['advisory_database_commit']=(lab/'advisory-commit.txt').read_text().strip()
artifact['advisory_exception']='Existing RUSTSEC-2026-0009 exception: dev-only time, affected parsing feature absent'
artifact['root_advisory_scan']=json.loads((lab/'audit-root.json').read_text(encoding='utf-8-sig'))
artifact['consumer_advisory_scan']=json.loads((lab/'audit-consumer.json').read_text(encoding='utf-8-sig'))
for key in ('root_advisory_scan','consumer_advisory_scan'):
    assert not artifact[key]['vulnerabilities']['found'] and not artifact[key]['warnings']
for name in ('putty_bridge_intel_mac','putty_bridge_scaleway_nbreq'):
    rehearsal=json.loads((lab/(name+'-darwin.json')).read_text(encoding='utf-8-sig'))
    assert rehearsal['ok'] and rehearsal['exit_code']==0 and rehearsal['status']=='completed'
    assert rehearsal['output'].count('test result: ok. 5 passed')==2
    assert 'aborting upload due to dry run' in rehearsal['output']
artifact['darwin_rehearsals']='Both Macs: five tests on stable/MSRV, stable warning-denied lint, Cargo publication dry run'
(root/'thoughts/evidence/nbreq_020_artifacts.json').write_text(json.dumps(artifact,indent=2)+'\n')
print(json.dumps(artifact,indent=2))
