from pathlib import Path
import hashlib,json,tarfile

root=Path(__file__).resolve().parents[2]
lab=root/'target/release-020'
items={}
for name in ('Cargo.toml','Cargo.lock','README.md','SECURITY.md','LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.html','rustfmt.toml','about.toml','about.hbs'):
    path=root/name
    if path.is_file(): items['source/'+name]=path
for name in ('src','tests','examples','docs','support/winpoll','support/darwin','tools/xtask','.github','.cargo'):
    for path in (root/name).rglob('*'):
        relative=path.relative_to(root)
        if not path.is_file() or set(relative.parts).intersection(('target','__pycache__')): continue
        if 'fuzz' in relative.parts and path.suffix!='.seed': continue
        items['source/'+relative.as_posix()]=path
for path in (root/'tools/release-consumer').rglob('*'):
    relative=path.relative_to(root/'tools/release-consumer')
    if path.is_file() and not set(relative.parts).intersection(('target','__pycache__','Cargo.lock')):
        items['consumer/'+relative.as_posix()]=path
for name in ('nbreq-0.2.0.crate','nbreq-darwin-0.1.0.crate'):
    items['packages/'+name]=lab/'package-build-b/package'/name
items['remote-job.py']=lab/'remote-job.py'
manifest={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in sorted(items.items())}
(lab/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(lab/'remote-020-20260910.tar.gz','w:gz') as archive:
    archive.add(lab/'source-manifest.json',arcname='source-manifest.json')
    for name,path in sorted(items.items()): archive.add(path,arcname=name,recursive=False)
print(json.dumps(dict(files=len(items),bytes=(lab/'remote-020-20260910.tar.gz').stat().st_size,sha256=hashlib.sha256((lab/'remote-020-20260910.tar.gz').read_bytes()).hexdigest()),indent=2))
