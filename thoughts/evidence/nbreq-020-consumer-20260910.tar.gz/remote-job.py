"""Run an isolated release rehearsal and retain bounded evidence; never publish."""
from pathlib import Path
import hashlib, json, os, platform, subprocess, sys, tarfile, time

root=Path(__file__).resolve().parent
out=root/'evidence'
out.mkdir(exist_ok=False)
steps=[]
env=dict(os.environ, CARGO_TARGET_DIR=str(root/'build'))
def command(label,args,cwd):
    print(label,flush=True)
    started=time.monotonic()
    with (out/(label+'.log')).open('wb') as log:
        result=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    steps.append(dict(label=label,command=args,exit_code=result.returncode,seconds=time.monotonic()-started))
    (out/'steps.json').write_text(json.dumps(steps,indent=2))
    if result.returncode: raise RuntimeError(label+' failed')

status='failed'
try:
    manifest=json.loads((root/'source-manifest.json').read_text())
    for name,expected in manifest.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected, name
    (out/'platform.json').write_text(json.dumps(dict(platform=platform.platform(),machine=platform.machine()),indent=2))
    for tc in ('stable','1.85.0'):
        command(tc+'-versions',['rustup','run',tc,'rustc','--version','--verbose'],root)
        command(tc+'-fetch',['rustup','run',tc,'cargo','fetch','--locked'],root/'source')
        command(tc+'-verify',['rustup','run',tc,'cargo','run','--locked','--offline','--manifest-path','tools/xtask/Cargo.toml','--','verify','--offline'],root/'source')
    command('consumer',[sys.executable,str(root/'consumer/run.py'),'--package',str(root/'packages/nbreq-0.2.0.crate'),'--darwin-package',str(root/'packages/nbreq-darwin-0.1.0.crate'),'--out',str(out/'consumer'),'--live-dns','example.com','--live-https','https://example.com/'],root)
    status='passed'
finally:
    (out/'status.json').write_text(json.dumps(dict(status=status,steps=steps),indent=2))
    with tarfile.open(root/'evidence.tar.gz','w:gz') as archive:
        archive.add(root/'source-manifest.json',arcname='source-manifest.json')
        for path in out.rglob('*'):
            if path.is_file() and not set(path.relative_to(out).parts).intersection(('build','target','__pycache__')):
                archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
    print('release_rehearsal_status='+status,flush=True)
