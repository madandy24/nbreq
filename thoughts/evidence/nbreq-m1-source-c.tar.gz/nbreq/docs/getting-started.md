# Using NBReq

NBReq is built around one explicit owner. An `Engine` owns network state, pools, DNS work, callback
workers, limits, and shutdown. It issues cheap cloneable `Client` command handles, but a Client
neither owns nor extends the Engine's lifetime. Keep the Engine in the service or module that is
responsible for stopping HTTP.

The default Cargo features are `native` and `resolver`. They provide NBReq's Rust-native HTTP/1.1,
DNS, TCP, public Resolver, and rustls implementation without Tokio or another async runtime.

Add the released crate with the native backend enabled by default:

```toml
[dependencies]
nbreq = "0.1"
```

An HTTP-only consumer can omit the public Resolver API and its Windows search-suffix registry
reader while retaining native HTTP and exact-name DNS for HTTP and hostname `TcpConnector`:

```toml
[dependencies]
nbreq = { version = "0.1", default-features = false, features = ["native"] }
```

The `resolver` feature implies `native`. Turning it off does not use a blocking OS resolver and does
not create a different DNS owner; it only removes the public Resolver surface and search expansion.

## Basic buffered requests

Spawned mode owns its reactor thread and supports simple Engine-bound blocking GET and POST calls.
The convenience builder delegates to the ordinary Request and Client path, so it uses the same
backend, pool, limits, timeouts, redirects, TLS policy, errors, and shutdown owner:

```rust,no_run
use std::time::Duration;

use nbreq::{Engine, EngineConfig};

let engine = Engine::new(EngineConfig::spawned())?;

let response = engine
    .get("https://example.com/")
    .header("Accept", "text/plain")
    .total_timeout(Duration::from_secs(30))
    .call()?;

let created = engine
    .post("https://example.com/items")
    .header("Content-Type", "application/json")
    .send(br#"{"name":"thing"}"#)?;

println!("GET {}, POST {}", response.status(), created.status());
engine.shutdown()?;
# Ok::<(), Box<dyn std::error::Error>>(())
```

`call()` sends the body already configured on the builder and is valid for an empty POST.
`send(body)` replaces that buffered body; `send_empty()` explicitly replaces it with an empty body.
HTTP 4xx and 5xx statuses remain ordinary `Response` values. These blocking terminals reject a
manually driven Engine with `WrongMode` rather than driving it implicitly.

## Spawned mode and explicit blocking requests

Issue a cheap cloneable Client when code needs the explicit Request surface or will later use
callbacks, direct waiters, cancellation handles, or streaming. The Client does not own or extend
the Engine lifetime:

```rust,no_run
use std::time::Duration;

use nbreq::{Engine, EngineConfig, Request};

let engine = Engine::new(EngineConfig::spawned())?;
let client = engine.client();

let request = Request::get("https://example.com/")
    .connect_timeout(Duration::from_secs(5))
    .inactivity_timeout(Duration::from_secs(10))
    .total_timeout(Duration::from_secs(30))
    .build()?;
let response = client.execute(request)?;

println!("HTTP {}", response.status());
engine.shutdown()?;
# Ok::<(), Box<dyn std::error::Error>>(())
```

`execute` returns a `Response` only for completed HTTP exchanges. A 404 or 500 remains a Response;
transport, timeout, policy, and cancellation outcomes are errors. Total timeout begins when NBReq
accepts the request, so queue time is included. TLS certificate and hostname verification is on by
default. Disable it only through the deliberately explicit `TlsVerification` compatibility option.

## Private certificate authorities

Add DER-encoded root certificates to an Engine when an application uses a private CA. The roots
supplement platform trust, without modifying the operating-system trust store. Hostname, validity
and signature verification stay enabled:

```rust,no_run
use nbreq::{Engine, EngineConfig};

let root_der = std::fs::read("company-root.der")?;
let config = EngineConfig::spawned().with_additional_tls_root_certificate(root_der);
let engine = Engine::new(config)?; // Rejects malformed certificates during construction.
let response = engine.get("https://internal.example/").call()?;
engine.shutdown()?;
# Ok::<(), Box<dyn std::error::Error>>(())
```

Call the configuration method once per root. An Engine's trust policy is fixed at construction and
applies to all its HTTPS requests and redirects; use separate Engines for separate trust domains.
Windows, Linux and macOS use the existing platform verifier with extra roots. The pinned Android
verifier does not support this option and rejects a nonempty extra-root configuration explicitly.

## Callbacks and direct waiters

`Client::start` queues one `FnOnce` callback after the canonical terminal result is committed. User
code never runs on the network reactor or while the request registry is locked. In spawned mode the
callback runs on the Engine-owned callback pool:

```rust,no_run
use nbreq::{Completion, Engine, EngineConfig, Request};

let engine = Engine::new(EngineConfig::spawned())?;
let client = engine.client();
let handle = client.start(Request::get("https://example.com/").build()?, |result| {
    match result {
        Completion::Completed(response) => println!("HTTP {}", response.status()),
        Completion::Failed(error) => eprintln!("request failed: {error}"),
        Completion::Cancelled => eprintln!("request cancelled"),
        _ => {}
    }
})?;

// Idempotent if completion has already won.
handle.cancel()?;
engine.shutdown()?;
# Ok::<(), Box<dyn std::error::Error>>(())
```

Use `Client::submit` when the calling code wants a unique direct waiter instead. `PendingRequest`
can be polled, waited with a caller-local timeout, or given to a manual Engine's `drive_until`.
A waiter timeout does not cancel its request.

## Cancellation

Each accepted request has a cloneable cancellation-only `RequestHandle`. `cancel` is idempotent
after a terminal result and never recalls bytes already accepted by the operating system or acted
on by a remote server. `CancelOnDrop` is useful when cancellation should follow a local scope.

`Engine::cancel_all` cancels the entire Engine domain. It is appropriate during service shutdown;
independent cancellation domains should use independent Engines.

## Streaming responses and uploads

Every `StreamRequest` has a streaming response and returns one unique `ResponseReader`. A buffered
body remains replayable; `body_stream` consumes one unique `UploadBody` and redirects are returned
unfollowed once a live upload is involved.

```rust,no_run
use nbreq::{Engine, EngineConfig, StreamRequest, UploadBody};

let engine = Engine::new(EngineConfig::spawned())?;
let client = engine.client();

let (body, mut sender) = UploadBody::chunked(256 * 1024)?;
let request = StreamRequest::post("https://example.com/upload")
    .header("Content-Type", "application/octet-stream")
    .body_stream(body)
    .build()?;
let reader = client.submit_stream(request)?;

sender.push(vec![0_u8; 64 * 1024])?;
sender.finish()?;
let response = reader.collect()?;

println!("HTTP {}", response.status());
engine.shutdown()?;
# Ok::<(), Box<dyn std::error::Error>>(())
```

`UploadBody::fixed` generates `Content-Length` and requires exactly the declared byte count before
`finish`. `UploadBody::chunked` generates HTTP/1.1 chunk framing and permits an unknown total.
`try_push` never blocks and returns ownership of a refused chunk. Spawned-mode `push` admits large
chunks progressively and wakes on capacity, early response, cancellation, failure, or Engine stop.

`ResponseReader::wait_head`, `read`, and `collect` block only in spawned mode. Their `try_*`
counterparts are passive and are suitable for manual driving. `collect` is valid only before any
body byte has been consumed. Dropping a reader before known EOF requests cancellation; dropping it
after final EOF or a no-body response is harmless.

## Errors and TLS diagnosis

Use the structured fields on `Error` for decisions and treat `message()` as a payload-free human
diagnostic. In particular, `transport_stage()` identifies DNS, connect, TLS, send, receive, or HTTP
framing, while `tls_failure()` can distinguish safe categories such as hostname mismatch, unknown
issuer, expiry, peer alert, protocol failure, and local TLS I/O. Both enums are non-exhaustive, so
portable callers must retain a fallback arm:

```rust
use nbreq::{Error, TlsFailure};

fn tls_hint(error: &Error) -> &'static str {
    match error.tls_failure() {
        Some(TlsFailure::CertificateHostnameMismatch) => "check the requested hostname",
        Some(TlsFailure::CertificateUnknownIssuer) => "check the installed trust roots",
        Some(TlsFailure::CertificateExpired) => "renew the server certificate",
        Some(_) => "inspect the TLS category and deployment",
        None => "this was not a classified TLS failure",
    }
}
```

NBReq deliberately provides no raw-TLS-diagnostic switch: backend-native certificate errors can
contain requested or presented names. The structured category preserves operational usefulness
without making ordinary logging a data-disclosure path.

## Manual driving and GUI loops

Manual mode creates no reactor thread and dispatches callbacks inline only from explicit drive
calls. The unique Engine owner must call `drive`; Client methods and readers never drive it
implicitly:

```rust,no_run
use nbreq::{Completion, EngineBuilder, Request};

let mut engine = EngineBuilder::manual().build()?;
let client = engine.client();
let pending = client.submit(Request::get("https://example.com/").build()?)?;

match engine.drive_until(pending)? {
    Completion::Completed(response) => println!("HTTP {}", response.status()),
    Completion::Failed(error) => eprintln!("request failed: {error}"),
    Completion::Cancelled => eprintln!("request cancelled"),
    _ => {}
}
engine.shutdown()?;
# Ok::<(), Box<dyn std::error::Error>>(())
```

For a GUI with spawned networking, keep the Engine in an application service and have callbacks
send owned results through the GUI framework's own message/channel mechanism. Do not perform long
GUI work on NBReq's callback worker. Manual mode is useful only when the host can integrate regular
`drive` calls and accepts that delaying them delays all network progress.

Native TLS handshake processing uses an Engine-owned service, started lazily, with at most two
workers and four queued steps. These workers process supplied TLS bytes; sockets and application
callbacks stay with their existing owners. Established TLS traffic does not use the worker queue.
In manual mode, worker completion becomes network progress only on a subsequent `drive` call.
Saturated workers delay new handshakes within the existing connection limits and request deadlines.

## Shutdown, DLLs, and FFI ownership

`Engine::shutdown` consumes the unique owner, rejects new work, cancels accepted requests, stops and
joins network/resolver/TLS-worker work, seals callback admission, and waits for callbacks. A
callback that is itself currently running can therefore delay ordinary shutdown.

Cancellation and request deadlines close the request's NBReq socket without waiting for an
executing platform certificate check. That check may not be interruptible: its worker and TLS
state remain owned and bounded until it returns. Shutdown discards queued handshake work and
closes sockets before joining executing checks, so a slow platform check can delay shutdown.

`shutdown_for` can detach only the already-network-free callback domain and return
`ShutdownOutcome::CallbacksRemaining`. Keep the resulting `DetachedCallbacks` handle and wait for
it before unloading a module containing callback code. The handle owns no Engine, socket, resolver,
TLS, or backend state.

The `shutdown_for` duration bounds callback draining after network shutdown; it does not set a
deadline for joining executing platform certificate checks.

An FFI layer should expose opaque ownership handles: one unique Engine/service handle and separate
cloneable Client/request-control handles. Destroy consumer objects, stop the Engine, resolve any
detached callback handle, and only then permit library unload. Never initialize networking from a
Windows `DllMain` loader callback.

## Limits, pools, and metrics

Engine construction owns all resource ceilings: inflight requests, command and callback queues,
request/response bodies and headers, stream windows and aggregate queued bytes, active connections,
idle connections, and idle lifetime. Tighten them for the application; do not create an unbounded
Client-specific escape hatch.

`Engine::metrics` is a nonblocking, approximate, payload-free snapshot. Request and bounded-queue
metrics are portable. Check `connection_metrics_available` before interpreting physical
connection/pool counters; the native owner supplies them, while internal non-networking test
backends report honest unavailable zeroes.

## Backend and feature selection

- Default features: native backend, ordinary `Engine::new` and unqualified builder construction.
- `--no-default-features`: compiles the public types, but ordinary network construction returns
  `Unsupported`.
- `test-support`: deterministic downstream conformance controls, not required by consumers.

The historical curl Multi pilot is not part of the public crate feature matrix. It required a
locally patched binding and remains project-history/reference evidence rather than a supported
transport choice.

NBReq 0.1.0 supports Windows 10 x64 or later and native Linux x64 built against an Ubuntu 20.04 ABI
baseline. The Windows x86 GDS integration also passes its controlled compatibility workload under
Ubuntu 20.04's stock Wine 5; that is compatibility evidence for the Windows build, not a claim that
every Wine release and host combination is supported.
