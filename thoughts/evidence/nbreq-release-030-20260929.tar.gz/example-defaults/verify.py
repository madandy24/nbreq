from pathlib import Path
import json, os, re, shutil, signal, sys

root = Path('C:/User/projects/nbreq')
lab = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'target/timeout-defaults-20260929'))
from owned_command import command

def terminate(signum, _frame):
    raise SystemExit(128 + signum)
signal.signal(signal.SIGTERM, terminate)
out = lab/'checks'
out.mkdir(exist_ok=False)
env = dict(os.environ, CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           CARGO_TARGET_DIR=str(lab/'build'), RUSTDOCFLAGS='-D warnings')
env.pop('CARGO_BUILD_TARGET', None)
for label, args in [
    ('format', ['cargo','fmt','--check']),
    ('lint-examples', ['cargo','clippy','--locked','--offline','--all-features','--examples','--','-D','warnings']),
    ('build-examples', ['cargo','build','--locked','--offline','--examples']),
    ('run-examples', [sys.executable,'-B','tools/release-consumer/check_examples.py','--bin-dir',str(lab/'build/debug/examples'),'--out',str(out/'examples')]),
    ('native-examples', ['cargo','check','--locked','--offline','--examples','--no-default-features','--features','native']),
    ('msrv-examples', ['cargo','+1.85.0','check','--locked','--offline','--examples']),
    ('doc-tests', ['cargo','test','--locked','--offline','--all-features','--doc']),
]:
    command(args, root, out, label, env, 600)

scratch = lab/'uncommented'
shutil.copytree(root/'examples',scratch/'examples')
count = 0
for path in (scratch/'examples').glob('*.rs'):
    source = path.read_text()
    source, hits = re.subn(r'^(\s*)// (\..* // Default setting\..*)$', r'\1\2', source, flags=re.M)
    source, tls_hits = re.subn(r'^(\s*)// (let tls = tls\.handshake_timeout\(.*)$',r'\1\2',source,flags=re.M)
    count += hits + tls_hits
    path.write_text(source, newline='\n')
assert count == 53, count
(scratch/'Cargo.toml').write_text('''[package]
name = "nbreq-example-defaults-check"
version = "0.0.0"
edition = "2024"
[workspace]
[dependencies]
nbreq = { path = "C:/User/projects/nbreq" }
rcgen = "=0.13.2"
rustls = { version = "=0.23.45", default-features = false, features = ["ring", "std", "tls12"] }
time = { version = "=0.3.45", default-features = false, features = ["std"] }
''', newline='\n')
command(['cargo','check','--offline','--examples'],scratch,out,'uncommented-settings',env,600)
(out/'result.json').write_text(json.dumps(dict(status='passed',uncommented_settings=count,
                                              examples=19,local_executions=18),indent=2)+'\n')
