from pathlib import Path
import re

root = Path('C:/User/projects/nbreq')
for path in sorted((root/'examples').glob('*.rs')):
    text = path.read_text()
    if path.name.startswith('A'):
        total = 'None' if path.name.startswith('A09') else 'std::time::Duration::from_secs(120)'
        def http_defaults(match):
            indent = match.group(1)
            return '\n'.join(indent + '// .' + setting + ' // Default setting.' for setting in [
                'connect_timeout(std::time::Duration::from_secs(10))',
                'inactivity_timeout(std::time::Duration::from_secs(30))',
                'total_timeout(' + total + ')'])
        if path.name.startswith('A01'):
            text = text.replace('    let result = engine.get(url).call();',
                                '    let result = engine\n        .get(url)\n' +
                                http_defaults(re.match(r'( *)', '        ')) + '\n        .call();')
        else:
            text = re.sub(r'^ *\.(?:connect|inactivity)_timeout\(Duration::from_secs\(\d+\)\)\n', '', text, flags=re.M)
            text, count = re.subn(r'^( *)\.total_timeout\(Duration::from_secs\(15\)\)', http_defaults, text, flags=re.M)
            assert count == 1, path
    elif path.name.startswith('B'):
        comment = '// .total_timeout(std::time::Duration::from_secs(30)) // Default setting.'
        if path.name.startswith('B01'):
            text = text.replace('    let request = ResolveRequest::hostname(name).build()?;',
                                '    let request = ResolveRequest::hostname(name)\n        ' + comment + '\n        .build()?;')
        else:
            text = text.replace('.total_timeout(Duration::from_secs(10))', comment)
    elif path.name.startswith('C'):
        for name, value, note in [
            ('connect', 'std::time::Duration::from_secs(10)', ''),
            ('read_inactivity', 'None', ' No idle-read deadline.'),
            ('write_inactivity', 'std::time::Duration::from_secs(30)', '')]:
            text, count = re.subn(r'\.' + name + r'_timeout\(Duration::from_secs\(\d+\)\)',
                                 '// .' + name + '_timeout(' + value + ') // Default setting.' + note, text)
            assert count == 1, path
        text = text.replace('let tls = TlsOptions::new("127.0.0.1")?.handshake_timeout(Duration::from_secs(5));',
                            'let tls = TlsOptions::new("127.0.0.1")?;\n'
                            '    // Default setting; uncomment to change:\n'
                            '    // let tls = tls.handshake_timeout(std::time::Duration::from_secs(10));')
    active = '\n'.join(line.split('//', 1)[0] for line in text.splitlines()
                       if line.strip() != 'use std::time::Duration;')
    if 'Duration::' not in active:
        text = text.replace('use std::time::Duration;\n', '')
    path.write_text(text)
