"""Sequential, bounded local 0.3.0 pre-release stages. No stage publishes anything."""
import argparse
import hashlib
import json
import os
from pathlib import Path
from pathlib import PurePosixPath
import re
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import tomllib
from urllib.parse import unquote, urlsplit

ROOT = Path('C:/User/projects/nbreq')
LAB = ROOT / 'target/release-030-20260929/attempt-2'
VERSION = '0.3.0'
STAGES = ('verify', 'focused', 'http-focused', 'http-paced', 'http-stall',
          'http-paced-corrected', 'http-stall-corrected', 'verify-retry', 'package', 'packaged-tests',
          'packaged-tests-retry', 'registry',
          'publish-dry-run', 'publish-dry-run-identity', 'publish-dry-run-final-identity')


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()


def source_hashes():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    return {name: sha(ROOT / name) for name in names if name}


def stop_owned(process, stream):
    if os.name == 'nt' and process.poll() is None:
        try:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                           stdout=stream, stderr=subprocess.STDOUT, timeout=15, check=False)
        except (OSError, subprocess.TimeoutExpired):
            pass
        if process.poll() is None:
            process.kill()
    elif os.name != 'nt':
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    process.wait(timeout=20)


def run(out, label, argv, cwd, env, timeout):
    started = time.monotonic()
    receipt = dict(label=label, argv=argv, cwd=str(cwd), timeout_seconds=timeout)
    print('START', label, flush=True)
    with (out / (label + '.log')).open('xb') as stream:
        process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                   stdout=stream, stderr=subprocess.STDOUT,
                                   start_new_session=os.name != 'nt')
        receipt['pid'] = process.pid
        try:
            receipt['exit_code'] = process.wait(timeout=timeout)
        except BaseException as error:
            receipt['error'] = repr(error)
            stop_owned(process, stream)
            raise
        finally:
            receipt['elapsed_seconds'] = time.monotonic() - started
            receipt['exit_code'] = process.returncode
            write_json(out / (label + '.result.json'), receipt)
    print('END', label, receipt['exit_code'], flush=True)
    if receipt['exit_code']:
        raise RuntimeError(f'{label} failed; see {out / (label + ".log")}')


def inventory_root_archive(path, commit):
    prefix = 'nbreq-' + VERSION + '/'
    with tarfile.open(path) as bundle:
        entries = bundle.getmembers()
        names = {entry.name for entry in entries}
        if len(names) != len(entries) or not all(entry.isfile() and
                entry.name.startswith(prefix) and '\\' not in entry.name and
                '..' not in PurePosixPath(entry.name).parts for entry in entries):
            raise RuntimeError('invalid root archive members')
        files_in_archive = {name[len(prefix):] for name in names}
        vcs = json.load(bundle.extractfile(prefix + '.cargo_vcs_info.json'))
        if vcs['git']['sha1'] != commit or vcs['git'].get('dirty', False):
            raise RuntimeError('archive VCS source identity mismatch')
        manifest = tomllib.loads(bundle.extractfile(prefix + 'Cargo.toml').read().decode())
        if manifest['package']['name'] != 'nbreq' or manifest['package']['version'] != VERSION:
            raise RuntimeError('archive normalized manifest identity mismatch')
        for target, helper, version in [('cfg(windows)', 'nbreq-winpoll', '0.1.1'),
                                        ('cfg(target_os = "macos")', 'nbreq-darwin', '0.1.0')]:
            dependency = manifest['target'][target]['dependencies'][helper]
            if dependency['version'] != version or 'path' in dependency:
                raise RuntimeError('archive helper dependency is not registry-only: ' + helper)
        links = []
        versioned_links = []
        for entry in entries:
            if not entry.name.endswith('.md'):
                continue
            document = bundle.extractfile(entry).read().decode()
            for destination in re.findall(r'\]\(([^\s)]+)\)', document):
                url = urlsplit(destination)
                tag_prefix = '/madandy24/nbreq/blob/v' + VERSION + '/'
                if url.netloc == 'github.com' and url.path.startswith(tag_prefix):
                    target = unquote(url.path[len(tag_prefix):])
                    if target not in files_in_archive:
                        raise RuntimeError('missing future-tag target: ' + target)
                    if url.fragment:
                        target_text = bundle.extractfile(prefix + target).read().decode()
                        anchors = {re.sub(r'[^\w -]', '', heading.lower()).strip().replace(' ', '-')
                                   for heading in re.findall(r'(?m)^#{1,6}\s+(.+)$', target_text)}
                        if unquote(url.fragment) not in anchors:
                            raise RuntimeError('missing future-tag anchor: ' + destination)
                    versioned_links.append(dict(document=entry.name[len(prefix):],
                                                destination=destination, target=target,
                                                anchor=unquote(url.fragment)))
                if url.scheme or url.netloc or not url.path:
                    continue
                parts = list(PurePosixPath(entry.name).parent.parts)
                for part in PurePosixPath(unquote(url.path)).parts:
                    if part == '..':
                        if len(parts) <= 1:
                            raise RuntimeError('packaged link escapes archive: ' + destination)
                        parts.pop()
                    elif part != '.':
                        parts.append(part)
                target = '/'.join(parts)
                if target not in names:
                    raise RuntimeError('missing packaged link: ' + target)
                links.append(dict(document=entry.name[len(prefix):], destination=destination,
                                  target=target[len(prefix):]))
        files = {entry.name[len(prefix):]: hashlib.sha256(bundle.extractfile(entry).read()).hexdigest()
                 for entry in entries}
    if len(versioned_links) < 8:
        raise RuntimeError('future-tag link inventory unexpectedly incomplete')
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path), commit=commit,
                vcs=vcs, normalized_manifest_helpers='registry-only', files=files,
                relative_links=links, future_tag_links=versioned_links)


def archive_info():
    index = json.loads((LAB / 'authoritative-package/inventory.json').read_text(encoding='utf-8'))
    if index['commit'] != git('rev-parse', 'HEAD'):
        raise RuntimeError('authoritative package commit differs from current HEAD')
    if sha(Path(index['path'])) != index['sha256'] or Path(index['path']).stat().st_size != index['bytes']:
        raise RuntimeError('authoritative package bytes changed')
    if index['normalized_manifest_helpers'] != 'registry-only':
        raise RuntimeError('authoritative helper policy changed')
    return index


def extract_root_package(index, out):
    destination = Path(tempfile.mkdtemp(prefix='nbreq-030-packaged-')).resolve()
    if destination.is_relative_to(ROOT):
        raise RuntimeError('packaged extraction must be outside source workspace')
    write_json(out / 'extraction.json', dict(destination=str(destination),
        archive_path=index['path'], archive_sha256=index['sha256'],
        archive_bytes=index['bytes'], source_commit=index['commit']))
    archive = Path(index['path'])
    with tarfile.open(archive) as bundle:
        for member in bundle.getmembers():
            path = destination.joinpath(*Path(member.name).parts).resolve()
            if (not member.isfile() or not path.is_relative_to(destination.resolve())
                    or not member.name.startswith('nbreq-' + VERSION + '/')):
                raise RuntimeError('unsafe archive entry')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(bundle.extractfile(member).read())
    return destination / ('nbreq-' + VERSION)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=STAGES)
    args = parser.parse_args()
    out = LAB / args.stage
    out.mkdir(exist_ok=False)
    start_head = git('rev-parse', 'HEAD')
    start_hashes = source_hashes()
    write_json(out / 'source-before.json', dict(commit=start_head, files=start_hashes))
    env = dict(os.environ, CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
               PYTHONDONTWRITEBYTECODE='1')
    env.pop('CARGO_BUILD_TARGET', None)
    env.pop('CARGO_TARGET_DIR', None)
    failure = None
    try:
        if args.stage not in ('verify', 'focused', 'http-focused', 'http-paced',
                              'http-stall', 'http-paced-corrected', 'http-stall-corrected',
                              'verify-retry') and git('status', '--porcelain'):
            raise RuntimeError('clean committed source is required after verify')
        if args.stage in ('verify', 'focused', 'http-focused', 'http-paced',
                          'http-stall', 'http-paced-corrected', 'http-stall-corrected',
                          'verify-retry'):
            build = ROOT / 'target/release-030-20260929/verify/build'
            env.update(CARGO_TARGET_DIR=str(build), CARGO_NET_OFFLINE='true',
                       RUSTUP_TOOLCHAIN='stable', RUST_BACKTRACE='1')
            run(out, 'compiler', ['rustup', 'run', 'stable', 'rustc', '-vV'], ROOT, env, 30)
        if args.stage in ('http-focused', 'http-paced', 'http-stall',
                          'http-paced-corrected', 'http-stall-corrected'):
            diagnostic_modes = {'http-paced': 'pace', 'http-stall': 'stall',
                                'http-paced-corrected': 'pace', 'http-stall-corrected': 'stall'}
            if args.stage in diagnostic_modes:
                env['NBREQ_HTTP_DIAGNOSTIC_MODE'] = diagnostic_modes[args.stage]
            run(out, 'http-composition', ['rustup', 'run', 'stable', 'cargo', 'test',
                '--locked', '--offline', '--all-features', '--lib',
                'native_engine_composes_serialization_fragmentation_and_canonical_completion',
                '--', '--nocapture'], ROOT, env, 300)
        elif args.stage == 'focused':
            run(out, 'corrected-tls-deadlines', ['rustup', 'run', 'stable', 'cargo', 'test',
                '--locked', '--offline', '--no-default-features', '--features',
                'native,test-support', '--test', 'tcp_tls',
                'silent_peer_tls_establishment_times_out_and_cancel_is_terminal',
                '--', '--exact', '--nocapture'], ROOT, env, 300)
        elif args.stage in ('verify', 'verify-retry'):
            run(out, 'full-verifier', ['rustup', 'run', 'stable', 'cargo', 'run', '--locked',
                '--offline', '--manifest-path', 'tools/xtask/Cargo.toml', '--', 'verify',
                '--offline'], ROOT, env, 1800)
            if 'NBReq verification complete: all 30 steps passed' not in (
                    out / 'full-verifier.log').read_text(encoding='utf-8'):
                raise RuntimeError('full verifier did not report 30 passed steps')
        elif args.stage == 'package':
            run(out, 'helper-patched-rehearsal', [sys.executable, '-B',
                'tools/release-consumer/package_candidate.py', '--out', str(LAB / 'package-candidate')],
                ROOT, env, 3600)
            env.update(CARGO_TARGET_DIR=str(LAB / 'authoritative-package/build'),
                       RUSTUP_TOOLCHAIN='stable')
            run(out, 'registry-helper-package', ['rustup', 'run', 'stable', 'cargo', 'package',
                '--locked', '-p', 'nbreq'], ROOT, env, 1800)
            canonical = LAB / 'authoritative-package/build/package' / ('nbreq-' + VERSION + '.crate')
            inventory = inventory_root_archive(canonical, start_head)
            (LAB / 'authoritative-package').mkdir(exist_ok=True)
            write_json(LAB / 'authoritative-package/inventory.json', inventory)
            rehearsal = json.loads((LAB / 'package-candidate/packages.json').read_text())
            rehearsal_root = rehearsal['packages']['nbreq-' + VERSION + '.crate']
            write_json(out / 'archive-identities.json', dict(
                commit=start_head, authoritative=inventory,
                helper_patched_rehearsal={key: rehearsal_root[key] for key in ('path', 'bytes', 'sha256')},
                bytes_equal_to_rehearsal=(inventory['sha256'] == rehearsal_root['sha256'] and
                                          inventory['bytes'] == rehearsal_root['bytes'])))
        elif args.stage in ('packaged-tests', 'packaged-tests-retry'):
            packaged = extract_root_package(archive_info(), out)
            env.update(CARGO_TARGET_DIR=str(out / 'build'), CARGO_NET_OFFLINE='true',
                       RUSTUP_TOOLCHAIN='stable')
            for toolchain in ('stable', '1.85.0'):
                run(out, toolchain + '-compiler', ['rustup', 'run', toolchain, 'rustc', '-vV'],
                    packaged, env, 30)
                run(out, toolchain + '-packaged-focused', ['rustup', 'run', toolchain, 'cargo',
                    'test', '--locked', '--offline', '--all-features', '--test', 'timeout_defaults',
                    '--test', 'tcp_tls', '--test', 'tcp_tls_api', '--test', 'portable_tls'],
                    packaged, env, 1800)
                label = toolchain + '-packaged-http-composition'
                test_name = ('backend::native_http::tests::'
                    'native_engine_composes_serialization_fragmentation_and_canonical_completion')
                run(out, label, ['rustup', 'run', toolchain, 'cargo', 'test', '--locked',
                    '--offline', '--all-features', '--lib', test_name, '--', '--exact'],
                    packaged, env, 900)
                output = (out / (label + '.log')).read_text(encoding='utf-8')
                if ('running 1 test' not in output or
                        ('test ' + test_name + ' ... ok') not in output):
                    raise RuntimeError(label + ' did not exercise the exact HTTP unit test')
                run(out, toolchain + '-packaged-bundle', ['rustup', 'run', toolchain, 'cargo',
                    'test', '--locked', '--offline', '--all-features', '--lib', 'portable_tests'],
                    packaged, env, 900)
                run(out, toolchain + '-packaged-shutdown', ['rustup', 'run', toolchain, 'cargo',
                    'test', '--locked', '--offline', '--all-features', '--lib',
                    'final_tls_write_shutdown_'], packaged, env, 900)
        elif args.stage == 'registry':
            index = archive_info()
            archive = index['path']
            env.pop('CARGO_NET_OFFLINE', None)
            run(out, 'registry-candidate', [sys.executable, '-B',
                'tools/release-consumer/registry.py', '--mode', 'candidate', '--package', archive,
                '--out', str(LAB / 'registry-candidate'), '--toolchains', 'stable', '1.85.0'],
                ROOT, env, 5400)
            result = json.loads((LAB / 'registry-candidate/result.json').read_text())
            if result['status'] != 'passed' or result['archive_sha256'] != sha(Path(archive)):
                raise RuntimeError('registry candidate result or archive identity mismatch')
        elif args.stage == 'publish-dry-run':
            canonical = archive_info()
            env.update(CARGO_TARGET_DIR=str(out / 'build'), RUSTUP_TOOLCHAIN='stable')
            run(out, 'publish-dry-run', ['rustup', 'run', 'stable', 'cargo', 'publish', '--dry-run',
                '--locked', '-p', 'nbreq'], ROOT, env, 1800)
            generated = out / 'build/package' / ('nbreq-' + VERSION + '.crate')
            inventory = inventory_root_archive(generated, start_head)
            identical = (inventory['sha256'] == canonical['sha256'] and
                         inventory['bytes'] == canonical['bytes'])
            write_json(out / 'archive-byte-identity.json', dict(
                identical=identical, canonical={key: canonical[key] for key in ('path', 'bytes', 'sha256')},
                dry_run={key: inventory[key] for key in ('path', 'bytes', 'sha256')},
                source_commit=start_head))
            if not identical:
                raise RuntimeError('publish dry-run archive differs from exact tested candidate')
        elif args.stage in ('publish-dry-run-identity', 'publish-dry-run-final-identity'):
            canonical = archive_info()
            original = LAB / 'publish-dry-run'
            command = json.loads((original / 'publish-dry-run.result.json').read_text())
            original_summary = json.loads((original / 'summary.json').read_text())
            original_before = original / 'source-before.json'
            original_after = original / 'source-after.json'
            before_snapshot = json.loads(original_before.read_text())
            after_snapshot = json.loads(original_after.read_text())
            expected_command = ['rustup', 'run', 'stable', 'cargo', 'publish', '--dry-run',
                                '--locked', '-p', 'nbreq']
            if command['argv'] != expected_command or command['exit_code'] != 0:
                raise RuntimeError('original publish dry-run command did not succeed')
            if (before_snapshot != after_snapshot or before_snapshot['commit'] != start_head or
                    not original_summary['source_hashes_unchanged'] or
                    original_summary['commit'] != start_head):
                raise RuntimeError('original publish dry-run source identity changed')
            generated = {}
            for label in ('tmp-crate', 'tmp-registry'):
                path = original / 'build/package' / label / ('nbreq-' + VERSION + '.crate')
                generated[label] = inventory_root_archive(path, start_head)
            identical = all(candidate['sha256'] == canonical['sha256'] and
                            candidate['bytes'] == canonical['bytes']
                            for candidate in generated.values())
            write_json(out / 'archive-byte-identity.json', dict(
                identical=identical, dry_run_command=command,
                canonical={key: canonical[key] for key in ('path', 'bytes', 'sha256')},
                generated={label: {key: candidate[key]
                    for key in ('path', 'bytes', 'sha256')}
                    for label, candidate in generated.items()},
                original_source_snapshots=dict(before_path=str(original_before),
                    before_sha256=sha(original_before), after_path=str(original_after),
                    after_sha256=sha(original_after), identical=True),
                source_commit=start_head,
                initial_gate_failure='archive lookup omitted Cargo tmp-crate directory'))
            if not identical:
                raise RuntimeError('publish dry-run archive differs from exact tested candidate')
    except BaseException as error:
        failure = repr(error)
    end_hashes = source_hashes()
    end_head = git('rev-parse', 'HEAD')
    integrity = start_head == end_head and start_hashes == end_hashes
    write_json(out / 'source-after.json', dict(commit=end_head, files=end_hashes))
    write_json(out / 'summary.json', dict(stage=args.stage, status='passed' if not failure and
        integrity else 'failed', failure=failure, commit=start_head,
        source_hashes_unchanged=integrity, build_jobs=2, debug_info=0))
    if failure or not integrity:
        raise SystemExit(failure or 'tracked source changed during gate')


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    main()
