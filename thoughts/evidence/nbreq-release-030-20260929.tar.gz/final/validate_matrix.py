"""Validate downloaded 0.3.0 GitHub evidence without networking, Cargo, or audits.

Run separately for candidate, published, and CI after github_release.py has
saved run.json, jobs.json, artifacts.json, logs.zip, and every artifact ZIP.
The validator does not extract ZIPs; selected locks are copied only after all
receipts have passed. A later job can scan those exact bytes with a fresh DB.
"""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tomllib
import zipfile


ROOT = Path("C:/User/projects/nbreq")
LAB = Path(__file__).resolve().parent
REGISTRY = "registry+https://github.com/rust-lang/crates.io-index"
VERSION = "0.3.0"
HELPERS = {
    "nbreq-darwin": ["0.1.0", "31d7a69844b990331f85dc497f14d0b6a08f8ceaee402e7c6aa19919f3e3c839"],
    "nbreq-winpoll": ["0.1.1", "9e4fc64245514209beb6e3feccb4b980e1c259546a9e07543e3529e1d7053696"],
}
MODES = ("default", "native", "minimal", "test-support", "bundled-roots")
REGISTRY_NAMES = (
    "Ubuntu stable", "Ubuntu MSRV", "Windows stable", "Windows MSRV",
    "Intel Mac stable", "Intel Mac MSRV", "ARM Mac stable", "ARM Mac MSRV",
)
CI_NAMES = (
    "Ubuntu stable", "Windows stable", "Windows MSRV 1.85", "Ubuntu MSRV 1.85",
    "macOS 15 Intel stable", "macOS 15 Intel MSRV 1.85",
    "macOS 15 Apple Silicon stable", "macOS 15 Apple Silicon MSRV 1.85",
)
V030 = b"test v030::optional_timeout_api_and_stream_conversion_work_for_consumers ... ok"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_file(source, name):
    require(re.fullmatch(r"[0-9a-f]{40}", source) is not None, "invalid source SHA")
    require(".." not in PurePosixPath(name).parts and not name.startswith("/"), "unsafe source path")
    return subprocess.check_output(
        ["git", "show", source + ":" + name], cwd=ROOT, timeout=30
    )


def source_hash_matches(source, name, expected):
    data = source_file(source, name)
    # The checkout may have Windows CRLF while git show exposes committed LF.
    require(expected in (sha(data), sha(data.replace(b"\n", b"\r\n"))),
            "consumer source mismatch: " + name)


def consumer_test_sources(source):
    names = subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", source, "--",
         "tools/release-consumer/src", "tools/release-consumer/probes"],
        cwd=ROOT, timeout=30,
    ).decode("utf-8").splitlines()
    return {name.removeprefix("tools/release-consumer/") for name in names
            if name.endswith(".rs")}


def json_bytes(data, name):
    try:
        return json.loads(data)
    except (ValueError, UnicodeDecodeError) as error:
        raise ValueError("invalid JSON: " + name) from error


def safe_zip(path, expected_digest=None):
    raw = path.read_bytes()
    require(len(raw) <= 128 * 1024 * 1024, "oversized ZIP: " + str(path))
    digest = sha(raw)
    if expected_digest is not None:
        require(expected_digest == "sha256:" + digest, "GitHub artifact digest mismatch: " + str(path))
    archive = zipfile.ZipFile(path)
    members = {}
    inventory = []
    size_total = 0
    for info in archive.infolist():
        name = info.filename
        posix = PurePosixPath(name)
        require(not info.is_dir(), "unexpected ZIP directory: " + name)
        require(not posix.is_absolute() and name == posix.as_posix() and
                len(posix.parts) >= 1 and all(part not in ("", ".", "..") for part in posix.parts) and
                not any("\\" in part or ":" in part or any(ord(c) < 32 for c in part)
                        for part in posix.parts), "unsafe ZIP path: " + name)
        require(name.casefold() not in members, "duplicate ZIP path: " + name)
        require(not (info.flag_bits & 1), "encrypted ZIP entry: " + name)
        kind = (info.external_attr >> 16) & 0o170000
        require(kind in (0, stat.S_IFREG), "nonregular ZIP entry: " + name)
        require(info.file_size <= 16 * 1024 * 1024, "oversized ZIP member: " + name)
        size_total += info.file_size
        require(size_total <= 128 * 1024 * 1024, "oversized expanded ZIP: " + str(path))
        data = archive.read(info)
        require(len(data) == info.file_size, "ZIP size mismatch: " + name)
        members[name.casefold()] = (name, data)
        inventory.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    return digest, members, inventory


def member(members, name):
    entry = members.get(name.casefold())
    require(entry is not None and entry[0] == name, "missing ZIP member: " + name)
    return entry[1]


def prefix_of(members, suffix):
    matches = [name[:-len(suffix)] for name, _ in members.values() if name.endswith(suffix)]
    require(len(matches) == 1, "expected one ZIP " + suffix)
    return matches[0]


def collect_lock(locks, data, origin):
    digest = sha(data)
    parsed = tomllib.loads(data.decode("utf-8"))
    require(parsed.get("package"), "empty Cargo.lock: " + origin)
    if digest in locks:
        require(locks[digest]["data"] == data, "lock SHA collision")
        locks[digest]["origins"].append(origin)
    else:
        locks[digest] = dict(data=data, origins=[origin])
    return digest, parsed


def package_identity_list(lock_bytes):
    packages = tomllib.loads(lock_bytes.decode("utf-8"))["package"]
    return [{key: package[key] for key in ("name", "version", "source", "checksum")
             if key in package} for package in packages]


def verify_policy(members, prefix, label, steps, locks, origin):
    policy = json_bytes(member(members, prefix + label + "/consumer-policy.json"), label)
    initial = member(members, prefix + label + "/Cargo.initial.lock")
    selected = member(members, prefix + label + "/Cargo.lock")
    require(policy["status"] == "selected", "unselected consumer lock: " + label)
    require(policy["initial"]["sha256"] == sha(initial), "initial lock mismatch: " + label)
    require(policy["selected"]["sha256"] == sha(selected), "selected lock mismatch: " + label)
    initial_packages = package_identity_list(initial)
    selected_packages = package_identity_list(selected)
    require(policy["initial"]["packages"] == initial_packages and
            policy["selected"]["packages"] == selected_packages,
            "policy package lists differ from actual locks: " + label)
    before = {json.dumps(package, sort_keys=True) for package in initial_packages}
    after = {json.dumps(package, sort_keys=True) for package in selected_packages}
    removed = [json.loads(package) for package in sorted(before - after)]
    added = [json.loads(package) for package in sorted(after - before)]
    require(policy["removed"] == removed and policy["added"] == added,
            "policy lock delta differs from actual locks: " + label)
    release = re.search(r"^release: (\d+)\.(\d+)\.(\d+)", policy["rustc"], re.M)
    require(release is not None, "missing policy compiler: " + label)
    version = tuple(map(int, release.groups()))
    require((label.startswith("1.85.0-") and version == (1, 85, 0)) or
            (label.startswith("stable-") and version >= (1, 87, 0)),
            "compiler does not match consumer matrix label: " + label)
    if version < (1, 87, 0):
        require(policy["route"] == "compatibility-selected" and
                policy["command"][-4:] == ["-p", "yoke-derive", "--precise", "0.8.2"],
                "MSRV lock policy mismatch: " + label)
        selected_yoke = [p for p in policy["selected"]["packages"] if p["name"] == "yoke-derive"]
        require(len(selected_yoke) == 1 and selected_yoke[0]["version"] == "0.8.2",
                "MSRV yoke-derive mismatch: " + label)
        require({p["name"] for p in removed + added} <=
                {"yoke-derive", "synstructure"}, "unrelated MSRV lock changes: " + label)
        require(any(s["label"] == label + "-compatibility-lock" and s["passed"] for s in steps),
                "missing MSRV selection command: " + label)
    else:
        require(policy["route"] == "fresh" and policy["command"] is None and
                sha(initial) == sha(selected), "fresh graph was modified: " + label)
    digest, parsed = collect_lock(locks, selected, origin + "/" + label)
    return policy, digest, parsed


def verify_modes(members, prefix, label, steps):
    positive = negative = v030 = 0
    by_label = {s["label"]: s for s in steps}
    require(len(by_label) == len(steps), "duplicate command labels")
    for mode in MODES:
        test_label = label + "-" + mode
        require(by_label[test_label]["passed"] and by_label[test_label]["exit_code"] == 0,
                "consumer mode failed: " + test_label)
        log = member(members, prefix + test_label + ".log")
        counts = re.findall(rb"test result: ok\. (\d+) passed; 0 failed", log)
        require(len(counts) == 1 and int(counts[0]) > 0, "invalid consumer count: " + test_label)
        require(log.count(V030) == 1, "0.3 optional-timeout test missing: " + test_label)
        if mode == "bundled-roots":
            require(b"v021::bundled_roots_policy_is_explicit ... ok" in log,
                    "bundled root test missing: " + test_label)
        positive += int(counts[0])
        v030 += 1
    for suffix in ("resolver-absent", "testing-absent"):
        test_label = label + "-" + suffix
        require(by_label[test_label]["passed"] and by_label[test_label]["exit_code"] == 101 and
                b"unresolved import" in member(members, prefix + test_label + ".log"),
                "negative feature probe failed: " + test_label)
        negative += 1
    return positive, negative, v030


def verify_examples(members, prefix):
    examples = json_bytes(member(members, prefix + "examples/results.json"), "examples")
    summary = json_bytes(member(members, prefix + "examples/summary.json"), "example summary")
    require(summary["status"] == "passed" and summary["executions"] == 18 and
            summary["local_only"], "example summary mismatch")
    require(len(examples) == 18 and all(e["passed"] for e in examples),
            "example execution failures")
    require(all(e["exit_code"] == (1 if e["label"] == "response-limit-failure" else 0)
                for e in examples), "example exit classification mismatch")
    labels = [e["label"] for e in examples]
    require(len(set(labels)) == 18 and "C04-tcp-tls" in labels and
            "C05-tcp-starttls" in labels, "example labels missing")
    return 18


def verify_hosted(hosted, mode, source, expected_names):
    run = json_bytes((hosted / "run.json").read_bytes(), "run.json")
    jobs = json_bytes((hosted / "jobs.json").read_bytes(), "jobs.json")
    artifacts = json_bytes((hosted / "artifacts.json").read_bytes(), "artifacts.json")
    workflow = "ci.yml" if mode == "ci" else "registry-release.yml"
    require(run["head_sha"] == source and run["status"] == "completed" and
            run["conclusion"] == "success" and run["path"] == ".github/workflows/" + workflow and
            run["head_branch"] == "main" and
            (run["event"] == "workflow_dispatch" if mode != "ci" else
             run["event"] in ("push", "workflow_dispatch")),
            "run/source identity or conclusion mismatch")
    require(len(jobs) == len(expected_names) and len({j["name"] for j in jobs}) == len(jobs),
            "unexpected job count or duplicates")
    require({j["name"] for j in jobs} == set(expected_names), "unexpected job matrix")
    for job in jobs:
        require(job["run_id"] == run["id"] and job["head_sha"] == source and
                job["status"] == "completed" and job["conclusion"] == "success",
                "job run/source/conclusion mismatch: " + job["name"])
    require(len(artifacts) == (9 if mode == "ci" else 8), "artifact count mismatch")
    require(len({a["name"] for a in artifacts}) == len(artifacts), "duplicate artifact name")
    for artifact in artifacts:
        require(not artifact["expired"] and artifact["workflow_run"]["id"] == run["id"] and
                artifact["workflow_run"]["head_sha"] == source,
                "artifact run identity or expiry mismatch")
    return run, jobs, artifacts


def verify_platform(name, platform, machine):
    if "Ubuntu" in name:
        require(platform.startswith("Linux-") and machine == "x86_64",
                "Ubuntu artifact platform mismatch: " + name)
    elif "Windows" in name:
        require(platform.startswith("Windows-") and machine == "AMD64",
                "Windows artifact platform mismatch: " + name)
    elif "Intel Mac" in name or "macOS 15 Intel" in name:
        require(platform.startswith("macOS-") and machine == "x86_64",
                "Intel macOS artifact platform mismatch: " + name)
    elif "ARM Mac" in name or "Apple Silicon" in name:
        require(platform.startswith("macOS-") and machine == "arm64",
                "ARM macOS artifact platform mismatch: " + name)
    else:
        raise ValueError("unrecognized artifact platform: " + name)


def registry_artifact(members, mode, source, package_sha, locks, artifact_name):
    prefix = prefix_of(members, "inputs.json")
    inputs = json_bytes(member(members, prefix + "inputs.json"), "inputs")
    result = json_bytes(member(members, prefix + "result.json"), "result")
    steps = json_bytes(member(members, prefix + "steps.json"), "steps")
    host_archive_sha = inputs["archive_sha256"]
    require(re.fullmatch(r"[0-9a-f]{64}", host_archive_sha) is not None and
            inputs["mode"] == mode and
            inputs["package_vcs"]["git"]["sha1"] == source and
            not inputs["package_vcs"]["git"].get("dirty", False),
            "candidate package/source identity mismatch: " + artifact_name)
    require(result["status"] == "passed" and result["archive_sha256"] == host_archive_sha and
            result["steps"] == len(steps) and all(s["passed"] for s in steps),
            "consumer command failure: " + artifact_name)
    if mode == "published":
        require(host_archive_sha == package_sha, "published archive differs across hosts")
    require(result["registry_only"] == (mode == "published") and
            result["support_from_registry"], "registry support identity mismatch")
    require(len(result["cases"]) == 2 and len(inputs["toolchains"]) == 1,
            "consumer case/toolchain count mismatch")
    require({case["label"] for case in result["cases"]} ==
            {inputs["toolchains"][0] + "-fresh", inputs["toolchains"][0] + "-mio-coexist"},
            "consumer graph labels mismatch")
    require(inputs["helper_hashes"] == HELPERS,
            "helper identities differ from the pinned published registry checksums")
    require({name.replace("\\", "/") for name in inputs["test_source_files"]} ==
            consumer_test_sources(source), "consumer test-source set incomplete")
    for name, digest in inputs["test_source_files"].items():
        source_hash_matches(source, "tools/release-consumer/" + name.replace("\\", "/"), digest)
    positive = negative = v030 = 0
    for case in result["cases"]:
        label = case["label"]
        policy, lock_sha, lock = verify_policy(members, prefix, label, steps, locks, artifact_name)
        require(case["lock_sha256"] == lock_sha and case["dependency_route"] == policy["route"] and
                case["initial_lock_sha256"] == policy["initial"]["sha256"],
                "consumer case lock identity mismatch: " + label)
        require(case["support_from_registry"] and case["registry_only"] == (mode == "published"),
                "consumer case registry flags mismatch")
        require(case["packages"]["nbreq"] ==
                dict(version=VERSION, source=REGISTRY if mode == "published" else None),
                "root package identity mismatch: " + label)
        require(case["packages"]["webpki-roots"]["source"] == REGISTRY,
                "Mozilla roots not from registry: " + label)
        for helper, (version, checksum) in inputs["helper_hashes"].items():
            require(case["packages"][helper] == dict(version=version, source=REGISTRY),
                    "helper metadata mismatch: " + helper)
            entries = [p for p in lock["package"] if p["name"] == helper]
            require(len(entries) == 1 and entries[0]["version"] == version and
                    entries[0]["source"] == REGISTRY and entries[0]["checksum"] == checksum,
                    "helper published checksum mismatch: " + helper)
        if mode == "published":
            roots = [p for p in lock["package"] if p["name"] == "nbreq"]
            require(len(roots) == 1 and roots[0]["source"] == REGISTRY and
                    roots[0]["checksum"] == host_archive_sha, "published root checksum mismatch")
        p, n, v = verify_modes(members, prefix, label, steps)
        positive += p
        negative += n
        v030 += v
    example_lock = member(members, prefix + "package-examples-Cargo.lock")
    require(sha(example_lock) == inputs["example_lock_sha256"] and
            inputs["example_dependency_route"] ==
            "unchanged packaged Cargo.lock with --locked; not a fresh consumer graph",
            "packaged example lock identity mismatch")
    collect_lock(locks, example_lock, artifact_name + "/packaged-examples")
    examples = verify_examples(members, prefix)
    require(len(steps) == (25 if "MSRV" in artifact_name else 23),
            "unexpected registry command count: " + artifact_name)
    verify_platform(artifact_name, inputs["platform"], inputs["machine"])
    return dict(platform=inputs["platform"], machine=inputs["machine"],
                toolchains=inputs["toolchains"], positive=positive, negative=negative,
                v030=v030, examples=examples,
                host_reported_tested_archive_sha256=host_archive_sha)


def ci_artifact(members, source, locks, artifact_name):
    prefix = prefix_of(members, "nbreq-consumers/inputs.json")
    inputs = json_bytes(member(members, prefix + "nbreq-consumers/inputs.json"), "CI inputs")
    result = json_bytes(member(members, prefix + "nbreq-consumers/result.json"), "CI result")
    steps = json_bytes(member(members, prefix + "nbreq-consumers/steps.json"), "CI steps")
    require(inputs["commit"] == source and result["status"] == "passed" and
            result["steps"] == len(steps) and result["cases"] == 2 and
            not result["registry_only"] and all(s["passed"] for s in steps),
            "CI consumer/source failure: " + artifact_name)
    for name, digest in inputs["files"].items():
        source_hash_matches(source, name.replace("\\", "/"), digest)
    require(len(inputs["toolchains"]) == 1, "CI compiler count mismatch")
    positive = negative = v030 = 0
    for flavor in ("fresh", "mio-coexist"):
        label = inputs["toolchains"][0] + "-" + flavor
        policy, lock_sha, lock = verify_policy(
            members, prefix + "nbreq-consumers/", label, steps, locks, artifact_name
        )
        versions = json_bytes(member(members, prefix + "nbreq-consumers/" + label + "/versions.json"),
                              "CI versions")
        require(versions["nbreq"] == VERSION and versions["webpki-roots"] and
                (flavor != "mio-coexist" or versions["mio"] == "1.2.3"),
                "CI dependency identity mismatch")
        require(any(p["name"] == "nbreq" and p["version"] == VERSION for p in lock["package"]),
                "CI root lock identity mismatch")
        p, n, v = verify_modes(members, prefix + "nbreq-consumers/", label, steps)
        positive += p
        negative += n
        v030 += v
    require(len(steps) == (23 if inputs["toolchains"][0] == "1.85.0" else 21),
            "unexpected CI consumer command count")
    examples = json_bytes(member(members, prefix + "nbreq-examples/results.json"), "CI examples")
    example_summary = json_bytes(member(members, prefix + "nbreq-examples/summary.json"),
                                 "CI example summary")
    require(example_summary["status"] == "passed" and example_summary["executions"] == 18 and
            example_summary["local_only"], "CI example summary mismatch")
    require(len(examples) == 18 and all(e["passed"] for e in examples),
            "CI example failures")
    require(all(e["exit_code"] == (1 if e["label"] == "response-limit-failure" else 0)
                for e in examples), "CI example classification mismatch")
    verify_platform(artifact_name, inputs["platform"], inputs["machine"])
    return dict(platform=inputs["platform"], machine=inputs["machine"],
                toolchains=inputs["toolchains"], positive=positive, negative=negative,
                v030=v030, examples=18)


def ci_run_logs(hosted, jobs, source, locks):
    log_sha, members, inventory = safe_zip(hosted / "logs.zip")
    for job in jobs:
        name = job["name"]
        if name.startswith("Verify ("):
            for suffix, phrase in (
                ("Run complete offline verifier.txt", b"NBReq verification complete: all 30 steps passed"),
                ("Build and run examples against local fixtures.txt", b"Example checks passed: 18 executions"),
            ):
                matches = [entry for entry, _ in members.values()
                           if entry.startswith(name + "/") and entry.endswith(suffix)]
                require(len(matches) == 1 and phrase in member(members, matches[0]),
                        "CI full verifier or example run missing: " + name)
        elif name == "Component and dependency licenses":
            require(any(s["name"] == "Reject license-report drift" and
                        s["conclusion"] == "success" for s in job["steps"]),
                    "license report comparison missing")
        elif name == "RustSec advisory scan":
            require(any(s["name"] == "Scan exact lock graph" and
                        s["conclusion"] == "success" for s in job["steps"]),
                    "hosted RustSec scan missing")
    root_lock = source_file(source, "Cargo.lock")
    digest, _ = collect_lock(locks, root_lock, "CI/source-Cargo.lock-and-examples")
    return dict(sha256=log_sha, entries=inventory, root_lock_sha256=digest)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("candidate", "published", "ci"), required=True)
    parser.add_argument("--source", required=True, help="Exact expected 40-hex release commit")
    parser.add_argument("--package-sha", help="Exact root .crate SHA256, required for registry modes")
    parser.add_argument("--hosted", type=Path, help="Downloaded evidence directory")
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.source) is not None, "source must be 40-hex SHA")
    if args.mode == "ci":
        require(args.package_sha is None, "CI does not take a package SHA")
    else:
        require(args.package_sha is not None and
                re.fullmatch(r"[0-9a-f]{64}", args.package_sha) is not None,
                "registry mode needs exact .crate SHA256")
        canonical = json_bytes((LAB / "authoritative-package/inventory.json").read_bytes(),
                               "authoritative package")
        archive = Path(canonical["path"])
        require(canonical["commit"] == args.source and canonical["sha256"] == args.package_sha and
                canonical["vcs"]["git"]["sha1"] == args.source and archive.is_file() and
                sha(archive.read_bytes()) == args.package_sha,
                "local authoritative package identity mismatch")
    hosted = (args.hosted or LAB / ("hosted-ci" if args.mode == "ci" else "hosted-" + args.mode)).resolve()
    expected_names = (["Verify (" + name + ")" for name in CI_NAMES] +
                      ["RustSec advisory scan", "Component and dependency licenses"]
                      if args.mode == "ci" else
                      ["Registry (" + name + ")" for name in REGISTRY_NAMES])
    run, jobs, artifacts = verify_hosted(hosted, args.mode, args.source, expected_names)
    expected_artifacts = ({"consumers-" + name for name in CI_NAMES} | {"advisory-evidence"}
                          if args.mode == "ci" else
                          {"registry-" + args.mode + "-" + name for name in REGISTRY_NAMES})
    require({a["name"] for a in artifacts} == expected_artifacts, "artifact matrix mismatch")
    locks, inventory, records = {}, [], []
    positive = negative = v030 = examples = 0
    advisory = None
    for artifact in artifacts:
        path = hosted / ("artifact-" + str(artifact["id"]) + ".zip")
        digest, members, files = safe_zip(path, artifact["digest"])
        inventory.append(dict(name=artifact["name"], artifact_id=artifact["id"],
                              sha256=digest, files=files))
        if artifact["name"] == "advisory-evidence":
            report = json_bytes(member(members, "cargo-audit.json"), "hosted advisory")
            require(not report["vulnerabilities"]["found"] and not report["warnings"],
                    "hosted RustSec findings")
            advisory = member(members, "advisory-db.txt").decode("utf-8")
            require(re.search(r"^cargo-audit-audit 0\.22\.2$", advisory, re.M) and
                    re.search(r"^[0-9a-f]{40} ", advisory, re.M) and
                    report["database"]["last-commit"] in advisory,
                    "hosted advisory DB/tool identity missing")
            continue
        if args.mode == "ci":
            record = ci_artifact(members, args.source, locks, artifact["name"])
        else:
            record = registry_artifact(members, args.mode, args.source, args.package_sha,
                                       locks, artifact["name"])
        require(record["toolchains"] == (["1.85.0"] if "MSRV" in artifact["name"] else ["stable"]),
                "artifact compiler does not match its matrix name")
        record.update(name=artifact["name"], artifact_sha256=digest)
        records.append(record)
        positive += record["positive"]
        negative += record["negative"]
        v030 += record["v030"]
        examples += record["examples"]
    require(len(records) == 8 and positive == 752 and negative == 32 and
            v030 == 80 and examples == 144,
            f"unexpected matrix counts: positive={positive}, negative={negative}, "
            f"v030={v030}, examples={examples}")
    if args.mode == "ci":
        require(advisory is not None, "CI advisory artifact missing")
        logs = ci_run_logs(hosted, jobs, args.source, locks)
        require(logs["root_lock_sha256"] in advisory,
                "hosted RustSec scanned a different root lock")
    else:
        logs = None
    # Delay writes until the entire evidence set has passed. Never overwrite a
    # prior receipt, and keep every selected lock's exact bytes for later audit.
    lock_dir = LAB / (args.mode + "-selected-locks")
    lock_dir.mkdir(exist_ok=False)
    lock_records = []
    for digest, item in sorted(locks.items()):
        (lock_dir / (digest + ".lock")).write_bytes(item["data"])
        lock_records.append(dict(sha256=digest, origins=item["origins"]))
    (lock_dir / "index.json").write_text(json.dumps(lock_records, indent=2) + "\n", encoding="utf-8")
    (LAB / (args.mode + "-artifact-inventory.json")).write_text(
        json.dumps(dict(run_id=run["id"], artifacts=inventory, logs=logs), indent=2) + "\n",
        encoding="utf-8",
    )
    receipt = dict(status="passed", mode=args.mode, source=args.source, run_id=run["id"],
                   run_attempt=run["run_attempt"], run_url=run["html_url"],
                   canonical_package_sha256=args.package_sha, jobs=len(jobs), consumer_graphs=16,
                   positive_tests=positive, negative_probes=negative, v030_passes=v030,
                   examples=examples, selected_lock_count=len(locks),
                   selected_locks=lock_records, artifacts=records,
                   host_archive_identity="reported by each hosted test receipt; archive bytes are not uploaded",
                   audit_status="pending fresh advisory database scan")
    (LAB / (args.mode + "-matrix-verified.json")).write_text(
        json.dumps(receipt, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({k: v for k, v in receipt.items()
                      if k not in ("artifacts", "selected_locks")}, indent=2))


if __name__ == "__main__":
    main()
