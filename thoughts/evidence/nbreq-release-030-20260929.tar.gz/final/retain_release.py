"""Plan, then retain reviewed 0.3.0 release evidence with exact file read-back.

`plan` writes only an ignored lab inventory. `archive` requires the approved
SHA256 of that plan and creates the tracked evidence archive and compact index.
No source checkout, build/cache tree, advisory DB checkout, or private bridge
directory is traversed. Run only after the final local and hosted gates finish.
"""

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import zipfile


ROOT = Path("C:/User/projects/nbreq")
PARENT = ROOT / "target/release-030-20260929"
FINAL = PARENT / "attempt-2"
EXAMPLES = ROOT / "target/example-defaults-20260929"
EVIDENCE = ROOT / "thoughts/evidence"
ARCHIVE = EVIDENCE / "nbreq-release-030-20260929.tar.gz"
PUBLIC_INDEX = EVIDENCE / "nbreq_release_030_artifacts.json"
PLAN = FINAL / "retention-plan.json"
MAX_FILE = 128 * 1024 * 1024
MAX_NESTED_TOTAL = 256 * 1024 * 1024
ALLOWED_SUFFIXES = (".json", ".jsonl", ".log", ".txt", ".md", ".py", ".rs", ".diff",
                    ".toml", ".lock", ".zip", ".crate")
DENIED_COMPONENTS = {"build", "target", "cache", "__pycache__", "unpacked",
                     "advisory-db", ".git", "node_modules", "tmp", "temp"}
PARENT_GROUPS = {"verify", "verify-retry", "focused", "package", "package-candidate",
                 "packaged-tests", "packaged-tests-retry", "workspace-audit",
                 "authoritative-package", "hosted-candidate", "hosted-ci",
                 "candidate-selected-locks"}
FINAL_GROUPS = {"verify", "verify-retry", "focused", "http-focused", "http-paced",
                "http-paced-corrected", "http-stall", "http-stall-corrected",
                "package", "package-candidate",
                "packaged-tests", "packaged-tests-retry", "registry", "registry-candidate",
                "publish-dry-run", "publish-dry-run-identity",
                "publish-dry-run-final-identity", "authoritative-package",
                "hosted-candidate", "hosted-ci",
                "hosted-published", "candidate-selected-locks", "ci-selected-locks",
                "published-selected-locks", "selected-lock-audit",
                "selected-lock-audit-final", "workspace-audit"}
PARENT_FILES = {"release_gate.py", "github_release.py", "owned_command.py",
                "audit_workspace.py", "inspect_failed_jobs.py", "validate_matrix.py",
                "scan_selected_locks.py", "candidate-matrix-verified.json",
                "candidate-artifact-inventory.json"}
FINAL_FILES = {"release_gate.py", "github_release.py", "owned_command.py",
               "validate_matrix.py", "scan_selected_locks.py", "retain_release.py",
               "interrupted-verify.json", "rejected-paced-control.json",
               "http-composition-diagnostic.rs", "http-composition-diagnostic.diff",
               "http-composition-diagnostic-corrected.rs",
               "http-composition-diagnostic-corrected.diff",
               "http-composition-accepted.rs", "http-composition-accepted.diff",
               "final-review.json",
               "candidate-matrix-verified.json", "candidate-artifact-inventory.json",
               "ci-matrix-verified.json", "ci-artifact-inventory.json",
               "published-matrix-verified.json", "published-artifact-inventory.json"}
EXAMPLE_GROUPS = {"checks", "uncommented"}
EXAMPLE_FILES = {"verify.py", "update.py"}
SECRET_SHAPES = (
    re.compile(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})"),
    re.compile(rb"AKIA[A-Z0-9]{16}"),
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"(?i:authorization)\s*[:=]\s*(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{16,}"),
    re.compile(rb"(?:xox[baprs]-[A-Za-z0-9-]{20,}|sk-[A-Za-z0-9_-]{30,})"),
)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def git_blobs(commit):
    """Read every tracked blob from an exact commit without using working-tree state."""
    listing = subprocess.run(["git", "-C", str(ROOT), "ls-tree", "-r", "-z", commit],
                             check=True, stdout=subprocess.PIPE).stdout
    entries = []
    for row in listing.split(b"\0"):
        if not row:
            continue
        metadata, raw_path = row.split(b"\t", 1)
        mode, kind, object_id = metadata.split(b" ")
        require(kind == b"blob" and mode in (b"100644", b"100755"),
                "unexpected tracked object in final commit")
        entries.append((raw_path.decode("utf-8"), object_id))
    response = subprocess.run(["git", "-C", str(ROOT), "cat-file", "--batch"],
                              input=b"".join(object_id + b"\n" for _, object_id in entries),
                              check=True, stdout=subprocess.PIPE).stdout
    cursor = 0
    blobs = {}
    for path, object_id in entries:
        end = response.index(b"\n", cursor)
        returned_id, kind, raw_size = response[cursor:end].split(b" ")
        require(returned_id == object_id and kind == b"blob", "Git blob identity mismatch")
        size = int(raw_size)
        cursor = end + 1
        data = response[cursor:cursor + size]
        require(len(data) == size and response[cursor + size:cursor + size + 1] == b"\n",
                "Git blob framing mismatch")
        cursor += size + 1
        require(path not in blobs, "duplicate Git path")
        blobs[path] = data
    require(cursor == len(response), "unexpected Git batch trailing bytes")
    return blobs


def bind_precommit_verifier(source):
    before = read_json(FINAL / "verify-retry/source-before.json")
    after = read_json(FINAL / "verify-retry/source-after.json")
    require(before == after and len(before["files"]) == 473 and
            before["commit"] == "ae114cf7d97c0764a9465d7399a2014191bedf67",
            "precommit verifier source snapshot changed")
    blobs = git_blobs(source)
    require(set(blobs) == set(before["files"]),
            "precommit verifier/final commit tracked file sets differ")
    allowed_plan_edit = "thoughts/nbreq_030_release_plan.md"
    differing = []
    for path, old_hash in before["files"].items():
        blob = blobs[path]
        lf = blob.replace(b"\r\n", b"\n")
        acceptable_hashes = {sha(blob), sha(lf), sha(lf.replace(b"\n", b"\r\n"))}
        if old_hash not in acceptable_hashes:
            # A checkout can contain mixed line endings. Its exact raw hash
            # must still match the verifier snapshot before normalization.
            checkout = ROOT / path
            checkout_bytes = checkout.read_bytes()
            if not (sha(checkout_bytes) == old_hash and
                    checkout_bytes.replace(b"\r\n", b"\n") == lf):
                differing.append(path)
    require(set(differing).issubset({allowed_plan_edit}),
            "precommit verifier differs from final tracked source outside release plan: " +
            ", ".join(differing[:10]))
    return dict(precommit=before["commit"], tracked_files=len(blobs),
                permitted_postverify_plan_edits=differing)


def check_name(name):
    path = PurePosixPath(name)
    require(name == path.as_posix() and not path.is_absolute() and len(path.parts) > 0 and
            all(part not in ("", ".", "..") and "\\" not in part and ":" not in part and
                not any(ord(char) < 32 for char in part) for part in path.parts),
            "unsafe archive member: " + name)
    return path


def scan_text(name, data):
    for pattern in SECRET_SHAPES:
        require(pattern.search(data) is None, "credential-shaped content: " + name)


def nested_inventory(name, data):
    if not (name.endswith(".zip") or name.endswith(".crate") or name.endswith(".tar.gz")):
        scan_text(name, data)
        return None
    members = []
    seen = set()
    expanded = 0
    if name.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            require(len(archive.infolist()) <= 20000, "too many ZIP entries: " + name)
            for item in archive.infolist():
                require(not item.is_dir() and not (item.flag_bits & 1),
                        "directory/encrypted nested ZIP entry: " + name)
                path = check_name(item.filename)
                kind = (item.external_attr >> 16) & 0o170000
                require(kind in (0, stat.S_IFREG), "nonregular nested ZIP member: " + name)
                require(item.file_size <= MAX_FILE, "oversized nested ZIP member: " + name)
                nested = archive.read(item)
                require(len(nested) == item.file_size, "nested ZIP size mismatch: " + name)
                require(path.as_posix().casefold() not in seen, "duplicate nested ZIP member: " + name)
                seen.add(path.as_posix().casefold())
                expanded += len(nested)
                require(expanded <= MAX_NESTED_TOTAL, "oversized nested ZIP: " + name)
                require(not item.filename.endswith((".zip", ".gz", ".crate")),
                        "unexpected archive inside ZIP: " + name + "/" + item.filename)
                scan_text(name + "/" + item.filename, nested)
                members.append(dict(path=item.filename, bytes=len(nested), sha256=sha(nested)))
    else:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
            tar_members = archive.getmembers()
            require(len(tar_members) <= 20000, "too many nested TAR entries: " + name)
            for item in tar_members:
                require(item.isfile(), "nonregular nested TAR member: " + name)
                path = check_name(item.name)
                require(item.size <= MAX_FILE, "oversized nested TAR member: " + name)
                nested = archive.extractfile(item).read()
                require(len(nested) == item.size, "nested TAR size mismatch: " + name)
                require(path.as_posix().casefold() not in seen, "duplicate nested TAR member: " + name)
                seen.add(path.as_posix().casefold())
                expanded += len(nested)
                require(expanded <= MAX_NESTED_TOTAL, "oversized nested TAR: " + name)
                require(not item.name.endswith((".zip", ".gz", ".crate")),
                        "unexpected archive inside TAR: " + name + "/" + item.name)
                scan_text(name + "/" + item.name, nested)
                members.append(dict(path=item.name, bytes=len(nested), sha256=sha(nested)))
    return members


def add_file(files, source, name):
    require(not source.is_symlink(), "symlink evidence source: " + name)
    source = source.resolve(strict=True)
    require(source.is_file(), "not a regular evidence file: " + name)
    require(source.is_relative_to(ROOT), "evidence escaped workspace: " + name)
    require(name not in files, "duplicate evidence path: " + name)
    check_name(name)
    require(source.stat().st_size <= MAX_FILE, "oversized evidence file: " + name)
    files[name] = source


def group_files(files, base, label, groups, singles):
    for relative in sorted(singles):
        path = base / relative
        if path.is_file():
            add_file(files, path, label + "/" + relative.replace("\\", "/"))
    for group in sorted(groups):
        folder = base / group
        if not folder.is_dir():
            continue
        require(not folder.is_symlink(), "symlink evidence group: " + str(folder))
        for current, directories, filenames in os.walk(folder, followlinks=False):
            current_path = Path(current)
            directories[:] = [name for name in directories
                              if name.lower() not in DENIED_COMPONENTS and
                              not name.startswith(".") and not (current_path / name).is_symlink()]
            for filename in filenames:
                path = current_path / filename
                if filename.startswith(".") or not filename.lower().endswith(ALLOWED_SUFFIXES):
                    continue
                relative = path.relative_to(base)
                add_file(files, path, label + "/" + relative.as_posix())


def collect(source, package_sha):
    first_candidate = read_json(PARENT / "candidate-matrix-verified.json")
    first_ci = read_json(PARENT / "hosted-ci/run.json")
    require(first_candidate["status"] == "passed" and
            first_candidate["source"] == first_ci["head_sha"] and
            first_ci["status"] == "completed" and first_ci["conclusion"] == "failure",
            "first candidate/CI outcome classification mismatch")
    verify = read_json(FINAL / "verify-retry/summary.json")
    require(verify["status"] == "passed" and verify["source_hashes_unchanged"],
            "precommit full verifier incomplete or source changed during test")
    verifier_binding = bind_precommit_verifier(source)
    require(verify["commit"] == verifier_binding["precommit"],
            "precommit verifier receipt and source snapshot disagree")
    for stage in ("package", "registry", "publish-dry-run-final-identity"):
        outcome = read_json(FINAL / stage / "summary.json")
        require(outcome["status"] == "passed" and outcome["commit"] == source and
                outcome["source_hashes_unchanged"],
                "final local stage incomplete or source changed: " + stage)
    packaged_passes = []
    for stage in ("packaged-tests", "packaged-tests-retry"):
        summary_path = FINAL / stage / "summary.json"
        if summary_path.is_file() and read_json(summary_path)["status"] == "passed":
            packaged_passes.append(stage)
    require(len(packaged_passes) == 1, "expected one accepted final packaged-test stage")
    packaged_stage = packaged_passes[0]
    packaged = read_json(FINAL / packaged_stage / "summary.json")
    require(packaged["commit"] == source and packaged["source_hashes_unchanged"],
            "final packaged tests not bound to release source")
    require("NBReq verification complete: all 30 steps passed" in
            (FINAL / "verify-retry/full-verifier.log").read_text(encoding="utf-8"),
            "final full verifier did not complete 30 steps")
    for compiler in ("stable", "1.85.0"):
        for check in ("packaged-focused", "packaged-bundle", "packaged-shutdown",
                      "packaged-http-composition"):
            result = read_json(FINAL / packaged_stage / (compiler + "-" + check + ".result.json"))
            require(result["exit_code"] == 0,
                    "packaged verification failed: " + compiler + "/" + check)
    registry = read_json(FINAL / "registry-candidate/result.json")
    require(registry["status"] == "passed" and registry["archive_sha256"] == package_sha and
            len(registry["cases"]) == 4,
            "final local registry consumers incomplete")
    original_dry_run = FINAL / "publish-dry-run"
    intermediate = read_json(FINAL / "publish-dry-run-identity/summary.json")
    require(intermediate["status"] == "passed" and intermediate["commit"] == source,
            "intermediate dry-run identity receipt changed")
    original_summary = read_json(original_dry_run / "summary.json")
    command = read_json(original_dry_run / "publish-dry-run.result.json")
    command_log = (original_dry_run / "publish-dry-run.log").read_text(encoding="utf-8")
    expected_command = ["rustup", "run", "stable", "cargo", "publish", "--dry-run",
                        "--locked", "-p", "nbreq"]
    require(original_summary["status"] == "failed" and
            "FileNotFoundError" in original_summary["failure"] and
            original_summary["commit"] == source and
            original_summary["source_hashes_unchanged"] and
            command["argv"] == expected_command and command["exit_code"] == 0 and
            Path(command["cwd"]).resolve() == ROOT.resolve() and
            "Uploading nbreq v0.3.0" in command_log and
            "warning: aborting upload due to dry run" in command_log,
            "original publish dry-run command/failure classification mismatch")
    original_before_path = original_dry_run / "source-before.json"
    original_after_path = original_dry_run / "source-after.json"
    original_before = read_json(original_before_path)
    require(original_before == read_json(original_after_path) and
            original_before == read_json(FINAL / "package/source-before.json") and
            original_before["commit"] == source and len(original_before["files"]) == 473,
            "original publish dry-run source snapshots mismatch")
    dry_run = read_json(FINAL / "publish-dry-run-final-identity/archive-byte-identity.json")
    snapshot_receipt = dry_run["original_source_snapshots"]
    require(dry_run["identical"] and dry_run["source_commit"] == source and
            dry_run["dry_run_command"] == command and
            dry_run["initial_gate_failure"] ==
            "archive lookup omitted Cargo tmp-crate directory" and
            snapshot_receipt["identical"] and
            Path(snapshot_receipt["before_path"]).resolve() == original_before_path.resolve() and
            Path(snapshot_receipt["after_path"]).resolve() == original_after_path.resolve() and
            snapshot_receipt["before_sha256"] == sha(original_before_path.read_bytes()) and
            snapshot_receipt["after_sha256"] == sha(original_after_path.read_bytes()),
            "corrected dry-run receipt lost original command/source binding")
    expected_archives = {"canonical": FINAL / "authoritative-package/build/package/nbreq-0.3.0.crate",
                         "tmp-crate": original_dry_run / "build/package/tmp-crate/nbreq-0.3.0.crate",
                         "tmp-registry": original_dry_run / "build/package/tmp-registry/nbreq-0.3.0.crate"}
    for label, path in expected_archives.items():
        entry = dry_run["canonical"] if label == "canonical" else dry_run["generated"][label]
        require(Path(entry["path"]).resolve() == path.resolve() and
                entry["sha256"] == package_sha and entry["bytes"] == path.stat().st_size and
                sha(path.read_bytes()) == package_sha,
                "corrected publish dry-run archive mismatch: " + label)
    interruption = read_json(FINAL / "interrupted-verify.json")
    rejected = read_json(FINAL / "rejected-paced-control.json")
    require(interruption["status"] == "interrupted_before_completion" and
            not interruption["complete_30_step_result"] and
            rejected["status"] == "rejected_as_paced_evidence",
            "attempt-2 interrupted/rejected diagnostic labels missing")
    example_result = read_json(EXAMPLES / "checks/result.json")
    example_summary = read_json(EXAMPLES / "checks/examples/summary.json")
    require(example_result == dict(status="passed", uncommented_settings=53,
                                   examples=19, local_executions=18) and
            example_summary["status"] == "passed" and
            example_summary["executions"] == 18 and example_summary["local_only"] and
            len(list((EXAMPLES / "uncommented/examples").glob("[ABC]*.rs"))) == 19,
            "prior example-defaults proof incomplete")
    final_inventory = read_json(FINAL / "authoritative-package/inventory.json")
    require(final_inventory["commit"] == source and final_inventory["sha256"] == package_sha and
            final_inventory["vcs"]["git"]["sha1"] == source,
            "final canonical archive identity mismatch")
    final_archive = Path(final_inventory["path"])
    require(final_archive.resolve() ==
            (FINAL / "authoritative-package/build/package/nbreq-0.3.0.crate").resolve(),
            "final canonical archive path mismatch")
    require(sha(final_archive.read_bytes()) == package_sha,
            "final canonical archive bytes changed")
    for mode in ("candidate", "ci"):
        receipt = read_json(FINAL / (mode + "-matrix-verified.json"))
        require(receipt["status"] == "passed" and receipt["source"] == source and
                receipt["positive_tests"] == 752 and receipt["negative_probes"] == 32 and
                receipt["examples"] == 144, "final hosted matrix incomplete: " + mode)
    first_audit = read_json(FINAL / "selected-lock-audit/summary.json")
    require(first_audit["status"] == "failed" and first_audit["audited_locks"] == 0 and
            first_audit["distinct_locks"] == 10 and
            "RustSec findings/database/policy mismatch" in first_audit["failure"] and
            first_audit["advisory_database_commit"] ==
            "f23b768236fe2880e4cfa167da662cad8ca79240",
            "first audit harness-metadata failure classification mismatch")
    audit = read_json(FINAL / "selected-lock-audit-final/summary.json")
    require(audit["status"] == "passed" and audit["source"] == source and
            audit["package_sha256"] == package_sha and
            audit["audited_locks"] == audit["distinct_locks"] and
            audit["database_identity_source"] == "verified clean pinned local Git checkout" and
            audit["advisory_database_commit"] ==
            "f23b768236fe2880e4cfa167da662cad8ca79240" and
            audit["advisory_count"] == 1277,
            "final selected-lock audit incomplete")
    final_review = read_json(FINAL / "final-review.json")
    require(final_review["status"] == "passed" and final_review["source"] == source and
            final_review["canonical_package_sha256"] == package_sha and
            final_review["scope"] == "pre-release" and
            final_review["publication_authorized"] is False,
            "final independent pre-release review receipt missing or mismatched")
    files = {}
    group_files(files, PARENT, "first-attempt", PARENT_GROUPS, PARENT_FILES)
    group_files(files, FINAL, "final", FINAL_GROUPS, FINAL_FILES)
    group_files(files, EXAMPLES, "example-defaults", EXAMPLE_GROUPS, EXAMPLE_FILES)
    # These two exact package files live beneath a build directory by design;
    # no other build-tree member is retained.
    add_file(files, final_archive, "final/canonical/nbreq-0.3.0.crate")
    first_inventory = PARENT / "authoritative-package/inventory.json"
    if first_inventory.is_file():
        first = read_json(first_inventory)
        old_archive = Path(first["path"])
        require(old_archive.resolve() ==
                (PARENT / "authoritative-package/build/package/nbreq-0.3.0.crate").resolve(),
                "first-attempt canonical archive path mismatch")
        require(sha(old_archive.read_bytes()) == first["sha256"],
                "first-attempt canonical archive changed")
        add_file(files, old_archive, "first-attempt/canonical/nbreq-0.3.0.crate")
    prior_archive = EVIDENCE / "nbreq-timeout-defaults-030-20260929.tar.gz"
    require(prior_archive.is_file(), "prior timeout-defaults evidence archive missing")
    prior_reference = dict(path=str(prior_archive.relative_to(ROOT).as_posix()),
                           sha256=sha(prior_archive.read_bytes()),
                           bytes=prior_archive.stat().st_size)
    return files, prior_reference, verifier_binding, packaged_stage


def inventory(files):
    rows = []
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        rows.append(dict(path=name, source=str(path), bytes=len(data), sha256=sha(data),
                         nested=nested_inventory(name, data)))
    return rows


def plan(source, package_sha):
    require(not PLAN.exists(), "retention plan already exists")
    files, prior, verifier_binding, packaged_stage = collect(source, package_sha)
    rows = inventory(files)
    record = dict(source=source, canonical_package_sha256=package_sha,
                  prior_timeout_defaults_archive=prior,
                  precommit_verifier_binding=verifier_binding,
                  accepted_packaged_stage=packaged_stage,
                  first_attempt_candidate="passed, superseded source",
                  first_attempt_ci="failed, 9/10 jobs; retained as failure evidence",
                  original_publish_dry_run="Cargo exit 0; wrapper failed on archive path",
                  intermediate_dry_run_identity="superseded by final receipt with original source binding",
                  initial_selected_lock_audit="failed on cargo-audit JSON null local-DB commit; retained",
                  final_attempt="passed local and hosted gates with exact canonical archive",
                  files=rows, file_count=len(rows), total_source_bytes=sum(r["bytes"] for r in rows),
                  excluded="build/cache/unpacked/advisory DB/private bridge trees")
    PLAN.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(plan=str(PLAN), plan_sha256=sha(PLAN.read_bytes()),
                          files=len(rows), bytes=record["total_source_bytes"]), indent=2))


def archive(approved_plan_sha):
    require(re.fullmatch(r"[0-9a-f]{64}", approved_plan_sha) is not None,
            "archive requires approved exact plan SHA256")
    require(PLAN.is_file() and sha(PLAN.read_bytes()) == approved_plan_sha,
            "approved plan hash mismatch")
    require(not ARCHIVE.exists() and not PUBLIC_INDEX.exists(),
            "release evidence output already exists")
    record = read_json(PLAN)
    files, prior, verifier_binding, packaged_stage = collect(
        record["source"], record["canonical_package_sha256"])
    rows = inventory(files)
    require(rows == record["files"] and prior == record["prior_timeout_defaults_archive"] and
            verifier_binding == record["precommit_verifier_binding"] and
            packaged_stage == record["accepted_packaged_stage"],
            "evidence changed after plan approval")
    internal = json.dumps({key: value for key, value in record.items() if key != "files"} |
                          {"files": [{key: value for key, value in row.items() if key != "source"}
                                     for row in rows]}, indent=2).encode("utf-8") + b"\n"
    manifest_name = "retained-files.json"
    pending_archive = FINAL / "retention-pending.tar.gz"
    require(not pending_archive.exists(), "pending archive already exists")
    with pending_archive.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
            with tarfile.open(fileobj=gz, mode="w") as bundle:
                entries = ([(row["path"], files[row["path"]].read_bytes()) for row in rows]
                           + [(manifest_name, internal)])
                for name, data in entries:
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    bundle.addfile(info, io.BytesIO(data))
    expected = {row["path"]: row["sha256"] for row in rows} | {manifest_name: sha(internal)}
    with tarfile.open(pending_archive, mode="r:gz") as bundle:
        members = bundle.getmembers()
        require(len(members) == len(expected) and
                {item.name for item in members} == set(expected),
                "archive member set mismatch")
        for item in members:
            require(item.isfile() and item.name in expected and
                    sha(bundle.extractfile(item).read()) == expected[item.name],
                    "archive read-back mismatch: " + item.name)
    os.replace(pending_archive, ARCHIVE)
    external = dict(archive=ARCHIVE.name, sha256=sha(ARCHIVE.read_bytes()),
                    bytes=ARCHIVE.stat().st_size, source=record["source"],
                    canonical_package_sha256=record["canonical_package_sha256"],
                    approved_plan_sha256=approved_plan_sha, regular_members=len(expected),
                    prior_timeout_defaults_archive=prior,
                    groups={group: sum(row["path"].startswith(group + "/") for row in rows)
                            for group in ("first-attempt", "final", "example-defaults")})
    PUBLIC_INDEX.write_text(json.dumps(external, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(external, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("plan", "archive"))
    parser.add_argument("--source", help="final release commit for plan")
    parser.add_argument("--package-sha", help="final canonical .crate SHA256 for plan")
    parser.add_argument("--approved-plan-sha", help="explicitly approved plan SHA256 for archive")
    args = parser.parse_args()
    if args.mode == "plan":
        require(args.source and args.package_sha and not args.approved_plan_sha,
                "plan needs source and package SHA")
        plan(args.source, args.package_sha)
    else:
        require(args.approved_plan_sha and not args.source and not args.package_sha,
                "archive needs the approved plan SHA only")
        archive(args.approved_plan_sha)


if __name__ == "__main__":
    main()
