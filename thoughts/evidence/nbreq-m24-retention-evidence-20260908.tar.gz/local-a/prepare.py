from pathlib import Path
import difflib
import hashlib
import io
import json
import subprocess
import tarfile

out = Path('target/m24')
before_manifest = '003e80423d2eab3c70965384ae3615bd41c51f35f80922a9772b2ae22a418196'
compare = Path('target/m23/c/compare.py').read_text(encoding='utf-8').replace('3704fc13a50678386a8189e12344f27ae084c5cdb143c1ae821877115d256302', before_manifest).replace('M23_COMPARE_PASS','M24_COMPARE_PASS')
(out / 'compare.py').write_bytes(compare.encode('utf-8'))
names = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
prefixes = ('src/','tests/','support/','examples/','docs/','tools/xtask/','tools/f5-observe/')
roots = {'Cargo.toml','Cargo.lock','README.md','SECURITY.md','LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.html','.gitignore','rustfmt.toml'}
files = {name:Path(name).read_bytes() for name in names if (name in roots or name.startswith(prefixes)) and Path(name).is_file() and '/target/' not in name and '/__pycache__/' not in name}
for name in ('Cargo.lock','tools/f5-observe/memory/Cargo.lock','tools/f5-observe/memory/meter/Cargo.lock'):
    files[name] = Path(name).read_bytes()
with tarfile.open('thoughts/evidence/nbreq-m23-request-20260907-d.tar.gz') as archive:
    prior = {m.name.removeprefix('nbreq/'):archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
changed = sorted(name for name,data in files.items() if prior.get(name) != data)
assert changed == ['src/backend/native.rs','src/backend/native_http.rs','src/backend/native_http/tests.rs','src/backend/native_http/tests/retained_capacity.rs','src/backend/native_tls.rs'], changed
diff = ''.join(''.join(difflib.unified_diff(prior.get(name,b'').decode().splitlines(True),files[name].decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name)) for name in changed)
(out / 'source.diff').write_bytes(diff.encode('utf-8'))
for name in ('remote.sh','compare.py','collect.py'):
    files['m24-'+name] = (out/name).read_bytes().replace(b'\r\n',b'\n')
manifest = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode('utf-8')
files['m24-source.sha256'] = manifest
path = out / 'nbreq-m24-retention-20260908-a.tar.gz'
assert not path.exists(), 'Choose a new explicit source revision; do not overwrite a frozen snapshot.'
with tarfile.open(path,'w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo('nbreq/'+name)
        info.size=len(data)
        info.mode=0o755 if name.endswith('.sh') else 0o644
        archive.addfile(info,io.BytesIO(data))
result=dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256(manifest).hexdigest(),files=len(files),changed_from_m23_d=changed)
(out/'bundle.json').write_bytes(json.dumps(result,indent=2).encode('utf-8'))
(out/'source.sha256').write_bytes(manifest)
for name,provenance in [('windows','target/m23/c/windows-comparison/provenance.json'),('linux','target/m23/c/linux-evidence/comparison/provenance.json')]:
    before=json.loads(Path(provenance).read_text(encoding='utf-8'))
    assert before['sources']['after']==before_manifest
    if name=='windows':
        for mode in ['plain','meter']:
            binary=before['binaries']['after'][mode]
            assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest()==binary['sha256']
    (out/(name+'-before-provenance.json')).write_bytes(json.dumps(before,indent=2).encode('utf-8'))
print(json.dumps(result,indent=2))
