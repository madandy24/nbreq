from pathlib import Path
import json

root=Path('target/m24/b')
data={host:json.loads(path.read_text(encoding='utf-8')) for host,path in [('Windows',root/'windows-comparison-summary.json'),('Linux',root/'linux-evidence/comparison-summary.json')]}
lines=['## Final paired measurements','',
 'Each host ran three alternating before/after repetitions of HTTP/HTTPS 1 KiB and 50 KiB plus',
 'extended HTTPS 50 KiB: 32 connections, 16 steady rounds, separate fixture/client processes and',
 'separate plain/meter binaries. All 120 cases validate exact bytes, accounting, reuse, TLS trust',
 'where applicable, and joined cleanup. Before is frozen M2.3 C (production identical to D);',
 'after is frozen M2.4 B. Heap endpoints below are medians; peaks are maxima over three cases.',
 'Process memory is sampled from uninstrumented runs and uses different OS counters.','',
 '| Extended HTTPS checkpoint | Windows before → after MiB | Linux before → after MiB |',
 '| --- | ---: | ---: |']
extended={host:next(r for r in value['groups'] if r['extended']) for host,value in data.items()}
for phase,label in [('released_idle','Ordinary burst released'),('slow_reader_drain','Slow readers drained'),('large_transfer_retained','4 MiB reply still held'),('post_large_idle','Large reply released'),('shutdown_idle','After joined shutdown')]:
    values=[' → '.join(f"{extended[host][v]['phases'][phase]['heap_end']['median']/1048576:.3f}" for v in ['before','after']) for host in ['Windows','Linux']]
    lines.append('| '+label+' | '+' | '.join(values)+' |')
lines += ['', 'The post-large endpoint follows cancellation/replacement and streaming phases. It is not a',
 'pure single-upload experiment. The deterministic connection tests separately prove 512 KiB',
 'send storage is trimmed on idle parking and the same connection handles the next 50 KiB upload.',
 'The held 4 MiB reply remains legitimate application data. Heap release does not require the',
 'process allocator to return pages to the OS immediately.','',
 '| Workload | Windows allocated KiB/request before → after | Linux allocated KiB/request before → after |',
 '| --- | ---: | ---: |']
for index in range(5):
    row=data['Windows']['groups'][index]
    label=f"{row['protocol'].upper()} {row['body_bytes']//1024} KiB"+(' extended' if row['extended'] else '')
    values=[' → '.join(f"{data[host]['groups'][index][v]['requested_bytes_per_request']['median']/1024:.2f}" for v in ['before','after']) for host in ['Windows','Linux']]
    lines.append('| '+label+' | '+' | '.join(values)+' |')
lines += ['', 'Ordinary steady allocation churn and small-call idle retention are essentially unchanged.',
 'The change primarily reduces unused storage retained after streaming/large work. It does not',
 'replace M3 admission/accounting or establish a whole-GDS/128–256 MB device budget.','',
 '| Observed extended-workload peak | Windows before → after MiB | Linux before → after MiB |',
 '| --- | ---: | ---: |']
for field,label in [('peak_heap','Live Rust heap (meter)'),('peak_rss','Working set / RSS (plain)'),('peak_private','Private commit (Windows only)')]:
    values=[' → '.join(f'{extended[host][v][field]/1048576:.2f}' for v in ['before','after']) if host=='Windows' or field!='peak_private' else 'Unavailable' for host in ['Windows','Linux']]
    lines.append('| '+label+' | '+' | '.join(values)+' |')
lines += ['', '## Performance and limits','',
 '| Short batch median throughput (requests/s) | Windows before → after | Linux before → after |',
 '| --- | ---: | ---: |']
for index in range(5):
    row=data['Windows']['groups'][index]
    label=f"{row['protocol'].upper()} {row['body_bytes']//1024} KiB"+(' extended' if row['extended'] else '')
    values=[' → '.join(f"{data[host]['groups'][index][v]['rps']['median']:.0f}" for v in ['before','after']) for host in ['Windows','Linux']]
    lines.append('| '+label+' | '+' | '.join(values)+' |')
lines += ['', 'The short Windows batch contains inconsistent throughput/latency, including material apparent',
 'slowdowns. One predeclared follow-up used the same frozen plain binaries with 32 connections,',
 '128 rounds and five alternating pairs for each of three workloads: 30 valid cases, all joined.',
 'It is a separate longer workload; preserve both batches rather than replacing the original data.','',
 '| Longer Windows run | Median requests/s before → after | Median p95 ms before → after |',
 '| --- | ---: | ---: |']
for row in json.loads((root/'windows-timing/summary.json').read_text(encoding='utf-8')):
    values=[' → '.join(f"{row[v][field]['median']:.2f}" for v in ['before','after']) for field in ['requests_per_second','latency_p95_ms']]
    lines.append(f"| {row['protocol'].upper()} {row['body_bytes']//1024} KiB | "+' | '.join(values)+' |')
lines += ['', 'Longer-run median throughput changes approximately -2.0%, -1.1%, +4.8%; median p95 latency',
 'changes +8.4%, +10.2%, -16.9%. Ranges overlap and these hosts are not isolated benchmark machines.',
 'The evidence supports proceeding, but does not establish zero cost or exclude smaller latency',
 'regressions. Full ranges and process/phase counters are in the archived summaries/raw records.',
 'Cross-host timing differences are not attributed to platform software.','',
 'Repeated large uploads may regrow/retrim the send queue; this is the deliberate memory/reuse',
 'tradeoff. There is no dedicated sustained-large throughput study in M2.4. Remaining stream/TLS',
 'state, native allocations, allocator pages, application-held bodies and GDS queues remain real',
 'costs. M2.5 is next; MQ-03 must precede M3 budgets, and actual-device acceptance remains M4.','']
(root/'report-tables.md').write_bytes('\n'.join(lines).encode('utf-8'))
print('\n'.join(lines))
