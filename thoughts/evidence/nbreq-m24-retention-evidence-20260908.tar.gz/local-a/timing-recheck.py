from pathlib import Path
import hashlib
import importlib.util
import json
from statistics import median

root=Path('target/m24/b')
out=root/'windows-timing'
out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('m1_runner','tools/f5-observe/memory/run.py')
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original=json.loads((root/'windows-comparison/provenance.json').read_text(encoding='utf-8'))
binaries={v:Path(original['binaries'][v]['plain']['path']) for v in ['before','after']}
for v,path in binaries.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest()==original['binaries'][v]['plain']['sha256']
provenance=dict(host=runner.host_info(),sources=original['sources'],binaries={v:original['binaries'][v]['plain'] for v in binaries},workloads=[['http',51200],['https',1024],['https',51200]],connections=32,rounds=128,repetitions=5,extended=False,instrumented=False,reason='One fixed longer-run follow-up after noisy/degraded short Windows throughput samples; retain both batches.')
(out/'provenance.json').write_bytes(json.dumps(provenance,indent=2).encode('utf-8'))
results=[]
for repetition in range(5):
    for protocol,size in [('http',51200),('https',1024),('https',51200)]:
        for version in (['before','after'] if repetition%2==0 else ['after','before']):
            name=f'{version}-{protocol}-b{size}-r{repetition+1}'
            case=runner.run_case(binaries[version],binaries[version],out/name,original['sources'][version],protocol,32,size,128,False)
            assert not case['client']['instrumented']
            case.update(case=name,version=version,repetition=repetition+1)
            results.append(case)
            print('PASS',name,flush=True)
(out/'results.json').write_bytes(json.dumps(results,indent=2).encode('utf-8'))
rows=[]
for protocol,size in [('http',51200),('https',1024),('https',51200)]:
    row=dict(protocol=protocol,body_bytes=size)
    for v in ['before','after']:
        phases=[next(p for p in c['phases'] if p['phase']=='steady') for c in results if c['version']==v and c['protocol']==protocol and c['client']['body_bytes']==size]
        row[v]={field:dict(min=min(values),median=median(values),max=max(values)) for field in ['requests_per_second','latency_p95_ms'] for values in [[p[field] for p in phases]]}
    rows.append(row)
(out/'summary.json').write_bytes(json.dumps(rows,indent=2).encode('utf-8'))
print('M24_TIMING_PASS',len(results),flush=True)
print(json.dumps(rows,indent=2))
