from pathlib import Path
import hashlib
import io
import json
import tarfile

root=Path('target/m24')
final=root/'b'
before_hash='003e80423d2eab3c70965384ae3615bd41c51f35f80922a9772b2ae22a418196'
after_hash='b1ddee56304a55f26f9ef0c7b215e9ca1d5f10632c47aa5bcd764965b15b519d'
markers=[
 'test backend::native_http::tests::retained_capacity::m24_buffered_tls_parking_bounds_retained_send_storage ... ok',
 'test backend::native_http::tests::retained_capacity::m24_streaming_tls_parking_bounds_retained_send_storage ... ok',
 'test backend::native_tls::tests::m24_consumed_stream_plaintext_releases_storage_without_losing_partial_bytes ... ok',
 'test backend::native::tests::m24_idle_parking_never_discards_queued_output ... ok',
 'test backend::native::tests::m24_idle_parking_rejects_unclean_and_stale_connections ... ok',
 'test backend::native::tests::m24_idle_send_retention_preserves_small_buffers_and_trims_only_above_threshold ... ok',
 'test backend::native_http::tests::idle_peer_close_is_evicted_before_the_next_request ... ok',
]
assert (final/'windows.exit').read_text(encoding='utf-8-sig').strip()=='0'
log=(final/'windows-verify.log').read_text(encoding='utf-8')
assert 'NBReq verification root: '+str(Path.cwd()) in log
assert 'NBReq verification complete: all 24 steps passed' in log
assert all(marker in log for marker in markers)
assert '29 passed; 0 failed' in (final/'windows-x86.log').read_text(encoding='utf-8')
assert '6 passed; 0 failed' in (root/'retention-green.log').read_text(encoding='utf-8')
assert '0 passed; 3 failed' in (root/'retention-red.log').read_text(encoding='utf-8')
failure='assertion failed: metrics.idle_connections_evicted() >= 1'
assert failure in (root/'windows-verify.log').read_text(encoding='utf-8')
for host in ['linux','intel','arm']:
    failed=root/('a-'+host+'-evidence')
    assert (failed/'run.exit').read_text().strip()=='1'
    assert failure in (failed/'verify-stable.log').read_text(encoding='utf-8')
    folder=final/(host+'-evidence')
    assert (folder/'run.exit').read_text().strip()=='0'
    for version in ['stable','1.85.0']:
        text=(folder/('verify-'+version+'.log')).read_text(encoding='utf-8')
        assert 'nbreq-m24-retention-20260908-b/nbreq' in text.splitlines()[0]
        assert 'NBReq verification complete: all 24 steps passed' in text
        assert all(marker in text for marker in markers)
for folder in [final/'windows-comparison',final/'linux-evidence/comparison',final/'windows-timing']:
    cases=json.loads((folder/'results.json').read_text(encoding='utf-8'))
    assert len(cases)==(30 if folder.name=='windows-timing' else 60)
    assert all(c['valid'] for c in cases)
    assert all(p['joined'] and p['exit_code']==0 and not p['forced'] for c in cases for p in c['cleanup'])
    provenance=json.loads((folder/'provenance.json').read_text(encoding='utf-8'))
    assert provenance['sources']==dict(before=before_hash,after=after_hash)
for host,folder in [('windows',final/'windows-comparison'),('linux',final/'linux-evidence/comparison')]:
    previous=json.loads((final/(host+'-before-provenance.json')).read_text(encoding='utf-8'))
    current=json.loads((folder/'provenance.json').read_text(encoding='utf-8'))
    assert all(previous['binaries']['after'][mode]['sha256']==current['binaries']['before'][mode]['sha256'] for mode in ['plain','meter'])

files={}
extensions={'.log','.json','.py','.ps1','.sh','.sha256','.diff','.rs','.exit'}
for folder,prefix in [(root,'local-a/'),(final,'local-b/')]:
    for path in folder.iterdir():
        if path.is_file() and path.suffix in extensions:
            files[prefix+path.name]=path.read_bytes()
    for path in folder.glob('bridge-*.json'):
        receipts=json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(receipts,list):receipts=[receipts]
        for receipt in receipts:
            if not isinstance(receipt,dict) or not {'Root','Id'}<=receipt.keys():continue
            result=Path(receipt['Root'])/'results'/(receipt['Id']+'.json')
            assert result.is_file(),result
            files['receipts/'+receipt['Id']+'.json']=result.read_bytes()
folders=[(final/'windows-comparison','windows/'),(final/'windows-timing','windows-timing/')]
folders += [(root/('a-'+host+'-evidence'),'failed-a-'+host+'/') for host in ['linux','intel','arm']]
folders += [(final/(host+'-evidence'),'final-b-'+host+'/') for host in ['linux','intel','arm']]
for folder,prefix in folders:
    for path in folder.rglob('*'):
        if path.is_file():files[prefix+path.relative_to(folder).as_posix()]=path.read_bytes()

artifacts={}
for revision,folder in [('a',root),('b',final)]:
    name='nbreq-m24-retention-20260908-'+revision+'.tar.gz'
    source=folder/name
    bundle=json.loads((folder/'bundle.json').read_text(encoding='utf-8'))
    data=source.read_bytes()
    assert hashlib.sha256(data).hexdigest()==bundle['sha256']
    with tarfile.open(source) as archive:
        members={m.name.removeprefix('nbreq/'):archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
    manifest=members['m24-source.sha256']
    assert hashlib.sha256(manifest).hexdigest()==bundle['manifest_sha256']
    for line in manifest.decode().splitlines():
        digest,path=line.split('  ',1)
        assert hashlib.sha256(members[path]).hexdigest()==digest
        if revision=='b' and not path.startswith('m24-'):
            assert Path(path).read_bytes()==members[path],path
    destination=Path('thoughts/evidence')/name
    assert not destination.exists(),destination
    destination.write_bytes(data)
    artifacts['source_'+revision]=dict(path=destination.as_posix(),sha256=bundle['sha256'],manifest_sha256=bundle['manifest_sha256'])
files['evidence.sha256']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode('utf-8')
output=Path('thoughts/evidence/nbreq-m24-retention-evidence-20260908.tar.gz')
assert not output.exists(),output
with tarfile.open(output,'w:gz') as archive:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name)
        info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
with tarfile.open(output) as archive:
    restored={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
assert restored==files
artifacts['evidence']=dict(path=output.as_posix(),sha256=hashlib.sha256(output.read_bytes()).hexdigest(),files=len(files),bytes=output.stat().st_size)
artifacts.update(initial_red_tests=3,final_memory_tests=6,final_full_verifiers=7,windows_x86_m2_tests=29,paired_cases=120,windows_longer_timing_cases=30,superseded_failed_full_attempts=4,final_source_revision='b',a_to_b_only_idle_eviction_fixture=True)
Path('thoughts/evidence/nbreq_m24_retention_artifacts.json').write_bytes(json.dumps(artifacts,indent=2).encode('utf-8'))
print(json.dumps(artifacts,indent=2))
