from pathlib import Path
import base64
import hashlib
import io
import sys
import tarfile

lab = Path(sys.argv[1]).resolve()
assert lab.name == 'nbreq-m24-retention-20260908-a'
assert (lab/'run.exit').read_text().strip() == '1'
text = (lab/'verify-stable.log').read_text()
assert 'NBReq verification root: '+str(lab/'nbreq') in text.splitlines()[0]
assert 'assertion failed: metrics.idle_connections_evicted() >= 1' in text
files = {p.name:p.read_bytes() for p in lab.glob('*.log')}
for name in ['run.exit','nbreq/m24-source.sha256']:
    files[name] = (lab/name).read_bytes()
files['evidence.sha256'] = ''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for name,data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info,io.BytesIO(data))
payload=buffer.getvalue()
print('M24_ARCHIVE_SHA256',hashlib.sha256(payload).hexdigest())
print('M24_ARCHIVE_BASE64',base64.b64encode(payload).decode())
