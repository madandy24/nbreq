$ErrorActionPreference = 'Stop'
$m24Root = Join-Path (Get-Location) 'target/m24'
$m24Exit = 1
try {
    cargo run --offline --manifest-path tools/xtask/Cargo.toml -- verify --offline *> "$m24Root/windows-verify.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows verifier failed; inspect its log.' }
    cargo test --offline --all-features --target i686-pc-windows-msvc --lib m2 -- --test-threads=1 *> "$m24Root/windows-x86.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows x86 companions failed.' }
    New-Item -ItemType Directory -Path "$m24Root/bin" | Out-Null
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml *> "$m24Root/windows-build-plain.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows plain observer build failed.' }
    Copy-Item -LiteralPath tools/f5-observe/memory/target/release/nbreq-f5-memory.exe -Destination "$m24Root/bin/plain.exe"
    cargo build --release --locked --offline --manifest-path tools/f5-observe/memory/Cargo.toml --features alloc-meter *> "$m24Root/windows-build-meter.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows meter observer build failed.' }
    Copy-Item -LiteralPath tools/f5-observe/memory/target/release/nbreq-f5-memory.exe -Destination "$m24Root/bin/meter.exe"
    $m24Bundle = Get-Content -LiteralPath "$m24Root/bundle.json" -Raw -Encoding UTF8 | ConvertFrom-Json
    & 'C:/Users/andre/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -X utf8 "$m24Root/compare.py" --before-plain target/m23/c/bin/plain.exe --before-meter target/m23/c/bin/meter.exe --after-plain "$m24Root/bin/plain.exe" --after-meter "$m24Root/bin/meter.exe" --output "$m24Root/windows-comparison" --source $m24Bundle.manifest_sha256 *> "$m24Root/windows-comparison.log"
    if ($LASTEXITCODE -ne 0) { throw 'Windows paired comparison failed.' }
    $m24Exit = 0
    Write-Output 'M24_WINDOWS_PASS'
} finally {
    Set-Content -LiteralPath "$m24Root/windows.exit" -Value $m24Exit -Encoding UTF8
}
