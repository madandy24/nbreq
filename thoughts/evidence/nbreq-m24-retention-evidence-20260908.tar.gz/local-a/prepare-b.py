from pathlib import Path
import difflib
import json
import tarfile

root = Path('target/m24')
out = root / 'b'
out.mkdir(exist_ok=True)
with tarfile.open(root / 'nbreq-m24-retention-20260908-a.tar.gz') as archive:
    prior = {m.name.removeprefix('nbreq/'): archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
changes = [name for name, data in prior.items() if Path(name).is_file() and Path(name).read_bytes() != data]
assert changes == ['src/backend/native_http/tests.rs'], changes
name = changes[0]
diff = ''.join(difflib.unified_diff(prior[name].decode().splitlines(True), Path(name).read_text(encoding='utf-8').splitlines(True), fromfile='A/'+name, tofile='B/'+name))
(out/'a-to-b.diff').write_bytes(diff.encode('utf-8'))
for name in ['remote.sh', 'collect.py']:
    text = (root/name).read_text(encoding='utf-8').replace('nbreq-m24-retention-20260908-a', 'nbreq-m24-retention-20260908-b')
    (out/name).write_bytes(text.encode('utf-8'))
text = (root/'prepare.py').read_text(encoding='utf-8').replace("Path('target/m24')", "Path('target/m24/b')").replace('nbreq-m24-retention-20260908-a', 'nbreq-m24-retention-20260908-b')
(out/'prepare.py').write_bytes(text.encode('utf-8'))
text = (root/'windows.ps1').read_text(encoding='utf-8').replace("'target/m24'", "'target/m24/b'")
(out/'windows.ps1').write_bytes(text.encode('utf-8'))
(out/'receive.py').write_bytes((root/'receive.py').read_bytes())
exec(compile(text := (out/'prepare.py').read_text(encoding='utf-8'), str(out/'prepare.py'), 'exec'))
