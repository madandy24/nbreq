import json
import sys
from pathlib import Path
from statistics import median

root = Path(sys.argv[1])
cases = json.loads((root/'results.json').read_text(encoding='utf-8'))
assert len(cases) == 60 and all(c['valid'] for c in cases)
assert all(p['joined'] and p['exit_code'] == 0 and not p['forced'] for c in cases for p in c['cleanup'])

def phase(c, name):
    return next(p for p in c['phases'] if p['phase'] == name)

def spread(values):
    return dict(min=min(values), median=median(values), max=max(values))

rows=[]
for protocol,size,extended in sorted({(c['protocol'],c['client']['body_bytes'],c['client']['extended']) for c in cases}):
    row=dict(protocol=protocol,body_bytes=size,extended=extended)
    for version in ['before','after']:
        selected=[c for c in cases if c['protocol']==protocol and c['client']['body_bytes']==size and c['client']['extended']==extended and c['version']==version]
        plain=[c for c in selected if not c['client']['instrumented']]
        meter=[c for c in selected if c['client']['instrumented']]
        assert len(plain)==len(meter)==3
        row[version]=dict(
            rps=spread([phase(c,'steady')['requests_per_second'] for c in plain]),
            p95_ms=spread([phase(c,'steady')['latency_p95_ms'] for c in plain]),
            requested_bytes_per_request=spread([phase(c,'steady')['allocation']['bytes_requested']/phase(c,'steady')['completed'] for c in meter]),
            allocation_calls_per_request=spread([(phase(c,'steady')['allocation']['allocations']+phase(c,'steady')['allocation']['reallocations'])/phase(c,'steady')['completed'] for c in meter]),
            peak_heap=max(p['allocation']['peak_live'] for c in meter for p in c['phases']),
            peak_rss=max(p['process']['sampled_peaks']['rss'] for c in plain for p in c['phases']),
            peak_private=max((p['process']['sampled_peaks'].get('private') or 0) for c in plain for p in c['phases']),
            phases={name:dict(
                heap_peak=spread([phase(c,name)['allocation']['peak_live'] for c in meter]),
                heap_end=spread([phase(c,name)['allocation']['live_after'] for c in meter]),
                bytes_requested=spread([phase(c,name)['allocation']['bytes_requested'] for c in meter]),
                allocation_calls=spread([phase(c,name)['allocation']['allocations']+phase(c,name)['allocation']['reallocations'] for c in meter]),
            ) for name in [p['phase'] for p in meter[0]['phases']]},
        )
    rows.append(row)
output=dict(cases=len(cases),groups=rows,provenance=json.loads((root/'provenance.json').read_text(encoding='utf-8')))
(root.parent/(root.name+'-summary.json')).write_bytes(json.dumps(output,indent=2).encode('utf-8'))
for row in rows:
    b,a=row['before'],row['after']
    print(row['protocol'],row['body_bytes'],'extended' if row['extended'] else 'ordinary')
    print('  allocation KiB/request',round(b['requested_bytes_per_request']['median']/1024,3),'->',round(a['requested_bytes_per_request']['median']/1024,3),'calls/request',round(b['allocation_calls_per_request']['median'],3),'->',round(a['allocation_calls_per_request']['median'],3))
    print('  RPS', {v:{k:round(x) for k,x in row[v]['rps'].items()} for v in ['before','after']})
    print('  p95 ms', {v:row[v]['p95_ms'] for v in ['before','after']})
    print('  peak heap/RSS/private MiB',{v:[round(row[v][field]/1048576,3) for field in ['peak_heap','peak_rss','peak_private']] for v in ['before','after']})
    for name in b['phases']:
        if name in ['released_idle','slow_reader_drain','large_transfer_retained','post_large_idle','shutdown_idle']:
            print('  phase',name,'heap end MiB',{v:round(row[v]['phases'][name]['heap_end']['median']/1048576,4) for v in ['before','after']})
