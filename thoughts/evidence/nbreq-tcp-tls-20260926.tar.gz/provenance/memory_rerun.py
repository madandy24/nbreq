"""One bounded ARM TLS memory rerun with a fixture-only LibreSSL adjustment.

Run as `python3 -B memory_rerun.py launch`. The frozen source tree and release
probe are verified, never edited or rebuilt. A fresh tiny source tree contains
only the changed memory controller and its unchanged sampler dependency.
"""

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import time


COMMIT = "bede85c32a41b7099c073e9585517d0ae4027342"
SOURCE_SHA256 = "7d476f855306661fe03cfc813a4f86dda972b4b79f897e2c5d9253e1f39d8bb5"
HELPER_SHA256 = "86cf2317a4de52c57c2d0e80c768682965a5a79868cc72f67a5ec3aefbd86e9a"
PROBE_SHA256 = "76e9f6483bea26156dd85b91708ea3e221c6037e2e8a34d1acaf98cc17e187e5"
FROZEN_ROOT = Path("/private/tmp/nbreq-tcp-tls-bede85c32a41")
FROZEN_GATE = Path("/private/tmp/nbreq-tcp-tls-bede85c32a41-gate")
UPLOADED_HELPER = Path("/tmp/nbreq-tls-memory-r2.py")
RERUN_ROOT = Path("/private/tmp/nbreq-tcp-tls-bede85c32a41-memory-r2")
OUT = Path("/private/tmp/nbreq-tcp-tls-bede85c32a41-memory-r2-gate")


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def require_hash(path, expected, label):
    if not path.is_file():
        raise RuntimeError(label + " is absent: " + str(path))
    actual = sha256(path)
    if actual != expected:
        raise RuntimeError(label + " hash mismatch: " + actual)
    return actual


def frozen_platform():
    path = FROZEN_ROOT / "tls-platform.py"
    if not path.is_file():
        raise RuntimeError("frozen platform supervisor is absent: " + str(path))
    spec = importlib.util.spec_from_file_location("frozen_tls_platform", str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_frozen(module):
    source_hash, manifest = module.verify_source(FROZEN_ROOT)
    if source_hash != SOURCE_SHA256 or manifest.get("commit") != COMMIT:
        raise RuntimeError("frozen source manifest or commit differs")
    return source_hash, manifest


def work():
    started = time.monotonic()
    failure = None
    source_before = None
    source_after = None
    probe_before = None
    probe_after = None
    helper_before = None
    helper_after = None
    sampler_hash = None
    sampler_after = None
    report = None
    probe = FROZEN_GATE / "build" / "release" / "nbreq-tcp-tls-probe"
    try:
        supervisor = frozen_platform()
        source_before, manifest = verify_frozen(supervisor)
        probe_before = require_hash(probe, PROBE_SHA256, "frozen release probe")
        helper_before = require_hash(UPLOADED_HELPER, HELPER_SHA256, "uploaded memory helper")
        sampler = FROZEN_ROOT / "tools" / "release-soak" / "process_sample.py"
        sampler_hash = manifest["files"]["tools/release-soak/process_sample.py"]
        require_hash(sampler, sampler_hash, "frozen process sampler")

        RERUN_ROOT.mkdir(parents=True, exist_ok=False)
        helper_copy = RERUN_ROOT / "tools" / "tcp-tls-probe" / "memory.py"
        sampler_copy = RERUN_ROOT / "tools" / "release-soak" / "process_sample.py"
        helper_copy.parent.mkdir(parents=True)
        sampler_copy.parent.mkdir(parents=True)
        shutil.copyfile(str(UPLOADED_HELPER), str(helper_copy))
        shutil.copyfile(str(sampler), str(sampler_copy))
        require_hash(helper_copy, HELPER_SHA256, "isolated memory helper")
        require_hash(sampler_copy, sampler_hash, "isolated process sampler")

        host = dict(platform=platform.platform(), machine=platform.machine(), python=sys.version,
                    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    source_commit=COMMIT, frozen_root=str(FROZEN_ROOT),
                    frozen_source_sha256_before=source_before,
                    frozen_probe=str(probe), frozen_probe_sha256_before=probe_before,
                    uploaded_helper=str(UPLOADED_HELPER), helper_sha256_before=helper_before,
                    isolated_root=str(RERUN_ROOT), sampler_sha256=sampler_hash,
                    wrapper_sha256=sha256(Path(__file__).resolve()))
        write_json(OUT / "host.json", host)

        env = dict(os.environ)
        env["PATH"] = str(Path.home() / ".cargo" / "bin") + os.pathsep + env.get("PATH", "")
        argv = [sys.executable, "-B", "tools/tcp-tls-probe/memory.py", "--binary",
                str(probe), "--out", str(OUT / "memory"), "--tls-version", "1.2"]
        supervisor.command(argv, RERUN_ROOT, OUT, "memory-observation", env, 420)
        report_path = OUT / "memory" / "report.json"
        if not report_path.is_file():
            raise RuntimeError("memory observation did not write a report")
        report = dict(path=str(report_path), sha256=sha256(report_path),
                      observations=json.loads(report_path.read_text(encoding="utf-8")))
    except BaseException as error:
        failure = repr(error)
    finally:
        try:
            supervisor = frozen_platform()
            source_after, _ = verify_frozen(supervisor)
            probe_after = require_hash(probe, PROBE_SHA256, "frozen release probe after rerun")
            helper_after = require_hash(UPLOADED_HELPER, HELPER_SHA256,
                                        "uploaded memory helper after rerun")
            if RERUN_ROOT.exists():
                require_hash(RERUN_ROOT / "tools" / "tcp-tls-probe" / "memory.py",
                             HELPER_SHA256, "isolated memory helper after rerun")
                if sampler_hash is not None:
                    sampler_after = require_hash(
                        RERUN_ROOT / "tools" / "release-soak" / "process_sample.py",
                        sampler_hash, "isolated process sampler after rerun")
            if source_before is not None and source_after != source_before:
                raise RuntimeError("frozen source changed during memory rerun")
            if probe_before is not None and probe_after != probe_before:
                raise RuntimeError("frozen release probe changed during memory rerun")
            if helper_before is not None and helper_after != helper_before:
                raise RuntimeError("uploaded memory helper changed during rerun")
        except BaseException as error:
            detail = "post-run integrity check: " + repr(error)
            failure = detail if failure is None else failure + "; " + detail
    result = dict(status="failed" if failure else "passed", failure=failure,
                  source_commit=COMMIT, frozen_source_sha256_before=source_before,
                  frozen_source_sha256_after=source_after,
                  probe_sha256_before=probe_before, probe_sha256_after=probe_after,
                  helper_sha256_before=helper_before, helper_sha256_after=helper_after,
                  sampler_sha256_after=sampler_after,
                  report=report, elapsed_seconds=time.monotonic() - started, pid=os.getpid())
    write_json(OUT / "result.json", result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


def stop_owned(child, log):
    if child.poll() is not None:
        return
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait(timeout=15)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("launch", "work"))
    args = parser.parse_args()
    if args.mode == "launch":
        OUT.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, "-B", str(Path(__file__).resolve()), "work"]
        with (OUT / "job.log").open("wb") as log:
            child = None
            try:
                child = subprocess.Popen(argv, cwd=str(OUT), stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=log, start_new_session=True,
                                         close_fds=True)
                record = dict(pid=child.pid, command=argv, out=str(OUT),
                              frozen_root=str(FROZEN_ROOT), isolated_root=str(RERUN_ROOT),
                              helper=str(UPLOADED_HELPER), helper_sha256=HELPER_SHA256,
                              probe_sha256=PROBE_SHA256)
                write_json(OUT / "launch.json", record)
            except BaseException:
                if child is not None:
                    stop_owned(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0
    if not OUT.is_dir():
        parser.error("fresh rerun gate must be created by launch")
    return work()


if __name__ == "__main__":
    def terminate(_signal, _frame):
        raise SystemExit("memory rerun received SIGTERM")
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
