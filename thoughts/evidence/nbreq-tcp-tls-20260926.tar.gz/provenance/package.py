"""Package the local TLS branch and exercise its examples/independent consumer; never publish."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile
import tempfile
from urllib.parse import unquote, urlsplit

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
root, out = args.root.resolve(), args.out.resolve()
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip():
    raise SystemExit('Package evidence requires clean committed source')
out.mkdir(parents=True, exist_ok=False)
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
spec = importlib.util.spec_from_file_location('tls_platform', Path(__file__).with_name('platform.py'))
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
env = dict(os.environ, CARGO_TARGET_DIR=str(out / 'build'))
env.pop('CARGO_BUILD_TARGET', None)
env['RUSTUP_TOOLCHAIN'] = 'stable'
steps = []
def run(label, argv, cwd=root, timeout=600):
    supervisor.command(argv, cwd, out, label, env, timeout)
    steps.append(label)

run('package', ['cargo', '+stable', 'package', '--locked', '--offline', '-p', 'nbreq'])
archive = out / 'build' / 'package' / 'nbreq-0.2.0.crate'
with tarfile.open(archive) as bundle:
    entries = bundle.getmembers()
    prefix = 'nbreq-0.2.0/'
    names = {entry.name for entry in entries}
    if len(names) != len(entries) or any(not e.isfile() or not e.name.startswith(prefix)
                                       or '..' in PurePosixPath(e.name).parts for e in entries):
        raise RuntimeError('invalid package inventory')
    vcs = json.load(bundle.extractfile(prefix + '.cargo_vcs_info.json'))
    assert vcs['git']['sha1'] == commit and not vcs['git'].get('dirty', False)
    for required in ['docs/tcp-tls.md', 'examples/C04-tcp-tls.rs', 'examples/C05-tcp-starttls.rs',
                     'examples/support/tls_echo.rs', 'tests/tcp_tls_api.rs']:
        assert prefix + required in names, required
    links = []
    for entry in entries:
        if not entry.name.endswith('.md'):
            continue
        content = bundle.extractfile(entry).read().decode()
        for destination in re.findall(r'\]\(([^\s)]+)\)', content):
            url = urlsplit(destination)
            if url.scheme or url.netloc or not url.path:
                continue
            parts = list(PurePosixPath(entry.name).parent.parts)
            for part in PurePosixPath(unquote(url.path)).parts:
                if part == '..':
                    assert len(parts) > 1
                    parts.pop()
                elif part != '.':
                    parts.append(part)
            target = '/'.join(parts)
            assert target in names, 'missing package link: ' + destination
            links.append(dict(document=entry.name, destination=destination, target=target))
    hashes = {entry.name: hashlib.sha256(bundle.extractfile(entry).read()).hexdigest() for entry in entries}
supervisor.write(out / 'inventory.json', dict(commit=commit, vcs=vcs, files=hashes, links=links,
                                            sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
# Cargo's extracted verification tree is beneath the user's main workspace. An
# ordinary example invocation there would inherit that unrelated ancestor manifest.
# Exercise byte-for-byte archive contents in an isolated temporary directory.
isolated = Path(tempfile.mkdtemp(prefix='nbreq-tls-package-' + commit[:8] + '-')).resolve()
with tarfile.open(archive) as bundle:
    for entry in bundle.getmembers():
        destination = isolated / entry.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(bundle.extractfile(entry).read())
packaged = isolated / 'nbreq-0.2.0'
for example in ['C04-tcp-tls', 'C05-tcp-starttls']:
    run(example, ['cargo', '+stable', 'run', '--locked', '--offline', '--example', example], packaged)
consumer = isolated / 'consumer'
consumer.mkdir()
shutil.copytree(root / 'tools/tcp-tls-probe/src', consumer / 'src')
manifest = (root / 'tools/tcp-tls-probe/Cargo.toml').read_text(encoding='utf-8')
manifest = manifest.replace('path = "../.."', 'path = ' + json.dumps(packaged.as_posix()))
(consumer / 'Cargo.toml').write_text(manifest, encoding='utf-8')
run('consumer-resolve', ['cargo', '+stable', 'generate-lockfile', '--offline'], consumer)
run('consumer-build', ['cargo', '+stable', 'build', '--locked', '--offline'], consumer)
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip():
    raise RuntimeError('source changed during package gate')
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() != commit:
    raise RuntimeError('source commit changed during package gate')
supervisor.write(out / 'result.json', dict(status='passed', commit=commit, steps=steps,
                                         isolated_root=str(isolated),
                                         package_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
print('Packaged TLS examples and independent consumer passed', flush=True)
