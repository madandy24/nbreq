"""Independent Wine TLS observations after the custom-root public-suite failure.

This lab-only runner keeps every step's result, including failures. It uses the
approved frozen archive verifier and process supervisor without changing trust,
the Wine prefix, NBReq source, or the remote application.
"""

import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import time


LAB = Path("/tmp/nbreq-tcp-tls-bede85c-wine-diagnostics")
RUNNER = Path("/tmp/nbreq-tcp-tls-bede85c-wine.py")
RUNNER_SHA256 = "8aadd475bf99137fc4d2931463bcc4bb2e02aa4ba617ceb6dc8fa700f40e1ab8"
ARCHIVE = Path("/tmp/nbreq-tcp-tls-bede85c-i686-wine.tar.gz")
LIVE_HOST = "cavesvr3.caverock.com"
STOP_REQUESTED = False


def load_runner(path):
    import hashlib
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != RUNNER_SHA256:
        raise RuntimeError("approved Wine supervisor SHA256 differs")
    spec = importlib.util.spec_from_file_location("nbreq_wine_supervisor", str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def one_step(runner, argv, out, label, env, timeout, expected_passed=None):
    try:
        result = runner.command(argv, out, label, env, timeout, expected_passed)
    except Exception as error:
        record = out / (label + ".result.json")
        if record.is_file():
            result = json.loads(record.read_text(encoding="utf-8"))
        else:
            result = dict(label=label, command=argv, error=repr(error), exit_code=None,
                          timed_out=False, passed_tests=None)
            runner.write_json(record, result)
    return result


def work(runner, archive, out, wine):
    started = time.monotonic()
    failure = None
    results = []
    try:
        prefix = runner.verify_prefix()
        manifest, files = runner.verify_and_unpack(archive, out)
        if not runner.SHIM.is_file() or runner.sha256(runner.SHIM) != runner.SHIM_SHA256:
            raise RuntimeError("existing ProcessPrng shim SHA256 differs")
        shim = out / "bin" / "bcryptprimitives.dll"
        shutil.copyfile(str(runner.SHIM), str(shim))
        if runner.sha256(shim) != runner.SHIM_SHA256:
            raise RuntimeError("app-local ProcessPrng shim copy SHA256 differs")
        wine_path = shutil.which(wine)
        if wine_path is None:
            raise RuntimeError("Wine executable is unavailable: " + wine)
        env = dict(os.environ)
        env.update(WINEPREFIX=str(runner.PREFIX), WINEARCH="win32", WINEDEBUG="-all")
        runner.write_json(out / "host.json", dict(
            platform=platform.platform(), machine=platform.machine(), python=sys.version,
            started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            source_commit=runner.COMMIT, archive=str(archive),
            archive_sha256=runner.ARCHIVE_SHA256, approved_supervisor=str(RUNNER),
            approved_supervisor_sha256=RUNNER_SHA256, prefix=prefix,
            display=env.get("DISPLAY"), wine_executable=wine_path,
            compiler=manifest.get("rustc"), cargo=manifest.get("cargo"),
            executable_hashes=files, shim_sha256=runner.SHIM_SHA256,
            live_host=LIVE_HOST, live_scope="greeting/capability/logout and greeting/EHLO/STARTTLS/re-EHLO/QUIT only",
        ))
        lib = str(out / runner.MEMBERS[0])
        api = str(out / runner.MEMBERS[2])
        probe = str(out / runner.MEMBERS[3])
        steps = [
            ("wine-version", [wine_path, "--version"], 30, None),
            ("owner-webpki-10", [wine_path, lib, "standalone_tls", "--test-threads=1", "--nocapture"], 300, 10),
            ("registry-tls", [wine_path, lib, "registry::tests::tls_", "--test-threads=1", "--nocapture"], 300, -1),
            ("tcp-io-tls", [wine_path, lib, "tcp::io::tests::tls_", "--test-threads=1", "--nocapture"], 300, -1),
            ("worker-capacity", [wine_path, lib, "native_tls::worker::tests::", "--test-threads=1", "--nocapture"], 300, -1),
            ("public-api-3", [wine_path, api, "--test-threads=1", "--nocapture"], 300, 3),
            ("live-imaps-993", [wine_path, probe, "imaps", LIVE_HOST, "993"], 60, None),
            ("live-smtp-25", [wine_path, probe, "smtp", LIVE_HOST, "25"], 60, None),
        ]
        for label, argv, timeout, expected in steps:
            if STOP_REQUESTED:
                raise InterruptedError("diagnostic runner was asked to stop")
            result = one_step(runner, argv, out, label, env, timeout, expected)
            results.append(result)
            runner.write_json(out / "progress.json", dict(steps=results))
            if STOP_REQUESTED:
                raise InterruptedError("diagnostic runner was asked to stop")
    except BaseException as error:
        failure = repr(error)
    failed_steps = [row["label"] for row in results if row.get("error") or row.get("exit_code") != 0]
    result = dict(status="stopped" if STOP_REQUESTED else ("setup_failed" if failure else "observed"),
                  setup_failure=failure, attempted_steps=len(results), failed_steps=failed_steps,
                  source_commit=runner.COMMIT, elapsed_seconds=time.monotonic() - started,
                  results=results, pid=os.getpid())
    runner.write_json(out / "result.json", result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("launch", "work"))
    parser.add_argument("--archive", type=Path, default=ARCHIVE)
    parser.add_argument("--runner", type=Path, default=RUNNER)
    parser.add_argument("--out", type=Path, default=LAB)
    parser.add_argument("--wine", default="/usr/bin/wine")
    args = parser.parse_args()
    out = args.out.resolve()
    if out != LAB:
        parser.error("this diagnostic uses only the fixed fresh lab " + str(LAB))
    archive = args.archive.resolve()
    runner_path = args.runner.resolve()
    runner = load_runner(runner_path)
    if args.mode == "launch":
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, "-B", str(Path(__file__).resolve()), "work",
                "--archive", str(archive), "--runner", str(runner_path),
                "--out", str(out), "--wine", args.wine]
        with (out / "job.log").open("wb") as log:
            child = None
            try:
                child = subprocess.Popen(argv, cwd=str(out), stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=log, start_new_session=True,
                                         close_fds=True)
                record = dict(pid=child.pid, command=argv, out=str(out))
                runner.write_json(out / "launch.json", record)
            except BaseException:
                if child is not None:
                    runner.stop_owned(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0
    if not out.is_dir():
        parser.error("the fresh diagnostic lab must be created by launch")
    return work(runner, archive, out, args.wine)


if __name__ == "__main__":
    def terminate(_signal, _frame):
        global STOP_REQUESTED
        STOP_REQUESTED = True
        raise SystemExit("diagnostic runner received SIGTERM")
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
