"""Run the frozen NBReq Windows x86 TLS tests under the existing private Wine prefix.

This lab-only harness neither configures Wine nor edits the NBReq source tree. Each
Wine command has its own process group, deadline, raw log, and result record.
"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import struct
import subprocess
import sys
import tarfile
import time


COMMIT = "bede85c32a41b7099c073e9585517d0ae4027342"
ARCHIVE_SHA256 = "e324feb8ba4aa966eb7479410327f9816aded196912ab9bffa5a36967f608a63"
SHIM_SHA256 = "92d437dc538ef6ddfae7fc0b2140ec407a6dacfb0c899ec67a6812e84387de86"
PREFIX = Path("/tmp/nbreq-wine-dns-lab-20260910/prefix")
LAB = Path("/tmp/nbreq-tcp-tls-bede85c-wine")
SHIM = Path("/tmp/nbreq-wine-dns-gate-final-20260910/bcryptprimitives.dll")
MEMBERS = (
    "bin/nbreq-lib-tests.exe",
    "bin/tcp_tls-tests.exe",
    "bin/tcp_tls_api-tests.exe",
    "bin/nbreq-tcp-tls-probe.exe",
    "manifest.json",
)
MAX_MEMBER_BYTES = 50 * 1024 * 1024


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def pe_machine(path):
    with path.open("rb") as source:
        dos = source.read(64)
        if len(dos) != 64 or dos[:2] != b"MZ":
            raise RuntimeError("not a PE executable: " + str(path))
        source.seek(struct.unpack_from("<I", dos, 0x3c)[0])
        header = source.read(6)
        if len(header) != 6 or header[:4] != b"PE\0\0":
            raise RuntimeError("invalid PE header: " + str(path))
        return struct.unpack_from("<H", header, 4)[0]


def verify_prefix():
    if not PREFIX.is_dir():
        raise RuntimeError("existing private Wine prefix is absent: " + str(PREFIX))
    registry = PREFIX / "system.reg"
    header = registry.open("rb").read(4096).decode("ascii", "ignore")
    match = re.search(r"(?m)^#arch=(\S+)", header)
    if not match or match.group(1).lower() != "win32":
        raise RuntimeError("existing Wine prefix is not marked #arch=win32")
    return dict(path=str(PREFIX), registry_arch=match.group(1))


def verify_and_unpack(archive, out):
    if not archive.is_file() or sha256(archive) != ARCHIVE_SHA256:
        raise RuntimeError("Wine archive SHA256 differs from the frozen Windows artifact")
    with tarfile.open(str(archive), "r:gz") as bundle:
        entries = bundle.getmembers()
        if tuple(entry.name for entry in entries) != MEMBERS:
            raise RuntimeError("Wine archive has unexpected members or order")
        if any(not entry.isfile() or entry.size > MAX_MEMBER_BYTES for entry in entries):
            raise RuntimeError("Wine archive has a non-file or oversized member")
        manifest_stream = bundle.extractfile("manifest.json")
        if manifest_stream is None:
            raise RuntimeError("Wine archive manifest is absent")
        manifest_bytes = manifest_stream.read(MAX_MEMBER_BYTES + 1)
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        if manifest.get("source_commit") != COMMIT or manifest.get("target") != "i686-pc-windows-msvc":
            raise RuntimeError("Wine archive source commit or target differs")
        listed = manifest.get("files")
        if not isinstance(listed, list) or tuple(row.get("archive_path") for row in listed) != MEMBERS[:-1]:
            raise RuntimeError("Wine archive manifest file list differs")
        (out / "bin").mkdir()
        extracted = []
        for row in listed:
            name = row["archive_path"]
            destination = out / name
            stream = bundle.extractfile(name)
            if stream is None:
                raise RuntimeError("missing Wine executable: " + name)
            with destination.open("wb") as output:
                shutil.copyfileobj(stream, output, length=1024 * 1024)
            if destination.stat().st_size != row.get("size_bytes") or sha256(destination) != row.get("sha256"):
                raise RuntimeError("Wine executable hash or size differs: " + name)
            machine = pe_machine(destination)
            if machine != 0x014c or row.get("pe_machine_hex") != "0x014c":
                raise RuntimeError("Wine executable is not PE I386: " + name)
            extracted.append(dict(role=row.get("role"), path=str(destination),
                                  sha256=row["sha256"], size_bytes=destination.stat().st_size,
                                  pe_machine_hex="0x014c"))
        (out / "manifest.json").write_bytes(manifest_bytes)
    return manifest, extracted


def stop_owned(child, log):
    if child.poll() is not None:
        return
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    try:
        child.wait(timeout=15)
    except subprocess.TimeoutExpired:
        log.write(b"owned process group did not exit within cleanup deadline\n")
        raise RuntimeError("owned process group did not exit within cleanup deadline")


def command(argv, out, label, env, timeout, expected_passed=None):
    if timeout > 300:
        raise ValueError("Wine step exceeds the 300-second bound")
    print(label, flush=True)
    started = time.monotonic()
    log_path = out / (label + ".log")
    result_path = out / (label + ".result.json")
    child = None
    timed_out = False
    error = None
    code = None
    with log_path.open("wb") as log:
        try:
            child = subprocess.Popen(argv, cwd=str(out), env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True, close_fds=True)
            write_json(out / (label + ".command.json"),
                       dict(argv=argv, pid=child.pid, timeout_seconds=timeout))
            try:
                code = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                raise RuntimeError(label + " exceeded its " + str(timeout) + "-second deadline")
        except BaseException as failure:
            error = repr(failure)
        finally:
            if child is not None:
                try:
                    stop_owned(child, log)
                except BaseException as cleanup_failure:
                    detail = "owned-process cleanup failed: " + repr(cleanup_failure)
                    error = detail if error is None else error + "; " + detail
    output = log_path.read_text(encoding="utf-8", errors="replace")
    passed = None
    if expected_passed is not None:
        matches = re.findall(r"test result: ok\.\s+(\d+) passed;\s+0 failed", output)
        if len(matches) != 1:
            error = error or (label + " did not report one passing Rust test summary")
        else:
            passed = int(matches[0])
            if expected_passed >= 0 and passed != expected_passed:
                error = error or (label + " passed " + str(passed) + " tests, expected " + str(expected_passed))
            if expected_passed < 0 and passed == 0:
                error = error or (label + " selected no regression tests")
    result = dict(label=label, command=argv, exit_code=code, timed_out=timed_out,
                  elapsed_seconds=time.monotonic() - started, passed_tests=passed, error=error)
    write_json(result_path, result)
    if error or code != 0:
        raise RuntimeError(label + " failed; see " + str(log_path) + " and " + str(result_path))
    return result


def work(archive, out, wine):
    started = time.monotonic()
    failure = None
    results = []
    manifest = None
    extracted = None
    try:
        prefix = verify_prefix()
        manifest, extracted = verify_and_unpack(archive, out)
        if not SHIM.is_file() or sha256(SHIM) != SHIM_SHA256:
            raise RuntimeError("existing app-local ProcessPrng shim SHA256 differs")
        shim_copy = out / "bin" / "bcryptprimitives.dll"
        shutil.copyfile(str(SHIM), str(shim_copy))
        if sha256(shim_copy) != SHIM_SHA256:
            raise RuntimeError("copied app-local ProcessPrng shim SHA256 differs")
        env = dict(os.environ)
        env.update(WINEPREFIX=str(PREFIX), WINEARCH="win32", WINEDEBUG="-all")
        wine_path = shutil.which(wine)
        if wine_path is None:
            raise RuntimeError("Wine executable is unavailable: " + wine)
        host = dict(platform=platform.platform(), machine=platform.machine(), python=sys.version,
                    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    wine_executable=wine_path, prefix=prefix, display=env.get("DISPLAY"),
                    archive=str(archive), archive_sha256=ARCHIVE_SHA256,
                    source_commit=COMMIT, compiler=manifest.get("rustc"),
                    cargo=manifest.get("cargo"), shim_source=str(SHIM),
                    shim_sha256=SHIM_SHA256, executables=extracted)
        write_json(out / "host.json", host)
        results.append(command([wine_path, "--version"], out, "wine-version", env, 30))
        lib = str(out / MEMBERS[0])
        tests = [
            ("tcp-tls-public", str(out / MEMBERS[1]), None, 20),
            ("tcp-tls-api-public", str(out / MEMBERS[2]), None, 3),
            ("standalone-owner", lib, "standalone_tls", 10),
            ("registry-tls", lib, "registry::tests::tls_", -1),
            ("tcp-io-tls", lib, "tcp::io::tests::tls_", -1),
            ("worker-capacity", lib, "native_tls::worker::tests::", -1),
        ]
        for label, executable, selector, expected in tests:
            argv = [wine_path, executable]
            if selector:
                argv.append(selector)
            argv.extend(["--test-threads=1", "--nocapture"])
            results.append(command(argv, out, label, env, 300, expected))
    except BaseException as error:
        failure = repr(error)
    result = dict(status="failed" if failure else "passed", failure=failure,
                  source_commit=COMMIT, archive_sha256=ARCHIVE_SHA256,
                  elapsed_seconds=time.monotonic() - started,
                  results=results, pid=os.getpid())
    write_json(out / "result.json", result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("launch", "work"))
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=LAB)
    parser.add_argument("--wine", default="/usr/bin/wine")
    args = parser.parse_args()
    archive = args.archive.resolve()
    out = args.out.resolve()
    if out != LAB:
        parser.error("this frozen run uses only " + str(LAB))
    if args.mode == "launch":
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, "-B", str(Path(__file__).resolve()), "work",
                "--archive", str(archive), "--out", str(out), "--wine", args.wine]
        with (out / "job.log").open("wb") as log:
            child = None
            try:
                child = subprocess.Popen(argv, cwd=str(out), stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=log, start_new_session=True,
                                         close_fds=True)
                record = dict(pid=child.pid, command=argv, out=str(out))
                write_json(out / "launch.json", record)
            except BaseException:
                if child is not None:
                    stop_owned(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0
    if not out.is_dir():
        parser.error("the fresh Wine lab must be created by launch")
    return work(archive, out, args.wine)


if __name__ == "__main__":
    def terminate(_signal, _frame):
        raise SystemExit("Wine runner received SIGTERM")
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
