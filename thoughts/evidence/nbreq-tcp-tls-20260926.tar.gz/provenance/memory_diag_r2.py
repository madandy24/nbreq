"""Bounded ARM loopback diagnosis of the isolated Python TLS 1.2 fixture.

Uses the same certificate generator and server context as memory rerun r2, but
replaces the Rust client with a restricted LibreSSL CLI client. Private keys
stay in the fresh diagnostic directory and are removed at completion.
"""

import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import ssl
import subprocess
import sys
import time


HELPER = Path("/private/tmp/nbreq-tcp-tls-bede85c32a41-memory-r2/tools/tcp-tls-probe/memory.py")
HELPER_SHA256 = "86cf2317a4de52c57c2d0e80c768682965a5a79868cc72f67a5ec3aefbd86e9a"
OUT = Path("/private/tmp/nbreq-tcp-tls-bede85c32a41-openssl-diagnostic-r2")
CIPHER = "ECDHE-ECDSA-AES128-GCM-SHA256"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def stop_owned(child):
    if child is None or child.poll() is not None:
        return
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait(timeout=5)


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    result = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  python=sys.version, python_ssl=ssl.OPENSSL_VERSION,
                  helper=str(HELPER), cipher=CIPHER, group="prime256v1",
                  signature_algorithms="CLI default; no -sigalgs option on this LibreSSL",
                  handshake_success=False)
    fixture = None
    child = None
    try:
        if not HELPER.is_file() or sha256(HELPER) != HELPER_SHA256:
            raise RuntimeError("isolated memory helper hash differs")
        result["helper_sha256"] = sha256(HELPER)
        spec = importlib.util.spec_from_file_location("isolated_memory_helper", str(HELPER))
        memory = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(memory)
        openssl = shutil.which("openssl")
        if openssl is None:
            raise RuntimeError("OpenSSL CLI unavailable")
        result["openssl_executable"] = openssl
        version = subprocess.run([openssl, "version"], capture_output=True, text=True,
                                 timeout=5, check=True)
        result["openssl_cli_version"] = version.stdout.strip()
        certs = memory.certificates(openssl, OUT)
        result["ca_pem_sha256"] = sha256(certs / "ca.pem")
        result["leaf_pem_sha256"] = sha256(certs / "leaf.pem")

        fixture = memory.LocalTlsServer(certs, 1, "1.2")
        fixture.start()
        argv = [openssl, "s_client", "-connect", fixture.address, "-tls1_2",
                "-cipher", CIPHER, "-groups", "prime256v1",
                "-CAfile", str(certs / "ca.pem"),
                "-verify_return_error"]
        result["client_command"] = argv
        with (OUT / "openssl-client.log").open("wb") as log:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True,
                                     close_fds=True)
            deadline = time.monotonic() + 10
            while fixture.handshakes == 0 and fixture.error is None and child.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError("restricted OpenSSL ClientHello did not complete in 10 seconds")
                time.sleep(0.02)
            result["handshakes_before_stop"] = fixture.handshakes
            result["server_negotiated_versions"] = list(fixture.negotiated_versions)
            result["server_error_before_stop"] = fixture.error
            try:
                fixture.stop()
            finally:
                fixture = None
            try:
                result["client_exit_code"] = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                raise TimeoutError("OpenSSL client did not exit in five seconds")
        result["client_log"] = str(OUT / "openssl-client.log")
        result["handshake_success"] = (result["handshakes_before_stop"] == 1 and
                                       result["server_negotiated_versions"] == ["TLSv1.2"])
        result["status"] = "observed"
    except BaseException as error:
        result["status"] = "failed"
        result["failure"] = repr(error)
    finally:
        cleanup = []
        try:
            stop_owned(child)
        except BaseException as error:
            cleanup.append("OpenSSL child: " + repr(error))
        if fixture is not None:
            try:
                fixture.stop()
            except BaseException as error:
                cleanup.append("fixture: " + repr(error))
        for name in ("ca.key", "leaf.key"):
            path = OUT / "certs" / name
            try:
                if path.exists():
                    path.unlink()
            except BaseException as error:
                cleanup.append("private key cleanup: " + repr(error))
        if cleanup:
            result["cleanup_errors"] = cleanup
            result["status"] = "failed"
        write_json(OUT / "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["status"] == "observed" and result["handshake_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
