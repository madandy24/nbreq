"""Retain bounded TLS gate evidence, excluding build trees and fixture certificates/keys."""
import argparse
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    pack = sub.add_parser('pack')
    pack.add_argument('--out', type=Path, required=True)
    pack.add_argument('--archive', type=Path, required=True)
    emit = sub.add_parser('emit')
    emit.add_argument('--archive', type=Path, required=True)
    emit.add_argument('--part', type=int, required=True)
    args = parser.parse_args()
    archive = args.archive.resolve()
    if args.mode == 'emit':
        data = archive.read_bytes()
        size = 256 * 1024
        parts = (len(data) + size - 1) // size
        if not 0 <= args.part < parts:
            parser.error('part is outside archive range')
        chunk = data[args.part * size:(args.part + 1) * size]
        print(json.dumps(dict(part=args.part, parts=parts,
                              sha256=hashlib.sha256(data).hexdigest(),
                              chunk_sha256=hashlib.sha256(chunk).hexdigest(),
                              base64=base64.b64encode(chunk).decode('ascii'))))
        return
    folder = args.out.resolve()
    if archive.exists():
        parser.error('preserve earlier evidence; archive must not exist')
    result = json.loads((folder / 'result.json').read_text(encoding='utf-8'))
    selected = []
    for current, dirs, files in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if not d.startswith('build')
                         and d not in ('certs', '__pycache__'))
        for name in sorted(files):
            path = Path(current) / name
            if path.suffix not in ('.json', '.jsonl', '.log', '.txt'):
                continue
            if path.is_symlink() or folder not in path.resolve().parents:
                raise RuntimeError('unexpected evidence path: ' + str(path))
            if path.stat().st_size > 32 * 1024 * 1024:
                raise RuntimeError('oversize evidence file: ' + str(path))
            selected.append((path, path.relative_to(folder).as_posix()))
    manifest = dict(result=result, files={name: hashlib.sha256(path.read_bytes()).hexdigest()
                                        for path, name in selected})
    payload = json.dumps(manifest, indent=2).encode('utf-8')
    with tarfile.open(archive, 'x:gz', compresslevel=9) as bundle:
        for path, name in selected:
            bundle.add(path, arcname=name, recursive=False)
        entry = tarfile.TarInfo('evidence-manifest.json')
        entry.size = len(payload)
        bundle.addfile(entry, io.BytesIO(payload))
    print(json.dumps(dict(archive=str(archive), bytes=archive.stat().st_size,
                          sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                          files=len(selected), result=result)))


if __name__ == '__main__':
    main()
