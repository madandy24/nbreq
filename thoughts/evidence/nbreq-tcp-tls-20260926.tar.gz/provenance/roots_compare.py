"""Lab-only Wine comparison of pinned verifier constructor and existing HTTPS roots.

All three diagnostic commands are independent, bounded observations. This
runner does not change trust, the existing Wine prefix, or NBReq source.
"""

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import tarfile
import time


LAB = Path("/tmp/nbreq-tcp-tls-bede85c-wine-roots")
RUNNER = Path("/tmp/nbreq-tcp-tls-bede85c-wine.py")
RUNNER_SHA256 = "8aadd475bf99137fc4d2931463bcc4bb2e02aa4ba617ceb6dc8fa700f40e1ab8"
MAIN_ARCHIVE = Path("/tmp/nbreq-tcp-tls-bede85c-i686-wine.tar.gz")
CONSTRUCTOR_ARCHIVE = Path("/tmp/nbreq-tcp-tls-verifier-constructor-i686.tar.gz")
CONSTRUCTOR_SHA256 = "9e473fdc870d099670bde608ac158ffec747926793d5858b07efec1afbbe4946"
ROOTS_ARCHIVE = Path("/tmp/nbreq-tcp-tls-roots-bede85c-i686.tar.gz")
ROOTS_SHA256 = "559f54244b3797bc1e429384f2237210a9664c97d8da66172428ab06fd5fc402"
STOP_REQUESTED = False


def load_runner(path):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != RUNNER_SHA256:
        raise RuntimeError("approved Wine supervisor SHA256 differs")
    spec = importlib.util.spec_from_file_location("nbreq_wine_supervisor", str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_extra(runner, archive, expected_sha, out, expected_member):
    if not archive.is_file() or runner.sha256(archive) != expected_sha:
        raise RuntimeError("diagnostic archive SHA256 differs: " + str(archive))
    with tarfile.open(str(archive), "r:gz") as bundle:
        members = bundle.getmembers()
        if ([member.name for member in members]
                != [expected_member, "manifest.json"]
                or any(not member.isfile() or member.size > runner.MAX_MEMBER_BYTES
                       for member in members)):
            raise RuntimeError("diagnostic archive members differ: " + str(archive))
        manifest_stream = bundle.extractfile("manifest.json")
        binary_stream = bundle.extractfile(expected_member)
        if manifest_stream is None or binary_stream is None:
            raise RuntimeError("diagnostic archive member missing")
        manifest = json.loads(manifest_stream.read(runner.MAX_MEMBER_BYTES + 1))
        if (manifest.get("source_commit") != runner.COMMIT
                or manifest.get("target") != "i686-pc-windows-msvc"
                or manifest.get("file", {}).get("archive_path") != expected_member):
            raise RuntimeError("diagnostic manifest source, target, or member differs")
        data = binary_stream.read(runner.MAX_MEMBER_BYTES + 1)
        if (len(data) != manifest["file"].get("size_bytes")
                or hashlib.sha256(data).hexdigest() != manifest["file"].get("sha256")):
            raise RuntimeError("diagnostic PE size or SHA256 differs")
        binary = out / expected_member
        binary.parent.mkdir(parents=True, exist_ok=True)
        binary.write_bytes(data)
        if runner.pe_machine(binary) != 0x014c:
            raise RuntimeError("diagnostic executable is not PE I386")
        runner.write_json(out / (binary.stem + ".manifest.json"), manifest)
        return dict(path=str(binary), sha256=runner.sha256(binary),
                    size_bytes=len(data), pe_machine_hex="0x014c", manifest=manifest)


def one_step(runner, argv, out, label, env, timeout, expected_passed):
    try:
        return runner.command(argv, out, label, env, timeout, expected_passed)
    except Exception as error:
        record = out / (label + ".result.json")
        if record.is_file():
            return json.loads(record.read_text(encoding="utf-8"))
        result = dict(label=label, command=argv, exit_code=None, timed_out=False,
                      passed_tests=None, error=repr(error))
        runner.write_json(record, result)
        return result


def work(runner, main_archive, constructor_archive, roots_archive, out, wine):
    started = time.monotonic()
    failure = None
    results = []
    constructor_output = None
    try:
        prefix = runner.verify_prefix()
        main_manifest, main_files = runner.verify_and_unpack(main_archive, out)
        constructor = verify_extra(runner, constructor_archive, CONSTRUCTOR_SHA256,
                                   out, "bin/verifier-constructor.exe")
        roots = verify_extra(runner, roots_archive, ROOTS_SHA256,
                             out, "bin/tls_roots-tests.exe")
        if not runner.SHIM.is_file() or runner.sha256(runner.SHIM) != runner.SHIM_SHA256:
            raise RuntimeError("existing ProcessPrng shim SHA256 differs")
        for directory in (out / "bin",):
            target = directory / "bcryptprimitives.dll"
            shutil.copyfile(str(runner.SHIM), str(target))
            if runner.sha256(target) != runner.SHIM_SHA256:
                raise RuntimeError("app-local ProcessPrng shim copy SHA256 differs")
        wine_path = shutil.which(wine)
        if wine_path is None:
            raise RuntimeError("Wine executable is unavailable: " + wine)
        env = dict(os.environ)
        env.update(WINEPREFIX=str(runner.PREFIX), WINEARCH="win32", WINEDEBUG="-all")
        runner.write_json(out / "host.json", dict(
            platform=platform.platform(), machine=platform.machine(), python=sys.version,
            started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            wine_executable=wine_path, prefix=prefix, display=env.get("DISPLAY"),
            source_commit=runner.COMMIT, approved_supervisor=str(RUNNER),
            approved_supervisor_sha256=RUNNER_SHA256,
            archives=[dict(path=str(main_archive), sha256=runner.ARCHIVE_SHA256),
                      dict(path=str(constructor_archive), sha256=CONSTRUCTOR_SHA256),
                      dict(path=str(roots_archive), sha256=ROOTS_SHA256)],
            main_compiler=main_manifest.get("rustc"), main_cargo=main_manifest.get("cargo"),
            main_executables=main_files, constructor=constructor, roots=roots,
            shim_sha256=runner.SHIM_SHA256,
        ))
        steps = [
            ("verifier-constructor", [wine_path, constructor["path"]], 60, None),
            ("https-additional-roots-4", [wine_path, roots["path"],
                                          "--test-threads=1", "--nocapture"], 300, 4),
            ("tcp-io-regressions-13", [wine_path, str(out / runner.MEMBERS[0]),
                                       "tcp::io::review_regressions::",
                                       "--test-threads=1", "--nocapture"], 300, 13),
        ]
        for label, argv, timeout, expected in steps:
            if STOP_REQUESTED:
                raise InterruptedError("diagnostic runner was asked to stop")
            result = one_step(runner, argv, out, label, env, timeout, expected)
            if label == "verifier-constructor":
                output = (out / (label + ".log")).read_text(
                    encoding="utf-8", errors="replace")
                lines = output.splitlines()
                keys = ("webpki_root_store=", "platform_constructor=",
                        "extra_root_constructor=")
                if any(sum(line.startswith(key) for line in lines) != 1 for key in keys):
                    result["error"] = "constructor result markers missing or repeated"
                    runner.write_json(out / (label + ".result.json"), result)
                constructor_output = {key[:-1]: next(
                    (line[len(key):] for line in lines if line.startswith(key)), None)
                    for key in keys}
                runner.write_json(out / "constructor-observation.json", constructor_output)
            results.append(result)
            runner.write_json(out / "progress.json", dict(steps=results))
            if STOP_REQUESTED:
                raise InterruptedError("diagnostic runner was asked to stop")
    except BaseException as error:
        failure = repr(error)
    failed_steps = [row["label"] for row in results if row.get("error") or row.get("exit_code") != 0]
    result = dict(status="stopped" if STOP_REQUESTED else ("setup_failed" if failure else "observed"),
                  setup_failure=failure, attempted_steps=len(results), failed_steps=failed_steps,
                  constructor_observation=constructor_output,
                  source_commit=runner.COMMIT, elapsed_seconds=time.monotonic() - started,
                  results=results, pid=os.getpid())
    runner.write_json(out / "result.json", result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("launch", "work"))
    parser.add_argument("--main-archive", type=Path, default=MAIN_ARCHIVE)
    parser.add_argument("--constructor-archive", type=Path, default=CONSTRUCTOR_ARCHIVE)
    parser.add_argument("--roots-archive", type=Path, default=ROOTS_ARCHIVE)
    parser.add_argument("--runner", type=Path, default=RUNNER)
    parser.add_argument("--out", type=Path, default=LAB)
    parser.add_argument("--wine", default="/usr/bin/wine")
    args = parser.parse_args()
    out = args.out.resolve()
    if out != LAB:
        parser.error("this comparison uses only the fixed fresh lab " + str(LAB))
    main_archive = args.main_archive.resolve()
    constructor_archive = args.constructor_archive.resolve()
    roots_archive = args.roots_archive.resolve()
    runner_path = args.runner.resolve()
    runner = load_runner(runner_path)
    if args.mode == "launch":
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, "-B", str(Path(__file__).resolve()), "work",
                "--main-archive", str(main_archive),
                "--constructor-archive", str(constructor_archive),
                "--roots-archive", str(roots_archive),
                "--runner", str(runner_path), "--out", str(out), "--wine", args.wine]
        with (out / "job.log").open("wb") as log:
            child = None
            try:
                child = subprocess.Popen(argv, cwd=str(out), stdin=subprocess.DEVNULL,
                                         stdout=log, stderr=log, start_new_session=True,
                                         close_fds=True)
                record = dict(pid=child.pid, command=argv, out=str(out))
                runner.write_json(out / "launch.json", record)
            except BaseException:
                if child is not None:
                    runner.stop_owned(child, log)
                raise
        print(json.dumps(record), flush=True)
        return 0
    if not out.is_dir():
        parser.error("the fresh comparison lab must be created by launch")
    return work(runner, main_archive, constructor_archive, roots_archive, out, args.wine)


if __name__ == "__main__":
    def terminate(_signal, _frame):
        global STOP_REQUESTED
        STOP_REQUESTED = True
        raise SystemExit("comparison runner received SIGTERM")
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
