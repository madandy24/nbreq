"""Bounded frozen-source TCP TLS platform gate; no publication or deployment."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temporary.replace(path)


def command(argv, cwd, out, label, env, timeout):
    print(label, flush=True)
    with (out / (label + '.log')).open('wb') as log:
        child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=os.name != 'nt')
        try:
            write(out / 'command.json', dict(label=label, pid=child.pid, command=argv,
                                           timeout_seconds=timeout))
            code = child.wait(timeout=timeout)
        except BaseException:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'],
                               stdout=log, stderr=subprocess.STDOUT, timeout=15)
            else:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            child.wait(timeout=15)
            raise
    write(out / (label + '.result.json'), dict(command=argv, exit_code=code))
    if code:
        raise RuntimeError(label + ' failed with exit ' + str(code))


def verify_source(root):
    manifest_path = root / 'tls-source.json'
    source = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        path = (root / name).resolve()
        if root not in path.parents or not path.is_file():
            raise RuntimeError('invalid manifest path: ' + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('source mismatch: ' + name)
    return source, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['launch', 'work'])
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--memory', action='store_true')
    parser.add_argument('--memory-tls-version', choices=['1.2', '1.3'], default='1.2')
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    if args.mode == 'launch':
        out.mkdir(parents=True, exist_ok=False)
        argv = [sys.executable, '-B', str(Path(__file__).resolve()), 'work',
                '--root', str(root), '--out', str(out)]
        if args.memory:
            argv.extend(['--memory', '--memory-tls-version', args.memory_tls_version])
        if args.live:
            argv.append('--live')
        with (out / 'job.log').open('wb') as log:
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                     start_new_session=os.name != 'nt', close_fds=True)
        record = dict(pid=child.pid, command=argv, out=str(out))
        write(out / 'launch.json', record)
        print(json.dumps(record), flush=True)
        return 0

    started = time.monotonic()
    source = None
    failure = None
    binaries = {}
    try:
        source, manifest = verify_source(root)
        write(out / 'host.json', dict(platform=platform.platform(), machine=platform.machine(),
                                     python=sys.version, source=source, commit=manifest['commit'],
                                     started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        env = dict(os.environ)
        env['PATH'] = str(Path.home() / '.cargo' / 'bin') + os.pathsep + env.get('PATH', '')
        env['RUSTUP_TOOLCHAIN'] = 'stable'
        env['CARGO_TARGET_DIR'] = str(out / 'build')
        env['CARGO_BUILD_JOBS'] = '2'
        cargo = str(Path.home() / '.cargo' / 'bin' / 'cargo')
        rustc = str(Path(cargo).with_name('rustc'))
        command([rustc, '+stable', '-vV'], root, out, 'stable-compiler', env, 30)
        command([cargo, '+stable', '--version'], root, out, 'stable-cargo', env, 30)
        command([cargo, '+stable', 'fetch', '--locked'], root, out, 'fetch', env, 300)
        command([cargo, '+stable', 'run', '--locked', '--manifest-path', 'tools/xtask/Cargo.toml',
                 '--', 'verify', '--offline'], root, out, 'stable-verify', env, 1800)
        command([cargo, '+stable', 'clippy', '--locked', '--manifest-path',
                 'tools/tcp-tls-probe/Cargo.toml', '--all-targets', '--', '-D', 'warnings'],
                root, out, 'probe-clippy', env, 600)
        command([cargo, '+stable', 'build', '--locked', '--release', '--manifest-path',
                 'tools/tcp-tls-probe/Cargo.toml'], root, out, 'probe-release', env, 900)
        binary = out / 'build' / 'release' / 'nbreq-tcp-tls-probe'
        binaries['probe'] = dict(path=str(binary), sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
        for example in ['C04-tcp-tls', 'C05-tcp-starttls']:
            command([cargo, '+stable', 'run', '--locked', '--offline', '--example', example],
                    root, out, example, env, 90)
        env['RUSTUP_TOOLCHAIN'] = '1.85.0'
        command([rustc, '+1.85.0', '-vV'], root, out, 'msrv-compiler', env, 30)
        command([cargo, '+1.85.0', 'test', '--locked', '--offline', '--all-features'],
                root, out, 'msrv-tests', env, 1200)
        env['RUSTUP_TOOLCHAIN'] = 'stable'
        if args.memory:
            command([sys.executable, '-B', 'tools/tcp-tls-probe/memory.py', '--binary',
                     str(binary), '--out', str(out / 'memory'),
                     '--tls-version', args.memory_tls_version],
                    root, out, 'memory-observation', env, 420)
        if args.live:
            for protocol, port in [('imaps', '993'), ('smtp', '25')]:
                command([str(binary), protocol, 'cavesvr3.caverock.com', port],
                        root, out, 'live-' + protocol, env, 60)
        final_source, _ = verify_source(root)
        if final_source != source:
            raise RuntimeError('source manifest changed during platform gate')
    except BaseException as error:
        failure = repr(error)
    result = dict(status='failed' if failure else 'passed', failure=failure, source=source,
                  elapsed_seconds=time.monotonic() - started, binaries=binaries, pid=os.getpid())
    write(out / 'result.json', result)
    print(json.dumps(result), flush=True)
    return 1 if failure else 0


if __name__ == '__main__':
    raise SystemExit(main())
