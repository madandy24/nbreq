"""Freeze an explicit NBReq-only source whitelist for authorized TLS test hosts."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
lab = Path(__file__).resolve().parent
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip():
    raise SystemExit('Freeze requires a clean committed source tree')
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
prefixes = ('src/', 'tests/', 'examples/', 'support/', 'tools/xtask/', 'tools/tcp-tls-probe/')
exact = {'Cargo.toml', 'Cargo.lock', 'README.md', 'SECURITY.md', 'THIRD_PARTY_LICENSES.html',
         'LICENSE-APACHE', 'LICENSE-MIT', 'docs/getting-started.md', 'docs/migrating-to-0.2.md',
         'docs/tcp-tls.md', 'tools/release-soak/process_sample.py'}
inputs = {}
for name in sorted(tracked):
    if not name or not (name in exact or name.startswith(prefixes)):
        continue
    path = (root / name).resolve()
    if root not in path.parents or path.is_symlink() or not path.is_file():
        raise RuntimeError('unexpected source path: ' + name)
    if any(part in ('target', '__pycache__', '.git', '.codex', '.agents') for part in Path(name).parts):
        raise RuntimeError('unexpected generated/private source path: ' + name)
    if path.suffix in ('.key', '.pfx', '.p12'):
        raise RuntimeError('private key material is not an allowed source file: ' + name)
    inputs[name] = path.read_bytes()
for source, name in [('platform.py', 'tls-platform.py'), ('collect.py', 'tls-collect.py')]:
    inputs[name] = (lab / source).read_bytes()
manifest = dict(commit=commit, files={name: hashlib.sha256(data).hexdigest()
                                   for name, data in inputs.items()})
payload = json.dumps(manifest, indent=2).encode('utf-8')
identity = hashlib.sha256(payload).hexdigest()
archive = lab / ('nbreq-tcp-tls-' + commit[:12] + '-source.tar.gz')
with tarfile.open(archive, 'x:gz', compresslevel=9) as bundle:
    for name, data in list(inputs.items()) + [('tls-source.json', payload)]:
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        bundle.addfile(entry, io.BytesIO(data))
summary = dict(commit=commit, source=identity, archive=str(archive), files=len(inputs),
               source_bytes=sum(map(len, inputs.values())), archive_bytes=archive.stat().st_size,
               sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(lab / (commit[:12] + '-source.json')).write_bytes(payload)
(lab / (commit[:12] + '-snapshot.json')).write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
