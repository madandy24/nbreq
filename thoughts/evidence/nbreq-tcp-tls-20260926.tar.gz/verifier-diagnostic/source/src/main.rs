use std::error::Error;
use std::sync::Arc;

use rcgen::{BasicConstraints, CertificateParams, DnType, IsCa, KeyPair, KeyUsagePurpose};

fn main() -> Result<(), Box<dyn Error>> {
    // Match the library fixture's CA shape. The private key never leaves this process.
    let key = KeyPair::generate()?;
    let mut params = CertificateParams::new(Vec::<String>::new())?;
    params.is_ca = IsCa::Ca(BasicConstraints::Unconstrained);
    params
        .distinguished_name
        .push(DnType::CommonName, "NBReq TCP TLS fixture CA");
    params.key_usages = vec![KeyUsagePurpose::KeyCertSign, KeyUsagePurpose::CrlSign];
    let root = params.self_signed(&key)?;

    let mut parsed = rustls::RootCertStore::empty();
    parsed.add(root.der().clone())?;
    println!("fixture=P256 rcgen-0.13.2 CA, in-memory only");
    println!("webpki_root_store=accepted entries={}", parsed.len());

    let provider = Arc::new(rustls::crypto::ring::default_provider());
    let platform = rustls_platform_verifier::Verifier::new(Arc::clone(&provider));
    println!("platform_constructor={:?}", platform.as_ref().map(|_| ()));
    let extra = rustls_platform_verifier::Verifier::new_with_extra_roots(
        [root.der().clone()],
        provider,
    );
    println!("extra_root_constructor={:?}", extra.as_ref().map(|_| ()));
    Ok(())
}
