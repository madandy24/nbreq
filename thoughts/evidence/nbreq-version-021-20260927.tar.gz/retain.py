from pathlib import Path
import hashlib, json, platform, subprocess, tarfile

lab = Path(__file__).resolve().parent
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert commit == '9e810211d700ff747a01ed727d8fe3d83f46fef6'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
result = json.loads((lab/'package/result.json').read_text())
assert result['status'] == 'passed' and result['source_commit'] == commit
packages = json.loads((lab/'package/packages.json').read_text())
for name, record in packages['packages'].items():
    payload = Path(record['path']).read_bytes()
    assert hashlib.sha256(payload).hexdigest() == record['sha256']
    with tarfile.open(record['path']) as archive:
        prefix = name.removesuffix('.crate') + '/'
        assert all(m.isfile() for m in archive.getmembers())
        observed = {m.name.removeprefix(prefix): hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive.getmembers()}
        assert observed == record['files']

changed = subprocess.check_output(['git', 'diff', '--name-only', '6719bcb', commit], cwd=root, text=True).splitlines()
snapshot = lab/'metadata-source'
for relative in changed:
    if relative.startswith('thoughts/'):
        continue
    path = snapshot/relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((root/relative).read_bytes())
(lab/'version-change.patch').write_bytes(subprocess.check_output(['git', 'diff', '6719bcb', commit], cwd=root))
identity = dict(source_commit=commit, platform=platform.platform(), python=platform.python_version(),
                rustc=subprocess.check_output(['rustc', '-Vv'], text=True).strip(),
                cargo=subprocess.check_output(['cargo', '-V'], text=True).strip(),
                scope='Version metadata and pre-documentation package identity rehearsal',
                package_command=['python', '-B', '-X', 'utf8', 'tools/release-consumer/package_candidate.py', '--out', str(lab/'package')],
                limitations=['No runtime or remote-platform suite rerun for metadata changes',
                             'Package verification used explicit local helper overrides; not registry-only acceptance',
                             'User documentation is the next pass; rebuild final release candidate afterwards',
                             'No push, merge, publication or GDS changes'])
(lab/'identity.json').write_text(json.dumps(identity, indent=2), encoding='utf-8')
files = [p for p in lab.iterdir() if p.is_file()]
files += [p for p in (lab/'package').iterdir() if p.is_file()]
files += [p for p in snapshot.rglob('*') if p.is_file()]
files += [p for p in (lab/'consumer').rglob('*') if p.is_file() and 'target' not in p.relative_to(lab/'consumer').parts]
members = {p.relative_to(lab).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
destination = root/'thoughts/evidence/nbreq-version-021-20260927.tar.gz'
assert not destination.exists()
with tarfile.open(destination, 'w:gz') as archive:
    for p in sorted(files):
        archive.add(p, arcname=p.relative_to(lab).as_posix(), recursive=False)
with tarfile.open(destination) as archive:
    entries = archive.getmembers()
    assert all(m.isfile() for m in entries) and len(entries) == len(members)
    assert {m.name: hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in entries} == members
index = dict(archive=destination.name, bytes=destination.stat().st_size, regular_members=len(members),
             sha256=hashlib.sha256(destination.read_bytes()).hexdigest(), identity=identity,
             package_result=result, packages={k: {field: value for field, value in v.items() if field not in ['files', 'relative_links']} | dict(files=len(v['files']), relative_links=len(v['relative_links'])) for k,v in packages['packages'].items()},
             excluded='Build outputs and .crate archives; package member hashes, logs and metadata sources retained', members=members)
(root/'thoughts/evidence/nbreq_version_021_artifacts.json').write_text(json.dumps(index, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:index[k] for k in ['archive','bytes','regular_members','sha256','packages']},indent=2))
