from pathlib import Path
import subprocess, json, hashlib, tomllib, shutil, os, ast
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab = Path(__file__).parent
env = dict(os.environ, CARGO_TARGET_DIR=str(lab/'build'))
records = []
def run(label, command, cwd=root):
    result = subprocess.run(command,cwd=cwd,env=env,capture_output=True,timeout=180)
    (lab/(label+'.stdout.log')).write_bytes(result.stdout)
    (lab/(label+'.stderr.log')).write_bytes(result.stderr)
    records.append(dict(label=label,command=command,cwd=str(cwd),exit=result.returncode))
    (lab/'results.json').write_text(json.dumps(records,indent=2))
    print(label, result.returncode, flush=True)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    return result.stdout
tracked = subprocess.check_output(['git','ls-files','*Cargo.toml','*Cargo.lock'],cwd=root,text=True).splitlines()
inventory = []
for p in tracked:
    data = (root/p).read_bytes()
    parsed = tomllib.loads(data.decode())
    inventory.append(dict(path=p,sha256=hashlib.sha256(data).hexdigest(),package=parsed.get('package')))
(lab/'manifest-lock-inventory.json').write_text(json.dumps(inventory,indent=2))
for item in json.loads((lab/'edits.json').read_text()):
    p = item['path']
    if not p.endswith('Cargo.lock'): continue
    old = tomllib.loads(subprocess.check_output(['git','show','HEAD:'+p],cwd=root).decode())
    new = tomllib.loads((root/p).read_text())
    for package in old['package']:
        if package['name'] == 'nbreq' and 'source' not in package: package['version'] = '0.2.1'
    assert old == new, 'Unrelated lock change: '+p
for p in ['tools/release-consumer/run.py','tools/release-consumer/registry.py','tools/release-consumer/package_candidate.py','tools/f5-observe/compare.py']:
    ast.parse((root/p).read_text(),filename=p)
manifests = ['Cargo.toml','smtp/Cargo.toml','support/darwin/Cargo.toml','support/winpoll/Cargo.toml','fuzz/Cargo.toml','tools/f5-observe/Cargo.toml','tools/f5-observe/memory/Cargo.toml','tools/macos-physical/Cargo.toml','tools/release-soak/Cargo.toml','tools/tcp-tls-probe/Cargo.toml','tools/wine-dns-probe/Cargo.toml']
metadata_summary = []
for p in manifests:
    label = 'metadata-'+p.replace('/','-').replace('.toml','')
    meta = json.loads(run(label,['cargo','metadata','--manifest-path',p,'--locked','--offline','--format-version','1']))
    nbreq = next((x for x in meta['packages'] if x['name']=='nbreq'),None)
    if nbreq:
        assert nbreq['version']=='0.2.1' and nbreq['source'] is None and Path(nbreq['manifest_path'])==root/'Cargo.toml'
    metadata_summary.append(dict(manifest=p,nbreq={k:nbreq[k] for k in ['version','source','manifest_path']} if nbreq else None))
run('smtp-check',['cargo','check','--locked','--offline','-p','nbreq-smtp','--all-targets'])
consumer=lab/'consumer'
consumer.mkdir(exist_ok=True)
for name in ['src','probes']:
    shutil.copytree(root/'tools/release-consumer'/name,consumer/name,dirs_exist_ok=True)
manifest=(root/'tools/release-consumer/Cargo.toml').read_text()
assert 'version = "=0.2.1"' in manifest
(consumer/'Cargo.toml').write_text(manifest+'\n[patch.crates-io]\nnbreq = { path = '+json.dumps(root.as_posix())+' }\n')
oldlock=Path('C:/User/projects/nbreq/target/api-release-review-20260927/consumer-Cargo.lock').read_text()
assert oldlock.count('name = "nbreq"\nversion = "0.2.0"')==1
(consumer/'Cargo.lock').write_text(oldlock.replace('name = "nbreq"\nversion = "0.2.0"','name = "nbreq"\nversion = "0.2.1"'))
meta=json.loads(run('consumer-metadata',['cargo','metadata','--locked','--offline','--format-version','1'],consumer))
nbreq=next(x for x in meta['packages'] if x['name']=='nbreq')
assert nbreq['version']=='0.2.1' and nbreq['source'] is None and Path(nbreq['manifest_path'])==root/'Cargo.toml'
for label,features in [('default',[]),('native',['--no-default-features','--features','native,v020']),('minimal',['--no-default-features','--features','v020']),('test-support',['--features','test-support'])]:
    run('consumer-'+label,['cargo','test','--no-run','--lib','--locked','--offline',*features],consumer)
# Execute only the unchanged legacy-manifest transformation statements from run.py.
tree=ast.parse((root/'tools/release-consumer/run.py').read_text())
replacement_nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='manifest' for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='replace']
scope={'manifest':manifest}
exec(compile(ast.Module(body=replacement_nodes,type_ignores=[]),'legacy-transform','exec'),{},scope)
legacy_manifest=tomllib.loads(scope['manifest'])
assert legacy_manifest['dependencies']['nbreq']['version']=='=0.1.1'
(lab/'legacy-transformed-Cargo.toml').write_text(scope['manifest'])
# Save source hashes after checks, proving Cargo did not refresh tracked dependency graphs.
for record in inventory:
    assert hashlib.sha256((root/record['path']).read_bytes()).hexdigest()==record['sha256'],record['path']
summary=dict(status='passed',base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),metadata=metadata_summary,consumer_identity={k:nbreq[k] for k in ['version','source','manifest_path']},consumer_modes=['default','native','minimal','test-support'],consumer_validation='compile tests only; no runtime rerun',smtp='cargo check --all-targets passed',legacy_baseline='exact =0.1.1 verified by executing run.py transformation',third_party_lock_entries='unchanged structurally',python_scripts='AST syntax passed',limitations=['Windows stable only','Obsolete windows-curl-dll experiment still requests removed curl-pilot; historical lock 0.0.0 unchanged','No publication, registry download or full package rehearsal; root coordinates clean source archive'])
(lab/'summary.json').write_text(json.dumps(summary,indent=2))
files=[p for p in lab.iterdir() if p.is_file() and p.name!='evidence-hashes.json']
(lab/'evidence-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
print('Version validation complete.',flush=True)
