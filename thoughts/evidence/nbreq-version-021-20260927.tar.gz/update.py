from pathlib import Path
import subprocess, re, json, hashlib
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab = Path(__file__).parent
changes = []
def edit(relative, transform):
    path = root / relative
    before = path.read_bytes()
    after = transform(before)
    assert after != before, relative
    path.write_bytes(after)
    changes.append(dict(path=relative, before_sha256=hashlib.sha256(before).hexdigest(), after_sha256=hashlib.sha256(after).hexdigest()))
def exact(relative, old, new):
    def replace(data):
        assert data.count(old) == 1, relative
        return data.replace(old, new)
    edit(relative, replace)
exact('Cargo.toml', b'name = "nbreq"\nversion = "0.2.0"', b'name = "nbreq"\nversion = "0.2.1"')
exact('smtp/Cargo.toml', b'nbreq = { path = "..", version = "0.2.0",', b'nbreq = { path = "..", version = "0.2.1",')
locks = subprocess.check_output(['git','ls-files','*Cargo.lock'],cwd=root,text=True).splitlines()
for relative in locks:
    data = (root/relative).read_bytes()
    if relative.startswith('thoughts/'):
        continue
    marker = b'name = "nbreq"\nversion = "0.2.0"'
    if marker in data:
        exact(relative, marker, b'name = "nbreq"\nversion = "0.2.1"')
exact('tools/release-consumer/Cargo.toml',b'nbreq = { version = "=0.2.0",',b'nbreq = { version = "=0.2.1",')
for relative in ['tools/release-consumer/run.py','tools/release-consumer/registry.py','tools/release-consumer/package_candidate.py']:
    edit(relative, lambda b: b.replace(b'0.2.0',b'0.2.1').replace(b'nbreq-020-',b'nbreq-021-'))
exact('.github/workflows/registry-release.yml',b'nbreq-0.2.0.crate',b'nbreq-0.2.1.crate')
exact('tools/f5-observe/compare.py',b"'0.2.0' if version == 'current'",b"'0.2.1' if version == 'current'")
(lab/'edits.json').write_text(json.dumps(changes,indent=2))
print(json.dumps(changes,indent=2))
