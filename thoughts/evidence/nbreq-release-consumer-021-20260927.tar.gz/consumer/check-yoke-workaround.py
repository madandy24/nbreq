from pathlib import Path
import json,os,shutil,subprocess,tomllib,hashlib
lab=Path(__file__).parent
original=lab/'pre-r5/1.85.0-fresh'
consumer=lab/'diagnostic-yoke-082'
shutil.copytree(original,consumer)
original_hash=hashlib.sha256((original/'Cargo.lock').read_bytes()).hexdigest()
env=dict(os.environ,CARGO_TARGET_DIR=str(lab/'pre-r5/build'))
records=[]
def run(label,args):
    p=subprocess.run(args,cwd=consumer,env=env,capture_output=True,timeout=300)
    (lab/(label+'.stdout.log')).write_bytes(p.stdout)
    (lab/(label+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(label=label,command=args,cwd=str(consumer),exit=p.returncode))
    (lab/'workaround-results.json').write_text(json.dumps(records,indent=2))
    print(label,p.returncode,flush=True)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    return p.stdout
cargo=['rustup','run','1.85.0','cargo']
run('workaround-pin-yoke',cargo+['update','--offline','-p','yoke-derive','--precise','0.8.2'])
graph=json.loads(run('workaround-metadata',cargo+['metadata','--locked','--offline','--all-features','--format-version','1']))
nbreq=next(p for p in graph['packages'] if p['name']=='nbreq')
roots=next(p for p in graph['packages'] if p['name']=='webpki-roots')
node=next(n for n in graph['resolve']['nodes'] if n['id']==nbreq['id'])
assert 'bundled-roots' in node['features'] and roots['id'] in node['dependencies']
assert roots['source']=='registry+https://github.com/rust-lang/crates.io-index'
for name,features,count in [('default',[],10),('native',['--no-default-features','--features','native,v020'],9),('minimal',['--no-default-features','--features','v020'],2),('test-support',['--features','test-support'],11),('bundled-roots',['--features','bundled-roots'],10)]:
    raw=run('workaround-'+name,cargo+['test','--locked','--offline','--lib',*features,'--','--test-threads=1'])
    assert ('test result: ok. '+str(count)+' passed').encode() in raw
assert original_hash==hashlib.sha256((original/'Cargo.lock').read_bytes()).hexdigest()
def identities(path):
    return {(p['name'],p['version'],p.get('source')) for p in tomllib.loads(path.read_text())['package']}
before=identities(original/'Cargo.lock')
after=identities(consumer/'Cargo.lock')
(lab/'workaround-summary.json').write_text(json.dumps(dict(status='passed',scope='Diagnostic downstream lock workaround only; not fresh dependency acceptance.',tests=42,original_lock_unchanged=True,original_lock_sha256=original_hash,removed=sorted(before-after),added=sorted(after-before)),indent=2))
