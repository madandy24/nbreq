from pathlib import Path
import json, os, subprocess, hashlib
lab=Path(__file__).parent
legacy=lab/'legacy'
env=dict(os.environ,CARGO_TARGET_DIR=str(lab/'legacy-build'))
records=[]
def run(label,args):
    p=subprocess.run(args,cwd=legacy,env=env,capture_output=True,timeout=300)
    (lab/(label+'.stdout.log')).write_bytes(p.stdout)
    (lab/(label+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(label=label,command=args,cwd=str(legacy),exit=p.returncode))
    (lab/'legacy-resumed-results.json').write_text(json.dumps(records,indent=2))
    print(label,p.returncode,flush=True)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    return p.stdout
run('legacy-fetch-missing-cache',['cargo','fetch','--locked'])
graph=json.loads(run('legacy-metadata-after-fetch',['cargo','metadata','--locked','--offline','--format-version','1']))
pkg=next(p for p in graph['packages'] if p['name']=='nbreq')
assert pkg['version']=='0.1.1' and pkg['source']=='registry+https://github.com/rust-lang/crates.io-index'
for tc in ['stable','1.85.0']:
    raw=run('legacy-'+tc,['rustup','run',tc,'cargo','test','--locked','--offline','--lib','--','--test-threads=1'])
    assert b'test result: ok. 3 passed' in raw
(lab/'legacy-summary.json').write_text(json.dumps(dict(status='passed',identity={k:pkg[k] for k in ['version','source','manifest_path']},test_count_per_toolchain=3,manifest_sha256=hashlib.sha256((legacy/'Cargo.toml').read_bytes()).hexdigest(),cache_note='Initial offline metadata failed for uncached zerocopy-derive 0.8.57; locked online fetch followed by unchanged offline checks.'),indent=2))
