from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab=Path(__file__).parent
source=root/'tools/release-consumer'
owned=['Cargo.toml','README.md','run.py','pre_r5.py','registry.py','src/lib.rs','src/v021.rs']
hashes={}
for name in owned:
    dest=lab/'tooling-source'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source/name,dest)
    hashes[name]=hashlib.sha256(dest.read_bytes()).hexdigest()
stable={}
for case in ['fresh','mio-coexist']:
    modes={}
    for mode in ['default','native','minimal','test-support','bundled-roots']:
        raw=(lab/f'pre-r5/stable-{case}-{mode}.log').read_text()
        match=re.search(r'test result: ok\. (\d+) passed; 0 failed;',raw)
        assert match
        modes[mode]=int(match[1])
    stable[case]=modes
summary=dict(status='tooling validated; unmodified fresh MSRV graph blocked upstream',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),tooling_hashes=hashes,
    red=json.loads((lab/'red.json').read_text(encoding='utf-8-sig')),
    actual_script_command=['python','tools/release-consumer/pre_r5.py','--out',str(lab/'pre-r5'),'--toolchains','stable','1.85.0'],
    fresh_stable=stable,fresh_stable_total=84,
    fresh_msrv_failure=dict(package='yoke-derive',version='0.8.3',location='src/lib.rs:202',error='E0599: primitive str::from_utf8 unavailable on Rust 1.85',log='pre-r5/1.85.0-fresh-default.log',lock='pre-r5/1.85.0-fresh/Cargo.lock',lock_sha256=hashlib.sha256((lab/'pre-r5/1.85.0-fresh/Cargo.lock').read_bytes()).hexdigest(),first_failing_mode='default',remaining_modes='not reached'),
    reviewed_lock=json.loads((lab/'reviewed-lock-summary.json').read_text()),
    legacy_fresh=dict(stable_tests=3,msrv='same yoke-derive 0.8.3 compilation failure',actual_registry_version='0.1.1',initial_offline_failure='uncached zerocopy-derive 0.8.57; locked online fetch retained graph'),
    legacy_frozen=json.loads((lab/'legacy-frozen-summary.json').read_text()),
    diagnostic_workaround=json.loads((lab/'workaround-summary.json').read_text()),
    static_checks=['All three Python scripts AST-parse','cargo fmt --manifest-path tools/release-consumer/Cargo.toml --check passed','git diff --check passed'],
    boundaries=['No core manifest/dependency/lock changes','Original fresh MSRV and legacy failure graphs preserved','Default+bundle construction tests do not establish external TLS handshake success','No new package or registry published-mode run; hosted scripts wired and reviewed','Native Windows only; no publication or commits'])
(lab/'summary.json').write_text(json.dumps(summary,indent=2))
manifest={}
for base,dirs,files in os.walk(lab):
    dirs[:]=[d for d in dirs if d not in ['build','legacy-build','reviewed-lock-build','__pycache__']]
    for name in files:
        path=Path(base)/name
        if name=='evidence-hashes.json':continue
        manifest[path.relative_to(lab).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
(lab/'evidence-hashes.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(dict(summary=str(lab/'summary.json'),evidence_files=len(manifest),fresh_stable=stable,workaround=summary['diagnostic_workaround']),indent=2))
