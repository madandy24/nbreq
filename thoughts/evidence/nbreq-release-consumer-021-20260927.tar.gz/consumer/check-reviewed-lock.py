from pathlib import Path
import hashlib,json,os,shutil,subprocess,tomllib
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab=Path(__file__).parent
consumer=lab/'reviewed-lock-consumer'
shutil.copytree(lab/'pre-r5/stable-fresh',consumer)
shutil.copy2(root/'Cargo.lock',consumer/'Cargo.lock')
before=tomllib.loads((root/'Cargo.lock').read_text())
env=dict(os.environ,CARGO_TARGET_DIR=str(lab/'reviewed-lock-build'))
records=[]
def run(label,args):
    p=subprocess.run(args,cwd=consumer,env=env,capture_output=True,timeout=300)
    (lab/(label+'.stdout.log')).write_bytes(p.stdout)
    (lab/(label+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(label=label,command=args,cwd=str(consumer),exit=p.returncode))
    (lab/'reviewed-lock-results.json').write_text(json.dumps(records,indent=2))
    print(label,p.returncode,flush=True)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    return p.stdout
graph=json.loads(run('reviewed-lock-adapt',['cargo','metadata','--offline','--all-features','--format-version','1']))
versions={p['name']:p['version'] for p in graph['packages'] if p['name'] in ['nbreq','webpki-roots','yoke-derive']}
assert versions=={'nbreq':'0.2.1','webpki-roots':'1.0.9','yoke-derive':'0.8.2'}
old={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in before['package'] if 'source' in p}
after=tomllib.loads((consumer/'Cargo.lock').read_text())
for p in after['package']:
    if 'source' in p: assert old[(p['name'],p['version'],p['source'])]==p.get('checksum'),p
for tc in ['stable','1.85.0']:
    for name,features in [('default',[]),('bundled',['--features','bundled-roots'])]:
        out=run('reviewed-lock-'+tc+'-'+name,['rustup','run',tc,'cargo','test','--locked','--offline','--lib',*features,'--','--test-threads=1'])
        assert b'test result: ok. 10 passed' in out
(lab/'reviewed-lock-summary.json').write_text(json.dumps(dict(status='passed',scope='Root reviewed lock adapted to independent consumer; no registry package versions/checksums changed. Not fresh graph proof.',versions=versions,tests=40,root_lock_sha256=hashlib.sha256((root/'Cargo.lock').read_bytes()).hexdigest(),consumer_lock_sha256=hashlib.sha256((consumer/'Cargo.lock').read_bytes()).hexdigest()),indent=2))
