from pathlib import Path
import json,os,shutil,subprocess,tomllib,hashlib
root=Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab=Path(__file__).parent
consumer=lab/'legacy-frozen'
shutil.copytree(lab/'legacy',consumer)
baseline=root/'tools/f5-observe/v011/Cargo.lock'
shutil.copy2(baseline,consumer/'Cargo.lock')
old={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in tomllib.loads(baseline.read_text())['package'] if 'source' in p}
env=dict(os.environ,CARGO_TARGET_DIR=str(lab/'legacy-build'))
records=[]
def run(label,args):
    p=subprocess.run(args,cwd=consumer,env=env,capture_output=True,timeout=300)
    (lab/(label+'.stdout.log')).write_bytes(p.stdout)
    (lab/(label+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(label=label,command=args,cwd=str(consumer),exit=p.returncode))
    (lab/'legacy-frozen-results.json').write_text(json.dumps(records,indent=2))
    print(label,p.returncode,flush=True)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    return p.stdout
graph=json.loads(run('legacy-frozen-adapt',['cargo','metadata','--offline','--format-version','1']))
pkg=next(p for p in graph['packages'] if p['name']=='nbreq')
assert pkg['version']=='0.1.1' and pkg['source']=='registry+https://github.com/rust-lang/crates.io-index'
for p in tomllib.loads((consumer/'Cargo.lock').read_text())['package']:
    if 'source' in p: assert old[(p['name'],p['version'],p['source'])]==p.get('checksum'),p
for tc in ['stable','1.85.0']:
    raw=run('legacy-frozen-'+tc,['rustup','run',tc,'cargo','test','--locked','--offline','--lib','--','--test-threads=1'])
    assert b'test result: ok. 3 passed' in raw
(lab/'legacy-frozen-summary.json').write_text(json.dumps(dict(status='passed',scope='Legacy consumer using existing historical v011 lock versions; no registry package version/checksum changes; not fresh graph proof.',identity={k:pkg[k] for k in ['version','source','manifest_path']},tests=6,baseline_lock_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest()),indent=2))
