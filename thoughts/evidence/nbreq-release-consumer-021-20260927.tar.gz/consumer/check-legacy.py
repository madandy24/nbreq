from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess
root = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp')
lab = Path(__file__).parent
source = root/'tools/release-consumer'
records = []
env = dict(os.environ, CARGO_TARGET_DIR=str(lab/'legacy-build'))
def run(label, command, cwd):
    result = subprocess.run(command,cwd=cwd,env=env,capture_output=True,timeout=300)
    (lab/(label+'.stdout.log')).write_bytes(result.stdout)
    (lab/(label+'.stderr.log')).write_bytes(result.stderr)
    records.append(dict(label=label,command=command,cwd=str(cwd),exit=result.returncode))
    (lab/'legacy-results.json').write_text(json.dumps(records,indent=2))
    print(label,result.returncode,flush=True)
    assert result.returncode==0, result.stderr.decode(errors='replace')
    return result.stdout
for name in ['run.py','pre_r5.py','registry.py']:
    ast.parse((source/name).read_text(),filename=name)
run('consumer-format',['cargo','fmt','--manifest-path',str(source/'Cargo.toml'),'--check'],root)
tree=ast.parse((source/'run.py').read_text())
nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='manifest' for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='replace']
scope={'manifest':(source/'Cargo.toml').read_text()}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'legacy-transform','exec'),{},scope)
legacy=lab/'legacy'
legacy.mkdir()
for name in ['src','probes']:
    shutil.copytree(source/name,legacy/name)
(legacy/'Cargo.toml').write_text(scope['manifest'])
run('legacy-resolve',['cargo','generate-lockfile','--offline'],legacy)
graph=json.loads(run('legacy-metadata',['cargo','metadata','--locked','--offline','--format-version','1'],legacy))
pkg=next(p for p in graph['packages'] if p['name']=='nbreq')
assert pkg['version']=='0.1.1' and pkg['source']=='registry+https://github.com/rust-lang/crates.io-index'
for toolchain in ['stable','1.85.0']:
    output=run('legacy-'+toolchain,['rustup','run',toolchain,'cargo','test','--locked','--offline','--lib','--','--test-threads=1'],legacy)
    assert b'test result: ok. 3 passed' in output
(lab/'legacy-summary.json').write_text(json.dumps(dict(status='passed',identity={k:pkg[k] for k in ['version','source','manifest_path']},test_count_per_toolchain=3,manifest_sha256=hashlib.sha256((legacy/'Cargo.toml').read_bytes()).hexdigest()),indent=2))
