"""Freeze diagnostic source, the exact Win32 executable and public inputs."""
import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--binary', type=Path, required=True)
a = p.parse_args()
root, lab = a.root.resolve(), Path(__file__).resolve().parent
data = a.binary.read_bytes()
assert data[:2] == b'MZ'
offset = struct.unpack_from('<I', data, 0x3c)[0]
assert data[offset:offset + 4] == b'PE\0\0'
assert struct.unpack_from('<H', data, offset + 4)[0] == 0x14c
inputs = {'bin/nbreq-wine-tls-probe.exe': data}
tool = root / 'tools' / 'wine-tls-probe'
for name in ('Cargo.toml', 'Cargo.lock', 'README.md', 'src/main.rs'):
    path = tool / name
    assert path.is_file() and not path.is_symlink()
    inputs['tools/wine-tls-probe/' + name] = path.read_bytes()
for name in ('run_probe.py', 'owned_command.py', 'freeze_probe.py'):
    inputs[name] = (lab / name).read_bytes()
for index in range(3):
    name = 'cavesvr3-chain-' + str(index) + '.der'
    inputs['certs/' + name] = (lab / name).read_bytes()
public = json.loads((lab / 'public-chain-name-verified.json').read_text())
for index, expected in enumerate(public['chain_sha256']):
    assert hashlib.sha256(inputs['certs/cavesvr3-chain-' + str(index) + '.der']).hexdigest() == expected
inputs['public-chain-name-verified.json'] = (lab / 'public-chain-name-verified.json').read_bytes()
manifest = dict(purpose='Wine trust diagnostic; no production library modification',
                base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
                rustc=subprocess.check_output(['rustc', '-vV'], text=True).strip(),
                target='i686-pc-windows-msvc',
                public_chain=dict(hostname=public['hostname'],
                                  verify_at_unix=int(public['mtime_utc_epoch']),
                                  captured_at=datetime.datetime.fromtimestamp(public['mtime_utc_epoch'], datetime.timezone.utc).isoformat()),
                files={name: hashlib.sha256(blob).hexdigest() for name, blob in inputs.items()})
payload = json.dumps(manifest, indent=2).encode()
identity = hashlib.sha256(payload).hexdigest()
folder = lab / ('frozen-' + identity[:12])
folder.mkdir(exist_ok=False)
archive = lab / ('wine-trust-probe-' + identity[:12] + '.tar.gz')
with tarfile.open(archive, 'x:gz', compresslevel=9) as output:
    for name, blob in list(inputs.items()) + [('probe-manifest.json', payload)]:
        destination = folder / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as file:
            file.write(blob)
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(blob), 0o644
        output.addfile(member, io.BytesIO(blob))
record = dict(folder=str(folder), archive=str(archive), manifest_sha256=identity,
              sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), bytes=archive.stat().st_size,
              members=len(inputs) + 1, binary_sha256=hashlib.sha256(data).hexdigest())
with (lab / ('snapshot-' + identity[:12] + '.json')).open('x', encoding='utf-8') as file:
    json.dump(record, file, indent=2)
print(json.dumps(record, indent=2))
