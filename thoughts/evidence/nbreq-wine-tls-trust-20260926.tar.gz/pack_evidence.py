"""Pack only reviewed public diagnostics; exclude executables and raw TLS sessions."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

lab = Path(__file__).resolve().parent
destination = Path('C:/User/projects/nbreq/target/worktrees/nbreq-smtp/thoughts/evidence')
archive = destination / 'nbreq-wine-tls-trust-20260926.tar.gz'
index_path = destination / 'nbreq_wine_tls_trust_artifacts.json'
assert not archive.exists() and not index_path.exists()
inputs = {}
identities = {
    '12534912a838': (
        '12534912a8382fbacc4c378a8cb088e5e639855a9c359326c95134e2d67e3035',
        'd1049537ce24d4fe220c15991a136e41b096744ee2260becfca73d18e81da708',
        'd08c9ea5391a3e91a116fe0864520f86249e7150e7a9036564675e71716df08b',
        '20adc70d7c3067ed88f4b2a76b85602a327b2580b69ae38e76647e079878f732'),
    '4aadb487b9e9': (
        '4aadb487b9e9080f044491442eed0e20f99beeb36516eee8a7c71c8bb1afc680',
        'a28014f6255e02f7b1c62cdb035a6bbf9c191b866952838ce9647e3da323ff61',
        '7917ffe95253aee9b15d02d82d042ff8e465979311babffda7676e89772b2af1',
        'cf06cd539805b897c0694af752bb1075fd0991539f9cc242502d42152d95da6f'),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add(path, name=None):
    assert path.is_file() and not path.is_symlink()
    assert lab in path.resolve().parents
    key = name or path.relative_to(lab).as_posix()
    assert key not in inputs
    data = path.read_bytes()
    assert len(data) < 2_000_000
    for marker in (b'PRIVATE' + b' KEY-----', b'Resumption' + b' PSK:',
                   b'Master-' + b'Key:', b'TLS session' + b' ticket:'):
        assert marker not in data
    inputs[key] = data


public_files = [
    'gds-policy-history.md', 'host-preflight.json',
    'constructor-crypt.log', 'constructor-trace-receipt.json',
    'public-chain.json', 'public-chain-name-verified.json',
    'public-chain-capture-receipt.json',
    'cavesvr3-imaps-public-chain-public-only.txt',
    'cavesvr3-imaps-name-verified-public-only.txt',
    'cavesvr3-chain-0.der', 'cavesvr3-chain-1.der', 'cavesvr3-chain-2.der',
    'upstream-wine-release-comparison.json', 'inspect_wine_releases.py',
    'native-build-provenance.json', 'native-build.log',
    'native-rustc-vV.txt', 'native-cargo-V.txt',
    'native-unsafe-time-final.jsonl', 'native-unsafe-time-final.stderr.log',
    'native-isolation-final-provenance.json', 'native-isolation-final-build.log',
    'prepare_remote.py', 'pack_evidence.py', 'collect_receipts.py',
    'diagnostic-checks.json', 'frozen-fmt-check.log', 'frozen-clippy.log',
    'frozen-msrv-x64-check.log', 'frozen-msrv-targets.log', 'bridge-receipts.json',
]
for name in public_files:
    add(lab / name)

for identity, (manifest_hash, archive_hash, binary_hash, wine_archive_hash) in identities.items():
    add(lab / ('snapshot-' + identity + '.json'))
    snapshot = json.loads((lab / ('snapshot-' + identity + '.json')).read_text())
    assert snapshot['manifest_sha256'] == manifest_hash
    assert snapshot['sha256'] == archive_hash and snapshot['binary_sha256'] == binary_hash
    input_archive = lab / ('wine-trust-probe-' + identity + '.tar.gz')
    assert digest(input_archive) == archive_hash and input_archive.stat().st_size == snapshot['bytes']
    assert digest(lab / ('wine-' + identity + '.tar.gz')) == wine_archive_hash
    frozen = lab / ('frozen-' + identity)
    assert digest(frozen / 'probe-manifest.json') == manifest_hash
    manifest = json.loads((frozen / 'probe-manifest.json').read_text())
    assert manifest['files']['bin/nbreq-wine-tls-probe.exe'] == binary_hash
    add(frozen / 'probe-manifest.json')
    for name, expected in manifest['files'].items():
        path = frozen / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
        if not name.startswith('bin/'):
            add(path)
    for platform in ('native', 'wine'):
        folder = lab / (platform + '-' + identity)
        host = json.loads((folder / 'host.json').read_text())
        result = json.loads((folder / 'result.json').read_text())
        for record in (host, result):
            assert record['manifest_sha256'] == manifest_hash and record['probe_sha256'] == binary_hash
        assert result['status'] == 'executed' and result['failure'] is None
        assert all(result[key] == value for key, value in host.items())
        names = ['host.json', 'result.json', 'command.json',
                 'generated.log', 'generated.result.json',
                 'public-chain.log', 'public-chain.result.json']
        if platform == 'wine':
            names.extend(['wine-version.log', 'wine-version.result.json', 'evidence-manifest.json'])
        if identity == '4aadb487b9e9':
            names.extend(['compact-generated.log', 'compact-generated.result.json'])
        if platform == 'wine':
            collected = json.loads((folder / 'evidence-manifest.json').read_text())
            assert collected['result'] == result
            assert set(collected['files']) == set(names) - {'evidence-manifest.json'}
            assert {p.name for p in folder.iterdir()} == set(names)
            for name, expected in collected['files'].items():
                assert digest(folder / name) == expected
        for name in names:
            if name.endswith('.result.json'):
                assert json.loads((folder / name).read_text())['exit_code'] == 0
        for name in names:
            add(folder / name)

manifest = dict(purpose='Diagnostic isolation only; no production Wine TLS fix',
                base_commit='fcd462e', runtime='Wine5.0 Ubuntu5.0-3ubuntu1, existing private Win32 prefix',
                frozen_manifests=['12534912a8382fbacc4c378a8cb088e5e639855a9c359326c95134e2d67e3035',
                                  '4aadb487b9e9080f044491442eed0e20f99beeb36516eee8a7c71c8bb1afc680'],
                excludes=['executables', 'build trees', 'private keys', 'credentials', 'GDS source',
                          'raw OpenSSL session output', 'full third-party source files'],
                files={name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                       for name, data in sorted(inputs.items())})
inputs['evidence-manifest.json'] = json.dumps(manifest, indent=2).encode()
with tarfile.open(archive, 'x:gz', compresslevel=9) as output:
    for name, data in sorted(inputs.items()):
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(data), 0o644
        output.addfile(item, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as check:
    assert set(check.getnames()) == set(inputs)
    for name, data in inputs.items():
        assert check.extractfile(name).read() == data
record = dict(archive=archive.name, bytes=archive.stat().st_size,
              sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
              files=len(inputs), uncompressed_bytes=sum(map(len, inputs.values())), manifest=manifest)
with index_path.open('x', encoding='utf-8') as output:
    json.dump(record, output, indent=2)
print(json.dumps({k: v for k, v in record.items() if k != 'manifest'}, indent=2))
