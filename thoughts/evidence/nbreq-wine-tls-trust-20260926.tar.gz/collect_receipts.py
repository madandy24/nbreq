"""Retain bounded bridge provenance without repeating encoded archive payloads."""
import hashlib
import json
from pathlib import Path

lab = Path(__file__).resolve().parent
queue = Path('C:/User/SecuritasNew/gds/scripts/sessions/putty_bridge/results')
ids = [
    '20260926-013327-f2905382', '20260926-013404-99a779e4',
    '20260926-013436-c1981113', '20260926-013530-f8561459',
    '20260926-013550-9181a392', '20260926-015051-8d9e4d89',
    '20260926-015121-b57156f0', '20260926-015155-41d77139',
    '20260926-015231-ea759f97', '20260926-015312-f20b0c45',
]
records = []
for identity in ids:
    raw = (queue / (identity + '.json')).read_bytes()
    value = json.loads(raw)
    assert value['id'] == identity and value['ok'] and value['exit_code'] == 0
    record = {key: value[key] for key in (
        'id', 'session', 'action', 'status', 'ok', 'exit_code', 'started_at',
        'finished_at', 'command', 'reason', 'remote_path', 'size_bytes', 'sha256'
    ) if key in value}
    record['raw_receipt_sha256'] = hashlib.sha256(raw).hexdigest()
    if ' emit ' in value.get('command', ''):
        record['output'] = 'Archive transport payload omitted; retrieved archive hash and member manifest retained separately.'
    else:
        record['output'] = value['output']
    records.append(record)
with (lab / 'bridge-receipts.json').open('x', encoding='utf-8') as output:
    json.dump(records, output, indent=2)
print('Retained ' + str(len(records)) + ' completed bridge receipts.')
