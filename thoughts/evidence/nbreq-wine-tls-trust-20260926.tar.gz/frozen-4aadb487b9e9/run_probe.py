"""Execute a frozen diagnostic under a bounded owned-process supervisor.

Success here means the diagnostic executed and retained its output. Certificate
acceptance and rejection are assessed from individual recorded probe events.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_inputs(root, manifest):
    required = {'run_probe.py', 'owned_command.py', 'bin/nbreq-wine-tls-probe.exe',
                'certs/cavesvr3-chain-0.der', 'certs/cavesvr3-chain-1.der',
                'certs/cavesvr3-chain-2.der'}
    if not required.issubset(manifest['files']):
        raise RuntimeError('manifest omits required executable inputs')
    for name, expected in manifest['files'].items():
        path = root / name
        if path.is_symlink() or root not in path.resolve().parents or digest(path) != expected:
            raise RuntimeError('frozen input differs: ' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--wine', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest_path = root / 'probe-manifest.json'
    if manifest_path.is_symlink():
        raise RuntimeError('manifest must be a regular file')
    manifest_bytes = manifest_path.read_bytes()
    manifest_hash = hashlib.sha256(manifest_bytes).hexdigest()
    manifest = json.loads(manifest_bytes)
    verify_inputs(root, manifest)
    helper = root / 'owned_command.py'
    spec = importlib.util.spec_from_file_location('owned_command', str(helper))
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    executable = root / 'bin' / 'nbreq-wine-tls-probe.exe'
    argv = [str(executable)]
    host = dict(platform=platform.platform(), machine=platform.machine(),
                started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                manifest_sha256=manifest_hash,
                probe_sha256=digest(executable), python=platform.python_version())
    failure = None
    installed_shim = None
    try:
        if args.wine:
            prefix = Path('/tmp/nbreq-wine-dns-lab-20260910/prefix')
            with (prefix / 'system.reg').open('rb') as source:
                header = source.read(4096).decode('ascii', 'ignore')
            if not re.search(r'(?m)^#arch=win32\s*$', header):
                raise RuntimeError('expected existing private Win32 prefix')
            shim = Path('/tmp/nbreq-wine-dns-gate-final-20260910/bcryptprimitives.dll')
            expected = '92d437dc538ef6ddfae7fc0b2140ec407a6dacfb0c899ec67a6812e84387de86'
            if digest(shim) != expected:
                raise RuntimeError('existing app-local shim differs')
            target = executable.with_name('bcryptprimitives.dll')
            with target.open('xb') as destination, shim.open('rb') as source:
                shutil.copyfileobj(source, destination)
            if digest(target) != expected:
                raise RuntimeError('copied shim differs')
            installed_shim = (target, expected)
            env.update(WINEPREFIX=str(prefix), WINEARCH='win32', WINEDEBUG='-all')
            argv.insert(0, str(args.wine))
            host.update(wine=str(args.wine), prefix=str(prefix), shim_sha256=expected)
            supervisor.command([str(args.wine), '--version'], root, out, 'wine-version', env, 15)
        supervisor.write(out / 'host.json', host)
        supervisor.command(argv, root, out, 'generated', env, 90)
        supervisor.command(argv + ['--compact-ca-key-usage'], root, out, 'compact-generated', env, 90)
        captured = manifest['public_chain']
        public = argv + ['--leaf', 'certs/cavesvr3-chain-0.der',
                         '--intermediate', 'certs/cavesvr3-chain-1.der',
                         '--intermediate', 'certs/cavesvr3-chain-2.der',
                         '--name', captured['hostname'], '--captured-at', captured['captured_at'],
                         '--at-unix', str(captured['verify_at_unix'])]
        supervisor.command(public, root, out, 'public-chain', env, 90)
    except BaseException as error:
        failure = repr(error)
    finally:
        try:
            verify_inputs(root, manifest)
            if manifest_path.is_symlink() or digest(manifest_path) != manifest_hash:
                raise RuntimeError('manifest changed during execution')
            if installed_shim is not None:
                target, expected = installed_shim
                if target.is_symlink() or digest(target) != expected:
                    raise RuntimeError('app-local shim changed during execution')
        except BaseException as error:
            failure = (failure + '; ' if failure else '') + repr(error)
        supervisor.write(out / 'result.json', dict(
            status='failed' if failure else 'executed', failure=failure,
            meaning='Execution status only; inspect per-case verification events.', **host))
    print(json.dumps(dict(status='failed' if failure else 'executed', failure=failure)))
    return 1 if failure else 0


if __name__ == '__main__':
    def terminate(_signum, _frame):
        raise SystemExit('diagnostic supervisor received SIGTERM')
    signal.signal(signal.SIGTERM, terminate)
    raise SystemExit(main())
