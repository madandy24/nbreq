"""Read-only upstream source comparison; never execute or install Wine code."""
import hashlib
import json
from pathlib import Path
import urllib.request

lab = Path(__file__).resolve().parent


def fetch(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'nbreq-wine-diagnostic'})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read()


records = []
for tag in ('wine-5.0', 'wine-9.0', 'wine-10.0', 'wine-11.0'):
    url = 'https://raw.githubusercontent.com/wine-mirror/wine/' + tag + '/dlls/crypt32/chain.c'
    try:
        data = fetch(url)
        source = data.decode()
        start = source.index('static BOOL WINAPI verify_ssl_policy(')
        end = source.index('\nstatic ', start + 20)
        policy = source[start:end]
        first_line = source[:start].count('\n') + 1
        interesting = []
        for offset, line in enumerate(policy.splitlines()):
            if any(word in line for word in ('baseChecks', 'dwFlags', 'REVOCATION', 'PARTIAL_CHAIN')):
                interesting.append({'line': first_line + offset, 'text': line.strip()})
        header_url = 'https://raw.githubusercontent.com/wine-mirror/wine/' + tag + '/include/wincrypt.h'
        header = fetch(header_url)
        for name, contents in ((tag + '-chain-source.c', data), (tag + '-wincrypt-source.h', header)):
            destination = lab / name
            if destination.exists():
                assert destination.read_bytes() == contents
            else:
                with destination.open('xb') as output:
                    output.write(contents)
        records.append(dict(tag=tag, url=url, sha256=hashlib.sha256(data).hexdigest(),
                            ssl_policy_references=interesting,
                            header_url=header_url, header_sha256=hashlib.sha256(header).hexdigest(),
                            header_declares_exclusive_flags=b'dwExclusiveFlags' in header,
                            authority='Source comparison only; this helper does not execute Wine. Separate Wine5 runtime evidence exists.'))
    except Exception as error:
        records.append(dict(tag=tag, url=url, error=repr(error)))
result = dict(purpose='Assess upgrade plausibility without claiming runtime compatibility', releases=records)
path = lab / 'upstream-wine-release-comparison.json'
with path.open('w', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result, indent=2))
