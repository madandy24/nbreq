import hashlib,json,sys,tarfile
from pathlib import Path,PurePosixPath
a,r=map(Path,sys.argv[1:3])
assert hashlib.sha256(a.read_bytes()).hexdigest()==sys.argv[3]
with tarfile.open(a) as f:
 m=f.getmembers()
 assert len(m)==13 and len({x.name for x in m})==13
 for x in m:
  p=PurePosixPath(x.name)
  assert x.isfile() and x.size<4194304 and not p.is_absolute() and '..' not in p.parts and '\\' not in x.name
 metadata=json.loads(f.extractfile('probe-manifest.json').read())
 assert {x.name for x in m}==set(metadata['files'])|{'probe-manifest.json'}
 r.mkdir(exist_ok=False)
 for x in m:
  d=f.extractfile(x).read()
  if x.name!='probe-manifest.json':assert hashlib.sha256(d).hexdigest()==metadata['files'][x.name]
  p=r/x.name
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as w:w.write(d)
print('Verified frozen probe archive and extracted '+str(r))
